# Run Nexora in GitHub Codespaces

Use Node.js 22.13+ (or 24+). From the repository root (`edit-main`):

```bash
corepack enable
corepack prepare pnpm@10.12.2 --activate
pnpm install --frozen-lockfile
pnpm dev
```

Open the forwarded port **5173** in the Codespaces Ports tab.

Production documentation build:

```bash
pnpm build
```

The API is a separate service (`pnpm api:dev`) and may require Cloudflare
configuration/secrets. It is not required to preview the documentation site.
