***
***
**[◄◄ Back to Wiki Index](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/index)**
***
***

# ► Streaming Sites

## ▷ Stream Aggregators

* **Note** - Sites that check and play streams within their own custom player exclusively. Sources vary site-to-site depending on which sites feel are worth using. Make sure to install an [adblocker](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_adblocking) (full version of uBlock Origin), and keep in mind some sites have no popups/redirect ads, or allow you to turn them off in settings. We note popup/redirect ad statuses of each site, as well as their other respective pros & cons on the [grading page](https://github.com/fmhy/FMHY/wiki/Stream-Site-Grading) / [2](https://fmhy-grading.pages.dev/).

***

* 🌟 **[Movy](https://www.movy.sx/)** - 4K / Dual Audio / External Subs / Ad-Toggle
* 🌟 **[Cinejoy](https://cinejoy.pk/)** - 4K / Dual Audio / External Subs / Ad-Toggle
* 🌟 **[PopcornMovies](https://popcornmovies.st/)** or [BingeBox](https://bingebox.ac/) - 4K / External Subs / Ad-Toggle
* 🌟 **[7Movies](https://7movies.ac/)**, [2](https://7movies.ws/), [3](https://7shows.st/) - 4K / Dual Audio / External Subs / Ad-Toggle / [Mirrors](https://7domains.fans/) / [Discord](https://discord.gg/JxgRaYMVHF) / [Telegram](https://t.me/+0XhCnzzvCt9hMTNl)
* 🌟 **[Atlantic](https://atlantic.bz/)** or [fprime](https://fprime.at/) - 4K / Dual Audio / External Subs / Ad-Toggle / [Discord](https://discord.com/invite/ekUMJ7WVnW)
* 🌟 **[P-Stream Forks](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25B7_p-stream_forks)** - 1080p / Dual Audio / External Subs
* 🌟 **[ShuttleTV](https://shuttletv.su/)**, [2](https://shuttletv.pk/), [3](https://shuttletv.me/) - 4K / Dual Audio / External  Subs / Ad-Toggle / [Discord](https://discord.gg/wsPmVB7ZJZ)
* 🌟 **[FlyStream](https://flystream.net/)** - 4K / Dual Audio / External Subs / Ad-Toggle / [Subreddit](https://www.reddit.com/r/FlyStream/) / [Discord](https://discord.gg/flystream)
* 🌟 **[Vivarium](https://vivarium.su/)** - 4K / Dual Audio / External Subs / Ad-Toggle / [Discord](https://discord.gg/XmePdY3H3B)
* 🌟 **[Rive](https://www.rivestream.app/)**, [2](https://rivestream.ru/), [3](https://rivestream.win/) or [CorsFlix](https://watch.corsflix.net), [2](https://watch.corsflix.dpdns.org) - 1080p / External Subs / Ad-Toggle / [Status](https://rentry.co/rivestream) / [Discord](https://discord.gg/6xJmJja8fV)
* ⭐ **[Flixer](https://flixer.gd)**, [2](https://flixer.su/), [3](https://flixer.cx/) or [Hexa](https://hexa.su/) - 1080p / Ad-Toggle
* ⭐ **[MeowTV](https://meowtv.ru/)** or [FlickyStream](https://flickystream.mov/) - 1080p / Dual Audio / External Subs / Ad-Toggle
* ⭐ **[SweetFox](https://sweetfox.app/)** or [67Movies](https://67movies.st/) - 4K / External Subs / Ad-Toggle
* ⭐ **[CineLite](https://cinelite.xyz/)** - 4K / Dual Audio / Popup + Redirect Free
* ⭐ **[ArrowTV](https://arrowtv.net/)**, [2](https://neonflix.st/) or [Cinezo](https://www.cinezo.st/), [2](https://www.flikhub.net/) - 4K / External Subs / Ad-Toggle
* ⭐ **[Ghostflix](https://ghostflix.st/)**, [2](https://redflix.one/), [3](https://redflix.club/) - 1080p / Dual Audio / External Subs / Ad-Toggle / [Status](https://redflix.fans/) / [Invite](https://discord.gg/wp5SkSWHW5) / [Telegram](https://t.me/multichannelofficial)
* ⭐ **[Spacedom](https://spacedom.live/)** - 1080p / Dual Audio / Popup + Redirect Free / [Discord](https://discord.com/invite/6NU9thcPYs)
* ⭐ **[dulo](https://dulo.mov/)** - 4K / External Subs / Ad-Toggle / [Discord](https://discord.gg/kSsqjhE2Sp)
* ⭐ **[Chillflix](https://chillflix.lol/)**, [Toflix](https://toflix.co/) or [Vuflix](https://vuflix.co/) - 4K / Dual Audio / External Subs / Ad-Toggle / [Discord](https://discord.gg/6r5KTZgqXV)
* ⭐ **[Way2Movies](https://beta.way2movies.live/)**, [2](https://way2movies.live/) - 1080p / Dual Audio / External Subs / Ad-Toggle / [Telegram](https://t.me/Way2MoviesFun) / [Discord](https://discord.gg/mH4zsaAmv7)
* ⭐ **[Movie Night](https://movienig.ht/)** - 1080p / Ad-Toggle / [Discord](https://discord.com/invite/kPJ2yJxYng)
* ⭐ **[Reelix](https://reelix.ac/)** or [Coreflix](https://coreflix.tv/) - 4K / External Subs / Popup + Redirect Free
* ⭐ **[moanatv.](https://lfmx.app/)** - 4K / Dual Audio / External Subs / Ad-Toggle
* [BingeBang](https://bingebang.st/) - 4K / External Subs / Popup + Redirect Free / [Status](https://bingebang.club/) / [Discord](https://discord.com/invite/v3EmsANYNM)
* [Lightflix](https://lightflix.app/) or [Afterdusk](https://afterdusk.app/) - 4K / External Subs / Ad-Toggle
* [MovieBite](https://moviebite.org/) - 1080p / Ad-Toggle / [Telegram](https://t.me/+8Wluy50R049kMmVk) / [Discord](https://discord.gg/ygexZUCXVa)
* [M-Zone](https://m-zone.cc/), [2](https://m-zone.org/) - 1080p / Dual Audio / External Subs / Popup + Redirect Free / [Discord](https://discord.com/invite/PFvCNcZCQC)
* [Koddo](https://koddo.to/) - 4K / Dual Audio / External Subs / Ad-Toggle / [Discord](https://discord.gg/Ss2x86nsvK)
* [Moonflix](https://moonflix.website/) - 1080p / Dual Audio / Popup + Redirect Free / [Telegram](https://t.me/Moonflix_official_Channel) / [Discord](https://discord.com/invite/XgndcbuKNG)
* [Cinema (BZ)](https://cinema.army/) - 1080p / Dual Audio / Ad-Toggle / [Telegram](https://t.me/cinemabz)
* [Zenox](https://zenox.lol/) - 4K / Dual Audio / External Subs / Popup + Redirect Free / [Discord](https://discord.com/invite/mYvhW9FNC9)
* [Nexa](https://nexa.mov/) - 4K / Popup + Redirect Free / [Discord](https://discord.com/invite/Yb6vu9xxUR)
* [ThugTV](https://thugtv.online/) - 1080p / Dual Audio / Ad-Toggle / [Telegram](https://t.me/thugtvonline) / [Discord](https://discord.gg/kZWYkvuGhM)
* [Bingr](https://bingr.one/) - 1080p / Dual Audio / External Subs / Ad-Toggle / [Discord](https://discord.com/invite/Dxq6bFv4FP)
* [watched](https://watched.cx/) - 1080p / Dual Audio / External Subs / Popup + Redirect Free / [Discord](https://discord.gg/t8J7eyY2F)
* [Freekz](https://freekz.to/) or [ZXCSTREAM](https://zxcstream.com/) - 1080p / External Subs / Popup + Redirect Free / [Telegram](https://t.me/+AZZmZ7-_SFsxM2M9) / [Discord](https://discord.gg/6ZXNmPedkG)
* [RIVO](https://rivo.st/) - 1080p / Dual Audio / Popup + Redirect Free / [Discord](https://discord.gg/jKRZrTTWd4)
* [GreyBox](https://greyboxtv.pages.dev/) - 1080p / Dual Audio / Popup + Redirect Free
* [CinemaOS](https://cinemaos.live/), [2](https://cinemaos.tech/) - 1080p / Dual Audio / External Subs / Ad-Toggle / [Discord](https://discord.gg/38yFnFCJnA)
* [Stellar](https://stellar.rip/) - 4K / External Subs / Popup + Redirect Free
* [4Movie](https://4movie.in/) - 1080p / Dual Audio / Ad-Toggle
* [TaroFlix](https://taroflix.net/) or [Cinetaro](https://cinetaro.to/) - 1080p / Dual Audio / Ad-Toggle / [Discord](https://discord.gg/2UPkZwn9v)
* [VaultPlayer](https://vaultplayer.co.uk/) - 1080p / Popup + Redirect Free
* [VidPlay](https://vidplay.to/) - 1080p / External Subs / Popup + Redirect Free
* [HiveX](https://hivex.stream/) - 4K / Dual Audio / External Subs / Ad-Toggle
* [Sleepy](https://sleepy.lat/) - 4K / External Subs / Pop up + Redirect Free / [Discord](https://discord.gg/uqHZy7NPRt)
* [Willow](https://willowmovies.com/) - 1080p / [4K Guide](https://rentry.co/willow-guide)
* [Nxsha](https://web.nxsha.app/) - 1080p / Dual Audio / External Subs / [Telegram](https://telegram.me/+8_u943HkSAY5ODA1)
* [SvStream](https://svstream.cc/), [2](https://nomorflix.cc/), [3](https://diostream.cc/) - 1080p / External Subs / [Status](https://nomorflix.com/)
* [cineruv](https://cineruv.website/) - 1080p / Dual Audio / External Subs / Popup + Redirect Free
* [3eyedraven](https://3eyedraven.watch/) - 1080p / Ad-Toggle
* [Cinemove](https://cinemove.cc/), [Watchly](https://watchly.mom/) or [Cinex](https://cinex.lol/) - 1080p / Dual Audio / External Subs
* [Mapple](https://mapple.fun/) - 4K / External Subs / [Telegram](https://t.me/mapple_tv)
* [MovieNerds](https://movienerds.site/), [2](https://vidflix.live/), [3](https://movieplex.online/) - 1080p / Dual Audio / Popup + Redirect Free
* [Smashystream](https://smashystream.xyz/) - 1080p / External Subs / [Telegram](https://telegram.me/+vekZX4KtMPtiYmRl)
* [NOVA](https://novahd.cc/) - 1080p / Dual Audio / Popup + Redirect Free
* [Zoryva X](https://zoryva.me/) - 1080p / Dual Audio / External Subs
* [NetPlay](https://netplayz.icu/) or [Cinelove](https://cinelove.live/) - 1080p / External Subs / [Discord](https://discord.gg/NCH4rzxJ36)
* [Kofi](https://kofi.mov/) - 720p / [Discord](https://discord.com/invite/JsJqRzrjaG)
* [Screenscape](https://screenscape.me/) - 1080p / Dual Audio / External Subs / [Telegram](https://t.me/ScreenScapee)
* [Youplex](https://youplex.site/) - 1080p / Dual Audio / [Discord](https://discord.com/invite/5eWu9Vz6tQ)
* [frameXTV](https://framextv.xyz/) - 4K / External Subs / [Discord](https://discord.gg/vPCHZ6PgRX)
* [All About Movies](https://allaboutmovies.pages.dev/) - 1080p

***

## ▷ P-Stream Forks

* **Note** - Sites that fork the original P-Stream / movie-web projects. You can add **extra sources** to these by using this **[extension](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/movie-web-sources.md)**. Default sources vary site-to-site depending on which sites feel are worth using. Make sure to install an [adblocker](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_adblocking) (full version of uBlock Origin), and keep in mind some sites allow you to turn off ads in settings.

***

* ⭐ **[Cinecat](https://cinecat.eu/)** - 4K / External Subs / Ad-Toggle / [Discord](https://discord.gg/mtSMCeTM2z) / [GitHub](https://github.com/xp-technologies-dev/p-stream)
* ⭐ **[Aether](https://aether.st/)**, [2](https://aether.cx/), [3](https://aether.ist/) - 4K / Dual Audio / External Subs / Ad-Toggle / [Status](https://rentry.co/aetherdomains) / [Discord](https://discord.gg/MadMF7xb5q)
* ⭐ **[Basement](https://basementx.lol/)** - 1080p / Dual Audio / External Subs / [GitHub](https://github.com/xp-technologies-dev/p-stream)
* [kstream](https://kdesa.stream/), [2](https://kdesa.app/) - 1080p / Dual Audio / External Subs / [Status](https://rentry.co/kdesadomains) / [Discord](https://discord.gg/c2Ykk8HKjS)
* [⁠Cinefork](https://cinefork.net/) - 1080p / Dual Audio / External Subs / Popup + Redirect Free
* [StreamWatch](https://streamwatch.online/), [2](https://pstream.site/), [3](https://streamwatch.pages.dev/) - 1080p / External Subs / [Discord](https://discord.gg/5eWu9Vz6tQ) / [GitHub](https://github.com/steveyout/streamwatch)
* [⁠FMFAU](https://fmfau.com/) - 1080p / External Subs / Dual Audio / Popup + Redirect Free / [Discord](https://discord.com/invite/cjhD23qHtn)

***

## ▷ Dedicated-Server

* **Note** - Sites with a focus on a single player / server. These are generally good in terms of speed, consistency, and having less mislabeled content. Many also remove and/or fix broken links. Make sure to install an [adblocker](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_adblocking) (full version of uBlock Origin), and keep in mind some sites have no popups/redirect ads, or allow you to turn them off in settings. We note popup/redirect ad statuses of each site, as well as their other respective pros & cons on the [grading page](https://github.com/fmhy/FMHY/wiki/Stream-Site-Grading) / [2](https://fmhy-grading.pages.dev/).

***

* ⭐ **[NEPU](https://nepu.io/)**, [2](https://nepu.is/), [3](https://nepu.app/) - 4K / [Status](https://rar.to/) / [Discord](https://discord.gg/nepu)
* ⭐ **[Cno](https://cno.to/)** / [Beta](https://beta.cno.to/) - 4K / External Subs
* ⭐ **[PressPlay](https://pressplayz.top/)** - 1080p / External Subs / [Discord](https://discord.com/invite/r4QrghF4B9)
* ⭐ **[arc018](https://arc018.stream/)** - 1080p / Popup + Redirect Free
* [Q62](https://q62flix.ws/) - 1080p / Dual Audio / Popup + Redirect Free
* [StreamingUnity](https://streamingunity.fun/) - 720p / Dual Audio / Popup + Redirect Free
* [CinemaCity](https://cinemacity.cc/) - 480p / Dual Audio / Popup + Redirect Free / [Telegram](https://t.me/CinemaCity_rip)
* [Flixtrz](https://flixtrz.com/) - 720p / Dual Audio / Ad-Toggle
* [ShowBox](https://www.showbox.media/) - 4K / Dual Audio / External Subs / Popup + Redirect Free / Use [Throwaway Gmail](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools/#wiki_.25B7_temp_mail)
* [Abibli](https://abibli.com/) - 720p / Dual Audio / Popup + Redirect Free
* [RidoMovies](https://ridomovies.is/) - 1080p / External Subs
* [Filmo](https://filmo.to/) - 720p / Dual Audio / Popup + Redirect Free / [Mirrors](https://filmo.domains/)
* [AZMovies](https://azmovies.to/) - 720p / External Subs / Some 3rd Party Hosts
* [M4uHD](https://m4uhd.vip) - 1080p / Popup + Redirect Free / [Clones](https://rentry.co/sflix#streamm4u-clones)
* [FshareTV](https://fsharetv.co/) - 1080p
* [Levidia](https://www.levidia.ch/), [2](https://supernova.to/), [3](https://ww1.goojara.to/) - 720p
* [SubSL](https://subsl.top/) - 1080p / [Telegram](https://t.me/Subsl_top)
* [PrimeWire](https://www.primewire.mov/), [2](https://primewire.zip/), [3](https://primewire.pw/) - 1080p / Mostly 3rd Party Hosts / [Status / Mirrors](https://primewire.nexus/)
* [YesMovie](https://ww1.yesmovies.ag/) - 720p
* [HollyMovieHD](https://hollymoviehd.cc/), [2](https://yeshd.net/), [3](https://novamovie.net/), [4](https://nmovies.cc/) - 1080p
* [Downloads-Anymovies](https://www.downloads-anymovies.co/) - 1080p
* [MovieBox](https://movieboxonline.net), [2](https://officialmoviebox.com/), [3](https://123moviesfree.club/), [4](https://netnaija.film), [5](https://m2box.org/) - 1080p / Popup + Redirect Free / [Mirrors](https://moviebox.co/)
* [LookMovie](https://lookmovie2.to/), [2](https://lookmovie2.la/), [3](https://lookmovie0.to/), [4](https://lookmovie4.to/), [5](https://lookmovie5.to/), [6](https://lookmovie6.to/) - 480p / External Subs / Popup + Redirect Free

***

## ▷ Multi-Server

* **Note** - Sites that allow users to choose between multiple different players from a list. Sources vary site-to-site depending on which sites feel are worth using. Make sure to install an [adblocker](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_adblocking) (full version of uBlock Origin), and keep in mind some sites have no popups/redirect ads, or allow you to turn them off in settings. We note popup/redirect ad statuses of each site, as well as their other respective pros & cons on the [grading page](https://github.com/fmhy/FMHY/wiki/Stream-Site-Grading) / [2](https://fmhy-grading.pages.dev/).

***

* ⭐ **[1Shows](http://1shows.org)**, [1Flex](https://www.1flex.org/) or [1Tube](https://www.1tube.org/) - 8 Sources / Popup + Redirect Free / [4K Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/1shows-note.md)
* ⭐ **[AniCine](https://anicine.sbs/)** - 11 Sources / Popup + Redirect Free / [Discord](https://discord.com/invite/SVQvWm5T4r)
* ⭐ **[ZetMoon](https://zetmoon.live/)** - 38 Sources / Popup + Redirect Free
* ⭐ **[TonkaCine](https://tonkacine.watch/)** - 8 Sources / Popup + Redirect Free
* ⭐ **[Anixtv](https://anixx.fun/)**, [2](https://anixtv.us.cc/), [3](https://anixtv.in/) - 11 Sources / Popup + Redirect Free / [Discord](https://discord.com/invite/AGsGU5KUYy)
* ⭐ **[Primeshows](https://www.primeshows.org/)**, [NetShows](https://netshows.xyz/), [YouShows](https://youshows.org/) - 9 Sources / [Discord](https://discord.com/invite/nmtywkrZjd)
* [CineWave](https://watch.cinewave.qzz.io/) - 22 Sources
* [HydraHD](https://hydrahd.gd/), [2](https://hydrahd.com/) - 12 Sources / [Status](https://hydrahd.info/) / [Telegram](https://t.me/HDHYDRAHD)
* [AuroraScreen](https://www.aurorascreen.mov/), [2](https://www.aurorascreen.org/) - 4 Sources / [Discord](https://discord.com/invite/kPUWwAQCzk)
* [Vidbox](https://vidbox.vc/), [2](https://cinehd.vc/), [3](https://vidbox.wtf/) - 46 Sources / Popup + Redirect Free / [Status](https://vidbox.website/) / [Discord](https://discord.gg/VGQKGPM9Ej)
* [Youflex](https://youflex.top/) - 30 Sources / Popup + Redirect Free
* [CandleStream](https://candlestream.xyz/#home) - 21 Sources / Popup + Redirect Free
* [Fireflix](https://fireflix4.pages.dev/) - 7 Sources
* [Heartive](https://heartiveplaystv.pages.dev/) - 12 Sources / Popup + Redirect Free
* [Flyflix](https://flyflix.cc/) - 23 Sources / Popup + Redirect Free / [Discord](https://discord.gg/sssvheMsVT)
* [Bingeflix](https://bingeflix.tv/) - 11 Sources / [Discord](https://discord.com/invite/ajRY6Bn3rr)
* [WatchSeries](https://watchseries.cool/), [2](https://watchseries.bar/) - 8 Sources / Ad-Toggle / [Mirrors](https://Watchseries.domains/)
* [Consumit](https://consumit.online/) - 7 Sources / Popup + Redirect Free
* [Flixvo](https://flixvo.pro/), [2](https://flixvo.fun/) - 30 Sources / Popup + Redirect Free
* [ONOFLIX](https://onoflix.live/) - 16 Sources / [Discord](https://discord.gg/eEmGSZ98cP)
* [FLIKER](https://fliker.freebuff.app/) - 17 Sources / Popup + Redirect Free
* [StreameX](https://streamex.hn/), [2](https://streamex.ws/) - 15 Sources / Popup + Redirect Free
* [Snowstream](https://snowstream.vercel.app/) - 21 Sources / Popup + Redirect Free / [Telegram](https://t.me/snowstreamchat)
* [CineNest](https://cine-nest-nine.vercel.app/) - 32 Sources / Popup + Redirect Free
* [OnionPlay](https://onionplay.ae/) - 9 Sources / [Discord](https://discord.com/invite/RjJgF755Pa)
* [Pawflix](https://pawflix.foo.ng/) - 41 Sources / Redirect + Popup Free / [Invite](https://discord.gg/pXnv7ha5XP)
* [CinebyTV](https://cinebytv.com) - 16 Sources / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/cinebytv-note.md)
* [Moviepire](https://moviepire.ru/), [2](https://phland.org/) - 38 Sources / [Telegram](https://t.me/hdoboxapk2)
* [MilkBox](https://milkbox.fyi/) - 40 Sources / Popup + Redirect Free / [Discord](https://discord.gg/N2eUKVWu5e)
* [FishyStream](https://fishystream-app.pages.dev/) - 24 Sources / Popup + Redirect Free / [GitHub](https://github.com/FishyServices/FishyStream)
* [DuaFile](https://download.duafile.com/) - 57 Sources
* [Meowly](https://meowly.qzz.io/) - 12 Sources / [GitHub](https://github.com/utkarshgupta188/meowly)
* [TVids](https://www.tvids.to/), [2](https://www.tvids.net/), [3](https://watch-tvseries.net/), [4](https://tvids.me/) - 11 Sources
* [Movies To Watch](https://www.moviestowatch.top/) - 25 Sources / Popup + Redirect Free
* [WatchOrbit](https://watchorbit.me/) - 51 Sources
* [RabbitMeow](https://rabbitmeow.online/) - 13 Sources
* [Warflix](https://warflix.im/) - 29 Sources / [Mirrors](https://warflix.cv/) / [Telegram](https://t.me/addlist/khVpZrgJToIxNTJl) / [Discord](https://discord.gg/qc4jksxk7a)
* [FlixFusion](https://flixfusion.cyou/) - 40 Sources
* [Streaming CSE](https://cse.google.com/cse?cx=006516753008110874046:cfdhwy9o57g##gsc.tab=0), [2](https://cse.google.com/cse?cx=006516753008110874046:o0mf6t-ugea##gsc.tab=0), [3](https://cse.google.com/cse?cx=98916addbaef8b4b6), [4](https://cse.google.com/cse?cx=0199ade0b25835f2e) - Multi-Site Search

***

## ▷ Stream Lounges

* **Note** - The following stream or allow users to stream random movies or shows, and generally include chatrooms.

***

* ⭐ **[MST3K FOREVER-a-thon](https://www.youtube.com/@MST3K/streams)**, [MST3K Twitch](https://www.twitch.tv/mst3k) or [MST3K Pluto](https://pluto.tv/us/watch/live-tv/30604/) - Mystery Science Theater 3000 Live Streams / Chat
* ⭐ **[RiffTrax Twitch](https://www.twitch.tv/rifftrax)** or [RiffTrax Pluto](https://pluto.tv/live-tv/rifftrax) - RiffTrax Live Streams / Chat
* [⁠TTN](https://watchttn.com/) - Random Streams / Chat
* [React.tv](https://react.tv/) - Random Streams
* [Baked.live](https://baked.live/) - Random User Channels / Chat / [Discord](https://discord.com/invite/baked)
* [psp-tv](http://sync.coconono.org) - Random User Channels / Chat
* [cytube](https://cytu.be/) - Random User Channels / Chat
* [⁠Kosmi](https://app.kosmi.io/room/lobby) - Random User Channels / Chat
* [VaughnLive](https://vaughn.live/browse/misc) - Random User Channels / Chat
* [⁠SPELUNKR](https://spelunkr.tv/) - Cable TV Style Internet Archive Stream Browser / [Discord](https://discord.gg/QhtW9DcRR3)
* [YTCH](https://ytch.tv/), [Channel Surfer](https://channelsurfer.tv/) or [FreeTVz](https://freetvz.com/) - Cable TV Style YouTube Stream Browsers / Custom Channels
* [RetroStrange](https://retrostrange.com/) - Public Domain Stream / Chat
* [EXP TV](https://linktr.ee/exp.tv) - Rare / Vintage / Obscure Media Stream
* [⁠VersusMedia](https://watch.versusmedia.com/live-channel) - Independent Film Stream
* [⁠Toonami Aftermath](https://www.toonamiaftermath.com/) - Toonami Livestream / Chat

***

## ▷ Free w/ Ads

* 🌐 **[Free-Official-Youtube-Content](https://github.com/superlincoln953/Free-Official-Youtube-Content)** - YouTube Channel List
* 🌐 **[YT Movies Multireddit](https://www.reddit.com/user/nbatman/m/streaming/)** - YouTube Streaming Subreddits
* 🌐 **[JustWatch](https://www.justwatch.com/us?monetization_types=free)** - Free w/ Ads Directory / Country Changed via URL
* ⭐ **[Tubi](https://tubitv.com)** - Movies / TV / 720p / [Downloader](https://github.com/warren-bank/node-hls-downloader-tubitv) / [Available Countries](https://corporate.tubitv.com/)
* ⭐ **[Plex](https://watch.plex.tv/)** - Movies / TV / 720p
* ⭐ **[Pluto](https://pluto.tv/)** - Movies / TV / 720p
* [Video Dictionary](https://videodictionary.kwebpia.net/?m=Full_Movies), [FreeGreatMovies](https://www.freegreatmovies.com/), [Voleflix](https://vole.wtf/voleflix/), [OpenCulture](https://www.openculture.com/freemoviesonline), [MoviesFoundOnline](https://moviesfoundonline.com/) or [Official YT Movies](https://www.youtube.com/feed/storefront?bp=ogUCKAY%3D) (US Only) - YouTube Movie Collections
* [PopcornFlix](https://popcornflix.com/) - Movies / TV
* [Prime Video Free](https://www.amazon.com/gp/video/storefront/?ie=UTF8&contentId=freetv) - Movies / TV / US Only
* [Roku](https://therokuchannel.roku.com/) - Movies / TV / US Only
* [DarkRoom](https://www.darkroom.film/) - Movies / TV / US Only / Requires Sign-Up
* [Fawesome](https://fawesome.tv/) - Movies / TV
* [Sling](https://watch.sling.com/) - Movies / TV / Live News / US Only
* [Fandango](https://athome.fandango.com/content/browse/free) - Movies / TV / US Only
* [Shout! TV](https://shout-tv.com/) - Movies / TV / US + CA Only / Auto-Next
* [Kanopy](https://kanopy.com/) or [hoopla](https://www.hoopladigital.com/) - Movies / TV / US Only / Requires Library Card
* [Found TV](https://watch.foundtv.com/) - Found Footage Movies / Requires Sign-Up
* [BYUtv](https://www.byutv.org/) - TV / Family-Friendly
* [⁠YOW.tv](https://yow.tv/) - Movies / TV / Indie
* [7+](https://7plus.com.au/) - Movies / TV / US + AU Only
* [Playary](https://www.playary.com/) - Movies / TV
* [Filmzie](https://filmzie.com/) - Movies / TV
* [ARTE](https://www.arte.tv/en) - Movies / TV / Auto-Next
* [BBC iPlayer](https://www.bbc.co.uk/iplayer) - Movies / TV / UK IP Required (windscribe) / VPN Recommended even in UK / [Downloader](https://github.com/get-iplayer/get_iplayer)
* [FlixHouse](https://flixhouse.com/) - Indie Movies
* [Cineverse](https://streaming.cineverse.com/) - Persian Movies / TV w/ English Subs

***

## ▷ Video Streaming

* **Note** - These are good for finding classic, obscure, and short films.

***

* ⭐ **[VK](https://vkvideo.ru/)** / [Enhancement Extension](https://vknext.net/)
* ⭐ **[OK](https://ok.ru/video)**
* ⭐ **[YouTube](https://www.youtube.com/)** / [Advanced Search](https://playlists.at/youtube/search/) / [Players / Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/social-media#wiki_.25BA_youtube_tools) / [Download Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/social-media#wiki_.25B7_youtube_downloaders)
* ⭐ **[Dailymotion](https://www.dailymotion.com/)**
* ⭐ **[BiliBili](https://www.bilibili.com/)**, [TypeType](https://watch.typetype.video/), [2](https://typetype.video/) / [GitHub](https://github.com/TypeType-Video/TypeType) or [BiliBili.tv](https://www.bilibili.tv/) / [Resources / Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/social-media/#wiki_.25BA_bilibili_tools)
* ⭐ **[Nico Nico](https://www.nicovideo.jp/)** / [Desktop](https://github.com/tor4kichi/Hohoema) or [TypeType](https://watch.typetype.video/), [2](https://typetype.video/) / [GitHub](https://github.com/TypeType-Video/TypeType)
* ⭐ **[Video Search CSE](https://cse.google.com/cse?cx=006516753008110874046:6v9mqdaai6q#gsc.tab=0)** - Multi-Site Video Search
* [MotionBox](https://omega.gg/MotionBox/) - Online Video Aggregation App
* [PeerTube](https://joinpeertube.org/) / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/social-media#wiki_.25B7_peertube_tools)
* [rutube](https://rutube.ru)
* [Videa](https://videa.hu/)
* [⁠TokyVideo](https://www.tokyvideo.com/)
* [⁠Vanillo](https://vanillo.tv/) / [Discord](https://discord.com/invite/cVWA4C6KHK)
* [Tape](https://github.com/tapexyz/tape)
* [ultimedia](https://www.ultimedia.com/)
* [odysee](https://odysee.com/) / [GitHub](https://github.com/OdyseeTeam)
* [Rumble](https://rumble.com/) - Requires VPN in Some Countries
* [DeafVideo](https://www.deafvideo.tv/) - ASL Vlogs + Videos / YouTube Style Site for Deaf Content

***

# ► Specialty Streaming

* ↪️ **[Documentary Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25BA_documentaries)**
* ↪️ **[Courses / Lectures](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7_streaming)**
* ⭐ **[Vimeo](https://vimeo.com/watch)**, [Viddsee](https://www.viddsee.com/), [Shortverse](https://www.shortverse.com/explore), [Short of the Week](https://www.shortoftheweek.com/) or [Argo](https://web.watchargo.com/) - Short Films
* ⭐ **[Ubu](https://ubu.com/film/)** - Short Films / Avant-Garde
* ⭐ **[RareFilmm](https://rarefilmm.com/)**, [Rare Movie Collection](https://rentry.co/FMHYB64#rmc) or [0xDB](https://0xdb.org/) - Rare Movies
* ⭐ **[Kodasusaka](https://kodasusaka.com/movies)** - Rare / Classic Japanese Movies / Some NSFW
* [⁠Interactive Player](https://github.com/Eveep23/Interactive-Player) - Interactive Content Player / Emulator / [Archive](https://rentry.co/FMHYB64#tnia) / [Discord](https://discord.gg/bYpcxUxkjm)
* [LIMA](https://www.li-ma.nl/) - Short / Experimental Films
* [LightCone](https://lightcone.org/en) - Short / Experimental Films
* [Le Cinéma Club](https://www.lecinemaclub.com/) - Hand-Picked Indie Films / [Archive](https://www.lecinemaclub.com/archives/index/)
* [Rohesia Hamilton Metcalfe](https://www.panix.com/~hamiltro/links/) - Experimental Films
* [Zero1Cine](https://zero1cine.com/) - AI Generated Films
* [HomeMovies101](https://www.homemovies100.it/en/) - Home Movies
* [Prelinger Archives](https://www.panix.com/~footage/) - Ephemeral Films / [Archive](https://archive.org/details/prelinger)
* [3DS Movies](https://rentry.co/FMHYB64#3dsm) - 3D Movies for 3DS Handhelds
* [GlobalShakespeares](https://globalshakespeares.mit.edu/) - Shakespeare Performance Recordings
* [TVARK](https://tvark.org/) or [Daily Commercials](https://dailycommercials.com/) - Commercial / TV Promo Archives
* [MovieCommentaries](https://www.youtube.com/@moviecommentaries) - Movie / TV Director Commentaries
* [DPAN](https://dpan.tv/), [Deaffest](https://deaffestonlinecinema.eventive.org/) (Sign-Up), [DMDb](https://deafmovie.org/free/) or [Lumo TV](https://lumotv.co.uk/) - Deaf Entertainment / News
* [Audiovault](https://audiovault.net/) - Descriptive Audio for Blind Users

***

## ▷ Anime Streaming

* 🌐 **[EverythingMoe](https://everythingmoe.com/)** - Anime Site Index / [Subreddit](https://www.reddit.com/r/everythingmoe/) / [Discord](https://discord.gg/GuueaDgKdS)
* 🌐 **[Wotaku](https://wotaku.wiki/websites)** - Anime Site Index / [Discord](https://discord.gg/vShRGx8ZBC) / [GitHub](https://github.com/wotakumoe/Wotaku)
* 🌐 **[The Index](https://theindex.moe/library/anime)** - Anime Site Index / [Wiki](https://thewiki.moe/) / [Discord](https://discord.gg/Snackbox)
* 🌐 **[⁠JustIndex](https://justindex.cc/)** - Anime Site Index / [Mirrors](https://projectjust.xyz/) / [Subreddit](https://www.reddit.com/r/ProjectJust) / [Discord](https://discord.gg/P3yqksmGun)
* ↪️ **[Anime Streaming Apps](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25B7_anime_streaming_apps)**
* 🌟 **[animepahe](https://animepahe.pw/)** - Hard Sub / Dub / Some NSFW / [Enhancements](https://update.greasyfork.org/scripts/520048/AnimePahe%20Improvements.user.js) / [Downloader](https://github.com/KevCui/animepahe-dl)
* 🌟 **[Anikoto](https://anikototv.to/)** or [Anisuge](https://animesuge.cz/) - Sub / Dub / Auto-Next / [Backups](https://anikoto.site/), [2](https://animesuge.bid/) / [Subreddit](https://www.reddit.com/r/animekoto/) / [Telegram](https://t.me/animesugetv)
* 🌟 **[Miruro](https://miruro.cx)** or [AniVault](https://anivault.tv/) - Hard Subs / Soft Subs / Dub / Auto-Next / [Status](https://status.miruro.com/) / [Subreddit](https://www.reddit.com/r/miruro/)
* 🌟 **[Re:ANIME](https://reanime.to/)**, [2](https://reanime.cz/), [3](https://reanime.wtf/) - Sub / Dub / Auto-Next / [Index](https://reindex.to/) / [Status](https://restatus.me/) / [Discord](https://discord.gg/SMNYA4Q6vD)
* ⭐ **[⁠Gotaku](https://gotaku.to/)** - Sub / Dub / Auto-Next
* ⭐ **[MKissa](https://mkissa.to/)** or [All Manga](https://allmanga.to/) - Sub / Dub / [Discord](https://discord.com/invite/6nce6cyJyM)
* ⭐ **[Ani.pm](https://ani.pm/)**, [2](https://ani.nz/), [3](https://ume.to/) - Sub / Dub / [Discord](https://discord.com/invite/anipm)
* ⭐ **[AnimeX](https://animex.one/)** - Sub / Dub / Auto-Next / [Discord](https://discord.com/invite/xNZcSQRbTm)
* ⭐ **[⁠NekoWatch](https://nekowatch.xyz/)** - Sub / Dub / Auto-Next / [Discord](https://discord.gg/52UrTJ3ytT)
* ⭐ **[AniLight](https://anilight.live/)** - Sub / Dub / Auto-Next / [Discord](https://discord.com/invite/zwv8PpAJmA)
* ⭐ **[Anidap](https://anidap.lol/)** - Sub / Dub / Auto-Next / [Discord](https://discord.gg/CGZEvjx53u)
* ⭐ **[⁠AniXo](https://anixo.online/)** - Sub / Dub / Auto-Next
* ⭐ **[⁠Anistream](https://anistream.one/)** - Sub / Dub / Auto-Next / [Discord](https://discord.gg/kwgASavPvG)
* [⁠Lunar](https://lunarx.to/) - Sub / Dub / [Telegram](https://t.me/lunarcommunity)
* [⁠JustAnime](https://justanime.to/) - Sub / Dub / Auto-Next / [Mirrors](https://projectjust.xyz/) / [Subreddit](https://www.reddit.com/r/ProjectJust/) / [Discord](https://discord.gg/P3yqksmGun)
* [WeebTube](https://weebtube.cc/) or [JJBA.lol](https://jjba.lol/) - Sub / Dub / Auto-Next / [Status](https://jjba.site/) / [Discord](https://discord.com/invite/vJW2vwzTGD)
* [⁠Kazora](https://kazora.cc/) - Sub / Dub / Auto-Next / [Discord](https://discord.gg/V5AWy78VTv)
* [KickAssAnime](https://kaa.lt/) - Sub / Dub / Auto-Next / [Telegram](https://t.me/kickassanimev3) / [Discord](https://discord.gg/6EGTnNQAaV)
* [Zanix](https://zanix.tr/) - Sub / Dub / Auto-Next
* [Kuroko](https://kuroko.cc/) - Sub / Dub / Auto-Next / [Discord](https://discord.gg/cdBcrvR7es)
* [⁠anv](https://anv.to/) - Sub / Dub / Auto-Next
* [⁠animeY](https://animey.to/) - Sub / Dub / Auto-Next
* [Aniwave](https://aniwaves.ru/), [2](https://hianimes.ru/) or [123anime](https://123animehub.cc/) - Sub / Dub / Auto-Next
* [AniZone](https://anizone.to/) - Sub
* [AniSnatch](https://anisnatch.top/), [2](https://anisnatch.site/) - Sub / Dub / [Telegram](https://t.me/anisnatch) / [Discord](https://discord.com/invite/3zrNYqeT4e)
* [AnimeStream](https://anime.uniquestream.net/) - Sub
* [⁠MeguAnimes](https://meguanime.com/) - Sub / Dub / Auto-Next
* [⁠YumeZone](https://yumezone.live/) - Hard Subs / Soft Subs / Dub / Auto-Next / [Discord](https://discord.gg/VPNSMcG6jM)
* [⁠Anime Nexus](https://anime.nexus/) - Sub / Dub / Auto-Next / [Discord](https://discord.gg/cDZwX3XEkc)
* [⁠AniChan](https://anichan.to/) - Sub / Dub
* [⁠AnimoTVSlash](https://animotvslash.org/) - Sub / Dub / Auto-Next
* [Yenime](https://yenime.net/) - Sub / Dub 
* [animeTVplus](https://animetvplus.xyz/) or [AniHost](https://anihosts.xyz/) - Sub / Dub / [Discord](https://discord.gg/CW9kFv2SPT)
* [⁠2Dhive](https://2dhive.com/) - Sub / Dub
* [Anikura](https://anikura.club/) - Sub / Dub / [X](https://x.com/anikuratv) / [Telegram](https://t.me/anikuraclub)
* [AnimeParadise](https://www.animeparadise.moe/) - Sub / Dub / [Discord](https://discord.com/invite/q3N6eWMMNP)
* [Anify](https://anify.to/) - Sub / Dub
* [Tsukuyomi](https://tsukuyomi.tv/) - Sub / Dub / Auto-Next / [Discord](https://discord.gg/YMuM7RuWnY)
* [⁠Kyren](https://kyren.moe/) - Sub / Dub / Auto-Next
* [⁠WatchAnimeX](https://watchanimez.me/) - Sub / Dub / Auto-Next
* [⁠Shonen](https://shonen.to/) - Sub / Dub / Auto-Next
* [⁠Tatakai](https://tatakai.me/browse) - Sub / Dub
* [⁠Aniclover](https://aniclover.cc/) - Sub / Dub
* [AnimeDex](https://animedex.fun/) - Sub / Dub / Auto-Next
* [Enma](https://www.enma.lol/) - Sub / Dub
* [AnimeLover](https://animelover.site/) - Sub / Dub
* [⁠Anikage](https://anikage.cc/) - Sub / Dub
* [⁠bAnime](https://banime.top/) - Sub / Dub / Auto-Next / [Status](https://status.banime.top/) / [Discord](https://discord.gg/tJqRjg5WzH)
* [AnimeOnsen](https://animeonsen.xyz/) - Sub / 720p / [Discord](https://discord.com/invite/U56ZMrD)
* [Yomi](https://yomi.to/) or [sakusaku](https://sakusaku.to/) - Sub / Dub / Auto-Next
* [⁠AniHQ](https://anihq.cc/) - Sub / Dub
* [KoToTV](https://kototv.to/) - Sub / Dub / Auto-Next / [Mirrors](https://hianime.help/) / [Discord](https://discord.gg/BkrKr2MZaE)
* [⁠Zenbu](https://zen-bu.cc/) - Sub / Dub / Auto-Next
* [Kawaii Anime](https://kawaiianime.cc/) - Sub / Dub
* [⁠9anime](https://9animstv.to/) - Sub / Dub
* [PirateXplay](https://piratexplay.cc/home) - Sub / [Mirrors](https://piratexplay.com/)
* [Kuroiru](https://kuroiru.co/) / [Subreddit](https://www.reddit.com/r/StreamingAnime/) / [Discord](https://discord.com/invite/ys6NASYQSd) or [Anime Streaming CSE](https://cse.google.com/cse?cx=006516753008110874046:vzcl7wcfhei) - Multi-Site Anime Search
* [AnimeXin](https://animexin.dev/) - Donghua / Sub
* [Lucifer Donghua](https://luciferdonghua.in/) - Donghua / Sub / [Telegram](https://telegram.me/luciferdonghuaz)
* [LMANIME](https://lmanime.com/) - Donghua / Sub
* [⁠DonghuaStream](https://donghuastream.org/) - Donghua / Sub
* [CKSub](https://donghua4k.net/) - Donghua / Sub / [Telegram](https://t.me/CKSubORG)
* [AnimeKhor](https://animekhor.org/) - Donghua / Sub / [Telegram](https://t.me/AnimeKhorOfficial)
* [Crimson Subs](https://crimsonfansubs.com/) - Donghua / Sub / [Discord](https://discord.gg/PmYn97vtue)

***

## ▷ Cartoon Streaming

* 🌐 **[Free Official YT Cartoons](https://github.com/superlincoln953/Free-Official-Youtube-Content?tab=readme-ov-file#cartoons)**
* ⭐ **[WCO](https://www.wco.tv/)**, [2](https://www.wcostream.tv/), [3](https://www.wcoforever.net/), [4](https://www.wcoflix.tv), [5](https://www.wcoanimesub.tv/), [6](https://www.wcoanimedub.tv/) - TV / Movies / Anime / [Status](https://www.wcostatus.com/)
* [PirateXplay](https://piratexplay.cc/home) - TV / Movies / Anime / [Mirrors](https://piratexplay.com/)
* [FunnierMoments](https://www.funniermoments.net/) - TV
* [MegaCartoons](https://www.megacartoons.net/) - TV
* [B98](https://www.b98.tv/home/) - Classic / TV
* [ToonTales](https://www.toontales.net/) - Classic / TV
* [SuperCartoons](https://www.supercartoons.net/) - Classic / TV
* [Japanese Animated Film Classics](https://animation.filmarchives.jp/index.html) - Japanese Animation Archive
* [Eddvault](https://eddvault.notion.site/Eddvault-3b7700da57bd4d429b927c1733ccb772) - Eddsworld Content Archive

***

## ▷ TV Streaming

* **Note** - Keep in mind sites listed in the main streaming sections also have TV shows. The sites below offer exclusively TV content.

***

* 🌐 **[Free Official YT TV Shows](https://github.com/superlincoln953/Free-Official-Youtube-Content?tab=readme-ov-file#TV-Shows)**
* ⭐ **[PrimeWire](https://www.primewire.mov/)**, [2](https://primewire.zip/) - TV / Anime / Mostly 3rd Party Hosts / [Status / Mirrors](https://primewire.nexus/)
* ⭐ **[Best Series](https://bstsrs.in/)**, [2](https://topsrs.day/), [3](https://srstop.link/) - TV / 3rd Party Hosts
* ⭐ **[NOXX](https://noxx.gg/)** - TV / 3rd Party Hosts
* [AZ Series](https://azseries.org/) - TV / 3rd Party Hosts
* [Levidia](https://www.levidia.ch/), [2](https://supernova.to/), [3](https://ww1.goojara.to/) - TV / 3rd Party Hosts
* [HISTORY](https://play.history.com/) - Full History / A+E Episodes
* [Adult Swim](https://www.adultswim.com/videos/) - Full Adult Swim Episodes
* [⁠DisneyNOW](https://disneynow.com/) - Full Disney Episodes / US Only
* [Red Bull TV](https://www.redbull.tv/) - Full Red Bull TV Episodes / Movies
* [SFBTV](https://diva.sfsu.edu/collections/sfbatv) - San Francisco TV Archive
* [HDclump](https://hdclump.com/) - Documentaries / Cooking / Gardening
* [BrokenSilenze](https://www.brokensilenze.net/) - Reality TV
* [AwardStreams](https://awardstreams.pages.dev/) - Live Award Show Replays / [X](https://x.com/AwardStreamLive) / [Telegram](https://t.me/+i7T1CzmIYL00Mjhh)
* [r/Panelshow](https://www.reddit.com/r/panelshow/) - Panel Shows
* [Taskmaster](https://rentry.co/bbbr4cfr) - Full Taskmaster Episodes
* [The Silent Library](https://thesilentlibrary.com/) - Japanese Game Shows
* [MyRM](https://myrunningman.com/) - My Running Man Episodes / [Subreddit](https://www.reddit.com/r/runningman/) / [Telegram](https://t.me/myrunningmancom) / [Discord](https://discord.gg/ARvZ4rwZzh)
* [No-Laughing Batsu Game List](https://redd.it/2fgm9p)
* [TWC Classics](https://twcclassics.com/) - Weather Channel Replays
* [TV Streaming CSE](https://cse.google.com/cse?cx=006516753008110874046:hrhinud6efg)

***

## ▷ Drama Streaming

* 🌐 **[EverythingMoe](https://everythingmoe.com/section/drama)** - Index / [Subreddit](https://www.reddit.com/r/everythingmoe/) / [Discord](https://discord.gg/GuueaDgKdS)
* ⭐ **[KatDrama](https://k-drama.in/)** - TV / Movies / [Discord](https://discord.com/invite/hf3F25dRv) / [Telegram](https://t.me/kat_drama_in)
* ⭐ **[GoPlay](https://goplay.su/)** - TV / Movies / [Discord](https://discord.com/invite/yY2P3DQR8S)
* [Einthusan](https://einthusan.tv/intro/) - Movies / VPN May Be Required
* [KissAsian](https://kissasian.com.gr/), [2](https://kisskh.fr/) - TV / Movies
* [KissKH](https://kisskh.ovh/), [2](https://kisskh.id/), [3](https://kisskh.is/), [4](https://kisskh.club/) - TV / Movies
* [⁠DramaNice](https://dramanice.boo/) - TV / Movies
* [Dramahood](https://dramahood.mom/) - TV / Movies
* [⁠KissNeo](https://kissneo.co/) - TV / Movies
* [⁠MyAsianTV](https://myasiantv.com.bz/) - TV / Movies
* [Asiaflix](https://asiaflix.net/), [2](https://asiaflix.in/) - TV / Movies / [Subreddit](https://www.reddit.com/r/Asiaflix/) / [Telegram](https://t.me/asiaflixapp) / [Discord](https://discord.com/invite/JTxEVkZWhc)
* [Rive](https://www.rivestream.app/kdrama), [2](https://rivestream.ru/kdrama) - Korean Drama / TV / Movies / [Discord](https://discord.com/invite/6xJmJja8fV)
* [Vidbox](https://vidbox.vc/asian-drama) - TV / Movies / [Discord](https://discord.gg/VGQKGPM9Ej)
* [KissAsian.video](https://kissasian.video/) - TV / Movies
* [KissKH.dk](https://kisskh.dk/), [2](https://kisskh.or.at/) - TV / Movies
* [AsianCrush](https://www.asiancrush.com/) - TV / Movies
* [OnDemandChina](https://www.ondemandchina.com/) - TV / Movies
* [⁠DramaFren](https://dramafren.org/) - Vertical Dramas / Mini-Series

***

## ▷ Classics / Public Domain

* ⭐ **[Internet Archive](https://archive.org/details/moviesandfilms)** - Classic / Silent Films / [Spreadsheet](https://rentry.co/FMHYB64#archive-films)
* ⭐ **[Danish Silent Film](https://www.stumfilm.dk/en/stumfilm)** - Danish Silent Film Archive
* [National Film Preservation Foundation](https://www.filmpreservation.org/preserved-films/screening-room) - 
* [Historic Films](https://www.historicfilms.com/) or [National Film Preservation Foundation](https://www.filmpreservation.org/) - Historic / Preserved Films
* [Cinetimes](https://cinetimes.org/en/) - Free Classic Films / Streaming Links
* [Public Domain Movies](https://publicdomainmovie.net/) - Public Domain Films
* [RetroFlix](https://retroflix.org/) or [Nukkard](https://nukkard.com/) - Classic Films
* [FilmsByTheYear](https://www.youtube.com/@FilmsbyTheYear/playlists) - Classic Films Playlists / YouTube
* [Wu Tang Collection](https://www.thewutangcollection.com/) - Classic Martial Arts Films
* [Old Timey Computer Show](https://otcs.minuspoint.com/schedule.html) - Live Retro Computer / Game Media Streams
* [The Classic Movies](https://www.the-classic-movies.com/) - Classic Films
* [moonflix](https://moonflix.com/) - Restored / Colorized Classic Films / Shows
* [Silent Hall of Fame](https://silent-hall-of-fame.org/index.php/free-films) - Silent Films / Rare Films

***

## ▷ Film Archives

* ⭐ **[The Library of Congress](https://www.loc.gov/film-and-videos/)** - Movies / Short Films
* ⭐ **[USNationalArchives](https://www.youtube.com/@USNationalArchives)** - Movies / Short Films
* [HuntleyArchives](https://www.huntleyarchives.com/) - Rare / Forgotten Short Films
* [European Film Gateway](https://www.europeanfilmgateway.eu/) - European Film Archive
* [Eastern European Movies](https://easterneuropeanmovies.com/) - Eastern European Film Archive
* [BFIPlayer](https://player.bfi.org.uk/free) / [Full List](https://player.bfi.org.uk/search/free?q=&availability=1) / [Archive](https://www.bfi.org.uk/bfi-national-archive) - British Film Institute / Requires UK VPN (windscribe) / Turn Off Adblock / Use Incog / Clear Cache
* [British Pathé](https://www.britishpathe.com/) or [ColonialFilm](http://www.colonialfilm.org.uk/) - British Video Archives
* [yfanefa](https://www.yfanefa.com/) - Yorkshire Film Archive
* [nfb.ca](https://www.nfb.ca/) - Canadian Film Archive
* [NFSA](https://www.nfsa.gov.au/) - Australian Film Archive
* [NGA Taonga](https://www.ngataonga.org.nz/search-use-collection/search/) or [NZOnScreen](https://www.nzonscreen.com/) - New Zealand's Audiovisual Archives
* [NLS](https://www.nls.uk/), [2](https://movingimage.nls.uk/) - Scottish Film & Video Archive
* [Northern Ireland Screen](https://digitalfilmarchive.net/) or [IFI Archive](https://ifiarchiveplayer.ie/) - Irish Film Archives
* [TexasArchive](https://texasarchive.org/) - Texas Film Archive
* [Chicago Film Archives](https://www.chicagofilmarchives.org/) - Chicago Film Archive
* [IndianCine](https://indiancine.ma/) - Indian Film Archive
* [National Film Archive of Japan](https://meiji.filmarchives.jp/) - Japanese Film Archive
* [Platfo Filmo](https://filmo.platfo.es/pages/home) - Spanish Film Archives
* [CCLM](https://www.cclm.cl/cineteca-online) - Chilean Film Archives
* [Cinematheque](https://www.cinematheque.fr/henri/english/) - Rare French Film Archive
* [Stiftung imai](https://stiftung-imai.de/), [Digitaler Lesesaal](https://digitaler-lesesaal.bundesarchiv.de/en) or [Film Portal](https://www.filmportal.de/en/videos) - German Video Archives
* [RussianFilmHub](https://russianfilmhub.com/) - Russian Films
* [Cinemata](https://cinemata.org/) - Asia-Pacific Social Films
* [Austrian Film Museum](https://www.filmmuseum.at/jart/prj3/filmmuseum/main.jart?rel=en) - Austrian Film Archive
* [35mm](https://35mm.online/en) - Polish Film Archive / [Database](https://filmpolski.pl/fp/index.php)
* [The Travel Film Archive](https://travelfilmarchive.com/) - Archival Travel Footage
* [DVIDS](https://www.dvidshub.net/) / [X](https://x.com/DVIDSHub), [UK Defence Imagery](https://www.defenceimagery.mod.uk/) or [Australian Defence Imagery](https://images.defence.gov.au/assets/) - Military Video Archives
* [Imperial War Museums](https://www.iwm.org.uk/) - British & Commonwealth War Footage / [X](https://x.com/I_W_M)
* [Atom Central](https://www.atomcentral.com/) - Historical Archive of Atomic & Nuclear Tests / [YouTube](https://www.youtube.com/@atomcentral)

***

# ► Live TV / Sports

* **Note** - Make sure to install an [adblocker](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_adblocking) (we recommend the full version of uBlock Origin) before using live sites. Try a [VPN](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_vpn) if sites are blocked, and remember to use [throwaway](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools/#wiki_.25B7_temp_mail) or [alias](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools/#wiki_.25B7_email_aliasing) emails when signing up for sites.

***

## ▷ Live TV

* 🌐 **[TVCL](https://www.tvchannellists.com/)** - TV Channel Index
* ⭐ **[NTV](https://ntv.st/)**, [2](https://ntvs.cx/) - TV / Sports / Aggregator / [Mirrors](https://ntvx.link/) / [Discord](https://discord.gg/uY3ud5gcpW)
* ⭐ **[zlive](https://zlive.st/)** - TV / Sports
* ⭐ **[StreamSports99](https://streamsports99.ru/live-tv)** - TV / Sports / [Mirrors](https://streamsports99.website/) / [Bypass Blocks](https://streamsports99.su/vpns) / [Discord](https://discord.gg/sUwU528aRn)
* ⭐ **[DaddyLive TV](https://dlive.sx/24-7-channels.php)**, [2](https://daddylive.pk/) - TV / Sports / [Telegram](https://t.me/+8uBUT1-0B741NTll)
* ⭐ **[Famelack](https://famelack.com/)** - TV / Sports / Globe Style
* ⭐ **[EasyWebTV](https://zhangboheng.github.io/Easy-Web-TV-M3u8/routes/tv.html)** or [IPTV Web](https://iptv-web.app/) - TV / Sports
* ⭐ **[SportsBite TV](https://sportsbite.org/channels)**, [2](https://sportsbite.org/channels) - TV / Sports / [Telegram](https://t.me/+Zo7CoigxqRczMjRk) / [Discord](https://discord.gg/Qg7uRXWAhU)
* [TitanTV](https://titantv.com/) - Live TV Listings / TV Schedule
* [Cinevid](https://cinevid.sbs/channels) - TV / Sports / [Status](https://cinevid.link/)
* [kool.to](https://kool.ws/), [huhu.to](https://huhu.to/), [vavoo.to](https://vavoo.to/) or [oha.to](https://oha.to/) - TV / Sports / European
* [Live24](https://livelive24.com/), [2](https://livelive24.st/) - TV / Sports
* [1TUbe](https://www.1tube.org/live-tv) - TV / Sports
* [⁠TVNow](https://tvnow.st/) - TV / Sports
* [Xumo Play](https://play.xumo.com/networks) - TV / US Only
* [DamiTV](https://damitv.st/livetv) or [OnDemand](https://ondemand.st/), [2](https://www.90minutes.pro/), [3](https://ondemand.to) - TV / Sports / [Discord](https://discord.gg/SyUrxKykh)
* [Pluto](https://pluto.tv/live-tv), [2](https://app-lgwebos.pluto.tv/live-tv) - TV / Sports / US Only
* [⁠FreeTVGarden](https://freetvgarden.com/) - TV / Sports / Globe Style
* [Watchott Live](https://iptv.watchott.org/) - TV / Sports / PW: `FREE-MEDIA`
* [xyzstreams](https://xyzstreams.st/) - TV / Sports
* [⁠TV Explorer](https://tvexplorer.live/) - TV / Sports
* [TV247US](https://tvnow247.top/) - TV / Sports
* [CXtv](https://www.cxtvlive.com/) - TV / Sports
* [WatchTVs](https://watchtvs.live/) - TV
* [Rive](https://www.rivestream.app/iptv), [2](https://rivestream.ru/iptv) - TV / Sports / [Discord](https://discord.com/invite/6xJmJja8fV)
* [Global Free TV](https://www.globalfreetv.com/) - TV / [Discord](https://discord.com/invite/pPaerCghRN)
* [vipotv](https://vipotv.com/) - TV / Sports
* [SquidTV](https://www.squidtv.net/) - TV
* [TVAtlas](https://tvatlas.app/) - TV
* [AwardStreams](https://awardstreams.pages.dev/) - Live Award Shows / [X](https://x.com/AwardStreamLive) / [Telegram](https://t.me/+i7T1CzmIYL00Mjhh)
* [Puffer](https://puffer.stanford.edu/) - San Fran TV / Requires Sign-Up
* [TV.Jest](https://tv.jest.one/) or [WorldNews24](https://worldnews24.tv/) - News
* [⁠election.run](https://election.run/) - Multi-Stream Election Streams / News
* [SHOWROOM](https://showroom-live.com/) - Live Performance Broadcasts
* [Koryo TV](https://koryo.tv/) or [KCNA](https://kcnawatch.us/korea-central-tv-livestream) - North Korean Live TV

***

## ▷ Live Sports

* **Note** - Make sure to install an [adblocker](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_adblocking) (we recommend the full version of uBlock Origin) before using live sites. Try a [VPN](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_vpn) if sites are blocked, and remember to use [throwaway](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools/#wiki_.25B7_temp_mail) or [alias](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools/#wiki_.25B7_email_aliasing) emails when signing up for sites.

***

* ↪️ **[Sports Calendars / Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25BA_sports)**
* ⭐ **[TimStreams](https://tim-streams.com/)**, [2](https://timstreams.co.rw/) - Live Events / [Discord](https://discord.gg/fTt4jKWM3u)
* ⭐ **[StreamCorner](https://streamcorner.st/)**, [2](https://streamcorner.foo/), [3](https://streamcorner.cloud/), [4](https://streamcorner.fun/) / [Status](https://beacons.ai/streamcorner) / [Discord](http://discord.gg/vV6rRFtWhW)
* ⭐ **[⁠StreamFree](https://strmfree.pk/)**, [2](https://strmfree.st/), [3](https://streamfree.top/) / [Mirrors](https://strmfree.link/) / [Discord](https://discord.gg/XkkAQ2PEDz)
* ⭐ **[PPV.ST](https://ppv.st/)**, [2](https://ppv.tj), [3](https://ppv.rw/), [4](https://ppv.ms/), [5](https://ppv.bi/), [6](https://ppvs.pk/), [7](https://ppv.ug/) - Live Events / [Mirrors](https://mirrors.st/) / [Discord](https://ppv.st/discord)
* ⭐ **[zlive](https://zlive.st/)**
* ⭐ **[SportsBite](https://sportsbite.org/)**, [2](https://sportsbite.org/) / [Telegram](https://t.me/+Zo7CoigxqRczMjRk) / [Discord](https://discord.gg/Qg7uRXWAhU)
* ⭐ **[StreamSports99](https://streamsports99.ru)** / [Mirrors](https://streamsports99.website/) / [Bypass Blocks](https://streamsports99.su/vpns) / [Discord](https://discord.gg/sUwU528aRn)
* ⭐ **[DaddyLive](https://dlive.sx/)**, [2](https://daddylive.pk/) / [Telegram](https://t.me/+8uBUT1-0B741NTll)
* [AURA Sports](https://aurasports.xyz/) / [Discord](https://discord.gg/NPuBAJZy7Y)
* [DamiTV](https://damitv.st/livetv) or [OnDemand](https://ondemand.st/), [2](https://www.90minutes.pro/), [3](https://ondemand.to) / [Discord](https://discord.gg/SyUrxKykh)
* [WatchSports(su)](https://watchsports.su/)
* [Strumyk](https://strumyk.pk/) or [Strims24](https://strims24.st/) / [Status](https://strumyk.domains/)
* [Cinevid](https://cinevid.sbs/events) / [Status](https://cinevid.link/)
* [RoxieStreams](https://roxiestreams.su/), [2](https://roxiestreams.info/), [3](https://roxiestreams.biz/) / [Status](https://roxiestreams.cc/)
* [BINTV](https://www.bintv.cc/) / [Status](https://www.bintv.link/) / [Discord](https://discord.com/invite/fp3EQjFAJQ)
* [⁠Futbol-X](https://www.futbol-x.xyz/), [2](https://www.futbol-x.top/) - Live Events / [Mirrors](https://futxtv.indevs.in/) / [Discord](https://discord.gg/UzHzerb6XY)
* [NTV](https://ntv.cx/), [2](https://ntvs.cx/) / [Discord](https://discord.gg/uY3ud5gcpW)
* [LiveTV](https://livetv.sx/enx/)
* [StreamEast](https://streameast.ga/), [2](https://streameast.ph/), [3](https://www.streameast.cf/), [4](https://www.streameast.ch/), [5](https://v2.streameast.ga/), [6](https://www.streameast.fi/) / [Status](https://status.streamea.st/) / [Mirrors](https://v5.gostreameast.link/) / [Telegram](https://t.me/streameastmirror)
* [DaddyLiveHD](https://daddylive.mov/), [2](https://daddylive.app/), [3](https://daddylive.li/) / [Mirrors](https://rentry.co/daddylivehd) / [Telegram](https://t.me/addlist/khVpZrgJToIxNTJl) / [Discord](https://discord.gg/qc4jksxk7a)
* [Reedstreams](https://reedstreams.to/), [2](https://reedstreams.st/) - Stream Aggregator / [Mirrors](https://reedstreams.link/)
* [xyzstreams](https://xyzstreams.st/)
* [Sportsurge](https://v2.sportsurge.net/)
* [⁠Matchora](https://matchora.to/)
* [TotalSportek](https://totalsport-ek.st/) or [Sportsurge.st](https://sportsurges.st/) / [Discord](https://discord.com/invite/mdEsarNMyF)
* [Tap4Sport](https://tap4sport.st/), [2](https://tap4sport.ci/), [3](https://tap4sport.pw/) / [Status](http://tap4sport.link/)
* [⁠CMVTV](https://cmvxd.lovable.app/) / [Status](https://cmvwd.lovable.app/) / [Telegram](https://t.me/cricketmemesverse)
* [⁠Fantastic Soda](https://fantasticsoda.com/)
* [FSL](https://freestreams-live1h.pk/) / [Discord](https://discord.gg/eXXJzDPchU)
* [⁠Streami](https://streamic.st/) / [Status](https://rentry.co/Streami)
* [SportOnTV](https://sportontv.click/) / [Discord](https://discord.gg/YhQPSSMps2) / [Mirrors](https://sotproxy.ext.io)
* [⁠FalconStreams](https://falconstreams.app/) / [Discord](https://discord.gg/FPgKwtXcYV)
* [CricHD](https://crichd.at/)
* [TheTVApp](https://thetvapp.plus/)
* [Rerace](https://www.rerace.net/sports/)
* [Reedsports](https://reedstreams.to/)
* [MainPortal66](https://mainportal66.com/)
* [⁠FCTV33](https://www.fctv33go.hair/), [2](https://emmau680.driveraudiencej2zeu49.sbs/) / [Telegram](https://t.me/madplay77_b)
* [VIP Box Sports](https://vipleague.me/home), [2](https://olympicweb.me/home), [3](https://fbstream.is/) / [Mirrors](https://rentry.co/vipbox-mirrors)
* [FawaNews](http://www.fawanews.sc/)
* [Baked.live](https://baked.live/) - MMA / Wrestling / [Discord](https://discord.com/invite/baked)
* [Guide TV](https://guidetv.live/) - Football
* [NBAMonster](https://nbamonster.com/) - Basketball
* [OnHockey](https://onhockey.tv/) - Hockey
* [Pitsport](https://pitsport.st/) - Motorsports
* [RacingLap](https://racinglap.net/) - Motorsports
* [OvertakeFans](https://overtakefans.com/) - Motorsports
* [F1 Live](https://flive.dpdns.org/) - Motorsports
* [NontonGP](https://esp32.nontonx.com/) - Motorcycle Racing
* [r/rugbystreams](https://www.reddit.com/r/rugbystreams/) - Rugby
* [Live Snooker Guide](https://redd.it/1ibz2yz) - Snooker
* [Tiz-Cycling](https://tiz-cycling.tv/) - Cycling

***

## ▷ Sports Replays

* 🌐 **[Official YT Sports Replay Channels](https://github.com/superlincoln953/Free-Official-Youtube-Content?tab=readme-ov-file#Sport)**
* ⭐ **[Basketball Video](https://basketball-video.com/)** - Basketball Replays
* ⭐ **[Footballia](https://footballia.net/)**, [2](https://footballia.eu/) - Classic Football Replays
* ⭐ **[Watch-Wrestling.eu](https://watch-wrestling.eu/)** - MMA / Wrestling Replays
* ⭐ **[1Max](https://1max.top/)** or [RealFights](https://realfight.top/) - MMA / Wrestling / Boxing Replays
* ⭐ **[Nascar Classics](https://classics.nascar.com/)** - Nascar Replays
* ⭐ **[FullRaces](https://fullraces.com/)** - Motorsport Replays
* ⭐ **[720pier](https://720pier.ru/)** - Sports Replays / Torrents
* [⁠Sport Video Archive](https://sport-video-archive.pages.dev/), [2](https://sv-archive.surge.sh/) - Sports Replays / Download / Torrent
* [⁠ReplayZone](https://replay-exc.pages.dev/) - Sports Replays
* [SportsReplay](https://watchreplay.net/) - Sports Replays
* [⁠LiveXTV](https://livextv.hybrows.workers.dev/replays) - Sports Replays
* [Classic Sports Fanatic](https://www.youtube.com/@classicsportsfanatic7183/playlists) - Full Classic Sports Replays
* [NFL Video](https://nfl-video.com/), [2](https://nfl-replays.com/) - American Football Replays
* [BasketballReplays](https://basketballreplays.net/) - Basketball Replays
* [MLBLive](https://mlblive.net/) - Baseball Replays
* [Steves Classic Baseball](https://www.youtube.com/playlist?list=PLbbmEcFXHSnOHeJdpQr0K808cPVzP0t_B) - Baseball Replays
* [FootballOrigin](https://www.footballorgin.com/) - Football Replays
* [FullMatchShows](https://fullmatchshows.com) - Football Replays
* [r/footballhighlights](https://www.reddit.com/r/footballhighlights/) - Football Replays
* [FOOTReplays](https://www.footreplays.com/) - Football Replays
* [Time Soccer TV](https://timesoccertv.com/) - Football Replays
* [SoccerFull](https://soccerfull.net/) - Football Replays
* [⁠HooFoot](https://hoofoot.net/) or [⁠MySoccerPulse](https://mysoccerpulse.com/) - Football Highlights / [Discord](https://discord.gg/p9g96CfDR6)
* [RuTracker Sports](https://rutracker.org/forum/index.php?c=28) - Sports Replays / Torrents / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent#wiki_.25BA_torrent_sites)
* [Sport Video](https://www.sport-video.org.ua/) - Sports Replays / Torrents
* [WatchProWrestling](https://watchprowrestling.store/) - MMA / Wrestling / Boxing Replays
* [WatchWrestling.ae](https://watchwrestling.ae/) - MMA / Wrestling Replays
* [AllWrestling24](https://allwrestling24.com/) - MMA / Wrestling Replays
* [PWrestling](https://pwrestling.com/) - MMA / Wrestling Replays
* [123Wrestling](https://123wrestling.com/) - Wrestling Replays
* [⁠XWD](https://xtreme-wrestling-downloads.com/) - Wrestling / Boxing Replays / Signup Required / Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators)
* [Archive Wrestling](https://archive.org/details/wrestlingtelevision?sort=date) - Classic Wrestling Replay Archive
* [Miselet](https://vkvideo.ru/@miselet) - Sumo Wrestling Replays
* [AllTheBestFights](https://www.allthebestfights.com/) - MMA / Boxing / Kickboxing Replays
* [TNA / Impact Replays](https://www.youtube.com/playlist?list=PLSadBNbijyoGV44wd96Fda7-GDYh9UktC) - TNA / Impact Wrestling Replays
* [OvertakeFans](https://overtakefans.com/) - Motorsports Replays
* [r/MotorsportsReplays](https://reddit.com/r/MotorsportsReplays) - Motorsports Replays
* [RacingLap](https://racinglap.net/) - Motorsports Replays
* [MotoMundo](https://motomundo.net/) - Motorsports Replays
* [Rerace](https://www.rerace.net/) - Motorsports Replays
* [F1 Live](https://f1live.dpdns.org/) - Motorsports Replays
* [NontonGP](https://replay.nontonx.com/) - Motorcycle Racing Replays
* [Rugby24](https://rugby24.net/) - Rugby Replays
* [⁠Sportarr](https://sportarr.net/) - Sports PVR for Torrents + Usenet / [Discord](https://discord.gg/YjHVWGWjjG) / [GitHub](https://github.com/Sportarr/Sportarr)

***

## ▷ IPTV Tools

* 🌐 **[Awesome IPTV](https://github.com/iptv-org/awesome-iptv)** - IPTV Resources
* 🌐 **[IPTV Playlists](https://rentry.co/FMHYB64#iptv-playlists)** - List of Playlists
* [⁠IPTV Surf](https://iptv.surf/) - IPTV Service Guide / Toolkit
* [⁠StreamCheck](https://search.streamcheck.pro/) - IPTV Provider Channel Checker
* [M3Unator](https://github.com/hasanbeder/M3Unator) - Generate M3U Playlists from Open Directories
* [PlaylistEditorTV](https://codeberg.org/Isayso/PlaylistEditorTV) - IPTV Playlist Editor
* [⁠NextPVR](https://www.nextpvr.com/) - M3U-Based DVR
* [TMDB-To-VOD](https://github.com/gogetta69/TMDB-To-VOD-Playlist) - Generate Playlists
* [IPTV Community](https://iptv.community/) - IPTV Forum
* [CaberNetwork](https://cabernetwork.github.io/) - IPTV Manager
* [SipTV Converter](https://siptv.eu/converter/) - M3U to TXT
* [M3U4U](https://m3u4u.com/) - M3U Editor
* [M3u8DL-RE](https://github.com/nilaoda/N_m3u8DL-RE/blob/main/README.en.md) / [GUI](https://github.com/naravid19/N_m3u8DL_RE_GUI) or [M3u8DL-CLI](https://nilaoda.github.io/N_m3u8DL-CLI/) - ⁠M3U8 Download Tools
* [IPTV Check](https://github.com/peterpt/IPTV-CHECK) - List Checker

***

## ▷ IPTV Players

* ↪️ **[Android IPTV Players](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android/#wiki_.25B7_android_live_tv)**
* ⭐ **[ynoTV](https://github.com/tbeezy/ynotv/)** - IPTV Player / Windows / [Docs](https://tbeezy.github.io/ynotvdoc/)
* ⭐ **[IPTVNator](https://4gray.github.io/iptvnator/)** - IPTV Player / Windows, macOS, Linux / [Telegram](https://t.me/iptvnator) / [GitHub](https://github.com/4gray/iptvnator)
* ⭐ **[Open TV](https://github.com/fredolx/open-tv)** - IPTV Player / Windows, macOS, Linux
* [LivePush](https://livepush.io/hls-player/index.html) - IPTV Web Player
* [IPTV Player](https://iptvplayer.stream/) - IPTV Web Player
* [⁠#IPTV](https://www.hashtagiptv.com/) - IPTV Web Player
* [M3U IPTV](https://m3u-ip.tv/browser) - IPTV Web Player
* [IPTV Player](https://iptv-player.me/) - IPTV Web Player

***

# ► Download Sites

* **Note** - Use **[redirect bypassers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools/#wiki_.25B7_redirect_bypass)** to skip link shorteners.

***

* ↪️ **[General DDL Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/download)**
* ↪️ **[Video Download Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video-tools#wiki_.25BA_video_download)**
* ⭐ **[111477](https://rentry.co/FMHYB64#directory-111477)** - Movies / TV / Anime / Directory / 4K / HEVC / [Features / Posters](https://greasyfork.org/scripts/603382) / [Discord](https://discord.gg/YjkP4pANpg)
* ⭐ **[downloadeverythingfromeverywhere](https://rentry.co/FMHYB64#defe)** - Multi-Site Aggregator / Movies / TV / Anime / 4K / HEVC
* ⭐ **[VegaMovies](https://1vegamovies.baby/)** - Movies / TV / Anime / 4K / HEVC / [Telegram](https://telegram.dog/vega_officials)
* ⭐ **[MKV BASE](https://mkvbase.site/)** - Movies / TV / Anime / 4K / HEVC / Remuxes / 3D / [Telegram](https://t.me/MkVBase)
* ⭐ **[DDLBase](https://ddlbase.com/)**, [2](https://ddlbase.com/) - Movies / TV / 4K / HEVC / 3D / Remuxes
* ⭐ **[Acer Movies](https://rentry.co/FMHYB64#acer)** - Movies / TV / Anime / 4K / HEVC / [Discord](https://discord.com/invite/hpkMqrwRCE)
* ⭐ **[⁠XDMovies](https://xdmovies.com/)**, [2](https://huh.xdmovies.wtf/) - Movies / TV / 4K / HEVC / [Discord](https://discord.com/invite/Py5KKx28Bx)
* ⭐ **[MovieParadise](https://movieparadise.org/)** - Movies / TV / 4K / HEVC / [Sign-Up (Better Host)](https://paste.to/?d2685dc847a535c4#7YmBZfs57EoYcBpnFwkxjz4QBzt3qXBEPkWbmY9aSkkj) / [2](https://notebin.de/?cfaf4edcc631a0e1#H133vUqrhQ6pxj2wPT8ZeH1zVuri6Qvo7gJYz6heMSZL) (PW: FMHY)
* ⭐ **[Scloud](https://rentry.co/FMHYB64#sc)** - Movies / TV / 4K / HEVC / Use Adblocker + [Redirect Bypass](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools#wiki_.25B7_redirect_bypass) / [Telegram](https://t.me/scloudmediahub)
* [Cinetaro](https://cinetaro.to/) - Movies / TV / Anime / 4K / HEVC / [Discord](https://discord.gg/2UPkZwn9v)
* [LightDLMovies](https://rentry.co/FMHYB64#lightdl) - Movies / TV / 1080p / HEVC / Use [Adblock](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_adblocking)
* [Vadapav](https://rentry.co/FMHYB64#vadapav) - Movies / TV
* [⁠4KHDHub](https://4khdhub.one/) - Movies / TV / 4K / HEVC
* [ShowBox](https://www.showbox.media/) - Movies / TV / Anime / 4K / HEVC / Use [Throwaway Gmail](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools/#wiki_.25B7_temp_mail)
* [PlayTorrio](https://playtorrio.xyz/), [2](https://playtorrio.pages.dev/) - Multi-Site Downloader / Movies / TV / Anime / 4K / HEVC / [Subreddit](https://www.reddit.com/r/PlayTorrio/) / [Discord](https://discord.gg/bbkVHRHnRk)
* [⁠Medeberiya](https://medeberiya.net/) - Movie / TV / 4K / HEVC
* [⁠KMMOVIES](https://kmmovies.shop/category/english/) - Movies / TV / 4K / HEVC
* [Ripper's Archive](https://rentry.co/FMHYB64#rippers-archive) - Movies / TV / Anime / 4K / HEVC
* [KatMovieHD](https://new.katmoviehd.top/) - Movies / TV / Anime / 4K / HEVC
* [⁠HindMoviez](https://hindmoviez.cafe/) - Movies / TV / Anime / 4K / HEVC
* [AV1Core](https://av1core.pages.dev/), [2](https://av1core.cyou/) - Movies / TV / Anime / 4K / HEVC / AV1 / Use [Redirect Bypass](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools#wiki_.25B7_redirect_bypass) / [Telegram](https://t.me/av1core)
* [HdMoviesHub](https://hdmovieshub.fyi/) - Movies / TV / 4K / HEVC
* [MultiShows](https://multishows.top/) - Movies / TV / Anime / 4K / HEVC / Use Red Download Button (Below Videos) / [Telegram](https://t.me/multishowsfun)
* [OlaMovies](https://olamovies.dad/) - Movies / TV / 4K / HEVC / Requires Google Account / Use [Adblock](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_adblocking) / [Requests](https://space.olamovies.dad/)
* [PSArips](https://psarips.com/) - Movies / TV / 4K / HEVC
* [HDHub4u](https://hdhub4u.fr/) - Movies / TV / 1080p / 4K / HEVC
* [StagaTV](https://www.stagatv.com/) - Movies / TV / 540p / HEVC
* [Willow](https://willowmovies.com/) - Movies / TV / Anime / 1080p
* [Movies Ni Pipay](https://moviesnipipay.me/) - Movies / TV / 1080p
* [1Shows](http://1shows.org) - Movies / TV / Anime / 4K / HEVC
* [RLSXTVT](https://rlsxtvt.icu/) - Movies / TV / 4K / HEVC
* [Levidia](https://www.levidia.ch/), [2](https://supernova.to/), [3](https://ww1.goojara.to/) - Movies / TV / Anime / 1080p / HEVC / Right Click to Save
* [downloads-anymovies](https://www.downloads-anymovies.co/) - Movies / 1080p / Right Click to Save
* [HollyMovieHD](https://hollymoviehd.cc/), [2](https://yeshd.net/), [3](https://novamovie.net/) - Movies / TV / Anime / 1080p
* [UHDMovies](https://modlist.in/?type=uhdmovies) - Movies / 4K / HEVC
* [TFPDL](https://tfpdl.se/category/movies/), [2](https://tfpdl.to/category/movies/) - Movies / TV / Anime / 4K / HEVC
* [Free Movies](https://free-movies.to/) - Movies / TV / 4K / HEVC
* [SeriesVault](https://seriesvault.win/), [2](https://seriesvault.org/) - TV / Anime / 1080p / HEVC
* [FilmFans](https://filmfans.org/) - Movies / 4K / HEVC
* [WorldFree4u](https://worldfree4u.expert/) - Movies / 4K / HEVC
* [SSR Movies](https://ssrmovies.blue/) - Movies / TV / 4K / HEVC / [Telegram](https://telegram.dog/+MF2EXeitLjMxY2Ux)
* [Best-MovieZ](https://www.best-moviez.ws/) - Movies / TV / 4K / HEVC
* [ShareBB](https://sharebb.me/) - Movies / TV / 4K / HEVC / Requires Sign-Up
* [SolidarityCinema](https://www.solidaritycinema.com/) - Movies / 1080p / HEVC / [Discord](https://discord.com/invite/zpGBVZgDad)
* [FilmGo](https://www.filmgo.live/) - Movies / TV / 1080p / HEVC
* [TodayTVSeries](https://www.todaytvseries1.com/) - TV / 1080p / HEVC
* [SubSL](https://subsl.top/) - Movies / TV / [Telegram](https://t.me/Subsl_top)
* [TV Shows](https://tvshows.ac/) - TV / 720p
* [Pahe](https://pahe.ink/) - Movies / TV / Anime / 4K / HEVC / [Warning](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/pahe-note.md) / [Discord](https://discord.gg/4AvaCsd2J4)
* [TvShows4Mobile](https://tvshows4mobile.org/) - TV / Anime / 360p / [Telegram](https://t.me/o2tvseries_new)
* [Naijavault](https://www.naijavault.com/) - Movies / TV / 720p
* [Waploaded](https://films.waploaded.com/movie) - Movies / TV / 1080p / HEVC
* [HDEncode](https://hdencode.org/) / [Improvement Script](https://github.com/mikeymuis/hdencode-filter-suite), [⁠Cinema of the World](https://worldscinema.org/) or [RapidMoviez](https://rmz.cr/) / [Mirrors](https://rmzmirrors.com/) - Movie & TV DDL Forums / 4K / HEVC / Requires [Debrid](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/download#wiki_.25BA_debrid_.2F_leeches)
* [TVSBoy](https://tvsboy.com/) - TV / 720p / Requires [Debrid](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/download#wiki_.25BA_debrid_.2F_leeches)
* [mov-cli](https://mov-cli.github.io/) - Downloading CLI / [Plugins](https://github.com/topics/mov-cli-plugin) / [Discord](https://discord.gg/BMzC7ePsBV) / [GitHub](https://github.com/mov-cli/mov-cli)
* [Video Download CSE](https://cse.google.com/cse?cx=006516753008110874046:wevn3lkn9rr) / [CSE 2](https://cse.google.com/cse?cx=89f2dfcea452fc451) / [CSE 3](https://cse.google.com/cse?cx=aab218d0aa53e3578)

***

## ▷ Telegram Channels

* [⁠FilmVault](https://filmvault.xyz/) - Movies / TV / Telegram Recommended
* [SearchMoviesBot](https://t.me/SearchMoviesBot) or [TVSeriesSearchBot](https://t.me/TVSeriesSearchBot) - Movies / TV
* [Cinefy](https://cinefy.cc/) - Movies / TV
* [PhonoFilm](https://phonofilm.cc/) - Movies / TV

***

## ▷ Specialty Downloading

* ⭐ **[r/DownUnderTV](https://www.reddit.com/r/DownUnderTV/)** - AU / NZ TV
* ⭐ **[Drama Day](https://dramaday.me/)** - Asian Drama
* ⭐ **[MKVDrama](https://mkvdrama.net/)** - Asian Drama
* [Rare Movie Collection](https://rentry.co/FMHYB64#rmc) - Rare Films
* [Sinflix](https://rentry.co/FMHYB64#sinflix) - Asian Drama
* [DramaSuki](https://rentry.co/FMHYB64#dramasuki) - Asian Drama
* [KimoiTV](https://kimoitv.com/) - Asian Drama
* [CondensedAudioCatalog](https://condensedaudiocatalog.com/) - Asian Drama
* [nKiri](https://thenkiri.com/) - Asian Drama / 720p
* [RareDoramas](https://www.raredoramas.com/) - Rare JDrama / 480p
* [Fanedit.org](https://fanedit.org/) or [FEC Database](https://docs.google.com/spreadsheets/d/18X0QzR904z94NZd7RXOaCuIa117fF0jnEmd7smmj7D0/) - Fanedits / DM Editors for Downloads

***

## ▷ Anime Downloading

* **Note** - Use **[redirect bypassers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools/#wiki_.25B7_redirect_bypass)** to skip link shorteners.

***

* 🌐 **[Wotaku](https://wotaku.wiki/websites#download)** - Anime Download Index / [Discord](https://discord.gg/vShRGx8ZBC) / [GitHub](https://github.com/wotakumoe/Wotaku)
* 🌐 **[EverythingMoe](https://everythingmoe.com/section/download)** - Anime DDL Index / [Subreddit](https://www.reddit.com/r/everythingmoe/) / [Discord](https://discord.gg/GuueaDgKdS)
* 🌐 **[The Index DDL](https://theindex.moe/collection/ddl)** - Anime DDL Sites / [Wiki](https://thewiki.moe/) / [Discord](https://discord.gg/snackbox)
* ⭐ **[Tokyo Insider](https://www.tokyoinsider.com/)** - Sub / Dub
* ⭐ **[Kayoanime](https://kayoanime.com/)** - Sub / Dub / Requires Google Account / [Telegram](https://t.me/AnimeKayo)
* ⭐ **[hi10anime](https://hi10anime.com/)** - Sub / Requires Sign-Up / [Discord](https://discord.gg/uZ85cbAg4T)
* ⭐ **[Anime Download CSE](https://cse.google.com/cse?cx=006516753008110874046:osnah6w0yw8)**
* [Anime-Sharing](https://www.anime-sharing.com/) - Sub / Dub / Anime / Manga Download Forum
* [⁠Anime Tosho](https://animetosho.net/) - Sub / Dub / [.onion](http://animetoshwu5w2kapugp6y25k3qpwicxwcll6odi2ptumvnh7ybqlfqd.onion/)
* [Anime2Enjoy](https://www.anime2enjoy.com/) - Sub / [Discord](https://discord.gg/PxSmumS)
* [animepahe](https://animepahe.pw/) - Hard Subs / Dub / Some NSFW / [Downloader](https://github.com/KevCui/animepahe-dl)
* [Chiby](https://www.animechiby.com/) - Sub / [Discord](https://discord.com/invite/WagHbBz)
* [Animevilla](https://animevilla.org/az-list/) - Sub / Dub / Some NSFW
* [AnimeSalt](https://animesalt.cx/) - Sub / Dub
* [PikaHD](https://pikahd.co/) - Sub / Dub
* [AniDL](https://anidl.org/) - Sub / Dub / [Discord](https://discord.com/invite/wPuzR2R) / [Telegram](https://telegram.me/anidl)
* [anime7.download](https://anime7.download/) - Sub
* [⁠JustAnime](https://justanime.to/) - Sub / Dub / [Mirrors](https://projectjust.xyz/) / [Subreddit](https://www.reddit.com/r/ProjectJust) / [Discord](https://discord.gg/P3yqksmGun)
* [⁠AnimeOut](https://www.animeout.xyz/) - Sub / Requires Sign-Up
* [nibl](https://nibl.co.uk/) - Sub / Dub / XDCC / [Discord](https://discord.com/invite/bUESsAg)
* [myanimetvbot](https://t.me/myanimetvbot), [Any_Animebot](https://t.me/Any_Animebot) or [anidlws](https://t.me/anidlws) - Telegram Anime Download Channels
* [anime-dl](https://github.com/gabelluardo/anime-dl) / [Frontend](https://github.com/vrienstudios/anime-dl) or [anigrab](https://github.com/ngomile/anigrab) - Anime CLI Downloaders
* [AniconforAnilist](https://github.com/EnArvy/AniconforAnilist) - Anime Folder Cover Automation

***

## ▷ [Educational Downloading](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7_downloading)

***

# ► Streaming Apps

* ↪️ **[Torrent Streaming](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25BA_torrent_apps)** - Torrent Streaming Apps
* ⭐ **[PlayTorrio](https://playtorrio.xyz/)**, [2](https://playtorrio.pages.dev/) - Streaming App / Use PlayTorrioHTTP Plugin / Windows, macOS, Linux / [Subreddit](https://www.reddit.com/r/PlayTorrio/) / [Discord](https://discord.gg/bbkVHRHnRk)
* ⭐ **[⁠Vyla Home](https://vyla.cc/products/home)**, [2](https://vyla.qzz.io) - Streaming App / Windows, macOS, Linux / [Subreddit](https://www.reddit.com/r/Vyla/) / [Discord](http://discord.gg/5eqRhKeywG) / [GitLab](https://gitlab.com/vyla-entertainment/home)
* [⁠SkyStream](https://github.com/akashdh11/skystream) - Streaming App / Extension-Based / Windows, macOS, Linux / [Discord](https://discord.gg/73XGA8Mxn9)
* [⁠FlyStream](https://flystream.net/apps) - Streaming App / Windows, macOS, Linux / [Subreddit](https://www.reddit.com/r/FlyStream/) / [Discord](https://discord.gg/flystream)
* [⁠Atlas](https://atlas.hls.lol/) - Streaming App / Windows
* [⁠Vega-Desktop](https://github.com/vega-org/vega-desktop) - Streaming App / Windows, macOS, Linux
* [⁠Showberry](https://github.com/Dackerie/showberry) - Streaming App / Windows, macOS, Linux
* [⁠WatchWave](https://watchwave.pro/) - Streaming App / Download in Top Right / Windows
* [⁠AIOStreams](https://docs.aiostreams.viren070.me/apps/) - Streaming App / Debrid or Usenet Required / Windows, macOS, Linux
* [mov-cli](https://mov-cli.github.io/) - Streaming CLI / [Plugins](https://github.com/topics/mov-cli-plugin) / Windows, macOS, Linux / [Discord](https://discord.gg/BMzC7ePsBV) / [GitHub](https://github.com/mov-cli/mov-cli)
* [Gir Society](https://discord.gg/WHxeZ3aTtb) - Plex + Jellyfin Public Playlist / Windows, macOS, Linux

***

## ▷ Anime Streaming Apps

* [Seanime](https://seanime.app/) - Anime Streaming App / Windows, macOS, Linux / [Discord](https://discord.com/invite/3AuhRGqUqh) / [GitHub](https://github.com/5rahim/seanime)
* [AnymeX](https://anymex.vercel.app/) - Anime Streaming App / [Extension Guide](https://wotaku.wiki/ext/mangayomi) / Windows, macOS, Linux / [GitHub](https://github.com/RyanYuuki/AnymeX)
* [Anikin](https://github.com/jerry08/Anikin) - Anime Streaming App / Windows / [Discord](https://discord.com/invite/U7XweVubJN)
* [Mizuki](http://mizuki.to/) - Anime Streaming App / Windows, macOS, Linux / [GitHub](https://github.com/Anisurge/App)
* [Unyo](https://github.com/K3vinb5/Unyo) - Anime Streaming App / Windows, macOS, Linux
* [⁠Tatakai](https://tatakai.app/) - Anime Streaming App / Extension-Based / Windows, macOS, Linux / [Discord](https://discord.com/invite/TWmbr7NYAW) / [GitHub](https://github.com/snozxyx/tatakai)
* [Miru](https://miru.js.org/en/) - Anime Streaming App / Windows, macOS, Linux / [Telegram](https://t.me/MiruChat) / [GitHub](https://github.com/miru-project/miru-app)
* [ani-cli](https://github.com/pystardust/ani-cli) - Anime Streaming CLI / Windows, macOS, Linux

***

## ▷ [Android Streaming](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25BA_android_streaming)

***

## ▷ [iOS Streaming](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25BA_ios_streaming)

***

# ► Torrent Apps

* **Note** - Remember to use a [VPN](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_vpn) before torrenting and [bind](https://wispydocs.pages.dev/torrenting/) it to your [client](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent#wiki_.25BA_torrent_clients) if it allows.

***

* 🌐 **[Awesome *Arr](https://ravencentri.cc/awesome-arr/)** / [GitHub](https://github.com/Ravencentric/awesome-arr) or [Locatarr](https://locatarr.github.io/) / [GitHub](https://github.com/Locatarr/locatarr.github.io) - Torrent App / Automation Tool Indexes
* ↪️ **[Remote Torrenting Services](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent#wiki_.25B7_remote_torrenting)** - Torrent Remotely Without Needing VPN
* ↪️ **[Media Servers / Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video-tools#wiki_.25BA_media_servers)**
* ↪️ **[Anime Torrent Streaming Apps](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25B7_anime_torrenting)**
* ⭐ **[Stremio](https://www.stremio.com/)** / [Subreddit](https://www.reddit.com/r/Stremio/) / [GitHub](https://github.com/Stremio), [⁠Stremio Desktop](https://github.com/Zaarrg/stremio-community-v5) (full mpv) or [Stremio Kai](https://allecsc.github.io/Stremio-Kai/) / [GitHub](https://github.com/allecsc/Stremio-Kai) (full mpv) - Torrent Streaming App / [WebUI](https://web.stremio.com/) / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video/#wiki_.25B7_stremio_tools)
* ⭐ **[PlayTorrio](https://playtorrio.xyz/)**, [2](https://playtorrio.pages.dev/) - Torrent Streaming App / Stremio Addon Support / [Subreddit](https://www.reddit.com/r/PlayTorrio/) / [Discord](https://discord.gg/bbkVHRHnRk)
* ⭐ **[Prowlarr](https://github.com/Prowlarr/Prowlarr)**, **[Jackett](https://github.com/Jackett/Jackett)**, [Bobarr](https://github.com/iam4x/bobarr) / [Discord](https://discord.gg/PFwM4zk), [nefarious](https://lardbit.github.io/nefarious/), [Traktarr](https://github.com/l3uddz/traktarr), [FlexGet](https://flexget.com/), [r/softwarr](https://reddit.com/r/softwarr) or [Watcher](https://nosmokingbandit.github.io/) - Autodownload Torrents
* ⭐ **[Radarr](https://radarr.video/)** - Autodownload Movie Torrents / [Auto-Subtitles](https://www.bazarr.media/) / [GitHub](https://github.com/Radarr/Radarr)
* ⭐ **[Sonarr](https://sonarr.tv/)** / [GitHub](https://github.com/Sonarr/Sonarr), [SickGear](https://github.com/SickGear/SickGear), [DuckieTV](https://schizoduckie.github.io/DuckieTV/) or [Medusa](https://pymedusa.com/) - Autodownload TV Torrents / [Guide](https://wiki.servarr.com/) / [Auto-Subtitles](https://www.bazarr.media/)
* ⭐ **[Requestrr](https://github.com/thomst08/requestrr)** or [Doplarr](https://github.com/activexray/doplarr_rs) - Discord Torrent Bots
* [⁠Nuvio Desktop](https://github.com/NuvioMedia/NuvioDesktop) or [⁠Nuvio HTPC](https://github.com/UmbraProjects/NuvioDesktop) / [Discord](https://discord.gg/wEgTPNXUMU) - Torrent Streaming App / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video/#wiki_.25B7_stremio_tools) / [Stremio Sync](https://nuviosync.com/) / [Plugins](https://nuvio-plugin-library.vercel.app/) / [Wiki / Guides](https://nuvio.wiki/)
* [Wyzie Subs](https://sub.wyzie.io/) - Subtitle Scraping API / [Setup](https://quiz.wyzie.io/) / [Plugins](https://store.wyzie.io/plugins) / [NPM Package](https://www.npmjs.com/package/wyzie-lib) / [Docs](https://docs.wyzie.io/)
* [Arr Scripts](https://github.com/RandomNinjaAtk/arr-scripts/) - Torrent App Automation Scripts
* [Autobrr](https://github.com/autobrr/autobrr) - Autodownload Movie Torrents
* [⁠Sportarr](https://sportarr.net/) - Sports PVR for Torrents + Usenet / [Discord](https://discord.gg/YjHVWGWjjG) / [GitHub](https://github.com/Sportarr/Sportarr)
* [Powder](https://powder.media/) - Torrent Streaming App
* [Ace Stream](https://acestream.org/) - Torrent Streaming App / [Channels](https://search-ace.stream/) / [Modded APK](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_modded_apks) (search) / [Docker Image](https://github.com/magnetikonline/docker-acestream-server) / [Mpv Script](https://github.com/Digitalone1/mpv-acestream)
* [WebTorrent](https://webtorrent.io/) - Torrent Streaming App / [GitHub](https://github.com/webtorrent/webtorrent)
* [WizTorrent](https://wiztorrent.com/) - Torrent Streaming App
* [⁠Magnolia](https://github.com/chwair/magnolia) - Torrent Streaming App
* [⁠SkyStream](https://github.com/akashdh11/skystream) - Torrent Streaming App / Stremio Addon Support / [Discord](https://discord.gg/73XGA8Mxn9)
* [rqbit](https://github.com/ikatson/rqbit/) - Torrent Streaming App / UPnP Integration
* [Instant.io](https://instant.io/), [BTorrent](https://btorrent.xyz/) or [Magnet Player](https://ferrolho.github.io/magnet-player/) - Stream Torrents in Browser
* [⁠Torlink](https://torlink.bairon.dev/) - Torrent Search + Download CLI / [GitHub](https://github.com/baairon/torlink)
* [Autosearch Extension](https://github.com/trossr32/sonarr-radarr-lidarr-autosearch-browser-extension) - Sonarr/Radarr/Lidarr Autosearch Extension
* [Unpackerr](https://unpackerr.zip/) - Automated Archive Extraction
* [VLC-Bittorrent](https://github.com/johang/vlc-bittorrent) or [StreamTim](https://streamtim.com/) - Stream Torrents in VLC
* [webtorrent-mpv-hook](https://github.com/mrxdst/webtorrent-mpv-hook) - Stream Torrents in MPV
* [RapidBay](https://github.com/hauxir/rapidbay) or [BitPlay](https://github.com/aculix/bitplay) - Self-Hosted Torrent Streaming

***

## ▷ Stremio Tools

* **Note** - Note that much of what is listed here will also be compatible with Nuvio as well.

***

* 🌐 **[Stremio Addons](https://stremio-addons.net/)** / [Subreddit](https://www.reddit.com/r/StremioAddons/) / [Discord](https://discord.com/invite/zNRf6YF) or [Midnight's Addons](https://addonsfortheweebs.midnightignite.me/addons) - Stremio Addons
* ⭐ **[Viren070's Guides](https://guides.viren070.me/stremio)** / [Discord](https://discord.com/invite/9Dn9mSxW6t) / [GitHub](https://github.com/Viren070/guides), **[Bye Sudo](https://stremio.ar0.eu/)** or [Streaming Perfect Setup](https://numb3rs.stream/) / [GitHub](https://github.com/luckynumb3rs/stremio-perfect-setup) - Stremio Guides
* [Stremio Addon Manager](https://addon-manager.viren070.me/) - Addon Manager / [GitHub](https://github.com/pancake3000/stremio-addon-manager)
* [⁠IbbyLabs Uptime Tracker](https://uptime.ibbylabs.dev/) - Stremio Addon Status
* [Stremio Account Bootstrapper](https://github.com/DryKillLogic/stremio-account-bootstrapper) - Easy Stremio Setup
* [⁠Kaptain.Stream](https://kaptain.stream/) - Nuvio Setup Wizard / Profile Editor / Collections
* [⁠AIOStreams](https://docs.aiostreams.viren070.me/) - Multi-Source Addon + Debrid Aggregator / [Discord](https://discord.com/invite/zRq8dVh5rJ) / [GitHub](https://github.com/Viren070/AIOStreams)
* [⁠AIOMetadata](https://github.com/cedya77/aiometadata) - Multi-Source Metadata & Catalogs Addon / [Public Instances](https://uptime.ibbylabs.dev/aiometadata)
* [Up Next](https://up-next.dontwanttos.top/) - Stremio Catalogs
* [Anime Catalogs](https://1fe84bc728af-stremio-anime-catalogs.baby-beamup.club/configure) - Stremio Anime Catalogs
* [Simkl Stremio](https://simkl.com/apps/stremio/) - Simkl for Stremio
* [Trakt Stremio](https://2ecbbd610840-trakt.baby-beamup.club/) - Trakt for Stremio

***

# ► Torrent Sites

* **Note** - Keep in mind that [torrent aggregators](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent/#wiki_.25B7_aggregators), or setups like Nuvio/Stremio & Torrentio, are sometimes better when it comes to finding content.

***

* ↪️ **[General Torrent Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent)**
* ⭐ **[1337x Movies](https://1337x.to/movie-library/1/)** - Movies / TV / Anime / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent#wiki_.25BA_torrent_sites)
* ⭐ **[RuTracker Movies](https://rutracker.org/forum/index.php?c=2)** - Movies / TV / Anime / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent#wiki_.25BA_torrent_sites)
* ⭐ **[ExT](https://ext.to/)**, [2](https://search.extto.com/) / [Proxy](https://extranet.torrentbay.st/)
* ⭐ **[Rive](https://www.rivestream.app/)**, [2](https://rivestream.ru/) or [CorsFlix](https://watch.corsflix.net), [2](https://watch.corsflix.dpdns.org) - Movies / TV / Anime / [Status](https://rentry.co/rivestream) / [Discord](https://discord.gg/6xJmJja8fV)
* ⭐ **[EZTV](https://eztvx.to/)** - TV / Anime
* [Video Torrent CSE](https://cse.google.com/cse?cx=006516753008110874046:gaoebxgop7j) or [1Tube](https://www.1tube.org/torrent) - Multi-Site Search
* [⁠DVDeez](https://dvdeez.top/) - DVD + Bluray ISOs
* [Youplex Torrents](https://youplex.cc/) - Movies / TV / Anime / 4K
* [TPB Movies](https://thepiratebay.org/search.php?q=top100:200) - Movies / TV / 4K / **Avoid Software / Games**
* [LimeTorrents](https://www.limetorrents.fun/) - Movies / TV
* [Heartive](https://heartiveplaystv.pages.dev/) - Movies / TV / Anime
* [CinemaCity](https://cinemacity.cc/) - Movies / TV / Anime / [Telegram](https://t.me/CinemaCity_rip)
* [⁠Kontrast](https://kontrast.top/) - Movies / TV
* [TorrentSurf](https://torrentsurf.to/) - Movies / TV
* [MSearch](https://msearch.vercel.app/) - Movies / TV
* [⁠RARBGLite](https://rarbglite.github.io/) - RARBG Movie Magnet Archive
* [Public Domain Movie Torrents](https://www.publicdomaintorrents.info/) - Movies
* [YTS](https://yts.gg/) or [YifyMovies](https://yifymovies.xyz/) - Movies / 4K / [Proxies](https://ytsproxies.com/) / [Status](https://yifystatus.com/) / [Discord](https://discord.gg/GwDraJjMga) / [Warning](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/yts-yify-critical.md)
* [JapaneseTorrents](https://japanesetorrents.wordpress.com/) - Asian Drama
* [IMDb Link em All](https://greasyfork.org/en/scripts/17154-imdb-link-em-all) or [IMDb-Scout-Mod](https://github.com/Purfview/IMDb-Scout-Mod) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/partitioned-cookies.md) - Torrent Site Results on IMDb
* [srrextra](https://github.com/srrDB/srrextra) - Scene Release Tracker on IMDb

***

## ▷ Anime Torrenting

* ⭐ **[Nyaa](https://nyaa.si/)**, [2](https://nyaa.iss.one/), [3](https://nyaa.iss.ink/) - Sub / Dub
* ⭐ **Nyaa Tools** - [Add Features](https://github.com/Arad119/Nyaa-Enhancer) / [TUI](https://github.com/Beastwick18/nyaa) / [Batch Download](https://github.com/marcpinet/nyaadownloader), [2](https://t.me/meow_in_japanese_bot) / [Python Wrapper](https://github.com/JuanjoSalvador/NyaaPy) / [Torrent Fetch](https://github.com/daynum/nyaabag) / [AnimeTosho Metadata](https://github.com/IONI0/Nyaa-AnimeTosho-Extender-ION-Fork) / [Quality Tags](https://releases.moe/about/)
* ⭐ **[Hayase](https://hayase.watch/)** - Torrent Streaming App / [Extensions](https://rentry.co/FMHYB64#hayase) / [Wiki](https://wiki.hayase.watch/)
* ⭐ **[Seanime](https://seanime.app/)** - Torrent Streaming App / [Discord](https://discord.com/invite/3AuhRGqUqh) / [GitHub](https://github.com/5rahim/seanime)
* ⭐ **[SeaDex](https://releases.moe/)** or [SeaDex Mirror](https://seadex.pages.dev/) - Anime Video Quality Guide / [Docs](https://releases.moe/about)
* [⁠nekoBT](https://nekobt.to/) - Sub / Dub
* [⁠Anime Tosho](https://animetosho.net/) - Sub / Dub
* [TsukiHime](https://tsukihime.org/) - Sub / Dub
* [⁠YumeZone](https://yumezone.live/torrents) - Sub / Dub / [Discord](https://discord.gg/VPNSMcG6jM)
* [TokyoTosho](https://www.tokyotosho.info/) - Sub
* [ShanaProject](https://www.shanaproject.com/) - Sub
* [Hi10Anime](https://hi10anime.com/) - Sub
* [bakabt](https://bakabt.me/) - Sub / Dub / [Interviews](https://wiki.bakabt.me/index.php/Sign_up)
* [Anime Torrent CSE](https://cse.google.com/cse?cx=006516753008110874046:lamzt6ls4iz)
* [Fansub Cartel](https://index.fansubcar.tel/), [2](https://docs.google.com/spreadsheets/d/1PJYwhjzLNPXV2X1np-S4rdZE4fb7pxp-QbHY1O0jH6Q/htmlview) - Fansubbers Index

***

## ▷ [Educational Torrenting](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7_downloading)

***

# ► Smart TV

* 🌐 **[⁠Jellyfin Smart TV Clients](https://github.com/awesome-jellyfin/awesome-jellyfin/blob/main/CLIENTS.md#-tv)**
* 🌐 **[⁠Awesome WebOS](https://github.com/tolgakurtuluss/awesome-webos)** - webOS TV Resources
* 🌐 **[⁠TroyPoint](https://troypoint.com/)** - App Index
* ↪️ **[Free w/ Ads Streaming](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25B7_free_w.2F_ads)**
* ⭐ **[TizenTube](https://tizentube.app/)** or [⁠YouTube for Tizen](https://github.com/SushyDev/tizen-youtube) - Ad-Free Samsung TV YouTube / [Setup Guide](https://www.notion.so/TizenBrew-Guide-30437864d8618033bb03e818e894fd5c) / [App Loader](https://github.com/SushyDev/tizen-homebrew), [2](https://github.com/reisxd/TizenBrew) / [Discord](https://discord.gg/m2P7v8Y2qR) / [GitHub](https://github.com/reisxd/TizenTube)
* ⭐ **[webOS Homebrew](https://www.webosbrew.org/)** - LG TV Homebrew / Ad-Free YouTube + Twitch / [Guide](https://wispydocs.pages.dev/lg-tv-homebrew/) / [Discord](https://discord.gg/xWqRVEm) / [GitHub](https://github.com/webosbrew/)
* ⭐ **[Nuvio](https://nuvio.tv/)** / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video/#wiki_.25B7_stremio_tools) / [Plugins](https://nuvio-plugin-library.vercel.app/) / [Wiki / Guides](https://nuvio.wiki/), [2](https://numb3rs.stream/) / [Discord](https://discord.gg/KVgDTjhA4H) / [GitHub](https://github.com/NuvioMedia/NuvioTVSmart), **[Stremio](https://www.stremio.com/)** / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video/#wiki_.25B7_stremio_tools), [WuPlay](https://github.com/wuplayapp/wuplay-releases) or [⁠RealStream](https://rstream.app/) / [Discord](https://discord.gg/jnDyHEkcZu) - Streaming App / Stremio Support
* [SamsungTVPlus](https://www.samsungtvplus.com/) - Streaming App
* [⁠Jellyfin Tizen](https://github.com/jellyfin/jellyfin-tizen) (search appstore) - Media Server / Streaming App
* [Kodi](https://kodi.tv/) - Media Server / Streaming App
* [⁠FlyStream](https://flystream.net/apps) - Streaming App / [Subreddit](https://www.reddit.com/r/FlyStream/) / [Discord](https://discord.gg/flystream)
* [⁠AIOStreams](https://docs.aiostreams.viren070.me/apps/) - Streaming App / Debrid or Usenet Required
* [YTCast](https://github.com/MarcoLucidi01/ytcast) - Cast YouTube Videos to Smart TV
* [iSponsorBlockTV](https://github.com/dmunozv04/iSponsorBlockTV) - SponsorBlock App
* [Playlet](https://channelstore.roku.com/details/4a41d0921265a5e31429a7679442153f:b5bcb5b630c28b01e93bf59856317b43/playlet) - Ad-Free YouTube Roku Client / [GitHub](https://github.com/iBicha/playlet)
* [⁠Twoku](https://github.com/worldreboot/twitch-reloaded-roku) - Improved Roku Twitch Client
* [⁠RoMote](https://github.com/wseemann/RoMote) - Open-Source Roku Remote
* [SmartTwitchTV](https://github.com/fgl27/SmartTwitchTV) - Smart TV Twitch App
* [Go2TV](https://github.com/alexballas/go2tv) or [FCast](https://fcast.org/) - Cast to Smart TVs
* [smart-tv-telegram](https://github.com/andrew-ld/smart-tv-telegram) - Stream Media from Telegram to Smart TV
* [ChanSort](https://github.com/PredatH0r/ChanSort) - TV Channel List Editor for Samsung, LG, etc.
* [Samsung Smart TV Adblock](https://redd.it/gn7fw5) - Block Samsung + Smart TV Ads
* [Apps2Samsung](https://github.com/Apps2Samsung) - Tizen Device Sideloading Tool / [Packages](https://github.com/Apps2Samsung/tizen-community-packages)
* [⁠MuTube](https://github.com/Exaphis/mutube), [⁠Unwatched](https://apps.apple.com/app/unwatched-para-youtube/id6477287463) / [GitHub](https://github.com/fer0n/Unwatched) or [Yattee](https://github.com/yattee/yattee) - Apple TV YouTube Apps
* [Blackb0x](https://github.com/NSSpiral/Blackb0x) - Apple TV Jailbreak
* [ATVLoadly](https://github.com/bitxeno/atvloadly) - Apple TV Sideloading

***

## ▷ Android TV / Firestick

* **Note** - The Firestick Select cannot run any Android Apps.

***

* 🌐 **[Awesome Android TV](https://github.com/Generator/Awesome-Android-TV-FOSS-Apps)**, **[Ultimate Android TV](https://xdaforums.com/t/android-ultimate-collection-guides.4513231/#post-87676359)** or **[⁠TroyPoint](https://troypoint.com/)** - Android TV App Indexes
* 🌐 **[KPFire](https://linktr.ee/kpfire)** - Firestick App Index
* ↪️ **[Android Streaming](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25BA_android_streaming)** / **[Apps](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_untouched_apks)**
* ⭐ **[NuvioTV](https://github.com/NuvioMedia/NuvioTV)** / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video/#wiki_.25B7_stremio_tools) / [Stremio Sync](https://nuviosync.com/) / [Plugins](https://nuvio-plugin-library.vercel.app/) / [Wiki / Guides](https://nuvio.wiki/) / [Discord](https://discord.gg/KVgDTjhA4H) - Streaming App / Stremio Support
* ⭐ **[TiviMate](https://tivimate.com/)**, [2](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_modded_apks) (search) or [⁠OwnTV](https://github.com/ahXN00/OwnTV/) - IPTV Players
* ⭐ **[Downloader App](https://www.aftvnews.com/downloader)** - Sideloading App / Downloader for Fire TV + Android TV / [URL Shortener](https://go.aftvnews.com/)
* ⭐ **[SmartTube](https://github.com/yuliskov/SmartTube)** / [2](https://smarttubeapp.github.io/) / [Discord](https://discord.com/invite/Wt8HDDej5z) / [Telegram](https://t.me/SmartTubeEN) or **[⁠TizenTube Cobalt](https://github.com/reisxd/TizenTubeCobalt)** / [Discord](https://discord.com/invite/m2P7v8Y2qR) / [Telegram](https://t.me/tizentubecobaltofficial) - Ad-Free Android TV / Firestick YouTube
* [⁠Flicky](https://github.com/mlm-games/flicky) - F-Droid Client
* [Android TV Tools v4](https://xdaforums.com/t/tool-all-in-one-tool-for-windows-android-tv-tools-v4.4648239/) - Multiple Android TV Tools
* [⁠Android TV Optimizer](https://github.com/bryanroscoe/shield_optimizer) - Android TV Optimization Tool
* [Android TV Piracy](https://rentry.co/androidtvpiracy) - Android TV Piracy Guide
* [Android TV Guide](https://www.androidtv-guide.com/) - Certified Android TV Devices / [Spreadsheet](https://docs.google.com/spreadsheets/d/1kdnHLt673EjoAJisOal2uIpcmVS2Defbgk1ntWRLY3E/)
* [StreamFire](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_modded_apks) (search) - Live TV for Firestick
* [S0undTV](https://github.com/S0und/S0undTV) - Twitch Player / [Discord](https://discord.gg/zmNjK2S)
* [SmartTVKick](https://github.com/CxWatcher/SmartTVKick) - Ad-Free FireTV + Android TV Kick App
* [Serenity Android](https://github.com/NineWorlds/serenity-android) - Emby Android TV App
* [CloudStream](https://github.com/recloudstream/cloudstream) - Streaming App / [Docs / Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25BA_android_streaming)
* [⁠Vega-Desktop](https://github.com/vega-org/vega-desktop) - Streaming App
* [Atlantic](https://atlantic.bz/android) - Streaming App
* [Syncler](https://syncler.net/) - Streaming App / [Providers](https://www.reddit.com/r/providers4syncler/)
* [⁠SkyStream](https://github.com/akashdh11/skystream) - Streaming App / Extension Based / [Discord](https://discord.gg/73XGA8Mxn9)
* [Vyla TV](https://vyla.cc/products/tv) - Streaming App / [GitLab](https://gitlab.com/vyla-entertainment/TV)
* [ARVIO](https://arvio.tv/) - TV Media Server w/ Stremio Addons + IPTV Support / [GitHub](https://github.com/ProdigyV21/ARVIO)
* [⁠StrexoPlayer](https://strexoplayer.onrender.com/) - Video Player w/ Stremio Sync
* [⁠mpvNova](https://github.com/Laskco/mpvNova) - Android TV Video / Media Player
* [Nova Video Player](https://github.com/nova-video-player/aos-AVP) - Android TV Video / Media Player
* [Hayase](https://hayase.watch/) - Torrent Streaming App / [Extensions](https://rentry.co/FMHYB64#hayase) / [Wiki](https://wiki.hayase.watch/)
* [⁠Sozo](https://sozo.azamov.me/) - Anime Streaming App
* [⁠Tatakai](https://tatakai.app/) - Anime Streaming App / Extension-Based / [Discord](https://discord.com/invite/TWmbr7NYAW) / [GitHub](https://github.com/snozxyx/tatakai)
* [aDrama](https://adrama.app/) - Asian Drama Streaming App
* [DigilogTV](https://github.com/aldrinzigmundv/digilogtv) - News Streaming App
* [APKUpdater](https://github.com/rumboalla/apkupdater) - APK Installer / Updater
* [atvTools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_modded_apks) (search) - Install Apps, Run ADB, Shell Commands, etc.
* [tvQuickActions](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_modded_apks) (search) - Remote Button Remapper / Requires Sign-Up
* [Projectivy Launcher](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_modded_apks) (search), [2](https://play.google.com/store/apps/details?id=com.spocky.projengmenu), [3](https://github.com/spocky/miproja1) / [XDA Thread](https://xdaforums.com/t/app-android-tv-projectivy-launcher.4436549/) / [Icon Pack](https://github.com/SicMundus86/ProjectivyIconPack), [AT4K Launcher](https://at4klauncher.com/) / [Subreddit](https://www.reddit.com/r/AT4K/) or [Leanback on Fire](https://github.com/tsynik/LeanbackLauncher) - Android TV Launchers
* [Launcher Manager](https://xdaforums.com/t/app-firetv-noroot-launcher-manager-change-launcher-without-root.4176349/) - Change Default Launcher
* [⁠AerialViews](https://github.com/theothernt/AerialViews) - Custom Screensaver App

***

# ► Tracking / Databases

* ⭐ **[Simkl](https://simkl.com/)** - Movie / TV / Anime Tracking / Automatic Tracking / [Apps](https://simkl.com/apps/) / [Import Tools](https://simkl.com/apps/import/)
* ⭐ **[Letterboxd](https://letterboxd.com/)** - Film Diary / Reviews / Ratings / Curated Lists / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_letterboxd_tools)
* ⭐ **[IMDb](https://www.imdb.com/)** - Movie / TV Database / Ratings / Reviews / [Advanced Search](https://www.imdb.com/search/) / [Frontend](https://libremdb.iket.me/)
* ⭐ **[ICheckMovies](https://www.icheckmovies.com/)** - Film Tracking / Curated Lists / Completion Statistics / [Enhanced](https://greasyfork.org/en/scripts/11541-icheckmovies-enhanced)
* ⭐ **[serializd](https://www.serializd.com/)** - TV Show Diary / Episode Reviews / Ratings / Lists / [Discord](https://discord.com/invite/xNt4CNG7jK)
* ⭐ **[RatS](https://github.com/StegSchreck/RatS)** - Transfer / Synchronize Ratings Between Services
* [Trakt](https://app.trakt.tv/) - Movie / TV Tracking / Automatic Scrobbling / Watch History / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_trakt_tools)
* [TVmaze](https://www.tvmaze.com/) - TV Show / Episode Database / Airing Schedules / [API](https://www.tvmaze.com/api)
* [TMDb](https://www.themoviedb.org/) - Community Movie / TV Database / Cast & Crew / [API](https://developer.themoviedb.org/docs/getting-started)
* [TheTVDB](https://thetvdb.com/) - Community TV / Movie Metadata Database / Episode Orders
* [AFI Catalog](https://aficatalog.afi.com/) - Historical American Film Database / Cast & Crew / Production Histories
* [Kinorium](https://en.kinorium.com/) - Movie / TV Tracking / Ratings / Recommendations
* [WeTrakr](https://wetrakr.com/) - Movie / TV / Anime Tracking / Automatic Scrobbling / Imports
* [EntertainMe](https://www.entertainme.fun/) - Movie / TV / Anime Tracking / Recommendations
* [Movieo](https://movieo.me/) - Movie Database / Advanced Filters / Watchlists / Reviews
* [AllMovie](https://www.allmovie.com/) - Movie Database / Professional Reviews / Genres / Themes
* [listal](https://www.listal.com/) - Movie Database
* [Rotten Tomatoes](https://www.rottentomatoes.com/) - Aggregated Critics' & Audience Reviews / [Add to Sites](https://greasyfork.org/en/scripts/35443) / [Add to IMDb](https://greasyfork.org/en/scripts/15222)
* [MediaTracker](https://github.com/bonukai/MediaTracker) or [Yamtrack](https://github.com/FuzzyGrim/Yamtrack) - Self-Hosted Media Trackers
* [Box Office Mojo](https://www.boxofficemojo.com/) - Movie Box Office Earnings / Historical Revenue Charts
* [MyDramaList](https://mydramalist.com/) - Asian Drama Database / Tracking / Reviews / Recommendations
* [HKMDB](https://hkmdb.com/db/index.php) - Hong Kong Cinema Database / Filmographies / Cast & Crew
* [GCDb](https://www.grindhousedatabase.com/) - Grindhouse / Exploitation Cinema Database
* [Spaghetti Western Database](https://www.spaghetti-western.net/index.php/Main_Page) - Spaghetti Western Films / Cast & Crew / Reviews
* [FFCritic](https://foundfootagecritic.com/) - Found Footage Horror Database / Reviews / Ratings
* [Class Real](https://www.classreal.com/) - Weird / Surreal / Psychedelic Movie Lists
* [IGMDB](https://igmdb.com/) - LGBTQ+ Movie Database
* [DMDb](https://deafmovie.org/) or [Sign on Screen](https://signonscreen.com/all-films/) - Deaf Cinema / Sign Language Films / Deaf Cast & Crew
* [namuwiki](https://en.namu.wiki/) - Korean Pop Culture / Entertainment Wiki
* [CageMatch](https://www.cagematch.net/) - Professional Wrestling Database / Wrestlers / Matches / Promotions
* [UKGameshows](https://www.ukgameshows.com/) - British Game Show Database / Presenters / Programme Histories
* [What's on Netflix](https://www.whats-on-netflix.com/), [uNoGS](https://unogs.com/) or [FlixWatch](https://www.flixwatch.co/) - Netflix Catalogue Discovery / Regional Availability
* [Netflix Top 10](https://www.netflix.com/tudum/top10) - Weekly Netflix Viewing Rankings / Global & Country Charts
* [Fameboxd](https://fameboxd.com/) - Public Letterboxd Accounts of Actors / Directors / Celebrities
* [Movie Mistakes](https://www.moviemistakes.com/) - Movie Continuity Errors / Goofs / Community Submissions

***

## ▷ Anime Tracking / Databases

* ⭐ **[MAL](https://myanimelist.net/)** - Anime Ratings / Reviews / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_myanimelist_tools) / [Discord](https://discord.com/invite/myanimelist)
* ⭐ **[AniList](https://anilist.co/)** - Anime Ratings / Reviews / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_anilist_tools) / [Discord](https://discord.com/invite/TF428cr)
* [Taiga](https://taiga.moe/) - Anime Tracking Program
* [Anime-Planet](https://www.anime-planet.com/) - Anime
* [Kitsu](https://kitsu.io/) - Anime
* [Kuroiru](https://kuroiru.co/) - Anime / [Subreddit](https://www.reddit.com/r/StreamingAnime/) / [Discord](https://discord.com/invite/ys6NASYQSd)
* [Anisearch](https://www.anisearch.com/) - Anime
* [AniDB](https://anidb.net/) - Anime
* [ACDB](https://www.animecharactersdatabase.com/) or [⁠Anibase](https://anibase.net/) - Anime Character Databases

***

## ▷ Recommendation Tools

* ⭐ **[They Shoot Pictures](https://www.theyshootpictures.com/)** - Aggregated Critics' Film Rankings / Greatest 1000 Films / Director Rankings
* ⭐ **[Sight and Sound](https://www.bfi.org.uk/sight-and-sound/greatest-films-all-time/)** - Decennial Critics' & Directors' Greatest Films Polls
* ⭐ **[MDBList](https://mdblist.com/)** or [FlickMetrix](https://flickmetrix.com/) - Aggregated Movie / TV Ratings / Advanced Filters
* ⭐ **[The Criterion Closet](https://thecriterioncloset.com/)** - Interactive Criterion Collection / Film Discovery / [Popular Closet Picks](https://closet-picks.com/)
* ⭐ **[TasteDive](https://tastedive.com/)** - Similar Movie / TV Recommendations
* ⭐ **[MovieLens](https://movielens.org/)** - Personalized Movie Recommendations / Adjustable Similarity Filters
* ⭐ **[Series Graph](https://seriesgraph.com/)** - TV Episode Ratings / Interactive Charts / Community Rankings / [Discord](https://discord.com/invite/W6NGKsyaUY)
* [Taste.io](https://www.taste.io/) - Movie / TV Recommendations Based on Similar Users
* [Cinetrii](https://cinetrii.com/) - Discover Film Influences / Thematic & Cinematic Connections
* [SuggestStream](https://suggestream.com/) - Interactive Movie / TV Discovery / Swipe Recommendations
* [FilmDilemma](https://filmdilemma.com/) - Movie Discovery / Comparisons / Curated Lists
* [BestSimilar](https://bestsimilar.com/) - Similar Movies / TV Shows by Plot & Theme
* [r/MovieSuggestions](https://www.reddit.com/r/MovieSuggestions/) - Community Movie Recommendations
* [MovieSync](https://movie-sync-app.web.app/) - Movie Recommendations
* [Simkl](https://simkl.com/) - Recommendations Based on Watch History
* [Nothing To Watch](https://nothing-to-watch.port80.ch/) - Interactive Movie Discovery Visualization / ~250MB Download / [GitHub](https://github.com/gnovotny/nothing-to-watch)
* [Ratings Graph](https://www.ratingraph.com/), [IMDb Table](https://docyx.github.io/imdb-table), [TV Chart](https://tvchart.benmiz.com/) or [Episode Hive](https://episodehive.com/) - Movie / TV Ratings / Episode Graphs
* [TV Charts](https://tvcharts.co/), [TheShowGrid](https://theshowgrid.com/) or [WhatToWatchOn.tv](https://whattowatchon.tv/) - TV Episode Ratings / Series Comparisons
* [MRQE](https://www.mrqe.com/) - Movie Review Search Engine / Critics' Reviews
* [Phi Phenomenon](https://phi-phenomenon.org/) - Aggregated Greatest Films Rankings / Genre & Era Lists
* [movy.fyi](https://movy.fyi/discover/) - Wikipedia-Based Top 1000 Films
* [DigitalDreamDoor](https://digitaldreamdoor.com/pages/movie-home.html) - Greatest Films Lists by Genre & Era
* [They Shoot Zombies](https://theyshootzombies.com/) - Aggregated Greatest Horror Films / Top 1000
* [ReelScary](https://www.reelscary.com/) - Horror Movie Ratings / Gore / Disturbing Content / Suspense
* [RelatedAnime](https://relatedanime.com/) - Anime Sequels / Prequels / Adaptations / Related Series
* [AnimeStats](https://anime-stats.net/), [AnimeKarmaList](https://animekarmalist.com/) or [Sprout](https://anime.ameo.dev/) - Anime Ratings / Recommendations
* [cringeMDb](https://cringemdb.com/) - Find Movies Without Awkward Sexual Content / Parent-Friendly Viewing
* [Common Sense Media](https://www.commonsensemedia.org/) or [Kids in Mind](https://kids-in-mind.com/) - Age-Based Media Reviews / Detailed Content Guides
* [Age Rating JuJu](https://www.ageratingjuju.com/) - Movie / TV Age Ratings / Parents' Guides

***

## ▷ Calendar / Upcoming

* ↪️ **[Blu-ray / DVD Release Calendars](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_physical_media_.2F_streaming)**
* ⭐ **[Your Countdown To](https://yourcountdown.to/)** - Countdown for Movies / TV / Anime / Video Games
* ⭐ **[Movie Countdown](https://moviescountdown.com/)** - Countdown for Upcoming Movies / [TV](https://countdown.tv/) / [Drama](https://dramacountdown.com/)
* ⭐ **[WhereYouWatch](https://whereyouwatch.com/latest-reports/)** or [r/movieleaks](https://reddit.com/r/movieleaks) - Movie Leak Notifications
* [Releases](https://www.releases.com/) - VOD / Streaming / Cinema Release Calendar
* [⁠Midloop](https://midloop.net/) - Streaming Service Release Calendar / [Discord](https://discord.gg/AvUxR59Yv5)
* [Episode Calendar](https://episodecalendar.com/) or [Next Episode](https://next-episode.net/) - TV Schedules / [Torrent Links](https://greasyfork.org/en/scripts/27367)
* [TrailerPunk](https://trailerpunk.com/) - Newest Movie Trailers
* [⁠The Digital Theater](https://thedigitaltheater.com/) - High Res Trailer Downloads
* [TVMaze](https://www.tvmaze.com/) - TV / Anime
* [My Episodes](https://www.myepisodes.com/) - TV
* [AniChart](https://anichart.net), [AnimeSchedule](https://animeschedule.net/), [Anica](https://anica.jp/), [AnimeCountdown](https://animecountdown.com/) or [LiveChart](https://www.livechart.me/) - Anime Release Calendars
* [Upcoming Anime Dubs](https://myanimelist.net/forum/?topicid=1692966) or [Dub Schedule](https://teamup.com/ksdhpfjcouprnauwda) - Anime Dub Release Trackers
* [WhenToStream](https://www.whentostream.com/) - Streaming Release News / Updates
* [⁠UKGameshows](https://www.ukgameshows.com/ukgs/TV_Guide_This_Week) - UK Game Show Calendar
* [showRSS](https://showrss.info/) - RSS / TV

***

# ► Subtitle Tools

* 🌐 **[elSubtitle](https://www.elsubtitle.com/)**, [SubConverter](https://subconverter.com/), [Subtitle One](https://subtitleone.cc/) or [Subtitle Tools](https://subtitletools.com/) - Subtitle Tools
* ⭐ **[Substital](https://substital.com/)** or [Movie-Subtitles](https://github.com/gignupg/Movie-Subtitles) - External Subtitle Extensions
* ⭐ **[Subtitle Edit](https://www.nikse.dk/subtitleedit)** / [GitHub](https://github.com/SubtitleEdit/subtitleedit), [DST](https://www.syedgakbar.com/projects/dst), [Aegisub](https://github.com/arch1t3cht/Aegisub/releases), [Tero Subtitler](https://www.uruworks.net/) / [GitHub](https://github.com/URUWorks/TeroSubtitler), [Subtitle Workshop Classic](https://sourceforge.net/projects/subtitle-workshop-classic/), [Jubler](https://www.jubler.org/) or [Subtitld](https://subtitld.org/) - Subtitle Editors
* [Penguin](https://github.com/carsonip/Penguin-Subtitle-Player) - External Subs Players
* [Adjust Subs Like a Pro](https://graph.org/Adjust-subtitles-in-seconds-like-a-pro-07-17) - ffsubsync Guide
* [Subshifter](https://subshifter.bitsnbites.eu/), [⁠AutoSubSync](https://github.com/denizsafak/AutoSubSync), [ffsubsync](https://smacke.net/ffsubsync/) / [GitHub](https://github.com/smacke/ffsubsync), [autosubsync-mpv](https://github.com/joaquintorres/autosubsync-mpv) or [autosubsync](https://github.com/oseiskar/autosubsync) - Sync Subtitles
* [asstosrt-wasm](https://sorz.github.io/asstosrt-wasm/) - ASS / SSA to SRT Subtitles Converter
* [WithSubtitles](https://withsubtitles.com/), [Revoldiv](https://revoldiv.com/), [pyTranscriber](https://pytranscriber.github.io/), [Auto-Subtitle](https://www.veed.io/tools/auto-subtitle-generator-online), [Vibe](https://thewh1teagle.github.io/vibe/), [⁠VideoLingo](https://github.com/Huanshere/VideoLingo) or [Turboscribe](https://turboscribe.ai/) - Video Transcribers / Subtitle Generators
* [TranslatesSubtitles](https://translatesubtitles.com/) / [2](https://translatesubtitles.co/) or [GPTSubtitler](https://gptsubtitler.com/) - Translate Subtitles
* [Auto Synced & Translated Dubs](https://github.com/ThioJoe/Auto-Synced-Translated-Dubs) - Create Translated Dubs
* [SoniTranslate](https://github.com/R3gm/SoniTranslate) - Video Translator
* [asbplayer](https://app.asbplayer.dev/) - Subtitle Sentence Mining
* [Sushi.net](https://github.com/maxpiva/Sushi.Net) - Automatic Subtitle Shifter Based on Audio
* [MkvDefaultTrackChanger](https://mkvdefaulttrackchanger.pages.dev/) - Easily Change Default MKV Subtitle / Audio Tracks / [GitHub](https://github.com/MikeMoolenaar/MkvDefaultTrackChanger)
* [mkv-extract](https://qgustavor.github.io/mkv-extract/), [gmkvextractgui](https://sourceforge.net/projects/gmkvextractgui/) or [MKVcleaver](https://www.videohelp.com/software/MKVcleaver) - Extract Subtitles from MKV Files
* [⁠VideOCR](https://github.com/timminator/VideOCR) or [VideoSubFinder](https://sourceforge.net/projects/videosubfinder/) - Hardcoded Subtitle Extractors
* [Subtitling Guide](https://baechusquad.download/guide/) - Subtitling Guide
* [YukiSubs Guides](https://yukisubs.wordpress.com/guides/), [I am Scum](https://iamscum.wordpress.com/guides/) or [Fansub Guide](https://unanimated.github.io/guides.htm) - Fansubbing Encoding Guides

***

## ▷ Download Subtitles

* ⭐ **[Open Subtitles](https://opensubtitles.org/)** / [Beta Site](https://www.opensubtitles.com/) - Subtitles
* ⭐ **[Subscene](https://sub-scene.com/)** - Subtitles
* ⭐ **[SubSource](https://subsource.net/)** - Subtitles
* ⭐ **[SubDL](https://subdl.com/)** - Subtitles
* ⭐ **[Addic7ed](https://www.addic7ed.com/)** - Subtitles / [Frontend](https://www.gestdown.info/)
* ⭐ **[Bazarr](https://www.bazarr.media/)** - Subtitle Autosearch / Download Tool / [Discord](https://discord.com/invite/MH2e2eb) / [GitHub](https://github.com/morpheus65535/bazarr)
* [Freesub](https://freesub.live/) - Subtitles
* [Subtitle Cat](https://www.subtitlecat.com/) - Subtitles
* [Subs4Free](https://www.subs4free.info/) - Subtitles
* [JustSubtitles](https://justsubtitles.com/) - Subtitles
* [IndexSubtitle](https://indexsubtitle.cc/) - Subtitles
* [YifySubtitles](https://yifysubtitles.ch/) - Subtitles
* [YTS Subs](https://yts-subs.com/) - Subtitles
* [Subtitlist](https://subtitlist.com/) - Subtitles
* [Subsearch](https://github.com/vagabondHustler/subsearch) or [Subliminal](https://subliminal.readthedocs.io/) - Python Download Scripts
* [kitsuneko](https://kitsunekko.net/) - Anime Subtitles
* [Closed Caption Browser](https://rentry.co/FMHYB64#closed-caption-browser) - Anime Closed Captions / Dubtitles
* [DownSub](https://downsub.com/) - Download Subs from Video Sites
* [SaveSubs](https://www.savesubs.com/) - Extract Subtitles from Online Videos
* [⁠ytsubdl](https://ytsubdl.com/) - Extract Subtitles/Transcript from YouTube Videos

***

# ► Helpful Sites / Tools

* 🌐 **[r/Animepiracy Wiki](https://thewiki.moe/)** or [Awesome ACG](https://github.com/soruly/awesome-acg) - Anime Tool Indexes
* ↪️ **[Blu-ray / DVD Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_physical_media_.2F_streaming)** / **[Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video-tools#wiki_.25B7_physical_media_tools)**
* ↪️ **[Media Posters / Covers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25B7_media_covers_.2F_posters)**
* ↪️ **[Media Soundtracks](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/audio#wiki_.25BA_media_soundtracks)**
* ↪️ **[File Data Automation](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/file-tools#wiki_.25B7_data_automation)**
* ⭐ **[BingeClock](https://www.bingeclock.com/)**, [Can I Binge?](https://canibinge.com/) or [tiii.me](https://tiii.me/) - TV Show Length Calculators
* ⭐ **[AnimeFillerList](https://www.animefillerlist.com/)** or [AnimeFillerGuide](https://www.animefillerguide.com/) - Anime Filler Guides
* ⭐ **[Quality / Release Type Guide](https://www.reddit.com/r/Piracy/wiki/guides/video_quality_and_types_of_releases)** - Video Quality / Release Type Guide
* ⭐ **[Release Group Qualities](https://docs.google.com/spreadsheets/u/0/d/1xz5zqrBumfMtLGA4VMt1VtOyh-47HDTv_swIYktX6AQ/htmlview)** - Movie / TV Release Group Quality Indexes
* [⁠WEB Source Tier List](https://gist.github.com/vevv/1d7037bb556c17e977b26b9f8f175853) - WEB-DL Quality Guide
* [TheIntroDB](https://theintrodb.org/) - Intro / Credit Skipping Extension / [Discord](https://discord.gg/Qn6RhamxT5) / [Telegram](https://t.me/theintrodb) / [GitHub](https://github.com/TheIntroDB)
* [IMDb-Scout-Mod](https://greasyfork.org/en/scripts/407284) - Add Stream / DDL Site Results to IMDb / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/partitioned-cookies.md)
* [FlickChart](https://www.flickchart.com/) - Rank Your Movies
* [Find Movie](https://find-movie.info/) or [QuoDB](https://www.quodb.com/) - Movie Quote Databases / Search
* [SubsLikeScript](https://subslikescript.com/), [Scripts Onscreen](https://scripts-onscreen.com/), [Scripts.com](https://www.scripts.com/), [IMSDB](https://imsdb.com/), [ScriptSlug](https://www.scriptslug.com/), [DailyScript](https://www.dailyscript.com/) or [SimplyScripts](https://www.simplyscripts.com/) - Media Scripts
* [Forever Dreaming](https://transcripts.foreverdreaming.org/) - Media Transcripts
* [⁠IMAX Guide](https://143190.xyz/) - Database of IMAX Theatres / [GitHub](https://github.com/r-imax/imaxguide)
* [MCU Order](https://aaronperris.com/mcu/) - Marvel Cinematic Universe Viewing Orders
* [DC Media List](https://docs.google.com/spreadsheets/d/1znGm7MswCG0yuRHSvyHDUuIdeNSS7DP-yWOEqKYTAIY/edit?gid=1873657259#gid=1873657259) - Full DC Media List (1935-2024)
* [RunPee](https://runpee.com/) - Best Movie Break Times
* [MoviePooper](https://moviepooper.com/) or [themoviespoiler](https://themoviespoiler.com/) - Movie Spoilers
* [Behind the Voice Actors](https://www.behindthevoiceactors.com/) - Voice Actors Database
* [Movie-Censorship](https://www.movie-censorship.com/) - Compare Alternate Versions of Media
* [ShotOnWhat?](https://shotonwhat.com/) - Film Technical Info / Equipment Database
* [Internet Movie Cars Database](https://www.imcdb.org/) - Movie Vehicle Database
* [Starring the Computer](https://www.starringthecomputer.com/) - Movie Computer Database / [Discord](https://discord.com/invite/6NbTfHEtgQ)
* [IMFDB](https://www.imfdb.org/wiki/Main_Page) / [Discord](https://discord.com/invite/FDHEkQ6szt) or [MGDB](http://mgdb.himitsukichi.com/pukiwiki/index.php) - Media Firearms Database
* [WheresTheJump?](https://wheresthejump.com/), [WhenJumpScare](https://www.whenjumpscare.com/), [NotScare](https://notscare.me/) or [WheresTheScares?](https://wheresthescares.com/) - Find Movie Jump Scares
* [DMT](https://dmtalkies.com/) - Movies / TV Ending Explanations and Recaps
* [WhatsatMovie](https://whatsatmovie.com/), [Talpa Search](https://www.talpasearch.com/) or [What is My Movie?](https://www.whatismymovie.com/) - Find Movies via Descriptions
* [Anime Skip](https://anime-skip.com/) - Auto Skip Anime Intros
* [trace.moe](https://trace.moe/) - Anime Scene Reverse Image Search
* [Anilinks](https://anilinks.neocities.org/) - Anime Related Site Index
* [watch_order](https://www.reddit.com/r/anime/wiki/watch_order) or [Chiaki](https://chiaki.site/) - Anime Watch Orders
* [Unconsenting Media](https://www.unconsentingmedia.org) - Database of Sexual Violence in Movies / Shows
* [Bechdel Test](https://bechdeltest.com/) - Movie Bechdel Test Check
* [Movie-Locations](https://www.movie-locations.com/), [⁠Movie Scene Map](https://moviescenemap.com/), [MovieLoci](https://www.movieloci.com/), [AtlasOfWonders](https://www.atlasofwonders.com/), [WhereDidTheyFilmThat](https://www.wheredidtheyfilmthat.co.uk/) - Film Location Maps
* [DramaWiki](https://wiki.d-addicts.com/), [KoreanDrama](https://www.koreandrama.org/) or [HanCinema](https://www.hancinema.net/) - Asian Drama Wikis
* [Sprocket School](https://www.sprocketschool.org/wiki/Main_Page) - Film Exhibition Wiki

***

## ▷ [Video Players / Servers / Sync](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video-tools)