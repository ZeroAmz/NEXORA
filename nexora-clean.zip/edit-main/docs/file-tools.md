***
***
**[◄◄ Back to Wiki Index](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/tools-index)**
***
***

# ► File Tools

* ↪️ **[File Scanners](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25B7_online_scanners)**
* ⭐ **[Krokiet](https://github.com/qarmin/czkawka/blob/master/krokiet/README.md)**, [czkawka](https://github.com/qarmin/czkawka) or [dupeGuru](https://dupeguru.voltaicideas.net/) - Duplicate File Finders
* [UnLock IT](https://emcosoftware.com/unlock-it/download) or [Lock Hunter](https://lockhunter.com/) - File Unlocker / Deleter
* [Icaros](https://github.com/Xanashi/Icaros) - Add Explorer Thumbnails to any Video Format
* [HTTPDirfs](https://github.com/fangfufu/httpdirfs) or [hfs](https://rejetto.com/hfs/) / [2](https://github.com/rejetto/hfs) - HTTP File Systems
* [WinBtrfs](https://github.com/maharmstone/btrfs) - Btrfs File System
* [mergerfs](https://github.com/trapexit/mergerfs) - Union File System
* [ExampleFile](https://www.examplefile.com/), [⁠Dummyfiles](https://dummyfiles.dev/) or [File-Examples](https://file-examples.com/) - Dummy Example Files

***

## ▷ Download Managers

* **Note** - For more info on the benefits of Download Managers, see [The Piracy Glossary](https://fluffle.cc/piracyglossary).

***

* ⭐ **[AB Download Manager](https://abdownloadmanager.com/)** - Download Manager / Windows, macOS, Linux, Android / [Firefox](https://addons.mozilla.org/firefox/addon/ab-download-manager/) / [Chrome](https://chromewebstore.google.com/detail/ab-download-manager-brows/bbobopahenonfdgjgaleledndnnfhooj) / [Telegram](https://t.me/abdownloadmanager_discussion) / [GitHub](https://github.com/amir1376/ab-download-manager)
* ⭐ **[JDownloader](https://jdownloader.org/)** - Download Manager / Windows, macOS, Linux
* ⭐ **JDownloader Tools** - [Apps](https://my.jdownloader.org/apps/) / [Dark Theme](https://github.com/moktavizen/material-darker-jdownloader), [2](https://redd.it/q3xrgj) / [Dracula Theme](https://draculatheme.com/jdownloader2) / [Debloat Guide](https://clarasguide.valeena.workers.dev/Guides/jdownloader2/)
* ⭐ **[IDM](https://rentry.co/FMHYB64#idm)**, [2](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/download#wiki_.25BA_software_sites), [3](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/games#wiki_.25BA_download_games) (search) - Download Manager / [Firefox](https://addons.mozilla.org/en-US/firefox/addon/tonec-idm-integration-module/) / [Chrome](https://chromewebstore.google.com/detail/idm-integration-module/ngpampappnmepgilojfohadhhmbhlaek) / Windows
* [Go Speed](https://gopeed.com/) - Download Manager / All Platforms / [Extension](https://github.com/GopeedLab/browser-extension) / [Plugins](https://github.com/search?q=topic%3Agopeed-extension&type=repositories) / [GitHub](https://github.com/GopeedLab/gopeed)
* [Rayburst](https://rayburst.pages.dev) - Download Manager / [GitHub](https://github.com/AnInsomniacy/rayburst)
* [FDM](https://www.freedownloadmanager.org/) - Download Manager / [YTDL Addon](https://github.com/meowcateatrat/elephant) / [Firefox](https://addons.mozilla.org/en-US/firefox/addon/free-download-manager-addon/) / [Chrome](https://chrome.google.com/webstore/detail/free-download-manager-chr/ahmpjcflkgiildlgicmcieglgoilbfdp/RK%3D2/RS%3DfQzscgKGm9aMezJJ7Gf2Fcc.JSo-) / Windows, macOS, Linux, Android
* [Brisk](https://github.com/BrisklyDev/brisk/) / Windows, macOS, Linux
* [Plexo](https://anmolkapil.github.io/plexo) - Multi-Connection / Windows, macOS, Linux / [GitHub](https://github.com/anmolkapil/plexo)
* [⁠HDM](https://hydra.javad.dev/) - Multi-Connection / Windows, macOS, Linux / [GitHub](https://github.com/ja7ad/hydra)
* [imFile](https://imfile.org/) / Windows, macOS, Linux / [GitHub](https://github.com/imfile-io/imfile-desktop)
* [⁠Aria2 Next](https://github.com/AnInsomniacy/aria2-next) or [aria2](https://aria2.github.io/) / [GitHub](https://github.com/aria2/aria2) - Terminal Download Manager / [Download Bot](https://github.com/gaowanliang/DownloadBot) / [WebUI](https://github.com/ziahamza/webui-aria2), [2](https://ariang.mayswind.net/) / Windows, macOS, Android
* [Persepolis](https://persepolisdm.github.io/) - Download Manager / Windows, macOS, Linux / [GitHub](https://github.com/persepolisdm/persepolis)
* [pyLoad](https://pyload.net/) - Lightweight Download Manager / Windows, macOS, Linux / [GitHub](https://github.com/pyload/pyload)
* [ArrowDL](https://www.arrow-dl.com/) - Download Manager / [Firefox](https://addons.mozilla.org/en-US/firefox/addon/arrow-dl/) / [Chrome](https://chrome.google.com/webstore/detail/arrow-dl/modofbhnhlagjmejdbalnijgncppjeio) / Windows, macOS, Linux / [GitHub](https://github.com/setvisible/ArrowDL)
* [Varia](https://github.com/giantpinkrobots/varia) - Download Manager / [Firefox](https://addons.mozilla.org/firefox/addon/varia-integrator/) / [Chrome](https://chrome.google.com/webstore/detail/dacakhfljjhgdfdlgjpabkkjhbpcmiff) / [Extesnsion](https://github.com/BrisklyDev/brisk-browser-extension) / Windows, macOS, Linux
* [⁠Surge](https://github.com/surge-downloader/surge) - TUI Download Manager / [Firefox](https://addons.mozilla.org/en-US/firefox/addon/surge/) / Windows, macOS, Linux
* [Cyberdrop-DL](https://pypi.org/project/cyberdrop-dl-patched) - TUI Download Manager / [GitHub](https://github.com/Cyberdrop-DL/cyberdrop-dl) / Windows, macOS, Linux
* [DownThemAll](https://www.downthemall.org/) - Download Management Extension / [Firefox](https://addons.mozilla.org/addon/downthemall/) / [Chrome](https://chrome.google.com/webstore/detail/downthemall/nljkibfhlpcnanjgbnlnbjecgicbjkge) / [GitHub](https://github.com/downthemall/downthemall)
* [HTTP Downloader](https://erickutcher.github.io/) - Download Manager for HTTP / FTP / SFTP / [Firefox](https://addons.mozilla.org/en-US/firefox/addon/http-downloader/) / [Chrome](https://github.com/erickutcher/httpdownloader/releases/download/CE_v1.0.2.8/HTTP_Downloader_Chrome_Extension.crx) / Windows / [GitHub](https://github.com/erickutcher/httpdownloader)

***

## ▷ Archiving / Compression

* 🌐 **[SuperCompression](https://supercompression.org/)** - File Compression Resources
* ⭐ **[NanaZip](https://nanazip.org/)** / [GitHub](https://github.com/M2Team/NanaZip) or **[7-Zip](https://www.7-zip.org/)** / [GitHub](https://github.com/ip7z/7zip) - File Archiver
* ⭐ **[PeaZip](https://peazip.github.io/)** - Cross-Platform File Archiver / [GitHub](https://github.com/peazip/PeaZip/)
* ⭐ **[CompactGUI](https://github.com/IridiumIO/CompactGUI)** - Transparent Compression
* [Fileforums](https://fileforums.com/) or [Encode](https://encode.su/) - Data Compression Forums
* [TurboBench](https://github.com/powturbo/TurboBench) - Compression Benchmark
* [⁠HatchZip](https://hatchzip.dev/) - Extract Archives While Freeing Disk Space / [GitHub](https://github.com/xevrion/hatchzip)
* [Efficient Compression Tool](https://github.com/fhanau/Efficient-Compression-Tool) or [Minuimus](https://birds-are-nice.me/software/minuimus.html) - File Archivers / Optimizers
* [ezyZip](https://www.ezyzip.com/) - Zip Files Online
* [unzip-online](https://unzip-online.com/en) - Unzip Files Online
* [Unrar online](https://unrar.online/) - Unrar Files Online
* [WinRAR](https://www.win-rar.com/), [2](https://www.rarlab.com) - File Archiver / [Remove Popups](https://rentry.co/FMHYB64#winrar) / [Update (Important)](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/winrar-critical.md)
* [ouch](https://crates.io/crates/ouch) - Archiving / Compression CLI / [GitHub](https://github.com/ouch-org/ouch)
* [UPX](https://upx.github.io/) - Executable File Compressor / [GitHub](https://github.com/upx/upx)

***

## ▷ File Converters

* ⭐ **[File Converter](https://file-converter.io/)** - Offline / Convert & Compress Files / Windows / [GitHub](https://github.com/Tichau/FileConverter) / [Warning](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/file-converter-critical.md)
* ⭐ **[VERT](https://vert.sh/)** - Offline / Some Video Conversions Require Servers / Web / [Discord](https://discord.gg/8XXZ7TFFrK) / [GitHub](https://github.com/VERT-sh/VERT)
* ⭐ **[Convert to it!](https://p2r3.github.io/convert/)** - Offline / File Converter / Web / [GitHub](https://github.com/p2r3/convert)
* ⭐ **[Aconvert](https://www.aconvert.com/)** - Online / Various Converters / 40MB / Web
* [⁠Docling](https://docling-project.github.io/docling/) / [GitHub](https://github.com/docling-project/docling) or [Pandoc](https://pandoc.org/) / [GitHub](https://github.com/jgm/pandoc) - PDF / Documents CLI Converters
* [ConvertCSV](https://www.convertcsv.com/) - Online CSV Data Conversion / Web
* [Filee](https://filee.sh/) - Offline / Drag & Drop File Converter / Windows, macOS, Linux / [GitHub](https://github.com/KnifeLemon/Filee)
* [Encoding Converter](https://encoding-converter.netlify.app/) - Online File Encoding Converter / Web
* [Deark](https://entropymine.com/deark/) - Decode and Convert Files / Windows, macOS, Linux / [GitHub](https://github.com/jsummers/deark)
* [text2img](https://master.ayra.ch/text2img/) - Local NFO Files to Image Converter / Web / [GitHub](https://github.com/AyrA/text2img)
* [Xconvert](https://www.xconvert.com) - Online / File Converter / 400MB / Web
* [FreeConvert](https://www.freeconvert.com/) - Online / Unlimited / Clear Cookies / Web
* [Convertio](https://convertio.co/) - Online / File Converter / 100MB / Web
* [AnyConvert](https://anyconv.com/) - Online / File Converter / 100MB / Web
* [MiConv](https://miconv.com/) - Online / File Converter / 75MB / Web
* [⁠Docpose](https://docpose.cloud/convert) - Online / File Converter / 25MB / Web
* [videoutils](https://www.videoutils.com/) - Online / File Converter / 500MB / Web
* [ConvertFiles](https://www.convertfiles.com/) - Online / File Converter / 250MB / Web
* [⁠ConvertX](https://github.com/C4illin/ConvertX) or [Transmute](https://transmute.sh/) / [GitHub](https://github.com/transmute-app/transmute) - Self-Hosted File Converters

***

## ▷ File Managers

* ⭐ **[Directory Opus](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/download#wiki_.25BA_software_sites)** (search) - Windows File Manager
* [DoubleCMD](https://doublecmd.sourceforge.io/) / [GitHub](https://github.com/doublecmd/doublecmd) or [muCommander](https://www.mucommander.com/) / [GitHub](https://github.com/mucommander/mucommander) - Cross-Platform File Managers
* [Sigma](https://sigma-file-manager.vercel.app) - Modern File Manager / [GitHub](https://github.com/aleksey-hoffman/sigma-file-manager)
* [Yazi](https://yazi-rs.github.io/) / [GitHub](https://github.com/sxyazi/yazi) or [superfile](https://superfile.dev/) / [GitHub](https://github.com/yorukot/superfile) - Terminal File Managers
* [OneCommander](https://www.onecommander.com/) - File Manager
* [FreeCommander](https://freecommander.com/) - File Manager
* [Q-Dir](https://www.softwareok.com/?seite=Freeware/Q-Dir) - File Manager
* [Files](https://files.community/) - Customizable File Manager / Use Classic Installer / [Discord](https://discord.gg/files) / [GitHub](https://github.com/files-community/Files)
* [Explorer++](https://explorerplusplus.com/) - Lightweight Windows File Manager / [GitHub](https://github.com/derceg/explorerplusplus)
* [Far Manager](https://www.farmanager.com/) - File / Archive Manager / [GitHub](https://github.com/FarGroup/FarManager)
* [Total Commander](https://www.ghisler.com/) - Shareware File Manager
* [Tablacus Explorer](https://tablacus.github.io/explorer_en.html) / [GitHub](https://github.com/tablacus/TablacusExplorer) or [Multi Commander](https://multicommander.com/) - Tab File Managers
* [Vifm](https://vifm.info/) - Vim-Based File Manager / [GitHub](https://github.com/vifm/vifm)
* [eza](https://eza.rocks/) / [GitHub](https://github.com/eza-community/eza) or [lsd](https://github.com/lsd-rs/lsd) - Modern `ls` Replacements
* [FileBrowser Quantum](https://filebrowserquantum.com/) / [GitHub](https://github.com/gtsteffaniak/filebrowser) or [⁠copyparty](https://github.com/9001/copyparty/) - Self-Hosted Web File Managers

***

## ▷ File Searching

* ⭐ **[Everything](https://voidtools.com/)** - File Search Engine / [Date Searching](https://rentry.co/etfd) / [Taskbar Integration](https://github.com/srwi/EverythingToolbar)
* [Recoll](https://www.recoll.org/) / [Addon](https://addons.mozilla.org/en-US/firefox/addon/recoll-we/), [DocFetcher](https://docfetcher.sourceforge.io/) or [Orange](https://0-range.github.io/) - Cross-Platform Search Engines
* [AnyTXT](https://anytxt.net/) or [WizFile](https://antibody-software.com/wizfile/) - Windows Search Engines
* [AstroGrep](https://sourceforge.net/projects/astrogrep/), [grepWin](https://github.com/stefankueng/grepWin) or [dnGrep](https://dngrep.github.io/) - Windows GUI Grep Utilities
* [fselect](https://github.com/jhspetersson/fselect) - SQL-like Search Engine
* [fd](https://github.com/sharkdp/fd) - User Friendly "find" Alternative
* [sist2](https://github.com/simon987/sist2) - Simple Incremental Search Tool

***

## ▷ File Encryption

* ⭐ **[Cryptomator](https://cryptomator.org/)** / [GitHub](https://github.com/cryptomator/cryptomator) or [Tahoe-LAFS](https://github.com/tahoe-lafs/tahoe-lafs) - Cloud File Encryption
* ⭐ **[VeraCrypt](https://www.veracrypt.fr/en/Home.html)** - Disk Encryptor / Use w/ External Drives / [GitHub](https://github.com/veracrypt/VeraCrypt)
* [age](https://github.com/FiloSottile/age) or [⁠rage](https://github.com/str4d/rage) - File Encryptor
* [Picocrypt-NG](https://github.com/Picocrypt-NG/Picocrypt-NG) - File Encryptor
* [gocryptfs](https://github.com/bailey27/cppcryptfs) - File Encryptor
* [Kryptor](https://www.kryptor.co.uk/) - File Encryptor
* [⁠VERNAM](https://vernam.app/) - File Encryptor / Web / [GitHub](https://github.com/LifetimeLabsDev/VERNAM)
* [⁠AES-256-GCM](https://d9.codeberg.page/aes-256-gcm-file-encryption.html) - AES-256-GCM File Encryptor / Web

***

## ▷ File Sync

* ⭐ **[SyncThing](https://syncthing.net/)** - Cross-Platform File Sync / [Android](https://github.com/researchxxl/syncthing-android), [2](https://github.com/chenxiaolong/BasicSync) / [Tray Support](https://martchus.github.io/syncthingtray/) / [GitHub](https://github.com/syncthing/syncthing)
* ⭐ **[FreeFileSync](https://freefilesync.org/)** - Open-Source File Sync
* [MyPhoneExplorer](https://www.fjsoft.at/) or [SyncFolder](https://apps.microsoft.com/detail/9nc73mjwhsww?rtc=1&hl=en-us&gl=US) - Phone and Desktop Sync
* [Resilio](https://www.resilio.com/individuals/) - P2P File Sync
* [⁠TangoShare](https://tangoshare.com/) - P2P File Sync
* [⁠SpaceDrop](https://spacedrop.app/) - P2P File Sync
* [⁠SpectrShare](https://spectrshare.com/) - P2P File Sync
* [rsync](https://rsync.samba.org) - Command-line File Sync / [GitHub](https://github.com/RsyncProject/rsync)
* [Unison](https://github.com/bcpierce00/unison) - Bidirectional File Sync

***

## ▷ File Backup

* ⭐ **[restic](https://restic.net/)** - Secure File Backup / [GitHub](https://github.com/restic/restic)
* ⭐ **[Kopia](https://kopia.io/)** - Encrypted File Backup / [GitHub](https://github.com/kopia/kopia/)
* ⭐ **[Rescuezilla](https://rescuezilla.com/)** / [GitHub](https://github.com/rescuezilla/rescuezilla) or [CloneZilla](https://clonezilla.org/) - Disk Image Backup
* [Echosync](https://www.luminescence-software.org/en/echosync/about/) - Folder Clone / Backup
* [BackupPC](https://backuppc.github.io/backuppc/) - Networked File Backup
* [TeraCopy](https://www.codesector.com/teracopy) - Copy Files Quickly / More Securely
* [UrBackup](https://www.urbackup.org/) - Client / Server File Backup
* [duplicity](https://duplicity.gitlab.io/) - File Backup
* [Duplicati](https://www.duplicati.com/) - File Backup
* [Borg](https://www.borgbackup.org/) - De-duplicating File Backup / [WebUI](https://github.com/karanhudia/borg-ui) / [GitHub](https://github.com/borgbackup/borg)
* [USBImager](https://bztsrc.gitlab.io/usbimager/) - USB Image Backup

***

## ▷ File Recovery

* ⭐ **[TestDisk](https://www.cgsecurity.org/wiki/TestDisk)** - File Recovery / [Source Code](https://git.cgsecurity.org/cgit/testdisk/tree/)
* [DMDE](https://dmde.com/) - File Recovery
* [PhotoRec](https://www.cgsecurity.org/wiki/PhotoRec) - File Recovery
* [Windows File Recovery](https://apps.microsoft.com/detail/9n26s50ln705) - File Recovery
* [MultiPar](https://github.com/Yutaka-Sawada/MultiPar) - Prevent File Corruption / [Guide](https://youtu.be/5TsExiAsCXA)
* [ShadowCopyView](https://www.nirsoft.net/utils/shadow_copy_view.html/) - Shadow Copy Explorers

***

## ▷ File Info / Metadata

* ↪️ **[Image Metadata Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25B7_photo_forensics_.2F_metadata)**
* ↪️ **[Audio Metadata Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/audio#wiki_.25B7_audio_metadata)**
* ⭐ **[Fileinfo](https://fileinfo.com/)** or [Filext](https://filext.com/) - File Extension Libraries
* ⭐ **[Phockup](https://github.com/ivandokov/phockup)** - Organize Photos / Videos by EXIF Date
* [⁠HashCheck](https://github.com/idrassi/HashCheck), [⁠HashMyFiles](https://www.nirsoft.net/utils/hash_my_files.html) or [RapidCRC Unicode](https://github.com/OV2/RapidCRC-Unicode) - Checksum / Hash Verifier
* [MediaInfo](https://mediaarea.net/en/MediaInfo) - Media File Analysis / Metadata Viewer / [Online](https://mediaarea.net/MediaInfoOnline)
* [MediaPeek](https://mediapeek.plnk.workers.dev/) - Online Media File Analysis / Metadata Viewer / [GitHub](https://github.com/luminalreason/mediapeek)
* [ExtractMetadata](https://www.extractmetadata.com/), [⁠FilesMD](https://www.filesmd.com/) or [Metadata2Go](https://www.metadata2go.com/) - Metadata Viewers / Editors
* [⁠PrivMeta](https://www.privmeta.com/) / [GitHub](https://github.com/DScaife/privmeta/), [MetaStrip](https://metastrip.app/) / [GitHub](https://github.com/lars-1987/metastrip), [Metadata Remover](https://ianonymous3000.github.io/metadata-remover/) / [GitHub](https://github.com/iAnonymous3000/metadata-remover) or [mat2](https://github.com/jvoisin/mat2) / [Web Version](https://0xacab.org/jvoisin/mat2-web) - Remove Metadata from Files
* [Attribute Changer](https://www.petges.lu/) - Edit File & Folder Properties
* [WhatsLink](https://whatslink.info/) - View File Download Web Metadata
* [Magika](https://github.com/google/magika) or [TridUI](https://github.com/JMcrafter26/TridUI) - File Type Detection Tools
* [TagSpaces](https://www.tagspaces.org/) or [Tagging for Windows](https://www.taggingforwindows.com/) - Tag-Based File Systems
* [SKTimeStamp](https://tools.stefankueng.com/SKTimeStamp.html) - Change File Created / Modified Time

***

## ▷ Formatting / Deletion

* ⭐ **[SDelete](https://learn.microsoft.com/en-us/sysinternals/downloads/sdelete)** - File Deletion CLI
* [Eraser](https://eraser.heidi.ie/), [File Shredder](https://fileshredder.org/), [Alternate File Shredder](https://www.alternate-tools.com/pages/c_fileshredder.php?lang=ENG) or [Delapp](https://github.com/differentrain/Delapp) - File Shredding
* [Parted Magic](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/download#wiki_.25BA_software_sites) (search) - Disk Partitioning / Data Recovery
* [SSuite File Shredder and Burner](https://www.ssuiteoffice.com/software/ssuitefileshredder.htm) - File Shredder with Disk Burning
* [Low Level Format](https://www.lowlevelformat.info/), [nwipe](https://github.com/martijnvanbrummelen/nwipe) or [ShredOS](https://github.com/PartialVolume/shredos.x86_64) - Complete Hard Drive Erasers
* [RED](https://www.jonasjohn.de/red.htm) - Remove Empty Directories

***

## ▷ Data Automation

* ⭐ **[Advanced Renamer](https://www.advancedrenamer.com/)**, [PowerRename](https://learn.microsoft.com/en-us/windows/powertoys/powerrename), [Szyszka](https://github.com/qarmin/szyszka), [F2](https://github.com/ayoisaiah/f2), [Ant Renamer](https://www.antp.be/software/renamer), [Flut Renamer](https://github.com/sun-jiao/flut-renamer) or [Bulk Rename Utility](https://www.bulkrenameutility.co.uk/) - Bulk Renamers
* [FoliCon](https://dineshsolanki.github.io/FoliCon/) - Automatic Custom Media Icons / Folders / [GitHub](https://github.com/DineshSolanki/FoliCon)
* [MediaMonkey](https://www.mediamonkey.com/) - Media Organizer
* [tinyMediaManager](https://www.tinymediamanager.org/) or [MediaElch](https://www.kvibes.de/mediaelch/) - Media Collection Managers
* [FileBot](https://www.filebot.net/) - Media File Renaming
* [TVRename](https://www.tvrename.com/) or [⁠Rename My TV Series](https://www.tweaking4all.com/home-theatre/rename-my-tv-series-v2/) - TV File Data Automation
* [Shoko](https://github.com/shokoanime) - Anime File Data Automation

***

# ► PDF Tools

* [PDFGrep](https://pdfgrep.org/) or [OCRmyPDF](https://github.com/ocrmypdf/OCRmyPDF) - PDF Text Search
* [PDFEncrypt](https://pdfencrypt.net/) - PDF File Encryption
* [GraphPaper](https://incompetech.com/graphpaper/) - PDF Graphs
* [PDF Bookmark Editor](https://mrfragger.github.io/pdf-bookmark-editor/) - PDF Bookmark Editor / [GitHub](https://github.com/mrfragger/pdf-bookmark-editor)
* [PDF Fixer](https://pdffixer.com/) - Repair Damaged PDFs
* [OpenSign](https://github.com/OpenSignLabs/OpenSign), [Signature PDF](https://pdf.24eme.fr/) / [GitHub](https://github.com/24eme/signaturepdf), [FalsiScan](https://gitlab.com/edouardklein/falsisign) or [Adobe Sign](https://www.adobe.com/acrobat/online/sign-pdf.html) - PDF Signature Tools
* [Google Drive PDF Downloader](https://github.com/zeltox/Google-Drive-PDF-Downloader) - Download Protected Google Drive PDFs
* [PDFCoffee](https://pdfcoffee.com/) - Upload PDF, Word or PowerPoint Files
* [PrintFriendly](https://www.printfriendly.com/) - Printer Formatting Tools

***

## ▷ Online PDF Toolkits

* ⭐ **[⁠ihatepdf](https://www.ihatepdf.cv/)** - Client-Side
* ⭐ **[BentoPDF](https://bentopdf.com/)** or [File PDF](https://filepdf.net/) - Client-Side / [GitHub](https://github.com/alam00000/bentopdf)
* [BreezePDF](https://breezepdf.com/) - Client-Side
* [⁠PDFKing](https://pdfking.app/) - Client-Side
* [PDFCraft](https://pdfcraft.devtoolcafe.com/) - Client-Side / [GitHub](https://github.com/PDFCraftTool/pdfcraft)
* [⁠itinypdf](https://itinypdf.com/) - Client-Side
* [PDFWix](https://pdfwix.com/), [2](https://pdfwix.github.io/pdfwix/) - Client-Side
* [⁠PDFkind](https://pdfkind.com/) - Client-Side
* [DigiPDF](https://digipdf.app/?lang=en_US) - Client-Side / [Source Code](https://codeberg.org/ladigitale/digipdf)
* [Sejda](https://www.sejda.com/) - Server-Side
* [ILovePDF](https://www.ilovepdf.com/) - Server-Side
* [⁠PDFResizer](https://pdfresizer.com/) - Server-Side
* [PDF2Go](https://www.pdf2go.com/) - Server-Side
* [DPDF](https://dpdf.com/) - Server-Side
* [Digiparser](https://www.digiparser.com/free-tools/pdf) - Server-Side

***

## ▷ Offline PDF Toolkits

* ⭐ **[Stirling](https://stirling.com/)** / Windows, macOS, Linux / [GitHub](https://github.com/Stirling-Tools/Stirling-PDF)
* ⭐ **[PDF24](https://www.pdf24.org/)** / Web-Based / Windows
* [⁠PDF4QT](https://jakubmelka.github.io/) / Windows, Linux / [GitHub](https://github.com/JakubMelka/PDF4QT)
* [Foxit](https://www.foxit.com/pdf-reader/) / All Platforms / [Features](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/download#wiki_.25BA_software_sites) (search) / [Warning](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/foxit-critical.md)
* [xPDFReader](https://www.xpdfreader.com/) / Windows, macOS, Linux
* [PDF Arranger](https://github.com/pdfarranger/pdfarranger) / Windows, Linux

***

## ▷ PDF Conversion Tools

* [Rare2PDF](https://rare2pdf.com/), [online2pdf](https://online2pdf.com/) or [2PDFConverter](https://www.2pdfconverter.com/) - File to PDF Conversion
* [⁠Tideflow](https://github.com/BDenizKoca/Tideflow-md-to-pdf) or [MD2PDF](https://md2pdf.netlify.app/) - Markdown to PDF Converters
* [PDFconvert](https://docupub.com/pdfconvert/) - PDF File Converters
* [Marker](https://github.com/VikParuchuri/marker) - PDF to Markdown
* [PDFCrowd](https://pdfcrowd.com/), [TailWindPDF](https://tailwindpdf.com/) or [wkhtmltopdf](https://wkhtmltopdf.org/) - HTML to PDF / Image Converter
* [Issuu](https://issuu.com/) - Convert PDF Files to Webpages, Flipbooks, Brochures & More / [Downloader](https://docdownloader.com/)
* [WebToPDF](https://webtopdf.com/) or [Percollate](https://github.com/danburzo/percollate) - Webpage to PDF Converters
* [Dangerzone](https://dangerzone.rocks/) - Convert Malicious PDFs to Safe Files / [GitHub](https://github.com/freedomofpress/dangerzone)

***

# ► File Transfer

* ⭐ **[LocalSend](https://localsend.org/)** - Local / All Platforms / [Web Version](https://web.localsend.org/) / [Discord](https://discord.com/invite/GSRWmQNP87) / [Subreddit](https://www.reddit.com/r/localsend/) / [GitHub](https://github.com/localsend/localsend)
* ⭐ **[Blip](https://blip.net/)** - Hybrid / Turn "Searchable by Name" Off in Settings / Windows, macOS, Linux, Android, iOS
* [Photon](https://photondev.netlify.app/) - Local / Windows, macOS, Linux, Android / [GitHub](https://github.com/abhi16180/photon)
* [KDE Connect](https://kdeconnect.kde.org/) - Local / All Platforms / [Source Code](https://kdeconnect.kde.org/get-involved.html)
* [Wormhole](https://wormhole.app/) - Online / Web / [Discord](https://discord.com/invite/de6FscsK5Z) / [GitHub](https://github.com/webtorrent/wormhole-crypto)
* [SEAL](https://seal.net/) - Online / Browser Encryption / No signup / Web
* [Warpinator](https://github.com/linuxmint/warpinator) - Local / Windows, Linux, Android
* [⁠Phone Link](https://www.microsoft.com/windows/sync-across-your-devices) - Hybrid / Windows, Android, iOS
* [Google Quick Share](https://www.android.com/quick-share/) - Hybrid / Windows, Android, iOS
* [Sefirah](https://github.com/shrimqy/Sefirah) - Local / Windows, Android
* [⁠D-LAN](https://github.com/Ummon/D-LAN) - Local / Windows, macOS, Linux
* [⁠AlterSend](https://github.com/denislupookov/altersend) - Online / Windows, macOS, Linux, Android, iOS
* [QRServ](https://play.google.com/store/apps/details?id=dev.uint.qrserv) - Local / Android / [GitHub](https://github.com/uintdev/qrserv)
* [Magic Wormhole](https://github.com/magic-wormhole/magic-wormhole) - Online / Windows, macOS, Linux, Android
* [croc](https://getcroc.com/) - Online / Windows, macOS, Linux, Android / [GUI](https://github.com/howeyc/crocgui) / [GitHub](https://github.com/schollz/croc)
* [LANDrop](https://landrop.app/) - Local / All Platforms / [Discord](https://discord.com/invite/5adm6sPugT) / [X](https://x.com/LANDropApp)
* [NahrajSoubor](https://new.nahrajsoubor.cz/) - Online / Web
* [FilePizza](https://file.pizza/) - Online / Web
* [Free Transfer](https://transfert.free.fr/upload) - Online / Web
* [IPFS](https://ipfs.tech/) - Desktop / Mobile Transfer / [Discord](https://discord.gg/vj7qWuAyHY)
* IPFS Tools - [Resources](https://awesome.ipfs.tech/), [2](https://github.com/ipfs/awesome-ipfs) / [Extension](https://github.com/ipfs/ipfs-companion) / [Desktop](https://github.com/ipfs/ipfs-desktop) / [IPFS Cluster](https://ipfscluster.io/)
* [aQRoss](https://aqross.app/) / Web or [qrcp](https://qrcp.sh/) / Share Files Using QR Codes / Windows, macOS, Linux / [GitHub](https://github.com/claudiodangelis/qrcp)
* [OnionShare](https://onionshare.org/) - Share Files Over Tor Network / Windows, macOS, Linux, Android, iOS / [GitHub](https://github.com/onionshare/onionshare)
* [FileZilla](https://filezilla-project.org/) - FTP Client / Windows, macOS, Linux / [Warning](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/filezilla-critical.md)
* [⁠Sendme](https://www.iroh.computer/sendme) / [GitHub](https://github.com/n0-computer/sendme) or [DashBeam](https://dashbeam.net/) / [GitHub](https://github.com/tonyantony300/dashbeam) - File Transfer CLIs
* [termscp](https://termscp.rs/) - File Transfer TUI / [GitHub](https://github.com/veeso/termscp)
* [WinSCP](https://winscp.net/eng/index.php) - FTP Client / Windows
* [⁠robocopy](https://learn.microsoft.com/windows-server/administration/windows-commands/robocopy) - Windows Built-In File Transfer Guide / [WebUI](https://ar-puuk.github.io/robocopy-gui/)

***

## ▷ P2P Transfer

* ⭐ **[PairDrop](https://pairdrop.net/)** / [GitHub](https://github.com/schlagmichdoch/pairdrop) or [⁠Snapdrop](https://node-snapdrop.onrender.com/) / Web
* ⭐ **[JustBeamIt](https://justbeamit.com/)** / Web
* [Surge](https://github.com/rule110-io/surge) - P2P App / Windows, macOS
* [ToffeeShare](https://toffeeshare.com/) / Web / [GitHub](https://github.com/ToffeeShare)
* [⁠Station307](https://www.station307.com/) / Web
* [new.space](https://new.space/) / iOS, Web
* [WebWormhole](https://webwormhole.com/) - [Chrome](https://chromewebstore.google.com/detail/webwormhole/jhombkhjanncdalcbcahinpjoacaiidn) / [Firefox](https://addons.mozilla.org/en-US/firefox/addon/webwormhole/) / Windows, macOS, Linux, Web / [GitHub](https://github.com/saljam/webwormhole)
* [⁠Clip Fish](https://clip.fish/) / Web / [GitHub](https://github.com/clip-fish/web)

***

# ► File Hosts

* **Note** - Remember it's **never** a good idea to upload personal or confidential files to any file host, even if they claim to be encrypted. Most file hosts only remove files after inactivity, while some delete them regardless. Check each host if you're concerned about file expiry. Tags are: Total Storage (x days w/ acc) / Max File Size / File Expiry (x days w/ acc) / Signup Requirements.

***

* 🌐 **[⁠Matcha](https://www.matchaup.my/)** - File Host Statuses / Index
* 🌐 **[Awesome File Hosts](https://fhhy.vercel.app/)** / [GitHub](https://github.com/FahadBinHussain/awesome-file-hosts) or **[PolyUpload File Hosts](https://github.com/spel987/PolyUploader?tab=readme-ov-file#-hosts)** - File Host Indexes
* ↪️ **[Video File Hosts](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video-tools#wiki_.25B7_video_file_hosts)**
* ↪️ **[Image File Hosts](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25B7_image_hosts)**
* ⭐ **[Gofile](https://gofile.io/)** - 1TB Monthly / Unlimited / 10 Days After Last Download / [Manager Export](https://greasyfork.org/en/scripts/515250)
* ⭐ **[Pixeldrain](https://pixeldrain.com/)** - 10GB / 60 Days After Last Download (10% min) / Signup Required for Upload / [Mirrors](https://docs.pixeldrain.com/questions_and_answers/#alternative-domain-names) / [Speedtest](https://pixeldrain.com/speedtest) / [Bypass](https://pixeldrain-bypass.gamedrive.org/) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/pixeldrain.md)
* ⭐ **[Mocha](https://mocha.my/)** - 150GB (w/ Account) / 20GB / 30 Days After Last Download / Signup Required / [Multi-Tool App](https://github.com/nxllvxxd/Mocha-Tools) / [Lite Version](https://lite.mocha.my/) (500MB, No Signup) / [Discord](https://discord.gg/hWPqHpCD3A)
* ⭐ **[VikingFile](https://vikingfile.com/)** - Unlimited / 15 Days After Last Download / Use Adblock / [Discord](https://discord.gg/EPEFC6KkpF)
* ⭐ **[⁠DropDrive](https://dropdrive.org/)** - 100GB / 60 Days After Last Download / [Discord](https://discord.com/invite/YSABtmnD7a)
* ⭐ **[Pillowcase](https://pillows.su/)** - Audio File Host / 200MB (500MB w/ Account) / Forever
* [Send.now](https://send.now/) - 100GB / 15 Days After Last Download (w/ Account)
* [⁠Patrins](https://patrins.com/) - 1TB / 7 Days / Requires Signup / [Discord](https://discord.gg/TrSHTfUaSN)
* [FileDitch](https://new.fileditch.com/) - 150GB / 45 Days / [Discord](https://discord.gg/gACnap5kKx)
* [⁠Luffy Files](https://luffyfiles.com/) - 10GB / 30 Days w/ Account
* [⁠Filekeeper](https://filekeeper.net/) - Unlimited / 7 Days After Last Download / Requires Signup
* [⁠storage.to](https://storage.to/) - 25GB / 7 Days
* [⁠filez.stream](https://filez.stream/) - 500GB / 60 Days After Last Download
* [Litterbox](https://litterbox.catbox.moe/) - 1GB / 3 Days
* [Catbox](https://catbox.moe/) - 200MB / Forever (w/ Account) / 2 Years (Inactive Files w/ no Account) / [Proxy](https://fatbox.moe/)
* [Transfer.it](https://transfer.it/) - Unlimited / 90 Days / Owned by MEGA.nz
* [MediaFire](https://www.mediafire.com/) - 4GB / Forever
* [⁠CryptFiles](https://cryptfiles.cloud/) - 10GB / Up to 30GB (active) / 1 Year (inactive)
* [⁠pone](https://pone.rs/) - 1GB / Forever
* [⁠Plik](https://up2store.de/) - 50GB / Forever
* [⁠MaraFile](https://marafile.cc/) - 1GB / Forever
* [Hxfile](https://hxfile.co/), [2](https://down.mdiaload.com/), [3](https://down.fast-down.com/) - 5GB / 180 Days After Last View
* [DataNodes](https://datanodes.to/) - 5GB / 5 Days (After Last Download) / 25GB / 7 Days After Last Download (w/ Account) / **Use uBlock** / [Discord](https://discord.gg/mKyBMyeKvh)
* [⁠Filester](https://filester.me/), [2](https://filester.sh/), [3](https://filester.si/), [4](https://filester.gg/) - 10GB / 45 Days After Last Download
* [⁠Stashr](https://stashr.wtf/) - 1GB / 30 days
* [⁠ATM](https://atm.rip/) - 10GB / Forever
* [eDisk](https://www.edisk.cz/) - 10GB / 30 Days
* [⁠Origrid](https://origrid.io/) - 100GB / 25GB / 7 Days After Last Download (30 w/ Account, Never w/ Plus)
* [⁠DropMeFiles (ua)](https://dropmefiles.com.ua/) - 100GB / 14 Days
* [⁠filedrop](https://r7zxn.cc/filedrop/) - 10GB / 30 Days / [Source Code](https://codeberg.org/r7zxn/filedrop)
* [hostb](https://hostb.org/) - Unlimited / 30 Days After Last Download / [Source Code](https://r-w-x.org/r/hostb.git)
* [MixDrop](https://mixdrop.ag/) - Unlimited / 60 Days / Requires Signup
* [1fichier.com](https://1fichier.com/) - 300GB / 15 Days (30 Days w/ Account)
* [Filebin](https://filebin.net/) - Unlimited / 6 Days / [Warning](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/filebin-critical.md)
* [file.kiwi](https://file.kiwi/) - Unlimited / 90 Hours / [File Expiry](https://file.kiwi/price)
* [FileFast](https://file.fast/) - 5GB / Unlimited / [Discord](https://discord.com/invite/PnHjVGfjQa)
* [⁠UpZur](https://upzur.com/) - 5GB / 1.95TB / 120 Days After Last Download / Requires Signup
* [Upload.bg](https://upload.bg/) - 10GB / 30 Days
* [⁠Zipyshare](https://zipyshare.com/) - 5GB / 7 Days After Last Download / Longer for Smaller Files
* [FEX.NET](https://fex.net/) - 100GB / 7 Days / [Telegram](https://t.me/FEXNETWORK)
* [DropMeFiles](https://dropmefiles.com/) - 50GB / 14 Days
* [⁠MixLoads](https://mixloads.to/) - 25.6GB / 2TB / 60 Days After Last Download / Requires Signup
* [⁠Transfr](https://www.transfr.me/) - 100GB / 7 Days
* [GigaFile](https://gigafile.nu/) - 300GB / 100 Days
* [⁠FilesYard](https://filesyard.com/) - 10GB / 15 Days
* [UploadNow](https://uploadnow.io/) - 100GB / 7 Days After Last Download
* [SwissTransfer](https://www.swisstransfer.com/) - 50GB / 30 Days / 250 Downloads
* [Depositfiles](https://depositfiles.com/) - 10GB / 90 Days
* [⁠TheUserCloud](https://theuser.cloud/) - 10GB / 60 Days
* [Hexupload](https://hexload.com/) - 15GB / 30 Days
* [Tempcloud](https://temp.kotol.cloud/) - 10GB / 3 Days
* [GrosFichiers](https://www.grosfichiers.com/) - 10GB / 14 Days
* [Imagenetz](https://www.imagenetz.de/?setLang=en) - 5GB / 30 Days After Last Download
* [FilePort](https://fileport.io/) - 5GB / 7 Days
* [MegaUp](https://megaup.net/) - 5GB / 30 Days
* [uDrop](https://www.udrop.com/) - 5GB / Forever
* [⁠2share](https://2share.su/) - 2GB / Forever
* [⁠NippyDrop](https://nippydrop.com/) - 2GB / 90 Days
* [FireLoad](https://www.fireload.com/) - 2GB / 60 Days / Requires Signup
* [⁠Savedly](https://savedly.net/) - Unlimited / 7 Days
* [Filegoat](https://filego.at/) - 5GB / 90 Days After Last View
* [Bestfile](https://bestfile.io/) - 5GB / 80 Days After Last Download
* [ufile.io](https://ufile.io/) - 5GB / 30 Days
* [Internxt Send](https://send.internxt.com/) - 5GB / 15 Days
* [⁠SendGB](https://www.sendgb.com/) - 5GB / 7 Days
* [Send](https://send.vis.ee/) - 2.5GB / 3 Days / 30 Downloads / [CLI](https://github.com/timvisee/ffsend) / [Instances](https://gitlab.com/timvisee/send-instances)
* [⁠JuiceBox](https://box.juicey.dev/) - 15GB / 14 Days
* [⁠Dosya Upload](http://www.dosyaupload.com/) - 4GB / 60 Days
* [pCloud Transfer](https://transfer.pcloud.com/) or [Tresorit Send](https://send.tresorit.com/) - 5GB / 7 Days / Requires Email
* [Temp.sh](https://temp.sh/) - 4GB / 3 Days
* [patchy.moe](https://patchy.moe/), [2](https://ayaya.beauty/) - 4GB / 14 Days / [Codeberg](https://codeberg.org/Fijxu/patchy)
* [⁠Mega4Upload](https://mega4upload.net/) - 3GB / 183GB / 150 Days After Last Download
* [Workupload](https://workupload.com/) - 2GB / 90 Days
* [JUMBOmail](https://www.jumbomail.me/) - 2GB / 7 Days / Requires Email
* [TransferSize](https://www.transfersize.com/) - 50GB / 7 Days
* [4d2.sh](https://4d2.sh/) - 1GB / 730 Days Max
* [pasted.sh](https://pasted.sh/) - 1GB / Forever / [GitHub](https://github.com/amnexya/pasted)
* [DropMB](https://dropmb.com/) - 512MB / 5 Years
* [⁠Lufi](https://upload.adminforge.de/), [2](https://upload.disroot.org/) - 2GB / 30 Days
* [FileGo](https://filego.app/) - 2GB / 30 Days / Requires Sign-Up
* [FilesPayouts](https://filespayouts.com/) - 10GB / Forever / Requires Sign-Up
* [Clicknupload](https://clicknupload.click) - 10GB / 8 Days / Requires Sign-Up
* [Smash](https://fromsmash.com/) - 2GB / 7 Days / Requires Email
* [⁠PolyUploader](https://polyuploader.vercel.app/) / [GitHub](https://github.com/spel987/PolyUploader) or [Z-o-o-m](https://z-o-o-m.eu/) - Multi-Host Upload Desktop Apps
* [Limited Upload Hosts](https://rentry.org/xc48kg) - More Hosts / 1GB or Below
* [⁠Pearcrypt](https://pearcrypt.lol/) - File Link Containers / [Discord](https://discord.com/invite/QrrryWKA6X)

***

## ▷ Cloud Storage

* **Note** - Free storage / Free account inactivity deletion / Cheapest USD/TB/month (Plan Name).

***

* 🌐 **[Eylenburg Comparisons](https://eylenburg.github.io/cloud_comparison.htm)** or [ComparisonTabl.es](https://comparisontabl.es/cloud-storage/) - Compare Cloud Storage Sites
* ↪️ **[Self-Hosted Cloud Storage](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_server_.2F_selfhosting)**
* ⭐ **[Google Drive](https://drive.google.com/)** - 5GB (15GB w/ Phone) / 2 Years / ~$3.33 (5TB Google AI Pro)
* ⭐ **[MEGA](https://mega.io/)** - 20GB / 3 Months / ~$1.72 (20TB Pro III) / [GitHub](https://github.com/meganz)
* [Proton Drive](https://proton.me/drive) - 5GB / 1 Year / ~$6.66 (3TB Workspace Premium) / [Discord](https://discord.com/invite/proton) / [Note](https://proton.me/support/more-free-storage-existing-users)
* [disk.yandex](https://disk.yandex.com/) - 5GB / 2 Years / ~$2.61 (4TB Personal)
* [Filen](https://filen.io/) - 10GB / 3 Months / ~$3.84 (10TB Pro X) / Requires Sign-Up for Sharing
* [Dropbox](https://www.dropbox.com/) - 1 or 2GB / 12 Months / ~$4.15 (15TB Advanced)
* [MediaFire](https://www.mediafire.com/) - 10GB / 8 Months / ~$5.83 (1TB Pro)
* [⁠CryptFiles](https://cryptfiles.cloud/) - 10GB / 1 Year (Inactive) / ~$9.24 (1-100TB Flexible)
* [VoidDrive](https://voiddrive.org/) - 30GB / Forever / ~$4.99 (1TB Basic)
* [icedrive](https://icedrive.net/) - 10GB / 3 Months / ~$2.07 (6TB Pro Max)
* [pCloud](https://www.pcloud.com/) - 10GB / 1 Year / ~$2.88 (10TB Ultra)
* [FEB](https://www.febbox.com/) - 10GB / 1 Month / ~$2.20 (1TB Personal)
* [Keybase](https://keybase.io/) - 250GB / Forever / [GitHub](https://github.com/keybase/client)
* [⁠InfiniCLOUD](https://infini-cloud.net/en/) - 20GB / 1 Year / ~$3.66 for 3TB
* [JumpShare](https://jumpshare.com/) - 2GB / 1 Year / $5.33 (3TB Business)
* [MrOwl](https://www.mrowl.com/) - 10GB / ~$16.67 (1TB Premium Plus)
* [Koofr](https://koofr.eu/) - 10GB / Forever / ~$10 (1TB Suitcase)
* [Blomp](https://www.blomp.com/) - 40GB / 1 Month / ~$1 for 10TB+
* [Backblaze B2](https://www.backblaze.com/cloud-storage/) - 10GB / ~$6
* [Cloudflare R2](https://www.cloudflare.com/products/r2/) - 10GB / Forever / ~$15
* [FileLu](https://filelu.com/) - 1GB / Forever / ~$3.13 for 40TB / **[Expiry Warning](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/filelu-critical.md)**
* [⁠Tresorit](https://tresorit.com/) - 3GB / Forever / 500 Per File / ~$6.94 (4TB Personal Pro)
* [Fix-OneDrive-Zip](https://github.com/pmqs/Fix-OneDrive-Zip) - Fix OneDrive Zip Files >4GB

***

## ▷ Cloud Managers

* ⭐ **[Rclone](https://rclone.org/)** - Cloud Storage Manager / [Guide](https://rentry.co/simple-rclone-usage) / [GUI](https://github.com/liriliri/rem) / [Colab](https://colab.research.google.com/github/szyha/RcloneLabArchive/blob/master/RcloneLab.ipynb) / [Transfer Tool](https://github.com/TheCaduceus/Multi-Cloud-Transfer-Tool) / [Telegram](https://t.me/rclonexbot) / [GitHub](https://github.com/rclone/rclone)
* ⭐ **[gclone](https://github.com/dogbutcat/gclone)** - Cloud Storage Manager
* ⭐ **[Air Explorer](https://airexplorer.net/en/)** - Cloud Storage Manager
* ⭐ **[RaiDrive](https://www.raidrive.com/)** - Cloud Storage Manager
* ⭐ **[Cyberduck](https://cyberduck.io/)** - Libre Server / Cloud Storage Browser / [GitHub](https://github.com/iterate-ch/cyberduck)
* [SpaceDrive](https://www.spacedrive.com/) - Cloud Storage Manager / [GitHub](https://github.com/spacedriveapp/spacedrive)
* [OpenList](https://doc.oplist.org/) - Cloud Storage Manager / [GitHub](https://github.com/OpenListTeam/OpenList)
* [MultCloud](https://www.multcloud.com/) - Cloud Storage Manager
* [xpipe](https://xpipe.io) - Remote File Manager / [GitHub](https://github.com/xpipe-io/xpipe)
* [FileStash](https://www.filestash.app/) - File Manager / [GitHub](https://github.com/mickael-kerjean/filestash)

***

## ▷ Google Drive Tools

* ⭐ **[OneClickRun](https://colab.research.google.com/github/biplobsd/OneClickRun/blob/master/OneClickRun.ipynb)** - Google Drive Tools / Use Throwaway Google Account / [Features](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/oneclick-note.md)
* [DriveUploader](https://driveuploader.com/) - Receive Files via Google Drive
* [ZIP Extractor](https://zipextractor.app/) - Google Drive / Gmail File Archiver
* [Google Drive CLI](https://github.com/glotlabs/gdrive) - Google Drive CLI Client
* [goodls](https://github.com/tanaikech/goodls) - Google Drive Downloader
* [gdrivedl](https://github.com/matthuisman/gdrivedl) - Google Drive Python Download Script
* [ISAAC](https://rentry.co/FMHYB64#gservice-gen) - Google Service Account Generators
* [goindex-extended](https://github.com/menukaonline/goindex-extended) / [Themes](https://install.kenci.workers.dev/) or [Google-Drive-Index](https://gitlab.com/GoogleDriveIndex/Google-Drive-Index) - Google Drive Indexers
* [gdurl](https://gdurl.com/), [GDrive Link Generator](https://www.wonderplugin.com/online-tools/google-drive-direct-link-generator/), [Direct.GDrive](https://direct.gdrive.vip/en/), [Maulvi](https://maulvi.github.io/) or [GDriveWebAppPublic](https://github.com/CloudflareHackers/GDriveWebAppPublic) - GDrive Link Generators / Host Direct Links
* [Google Drive Clone Bot](https://jsmsj.github.io/GdriveCloneBot/) - Copy Google Drives / [GitHub](https://github.com/jsmsj/GdriveCloneBot)
* [GD-EFC Link Encryptor](https://rekulous.github.io/gd-efc-encryptor/) - Google Drive Link Encryptor for GD-EFC
* [DriveRename](https://driverename.iblogbox.com/) - Bulk Google Drive File Rename
* [Sharer](https://sharer.pw) - Google Drive File Sharing

***

## ▷ MEGA Tools

* ⭐ **[Megabasterd](https://github.com/tonikelope/megabasterd)** - Download Quota Bypass / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/megabasterd-note.md)
* ⭐ **[MEGA Account Generators](https://rentry.co/FMHYB64#mega-gen)** - Account Gen / Unlimited Upload Size / [Fix](https://rentry.co/mega_account_generator)
* [MEGA Desktop](https://mega.io/desktop) - Official GUI App / [GitHub](https://github.com/meganz/MEGAsync)
* [MEGA CMD](https://mega.io/cmd) - Official CLI App / [GitHub](https://github.com/meganz/MEGAcmd)