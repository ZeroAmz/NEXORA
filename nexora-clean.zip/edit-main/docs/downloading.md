***
***
**[◄◄ Back to Wiki Index](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/index)**
***
***

***

# ► Software Sites

* **Note** - Always scan downloaded software with **[VirusTotal](https://www.virustotal.com/gui/)** before installation and run it in a sandboxed environment like **[Triage](https://tria.ge/)** to prevent system compromise. Note that any apps with fake names are generally not worth using. Many popular file hosts have download buttons that redirect to fake malicious download pages. Using the full version of [uBlock Origin](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_adblocking) can prevent this but it doesn't always work. Read this [guide](https://cs.rin.ru/forum/viewtopic.php?f=14&t=159345) to learn what fake malicious download pages look like and how to avoid them. A general rule is to avoid download pages that open in a new tab or redirected page, real downloads happen within the same page as the file host.

***

* 🌐 **[Adobe Alternatives](https://github.com/KenneyNL/Adobe-Alternatives)** - Adobe Software Alternative Index
* ↪️ **[Editing Software](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent/#wiki_.25BA_torrent_sites)** or [Keyflame](https://rentry.co/FMHYB64#keyflame) - Editing Software
* ⭐ **[Virgil Software Search](https://virgil.samidy.com/?engine=software)**, [2](https://virgil-search.pages.dev/?engine=software) / [GitHub](https://github.com/SamidyFR/Virgil) or [Software CSE](https://cse.google.com/cse?cx=ae17d0c72fa6cbcd4) - Multi-Site Software Search
* ⭐ **[CracksURL](https://cracksurl.com/)** / [Download Guide](https://cracksurl.com/how-to-download/) / [Telegram](https://t.me/+Fu_l5ukw7wNkMDll), [2](https://t.me/+8zQaYybFs_wyMzhl)
* ⭐ **[Soft98](https://soft98.ir/)** - Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators)
* ⭐ **[Nsane Forums](https://www.nsaneforums.com/)** - Requires Sign-Up
* ⭐ **[Mobilism](https://forum.mobilism.org/)** - Requires Sign-Up / [User Ranks](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/mobilism-ranks.md)
* ⭐ **[LRepacks](https://lrepacks.net/)** - Avoid Redirects / Use Adblock + [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators)
* ⭐ **[AlternativeTo](https://alternativeto.net/)** or [European Alternatives](https://european-alternatives.eu/) - Crowdsourced Recommendations
* [DownloadHa](https://www.downloadha.com/) - Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators)
* [Moum](https://moum.top/en/)
* [RetroSystemRevival](https://retrosystemsrevival.blogspot.com/) - Oldschool Software
* [Libreware](https://t.me/Libreware) - Telegram Channels
* [ZXPInstaller](https://zxpinstaller.com/) - Adobe Extension Installer

***

## ▷ FOSS Sites

* 🌐 **[Awesome Open Source](https://awesomeopensource.com/)**, [⁠definitive-opensource](https://github.com/mustbeperfect/definitive-opensource), [Awesome Useful Projects](https://github.com/Furthir/awesome-useful-projects) or [Awesome OSS](https://github.com/RunaCapital/awesome-oss-alternatives) - FOSS Indexes
* ↪️ **[Git Project Indexes](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_git_project_indexes)**
* ⭐ **[new(releases)](https://newreleases.io/)** - Software Release Notifications / [GitHub](https://github.com/newreleasesio)
* ⭐ **[Is It Really FOSS](https://isitreallyfoss.com)** - Determine if Software is FOSS / [Source Code](https://codeberg.org/danb/isitreallyfoss)
* [SourceForge](https://sourceforge.net/) - FOSS Repositories
* [OSSSoftware](https://osssoftware.org/) - FOSS Directory
* [Fossies](https://fossies.org/) - FOSS Directory
* [Gadgeteer](https://gadgeteer.co.za/opensourcesoftware/) - FOSS Directory
* [FossHub](https://www.fosshub.com/) - FOSS Directory
* [OSS Gallery](https://oss.gallery/) - FOSS Directory / [GitHub](https://github.com/dubinc/oss-gallery)
* [Opensource Builders](https://opensource.builders/) - FOSS Alt Directory / [GitHub](https://github.com/junaid33/opensource.builders)
* [OpenAlternative](https://openalternative.co/) - FOSS Alt Directory
* [opensourcealternative.to](https://www.opensourcealternative.to/) - FOSS Alt Directory
* [Awesome CLI Apps](https://github.com/toolleeo/awesome-cli-apps-in-a-csv) or [CLI Club](https://cli.club/) / [GitHub](https://github.com/cli-club/cli-club.github.io) - FOSS CLI Apps / Tools
* [FOSS Wiki](https://wikipedia.org/wiki/Portal:Free_and_open-source_software/Categories) - FOSS Wikis

***

## ▷ Freeware Sites

* 🌐 **[Awesome Free Software](https://github.com/Axorax/awesome-free-apps)**, [Awesome Free Apps](https://github.com/Axorax/awesome-free-apps), [Windows Ultimate Collection](https://xdaforums.com/t/windows-ultimate-collection-guides.4507867/) or [Free Lunch](https://github.com/auctors/free-lunch) - Freeware Indexes
* 🌐 **[Awesome Python Applications](https://github.com/mahmoud/awesome-python-applications)** - Python App Index
* ↪️ **[Software Package Managers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/system-tools#wiki_.25B7_package_managers)**
* ⭐ **[FluentStore](https://github.com/yoshiask/FluentStore)** - Alt Microsoft Store App / Windows
* ⭐ **[DanStore](https://danstore-ms.vercel.app/)**, **[store.rg](https://store.rg-adguard.net/)** or [StoreWeb](https://msft-store.tplant.com.au/) / [GitHub](https://github.com/StoreDev) - Microsoft Store WebUIs / [Guide](https://rentry.co/paidAppsMsStore)
* [MajorGeeks](https://www.majorgeeks.com/) - Freeware Downloads
* [Softpedia](https://www.softpedia.com/) - Freeware Directory
* [Realityripple](https://realityripple.com/) - Freeware Directory
* [OlderGeeks](https://oldergeeks.com/) - Freeware Directory
* [FilePuma](https://www.filepuma.com/) - Freeware Directory
* [FileEagle](https://www.fileeagle.com/) - Freeware Directory
* [LO4D](https://www.lo4d.com/) - Freeware Directory
* [SoftwareOK](https://www.softwareok.com/) - Freeware Directory
* [GRC](https://www.grc.com/freepopular.htm) - Freeware Directory
* [Uwe Sieber](https://www.uwe-sieber.de/english.html) - Freeware Directory
* [Software Informer](https://software.informer.com/) - Freeware Directory
* [PortableApps.com](https://portableapps.com/), [PortableFreeware](https://www.portablefreeware.com/), [Portapps](https://portapps.io/) or [PortableAppZ](https://portableappz.blogspot.com/) - Portable Apps
* [Nirsoft](https://www.nirsoft.net/), [Windows-Utilities](https://orga.cat/windows-utilities), [OS Vault](https://osvault.weebly.com/directory.html) or [WinTools](https://www.wintools.info/) - Windows Software
* [Suckless](https://suckless.org/) - Minimalist Software Ecosystem
* [VETUSWARE](https://vetusware.com/) - Abandonware / Operating Systems / Games
* [OldVersion](https://www.oldversion.com/) - Old Versions of Software
* [Vintage Software Collection](https://rentry.co/FMHYB64#the-vintage-software-collection) or [SCiZE's Classic Warez](https://scenelist.org/) - Retro Software
* [⁠Commodore Software](https://commodore.software/search/) - Commodore 64 / Commodore 128 / VIC-20 Software

***

## ▷ [Linux Software](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_software_sites)

***

## ▷ [Mac Software](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_software_sites2)

***

# ► Download Directories

* **Note** - Some Open Directories track IP addresses. Always use a [VPN](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_vpn) or [Tor](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25B7_browser_privacy) when accessing these resources.

***

* 🌐 **[r/opendirectories](https://www.reddit.com/r/opendirectories/)** - Open Directories Subreddit / [Telegram](https://t.me/r_OpenDirectories) / [/u/ODScanner](https://reddit.com/u/ODScanner)
* ⭐ **[EyeDex](https://www.eyedex.org/)**, [ODCrawler](https://odcrawler.xyz/) / [GitHub](https://github.com/MCOfficer/odcrawler-discovery) or [mmnt](https://www.mmnt.net/) - Open Directory Search Engines
* ⭐ **[Nicotine+](https://nicotine-plus.org/)** / [GitHub](https://github.com/nicotine-plus/nicotine-plus) or [Soulseek](https://slsknet.org/) - File Sharing App / Windows, macOS, Linux / [Stats](https://github.com/mrusse/Slsk-Upload-Stats-Tracker) / [Server App](https://github.com/slskd/slskd) / [Batch DDL](https://github.com/fiso64/sldl)
* [eMule](https://www.emule-project.com/) - File Sharing App / Windows / [GitHub](https://github.com/irwir/eMule)
* [⁠RetroShare](https://github.com/RetroShare/RetroShare/) - File Sharing App
* [mega.archive (Discord)](https://discord.gg/R3zEZUPp3Q) / [Chat](https://discord.gg/ZRhpUtzvkC) - Megadrive Archive
* [Mamont](https://www.mmnt.ru/int/) or [Search-22](https://search-22.com/ftp-search-tools) - FTP Search
* [Sala De Espera](https://matrix.to/#/!qbOtnJEDGsPuWZBHLX:matrix.org?via=matrix.org) - Drive Sharing Community
* [Open Directory Downloader](https://github.com/KoalaBear84/OpenDirectoryDownloader) - Open Directory Indexer
* [DemoZoo](https://demozoo.org/), [Pouet](https://www.pouet.net/prodlist.php), [Curio](https://curio.scene.org/) or [scene.org](https://files.scene.org/) - Demoscene Archives
* [CD.TextFiles](http://cd.textfiles.com/) - CD Text File Archive
* [Defacto2](https://defacto2.net/) - Scene / Sub-Scene Database

***

# ► Download Sites

* **Note** - General DDL sites use multiple sources, so it's best to avoid them for software and games. If needed, use **[redirect bypassers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools/#wiki_.25B7_redirect_bypass)** to skip link shorteners. Many popular file hosts have download buttons that redirect to fake malicious download pages. Using the full version of [uBlock Origin](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_adblocking) can prevent this but it doesn't always work. Read this [guide](https://cs.rin.ru/forum/viewtopic.php?f=14&t=159345) to learn what fake malicious download pages look like and how to avoid them. A general rule is to avoid download pages that open in a new tab or redirected page, real downloads happen within the same page as the file host.

***

* ⭐ **[Internet Archive](https://archive.org/)** - Video / Audio / Books / Magazines / Newspapers / ROMs / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage/#wiki_internet_archive_tools)
* ⭐ **[r/DataHoarder](https://reddit.com/r/DataHoarder)** or [Archive Team](https://wiki.archiveteam.org/) / [Subreddit](https://www.reddit.com/r/Archiveteam/) - Data Hoarding Communities
* [MaxRelease](https://max-rls.com/) - Video / Audio / Magazines
* [SCNLOG](https://scnlog.me/) - Video / Audio / ROMs / Books
* [SceneSource](https://www.scnsrc.me/), [2](https://www.scenesource.me/) - Video / Audio / ROMs / Books
* [WorldSRC](https://www.worldsrc.net/) - Video / Audio
* [AditHD](https://www.adit-hd.com/) - Video / Audio / Books
* [wJungle](https://wjungle.net/) - Audio / Books / NSFW / Requires Sign-Up
* [Novanon](https://novanon.net/) - Audio / Magazines / Comics / Books / Courses
* [ReleaseBB](https://rlsbb.ru/), [2](https://rlsbb.to/), [3](https://rlsbb.cc/), [4](https://rlsbb.in/) - Audio / Books / Magazines / [Track Shows](https://openuserjs.org/scripts/drdre1/ReleaseBB_rlsbb_TV_Show_Tracker) / [PreDB](https://log.rlsbb.ru/)
* [Psycho downloads](https://psychodownloads.com/) - Audio / Books / Magazines
* [Merlin Warez](https://merlinwz.com/) - Audio / Books / Audiobooks / Comics / Magazines
* [1DDL](https://1ddl.org/) - Audio / Books / Comics / Magazines
* [WarezLoad](https://warezload.net/index.php) - Audio / Books
* [Katz DDL](https://katzddl.net/) - Audio / Books / NSFW
* [TehParadox](https://www.tehparadox.net/) - Audio / Books / Magazines / ROMs
* [downTURK](https://www.downturk.net/) - Audio / Books
* [SoftArchive](https://softarchive.download/), [2](https://softarchive.is/), [3](https://sanet.lc/), [4](https://sanet.st/), [5](https://sanet.sb/), [6](https://soft.ac/), [7](https://sanet.ws/) - Audio / Books / Comics / Newspapers / Magazines / [Status](https://sastatus.com/) / [Warning](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/sanet-critical.md)
* [⁠ReleaseHive](https://releasehive.com/) - Video / Audio / Books / Requires [Debrid](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/download#wiki_.25BA_debrid_.2F_leeches)

***

## ▷ Search Sites

* **Note** - These aggregate from multiple sources, so it's best to avoid them for software / games.

***

* ⭐ **[Download CSE](https://cse.google.com/cse?cx=006516753008110874046:1ugcdt3vo7z)** / [CSE 2](https://cse.google.com/cse?cx=006516753008110874046:reodoskmj7h) - Multi-Site Search
* ⭐ **[4Shared](https://www.4shared.com/)**
* [File Host Search](https://cse.google.com/cse?cx=90a35b59cee2a42e1)
* [Linktury](https://www.ddlspot.com/)
* [MediafireTrend](https://mediafiretrend.com/) - Mediafire Search
* [WarezOmen](https://warezomen.com/) - Indexer / Search Engine
* [XDCC.EU](https://www.xdcc.eu/) - XDCC / Search Engine

***

## ▷ [Video Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25BA_download_sites)

***

## ▷ [Anime Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25B7_anime_downloading)

***

## ▷ [Educational Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu/#wiki_.25BA_downloading)

***

## ▷ [Game Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/games#wiki_.25BA_download_games)

***

## ▷ [Audio Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/audio#wiki_.25B7_download_sites)

***

# ► Usenet

* 🌐 **[Usenet-Uploaders](https://github.com/animetosho/Nyuu/wiki/Usenet-Uploaders)**
* ⭐ **[Usenet Guide / Automation Setup](https://docs.google.com/document/d/1TwUrRj982WlWUhrxvMadq6gdH0mPW0CGtHsTOFWprCo/mobilebasic)** / [2](https://redd.it/4x2mc9) / [3](https://www.iitk.ac.in/LDP/HOWTO/Usenet-News-HOWTO/x27.html) / [4](https://graph.org/EVERYTHING-YOU-NEED-TO-KNOW-ABOUT-USENET-09-04) / [5](https://www.reddit.com/r/usenet/wiki/index/) / [6](https://blog.decryption.net.au/t/a-fully-automated-usenet-piracy-machine-with-plex-sabnzbd-and-sonarr/130)
* [r/usenet](https://reddit.com/r/usenet)

***

## ▷ Indexers

* 🌐 **[Indexer List](https://www.reddit.com/r/usenet/wiki/indexers/)** - Indexer List
* [r/UsenetInvites](https://reddit.com/r/UsenetInvites)
* [NZBHydra2](https://github.com/theotherp/nzbhydra2) - NZB Meta search
* [Treasure Maps](https://treasure-maps.com/) - Multinational Indexer
* [NzbPlanet](https://nzbplanet.net/)
* [Orion](https://orionoid.com/)
* [binsearch](https://binsearch.info/)
* [NZB King](https://nzbking.com/)
* [NZB Index](https://www.nzbindex.com/), [2](https://www.nzbindex.nl/)
* [Newznab](https://www.newznab.com/)
* [NZBStars](https://nzbstars.com/)
* [usenet-crawler](https://www.usenet-crawler.com/)
* [GingaDaddy](https://www.gingadaddy.com/)
* [NZBFinder](https://nzbfinder.ws/)
* [⁠aninzb](https://aninzb.moe/) or [⁠AmeNZB](https://amenzb.moe/) (signup) - Anime NZB Indexer
* [OldUSe](https://article.olduse.net/) - Search Usenet Articles
* [altHUB](https://althub.co.za) - Unlimited Free Trials
* [Spotweb](https://github.com/spotweb/spotweb) - Spotnet Client

***

## ▷ Providers

* 🌐 **[r/usenet Providers](https://www.reddit.com/r/usenet/wiki/providers)** - Provider Lists
* 🌐 **[r/usenet Deals](https://www.reddit.com/r/usenet/wiki/providerdeals)** - Provider Deals
* 🌐 **[Usenet Provider Deals](https://usenet.rexum.space/deals)**
* [Usenet Providers Map](https://usenet.rexum.space/tree)

***

## ▷ Downloaders

* ⭐ **[sabnzbd](https://sabnzbd.org/)** / Windows, macOS, Linux / [Grabber](https://github.com/lem6ns/sabgrab)
* ⭐ **[NZBUnity](https://github.com/tumblfeed/nzbunity)** - Send NZBs to Client / [Firefox](https://addons.mozilla.org/en-US/firefox/addon/nzb-unity/) / [Chrome](https://chromewebstore.google.com/detail/nzb-unity/mpejfoghnejnbfkpbiafklkmlhebkapb)
* [NZBGet](https://nzbget.com/) / [GitHub](https://github.com/nzbgetcom/nzbget)
* [Usenet File Hashes](https://gist.github.com/4chenz/de3a3490aff19fd72e4fdd9b7dafc8f4) - Link File Hashes

***

# ► Debrid / Leeches

* 🌐 **[Debrid Services Comparison](https://debridcompare.pages.dev/)** / [GitHub](https://github.com/fynks/debrid-services-comparison)
* ↪️ **[Debrid Compatible Apps](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25BA_torrent_apps)**
* ⭐ **[TorBox](https://torbox.app/)** - Freemium / 10GB + 10 Monthly DDL Free / Requires Sign-Up / [Hosters](https://torbox.app/hosters) / [Unofficial Mobile Client](https://github.com/93Pd9s8Jt/atba), [2](https://gitlab.com/forgiving/yatba) / [Subreddit](https://www.reddit.com/r/TorBoxApp/) / [Discord](https://discord.com/invite/torbox) / [GitHub](https://github.com/TorBox-App)
* [Real-Debrid](https://real-debrid.com/) - Paid / [Android Client](https://github.com/LivingWithHippos/unchained-android) / [Torrent Client](https://github.com/rogerfar/rdt-client) / [DDL Client](https://github.com/ItsYeBoi20/TorrentDownloaderRD)
* [⁠NullBeat](https://nullbeat.thevolecitor.qzz.io/) - TorBox-Based Hi-Res Audio & CD FLAC Ripper
* [⁠Get4All](https://get4all.org/) - Premium Link Bypass / Use UBO + [Filter](https://pastebin.com/VFrdqPTe) & [Redirect Bypassers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools/#wiki_.25B7_redirect_bypass)
* [⁠Rip Anything From Anywhere](https://anything.rip/) - Multi-Site Bypass
* [iTeraPlay](https://iteraplay.com/), [Terabox Downloader](https://getindevice.com/terabox-downloader/), [⁠TeraBox Gen](https://terabox.hnn.workers.dev/), [TeraFetch](https://terafetch.com/) or [1024TeraDL](https://1024teradl.com/) - ⁠TeraBox Video Downloaders
* [Multi-OCH Helper](https://greasyfork.org/en/scripts/13884-multi-och-helper) - Quickly Send DDL Links to Premiumize & NoPremium
* [Debrid Media Manager](https://debridmediamanager.com/), [⁠Debrid Vault](https://debridvault.elfhosted.com/) or [Debrid Vault + Eclipse](https://discord.gg/B3QKzPRjhM) - ⁠Debrid Managers / Cloud Managers
* [Pixeldrain Limit Bypass](https://pixeldrain-bypass.gamedrive.org/) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/pixeldrain.md)

***

# ► IRC Tools

* 🌐 **[Awesome IRC](https://github.com/davisonio/awesome-irc)** - IRC Resources
* 🌐 **[NetSplit](https://netsplit.de/)** - IRC Channel Index
* 🌐 **[IRC Client Comparisons](https://wikipedia.org/wiki/Comparison_of_IRC_clients)**
* ↪️ **[Android IRC Clients](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_android_internet)**
* [IRC Guide](https://rentry.org/ircfmhyguide), [Libera Guides](https://libera.chat/guides/), [New Blood](https://anonops.com/newblood/) or [Simple Wiki Guide](https://wikipedia.org/wiki/Wikipedia:IRC/Tutorial) - IRC Guides
* [AdiIRC](https://adiirc.com/), [KVIrc](https://github.com/kvirc/KVIrc), or [Halloy](https://github.com/squidowl/halloy) - IRC Clients / Windows, macOS, Linux
* [Konversation](https://konversation.kde.org/) - IRC Client / Windows, Linux / [GitHub](https://github.com/KDE/konversation)
* [Convos](https://convos.chat/) / [GitHub](https://github.com/convos-chat/convos/) or [TheLounge](https://thelounge.chat/) / [GitHub](https://github.com/thelounge) - Self-hosted IRC Client / Web
* [Libera](https://libera.chat/), [tilde](https://tilde.chat/), [AnonOps](https://anonops.com/) or [Rizon](https://rizon.net/) - IRC Networks
* [⁠UnrealIRCd](https://www.unrealircd.org/) - IRC Server

***

# ► [Download Managers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/file-tools#wiki_.25B7_download_managers)