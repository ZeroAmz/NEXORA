***
***
**[◄◄ Back to Wiki Index](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/index)**
***
***

# ► Documentaries

* 🌐 **[Official YT Documentary Channels](https://github.com/superlincoln953/Free-Official-Youtube-Content?tab=readme-ov-file#Documentaries)**
* ⭐ **[IHaveNoTV](https://ihavenotv.com/)**
* ⭐ **[DocumentaryArea](https://www.documentaryarea.com/)** / [Remove Watermark](https://github.com/Julmik647/filterlists), [2](https://github.com/acridsoul/Clear-Mark) (or use PIP)
* ⭐ **[Documentary+](https://www.docplus.com/)**
* ⭐ **[1337x Documentaries](https://1337x.to/top-100-documentaries)** - Torrent
* [YT Video Essay Hall of Fame](https://docs.google.com/spreadsheets/d/1pMlfjJ4gb0vMt2xrQITBMzWypNHMj-lWKkK1KC6EjxA/edit?gid=88681539) - YouTube Video Essay Archive / [Frontend](https://heyitsdean.github.io/Video-Essay-Hall-Of-Fame/)
* [Top Documentary Films](https://topdocumentaryfilms.com/)
* [Thought Maybe](https://thoughtmaybe.com/)
* [Media Burn Archive](https://mediaburn.org/)
* [⁠TokyVideo](https://www.tokyvideo.com/documentaries)
* [ARTE](https://www.arte.tv/)
* [Documentary Storm](https://www.documentarystorm.com/)
* [Rocumentaries](https://rocumentaries.com/)
* [PBS](https://www.pbs.org/video/)
* [Folkstreams](https://www.folkstreams.net/)
* [Films For Action](https://www.filmsforaction.org/)
* [r/Documentaries](https://reddit.com/r/Documentaries)
* [Videoneat](https://www.videoneat.com/)
* [MVGroup](https://forums.mvgroup.org/)
* [NASA+](https://plus.nasa.gov/) - Official NASA Streaming Service

***

# ► Courses

## ▷ Streaming

* 🌐 **[Limnology](https://educational-channels.com//)** - Educational YouTube Channels
* ↪️ **[Udemy Tools / Coupons](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_udemy_coupons)**
* ⭐ **[edX](https://www.edx.org/)** - Courses / [Downloader](https://github.com/rehmatworks/edx-downloader)
* ⭐ **[MitOpenCourseWare](https://ocw.mit.edu/)** - Courses
* ⭐ **[Khan Academy](https://www.khanacademy.org/)** - Courses
* ⭐ **[Gresham College](https://www.gresham.ac.uk/)** - Lectures / [YouTube](https://www.youtube.com/@GreshamCollege/videos)
* ⭐ **[Class Central](https://www.classcentral.com/)** - Search for Courses
* [OpenLearn](https://www.open.edu/openlearn/) - Courses
* [Saylor Academy](https://learn.saylor.org/) - Courses
* [EbookFoundation Courses](https://github.com/EbookFoundation/free-programming-books#free-online-courses) - Courses
* [OpenCulture](https://www.openculture.com/freeonlinecourses) - Courses
* [DigitalGarage](https://grow.google/intl/uk/courses-and-tools/) - Google Courses
* [OpenHPI](https://open.hpi.de/) - Courses
* [OLI](https://oli.cmu.edu/independent-learner-courses/) - Courses
* [Video Lectures](https://videolectures.net/) - Lectures
* [Yale Courses](https://oyc.yale.edu/courses) - Lectures / [YouTube](https://www.youtube.com/@YaleCourses/)
* [Paul G. Allen School](https://www.youtube.com/@uwcse/) - Lectures
* [Crash Course](https://thecrashcourse.com/) - Topic Crash Courses
* [⁠HackerTube](https://hackertube.org/) - Educational YouTube Videos
* [Course CSE](https://cse.google.com/cse?cx=67ed14bf7b99643e3) - Multi-Site Course Search

***

## ▷ Downloading

* **Note** - Use **[redirect bypassers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools/#wiki_.25B7_redirect_bypass)** to skip annoying link shorteners.

***

* 🌐 **[Free-Courses-For-Everyone](https://github.com/MasterBrian99/Free-Courses-For-Everyone)** - Course Site Index
* ⭐ **[Course Busters](https://www.cbusters.com/home)** - Course Busters Access / Telegram Required
* [Docspedia](https://docspedia.world/) - Torrenting Sites / Use [VPN](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_vpn)
* [AfraTafreeh](https://afratafreeh.com/) - Courses
* [LinkedIn_Learning](https://t.me/linkedin_learning) - LinkedIn Courses
* [CertCommunity](https://www.certcommunity.org/forum/) - IT Cert Courses / Requires Phone # (Temp Works) / Use [Leeches](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/download#wiki_.25BA_debrid_.2F_leeches)

***

# ► Learning Sites

* 🌐 **[Learn Anything](https://learn-anything.xyz/)** - Learning Resource Search / [Free Method](https://rentry.co/FMHYB64#learn-anything) / [Discord](https://discord.gg/W7yDkEN67Y) / [GitHub](https://github.com/learn-anything/learn-anything)
* 🌐 **[OpenCulture](https://www.openculture.com/)** - Learning Resources
* 🌐 **[⁠The Borr Project](https://borr.dev/)** / [Discord](https://discord.gg/uR2QS36pdH) or **[OSSU](https://github.com/ossu/)** / [Discord](https://discord.gg/wuytwK5s9h) - Learning Resources
* 🌐 **[The Free Learning List](https://freelearninglist.org/)** - Learning Resources
* 🌐 **[Awesome Educational Games](https://github.com/yrgo/awesome-educational-games)** - Educational Games Index
* ↪️ **[Educational Books](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/reading#wiki_.25BA_educational_books)**
* ↪️ **[Quotes / Poetry](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/reading#wiki_.25B7_quotes_.2F_poetry)**
* ⭐ **[PhET](https://phet.colorado.edu/)**, [⁠Project Lumen](https://www.projectlumen.app/), [Cognito](https://cognito.org/) or [Academo](https://academo.org/) - Interactive Lessons
* ⭐ **[r/educationalgifs](https://reddit.com/r/educationalgifs)** - Learn with GIFs
* ⭐ **[r/explainlikeimfive](https://www.reddit.com/r/explainlikeimfive/)** - Have Anything Explained Very Simply
* ⭐ **[The Punctuation Guide](https://www.thepunctuationguide.com/)** - Punctuation Guide
* [⁠Basic Knowledge 101](https://www.basicknowledge101.com/) - Knowledgebase / Topic Learning
* [media.ccc.de](https://media.ccc.de/) - Educational Presentations
* [Stack Exchange](https://stackexchange.com/) - Q&A Communities
* [Explorabl.es](https://explorabl.es/), [MinuteLabs](https://minutelabs.io/) or [Wikiversity](https://www.wikiversity.org/) - Quizzes / Guides / Games
* [AFAIK](https://afaik.io/) - Learning Map / [Discord](https://discord.gg/mMNwRvWM8s)
* [AnimaGraffs](https://animagraffs.com/) - Animated Infographs
* [Memory Toys](https://memory.toys/), [⁠Memory League](https://memoryleague.com/), [Dual N-Back](https://nbacking.com/) or [BrainScale](https://brainscale.net/) - Memory Tests / Training
* [⁠Art of Memory](https://artofmemory.com/) - Memory Improvement Book, Games, and Forums
* [Information Is Beautiful](https://informationisbeautiful.net/), [The Pudding](https://pudding.cool/), [⁠sheets.works](https://sheets.works/data-viz/) or [HalcyonMaps](https://www.halcyonmaps.com/infographics) - Data / Information / Infographics / Visualizations
* [r/coolguides](https://www.reddit.com/r/coolguides/top/?screen_view_count=2&t=all) or [coolguid.es](https://coolguid.es/) - Guides & Tutorials
* [⁠Astral Codex Ten (ACX)](https://www.astralcodexten.com/) or [Read Scott Alexander](https://readscottalexander.com/) - Science, Psychology, and Philosophy Blog
* [Common Misconceptions](https://wikipedia.org/wiki/List_of_common_misconceptions) - Common Misconception Index
* [masterWiki](https://masterwiki.how/) - MasterClass Classes Republished as wikiHow Articles
* [LitCharts](https://www.litcharts.com/) - Literature Guides
* [Appropedia](https://www.appropedia.org/) - Sustainability Wiki
* [British & Exotic Mineralogy](https://www.c82.net/mineralogy/) - Mineralogy Database
* [ShipSpotting](https://www.shipspotting.com/) - Ship Index / Images
* [P2PU](https://www.p2pu.org/) - Join Learning Groups Using Free Courses

***

## ▷ Art Galleries / Collections

* ⭐ **[The Met](https://www.metmuseum.org/art/collection)** - Metropolitan Museum of Art Collection / Public-Domain Images
* ⭐ **[Google Arts & Culture](https://artsandculture.google.com/)** - Museum Collections / Art Exhibitions
* ⭐ **[Rijksmuseum](https://www.rijksmuseum.nl/en/collection)** - Dutch Art / Museum Collection / High-Resolution Downloads
* ⭐ **[WikiArt](https://www.wikiart.org/)** - Visual Art Encyclopedia / Artist Collections
* ⭐ **[Artic](https://www.artic.edu/collection)** - Art Institute of Chicago Collection / Open-Access Images
* ⭐ **[NGA](https://www.nga.gov/)** - National Gallery of Art / Public-Domain Images / Open Data
* ⭐ **[V&A](https://www.vam.ac.uk/)** - Victoria and Albert Museum Collections / Art / Design
* ⭐ **[Louvre](https://collections.louvre.fr/en/)** - Art / Antiquities Collections / Historical Research
* [MoMA](https://www.moma.org/collection/) - Museum of Modern Art Collection
* [Deutsche Digitale](https://www.deutsche-digitale-bibliothek.de/?lang=en) - German Digital Cultural Heritage Collections
* [VADS](https://vads.ac.uk/digital/) - UK Visual Arts / Design Archives / Digital Collections
* [Ashmolean](https://ashmolean.org/collections-online) - Art / Archaeology Collections / Historical Research
* [WGA](https://www.wga.hu/) - Web Gallery of Art / European Art History
* [Public Work](https://www.cosmos.so/public-work) - Public-Domain Image Search
* [The Last Museum](https://lastmuseum.com/) - Historical Artwork Search
* [Artvee](https://artvee.com/) - Public Domain Art / Vintage Illustrations
* [The Watercolour World](https://www.watercolourworld.org/) - Historical Watercolour Paintings / Archive
* [NPG](https://www.npg.org.uk/collections/) - National Portrait Gallery Collection
* [RCT](https://www.rct.uk/collection/) - Royal Collection Trust / British Royal Art Collections
* [Semantic Art Search](https://semantic-art-search.com/) - Semantic Artwork Search / [GitHub](https://github.com/KristianMSchmidt/semantic-art-search)
* [Centre Pompidou](https://www.centrepompidou.fr/en/collection) - Modern / Contemporary Art Collections
* [Guggenheim](https://www.guggenheim.org/collection-online) - Modern / Contemporary Art Collections
* [Frick](https://www.frick.org/art) - The Frick Collection / Fine Art
* [Gardner Museum](https://www.gardnermuseum.org/experience/collection) - Isabella Stewart Gardner Museum Collection
* [Museo](https://museo.app/) - Art Collections / Public-Domain Image Search
* [Haltadefinizione](https://www.haltadefinizione.com/en/) - High-Resolution Art Images / Italian Art
* [Artchive](https://www.artchive.com/) - Art History / Artist Collections
* [Arthur](https://arthur.io/) - Art Discovery / Collections
* [faenum](https://faenum.com/) - Public-Domain Artwork Search
* [Gallerix](https://gallerix.org/) - Fine Art / Painting Collections
* [S.D. Cason](https://sdcason.com/categories/) - Historical / Public-Domain Image Collections
* [poly.booru](https://poly.booru.nl/) - Historical Artifact Images / [Discord](https://discord.gg/jHnYbGJZSn) / [GitHub](https://github.com/cosbooru/cosbooru)
* [strauh.al](https://strauh.al/) - Digital Art Collection
* [DarkClassics](https://darkclassics.blogspot.com/) - Historical / Classical Art Collections
* [European Art](https://photos.app.goo.gl/q5GRdpSvARAqhbSh6) - European Artwork Collection
* [The Wolfman Museum of Art](https://wolfmanmuseum.org/) - Digital Art Museum

***

## ▷ Virtual Tours

* 🌐 **[Virtual Museum Resources](https://mcn.edu/a-guide-to-virtual-museum-resources/)** - Online Museums
* ⭐ **[CityHop](https://www.cityhop.cafe/)**, [Travel Remotely](https://travel-remotely.netlify.app/), [Portal Generator](https://flavourmachine.com/portal-generator/), [Walk with Feel](https://walkwithfeel.vercel.app/), [Outside Simulator](https://outsidesimulator.com/), [Japan Walkaround](https://thatguyedd.github.io/), [CityWalks](https://citywalks.live/), [Citywalki](https://www.citywalki.com/) or [Virtual Vacations](https://virtualvacation.us/) - Travel Simulators
* [Gez.la](https://gez.la/) - Virtual Tours Map
* [Wiki Spaces](https://wiki-spaces.org/) - Virtual Tours
* [Musei Vaticani](https://www.museivaticani.va/content/museivaticani/en/collezioni/musei/tour-virtuali-elenco.html) - Virtual Museum Tours
* [Natural History Museum](https://naturalhistory.si.edu/visit/virtual-tour) - Natural History Museum Virtual Tour
* [Digital Giza](https://mused.com/giza/) - Great Pyramid Virtual Tours
* [Persepolis Reimagined](https://persepolis.getty.edu/) - Explore Persepolis Recreation
* [BelowTheSurface](https://belowthesurface.amsterdam/en) - Archeological Object DB of Amsterdam
* [WW2 in 100 Objects](https://www.tweedewereldoorlog.nl/100voorwerpen/en/virtual-tour/) - WW2 Museum Virtual Tour
* [Harald Joergens Panoramas](https://www.haraldjoergens.com/panoramas.php) - Aircraft Virtual Tours
* [Virtual Visit Tours](https://www.virtualvisittours.com/) - Ireland Virtual Tours
* [Virtual Yosemite](https://www.virtualyosemite.org/) - Virtual Yosemite Tour
* [Matterport](https://discover.matterport.com/) - Explore Real Places Digitally
* [Basilica Viewer](https://virtual.basilicasanpietro.va/en/basilica-viewer/) - St. Peter’s Basilica Tour
* [360Cities](https://www.360cities.net/), [⁠Tas360](https://tas360.au/explore) or [Airpano](https://www.airpano.com/) - 360 Images / Videos
* [Smithsonian 3D](https://3d.si.edu/) - Smithsonian 3D Digitization Museum
* [National Palace Museum](https://tech2.npm.edu.tw/720vr/enHome.html) - National Palace Museum Virtual Tours
* [The Bayeux Tapestry](https://www.bayeuxmuseum.com/en/the-bayeux-tapestry/discover-the-bayeux-tapestry/explore-online/) - Bayeux Tapestry 3D Digitization

***

# ► Science / Math

* ↪️ **[Science News](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_science_news)**
* [TIB AV-Portal](https://av.tib.eu/) - Science Videos
* [LabXchange](https://www.labxchange.org/), [⁠UCAR Center Simulations](https://scied.ucar.edu/interactive) or [JavaLab](https://javalab.org/en/) - Interactive Science / Math Simulations
* [⁠MagnifiedSand](https://magnifiedsand.com/) - Microscopic Sand Magnification Database
* [LabPlot](https://labplot.org/), [PubQ Studio](https://pubq-studio.onrender.com/) or [ISciDAVis](https://sourceforge.net/projects/scidavis/) - Scientific Data Plotters
* [ImageJ](https://imagej.net/) / [Web](https://ij.imjoy.io/) or [Fiji](https://fiji.sc/) - Scientific Image Analyzers
* [BOINC](https://boinc.berkeley.edu/) - Donate Idle CPU + GPU Resources to Scientific Research / [Manager](https://boinc.berkeley.edu/central/) / [Number Theory](https://numberfields.asu.edu/NumberFields/) / [Humanitarian](https://worldcommunitygrid.org/) / [Subreddit](https://www.reddit.com/r/BOINC/)

***

## ▷ Physics

* 🌐 **[Physics Aviary](https://thephysicsaviary.com/Physics/Programs/Tools/find.php)** or [Falstad](https://www.falstad.com/mathphysics.html) - Physics Tools
* ⭐ **[The Feynman Lectures](https://www.feynmanlectures.caltech.edu/)** - Physics Lectures
* ⭐ **[Bartosz Ciechanowski](https://ciechanow.ski/)**, [Isaac Physics](https://isaacscience.org/), [PhysicsClassroom](https://www.physicsclassroom.com/), [HyperPhysics](http://hyperphysics.phy-astr.gsu.edu/hbase/), [MotionMountain](https://www.motionmountain.net/index.html) or [Splung](https://www.splung.com/) - Physics Lessons / Learning
* [Mujoco](https://github.com/google-deepmind/mujoco), [Physics Animations](https://www.animations.physics.unsw.edu.au/), [oPhysics](https://ophysics.com/index.html) or [MyPhysicsLab](https://www.myphysicslab.com/index-en.html) - Physics Simulations / Animations
* [LibreTexts Physics](https://phys.libretexts.org/Bookshelves) - Physics Learning / Guides
* [nLab Physics](https://ncatlab.org/nlab/show/higher+category+theory+and+physics) - Physics Encyclopedia
* [Algodoo](https://www.algodoo.com/) - Interactive Physics Tool
* [QPaths](https://qpaths.deqart.com/) - Learn Basic Quantum Terms
* [⁠Quantum Flytrap](https://quantumflytrap.com/) - Interactive Quantum Mechanics Virtual Lab
* [Quantum](https://play.google.com/store/apps/details?id=brychta.stepan.quantum_en) - Quantum Physics Learning App
* [Physics Forums](https://www.physicsforums.com/) - Physics / Science Forum
* [Unihedron](https://unihedron.com/projects/spectrum/downloads/spectrum-20190805.pdf) - Electromagnetic Radiation Spectrum Chart
* [Interactive 4D Handbook](https://baileysnyder.com/interactive-4d/) - Interactive Fourth Dimension
* [Ray Optics Simulation](https://phydemo.app/ray-optics/) - Light Reflection / Refraction Simulator
* [Compare Pendulum](https://www.myphysicslab.com/pendulum/compare-pendulum-en.html) or [DoublePendulum](https://theabbie.github.io/DoublePendulum/) - Pendulum Simulators
* [OpenFoam](https://openfoam.org/), [PC Progress](https://www.pc-progress.com/), [Fluid Simulation WebGL](https://paveldogreat.github.io/WebGL-Fluid-Simulation/), [WebGL Fluid Experiment](https://haxiomic.github.io/GPU-Fluid-Experiments/html5/), [OpenFOAM](https://www.openfoam.com/) / [GitHub](https://github.com/OpenFOAM/OpenFOAM-dev) or [Sim Flow](https://sim-flow.com/) - Fluid Dynamics Simulators
* [SimScale](https://www.simscale.com/) - Fluid Dynamics & Heat Transfer
* [⁠Mago Fluid](https://magofluid.gaia3d.com/) - Debris-Flow + Tsunami Simulation
* [Bouncy Balls](https://bouncyballs.org/) or [Balls Simulation](https://phydemo.app/balls-simulation/) - Ball Physics Simulator
* [WebGL Water](https://madebyevan.com/webgl-water/) - Water Simulation
* [LAMMPS](https://www.lammps.org/) - Molecular Dynamics (MD) Code
* [Avogadro](https://two.avogadro.cc/index.html), [2](https://sourceforge.net/projects/avogadro/) or [MolView](https://molview.org/) - Molecular Viewers / Editors
* [⁠Nuclear Reactor Simulator](https://dalton-nrs.manchester.ac.uk/) - ⁠Nuclear Reactor Simulator

***

## ▷ Math

* 🌐 **[Awesome Math](https://github.com/rossant/awesome-math)** or [Math Resources](https://docs.google.com/document/d/1rtokzhpvkUPnymudl_ZVmfAA7H33VIyLQUpujNGwrTo/) - Math Resources
* 🌐 **[Math and Science Lectures](https://github.com/Developer-Y/math-science-video-lectures)** - Index of Math + Science Video Courses
* ↪️ **[Calculators / Problem Solvers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7_calculators)**
* ↪️ **[LaTeX Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools#wiki_.25B7_latex_tools)**
* ⭐ **[Number Academy](https://number.academy/)** - Encyclopedia of Numbers
* ⭐ **[Wumbo](https://wumbo.net/)** - Math Reference Site
* ⭐ **[⁠The Borr Project](https://borr.dev/math/)** / [Discord](https://discord.gg/uR2QS36pdH) or **[OSSU Math](https://github.com/ossu/math)** / [PT-BR](https://github.com/ossu/math-br) / [Discord](https://discord.gg/wuytwK5s9h) - Math Roadmaps
* ⭐ **[AoPS Alcumus](https://artofproblemsolving.com/alcumus)** / [YouTube](https://www.youtube.com/channel/UCHZwMwa96o5gwBmVaIj_zVA) or [MathDash](https://mathdash.com/) - Adaptive Problem Solving
* ⭐ **[BetterExplained](https://betterexplained.com/)** - Math Guides / Courses
* ⭐ **[Paul's Online Math Notes](https://tutorial.math.lamar.edu/)**, [⁠Immortal's Maths Problems](https://www.math.umd.edu/~immortal/), [⁠Evan Chen](https://web.evanchen.cc/) or [LibreTexts Math](https://math.libretexts.org/Bookshelves) - Math Practice / Guides
* ⭐ **[Manim](https://www.manim.community/)**, [2](https://github.com/3b1b/manim) / [GitHub](https://github.com/ManimCommunity/manim/) - Generate Explanatory Math Videos / [Videos](https://github.com/3b1b/videos) / [Difference Between Versions](https://docs.manim.community/en/stable/faq/installation.html#different-versions)
* ⭐ **[WolframAlpha](https://www.wolframalpha.com/)** - Searchable Knowledge Base / [Mobile](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_modded_apks) (search)
* ⭐ **[OEIS](https://oeis.org/)** - Encyclopedia of Integer Sequences
* [Wolfram MathWorld](https://mathworld.wolfram.com/) or [nLab Math](https://ncatlab.org/nlab/show/mathematics) - Mathematics Encyclopedias
* [⁠Algebrica](https://algebrica.org/) - Mathematical Concept Database
* [Red Blob Games](https://www.redblobgames.com/), [⁠Mathua](https://mathua.com/) / [GitHub](https://github.com/chuma-beep/mathua) or [Mathspad](https://www.mathspad.co.uk/resources.php?interactives=1) - Interactive Math Learning
* [Matthen](https://blog.matthen.com/) - Math Animations
* [⁠Math Discord](https://discord.gg/math) - Math Help / Community Discord
* [⁠Mathematical Olympiads](https://mathematics.isodn.org/) - Mathematical Olympiads Discord Community / [Discord](https://discord.gg/KCdTTF5)
* [Mathcha](https://www.mathcha.io/) or [Corca](https://corca.app/) - Online Math Editors
* [SequenceDB](https://sequencedb.net/) - Sequence Machine
* [⁠Erich's Packing Center](https://erich-friedman.github.io/packing/) - Geometric Packing Problem Archive
* [⁠ProofWiki](https://proofwiki.org/) - Mathematical Proofs Encyclopedia
* [Giac/Xcas](https://www-fourier.univ-grenoble-alpes.fr//~parisse/giac.html) - Algebra System
* [Algebra Rules](https://algebrarules.com/) - Learn Algebra Rules
* [Linear Algebra Done Right](https://linear.axler.net/) - Linear Algebra Book / Guide
* [Calculus Made Easy](https://calculusmadeeasy.org), [⁠Ximera](https://ximera.osu.edu/mooculus) or [⁠Stitz Zeager](https://www.stitz-zeager.com/) - Learn / Practice Calculus
* [CLP](https://personal.math.ubc.ca/~CLP/) - Calculus Textbooks
* [Mathematics Roadmap](https://github.com/TalalAlrawajfeh/mathematics-roadmap) or [⁠Learn Mathematics](https://donkuri.github.io/learn-mathematics/) - Mathematics Book Recommendations
* [MathJax](https://www.mathjax.org/) - JavaScript Math Display
* [MathOnline](http://mathonline.wikidot.com/), [⁠CEMC](https://cemc.uwaterloo.ca/resources/courseware) or [Mathigon](https://mathigon.org/) - Math / Courses
* [Professor Leonard](https://www.youtube.com/channel/UCoHhuummRZaIVX7bD4t2czg), [⁠Art of Problem Solving](https://www.youtube.com/channel/UCHZwMwa96o5gwBmVaIj_zVA), [Flipped Mastery](https://www.flippedmath.com/), [3Blue1Brown](https://www.3blue1brown.com/) or [MisterWootube](https://www.youtube.com/c/misterwootube) - YouTube Math Lessons
* [Mathispower4u](https://www.mathispower4u.com/), [⁠Andy Math](https://andymath.com/), [⁠MadAsMaths](https://www.madasmaths.com/), [Math Planet](https://www.mathplanet.com/) or [CoolMath](https://www.coolmath.com/) - Math Lessons / Practice
* [Coolmath Games](https://www.coolmathgames.com/c/number-games) - Math Games
* [Cut The Knot](https://cut-the-knot.org/) or [⁠MathNet](https://mathnet.mit.edu/) - Math Equations / Problems
* [HSC Maths By Topic](https://hscmathsbytopic.firsteducation.com.au/) - HSC Math Practice
* [Vim/LaTeX Mathematics Note-Taking Guide](https://castel.dev/post/lecture-notes-1/)
* [ParkMath](https://parkmath.github.io/) or [FreeMathHelp](https://freemathhelp.com/) - Math Guides
* [ISODN Math](https://discord.gg/3sbwZdh) - ISODN Math Discord Community
* [Fourier Transform](https://www.jezzamon.com/fourier/index.html) - Interactive Fourier Transform Guide
* [Terence Tao Research](https://terrytao.wordpress.com/) - Mathematical Research
* [Open Logic Project](https://openlogicproject.org/) - Math Logic Teaching Materials
* [Math is Fun](https://www.mathsisfun.com/) - Math Tutorials / Puzzles / Games
* [Brainstellar Puzzles](https://brainstellar.com/puzzles) - Puzzles from Quant Interviews
* [Project Euler](https://projecteuler.net/) - Math / Programming Problems
* [⁠VibeMathed](https://vibemathed.com/) - Index of Mathematical Problems Solved by AI
* [LibreTexts Statistic](https://stats.libretexts.org/Bookshelves) - Statistic Practice / Guides
* [IMS](https://github.com/OpenIntroStat/ims) - Introduction to Modern Statistics
* [Seeing Theory](https://seeing-theory.brown.edu/) - Statistics & Probability Tutorials

***

## ▷ Engineering

* 🌐 **[The Engineering Toolbox](https://www.engineeringtoolbox.com/)** or [EngineersEdge](https://www.engineersedge.com/) - Engineering Resources
* 🌐 **[r/EngineeringStudents Resources](https://www.reddit.com/r/EngineeringStudents/wiki/resources)** - Engineering Student Resources
* 🌐 **[Awesome Electronics](https://github.com/kitspace/awesome-electronics)** - Electronic Engineering Resources
* 🌐 **[Engineering Blogs](https://github.com/kilimchoi/engineering-blogs)** - Engineering Blogs
* ↪️ **[Comp Sci Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu/#wiki_.25B7_computer_science)**
* ↪️ **[Vehicle Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25BA_vehicle)**
* ↪️ **[3D Modeling](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25BA_3d_models) / [CAD Apps](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25B7_cad_engineering)**
* ⭐ **[r/AskEngineers](https://www.reddit.com/r/AskEngineers/)** / [Wiki](https://www.reddit.com/r/AskEngineers/wiki/) - Engineering Subreddit
* ⭐ **[NPTEL](https://nptel.ac.in/courses)** or [Sabin](https://www.youtube.com/@SabinCivil) - Engineering Courses
* ⭐ **[KiCad](https://www.kicad.org/)** / [Libraries](https://kicad.github.io/) or [Horizon EDA](https://horizon-eda.org/) - Schematics Editor / PCB Creator / SPICE Integration
* [⁠IEEE Spectrum](https://spectrum.ieee.org/) - Engineering Magazine / News
* [Formulia](https://play.google.com/store/apps/details?id=m4.enginary) - Engineering Formulas / Tools
* [BOMwiki](https://bomwiki.com/) - Product Blueprint Components Database / [X](https://x.com/protosphinx) / [GitHub](https://github.com/BOMWiki)
* [⁠Hackster.io](https://www.hackster.io/) - Hardware Learning / Project Sharing
* [Sanfoundry](https://www.sanfoundry.com/) - Engineering Questions & Answers
* [SendCutSend Education](https://sendcutsend.com/education/) - CAD Engineering Study Guide / Videos / [X](https://x.com/sendcutsend)
* [SOLIDWORKS Practice Problems](https://www.solidworks.com/solution/education/practice-problems) - CAD Engineering Practice Exercises / [X](https://x.com/solidworks)
* [Tinkercad](https://www.tinkercad.com/) - Educational CAD Modeling
* [LibreTexts Engineering](https://eng.libretexts.org/Bookshelves) - Engineering Learning / Guides
* [⁠Lunchbox Sessions](https://www.lunchboxsessions.com/) - Interactive Mechanical / Electric Engineering Tutorials
* [CESDB](https://www.cesdb.com/) or [LavTeam](https://lavteam.org/) - Engineering Software
* [⁠MatWeb](https://www.matweb.com/) - Engineering Material Property Database
* [⁠Animated Engines](https://animatedengines.com/) - Engine Animations / Explanations
* [507 Movements](https://507movements.com/toc.html) - Mechanical Movement Animations
* [⁠How To Mechatronics](https://howtomechatronics.com/) - Tutorials / Guides for Mechatronics & Electronics
* [Robot Shop](https://community.robotshop.com/) - Robotics Forum
* [VisRo Robotics](https://robotics101-viscircuit.web.app/) / [Discord](https://discord.com/invite/TfwZ3hH2D2) or [⁠VittaScience](https://en.vittascience.com/code) - Robotics Learning
* [⁠Humanity's Last Machine](https://www.humanityslastmachine.com/) or [Humanoid Atlas](https://www.humanoids.fyi/) / [GitHub](https://github.com/kingjulio8238/humanoid-atlas) - Humanoid Robotics Hardware & Supply Chain Analysis
* [Cyberbotics](https://cyberbotics.com/) - Robot Simulator
* [Wokwi](https://wokwi.com/) - Arduino / ESP32 Board Simulators
* [HDLBits](https://hdlbits.01xz.net/) - Learn Circuit Design
* [⁠Last Minute Engineers](https://lastminuteengineers.com/) - Electronics Engineering Learning
* [Falstad](https://www.falstad.com/circuit/), [Altium](https://www.altium.com/viewer/), [SKiDL](https://devbisme.github.io/skidl/) / [GitHub](https://github.com/devbisme/skidl), [atopile](https://start.atopile.io/), [EasyEDA](https://easyeda.com/editor) or [LibrePCB](https://librepcb.org/) - Electronic Circuit Design / Simulation Tools
* [⁠The Pinouts Book](https://pinouts.org/) - Pinout Function Reference Guide
* [Circuit Steps](https://circuitsteps.com/) - Circuit Analysis Tool
* [BatteryUniversity](https://batteryuniversity.com/articles) - Learn About Batteries
* [⁠Datasheet4U](https://datasheet4u.com/) - Electronic Components Datasheet
* [Electronics Tutorials](https://www.electronics-tutorials.ws/) - Electronic Guides
* [⁠Hacker Fab](https://docs.hackerfab.org/) - Semiconductor Documentation / Research
* [RetroSix](https://www.retrosix.wiki/) - Retro Console Repair Guides + Info / [Discord](https://discord.gg/D4Envqc5jr)
* [/m/engineering](https://www.reddit.com/user/nbatman/m/engineering/) - Engineering Multireddit
* [⁠McMaster](https://www.mcmaster.com/) or [3D Find It](https://www.3dfindit.com/en/) - Free 3D Printable Hardware Parts + Tools
* [Build List](https://buildlist.org/) or [USA Parts Made Fast](https://partsmadefast.com/) / [X](https://x.com/mattfreed) - On-Demand Online Manufacturers

***

## ▷ Chemistry

* 🌐 **[Wolfram Alpha Chemistry](https://wolframalpha.com/examples/science-and-technology/chemistry)** - Chemistry Calculators / Tools
* ↪️ **[Periodic Tables](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7_periodic_tables)**
* ⭐ **[LibreTexts Chemistry](https://chem.libretexts.org)** - Chemistry Texts
* ⭐ **[Internet Chemistry](https://www.internetchemistry.com/search.php)** - Chemistry Search Index
* [Chemistry Basics](https://saylordotorg.github.io/text_the-basics-of-general-organic-and-biological-chemistry/index.html) - Basics of General, Organic, and Biological Chemistry
* [ChemicalAid](https://www.chemicalaid.com/), [⁠WebQC](https://www.webqc.org/) or [Chemequations](https://chemequations.com/en/) - Chemistry Calculators / Element Tables
* [QuickChem](https://play.google.com/store/apps/details?id=com.map.michael.chemistry) - Chemistry Calculator
* [PubChem](https://pubchem.ncbi.nlm.nih.gov/), [MOTM](https://www.chm.bris.ac.uk/motm/motm.htm) or [NIST](https://webbook.nist.gov/chemistry/) - Chemistry Wikis
* [⁠Chempirical](https://chempirical.com/) - Chemistry Tools / Web
* [Video-Tutor](https://www.video-tutor.net/) / [YT](https://youtube.com/@theorganicchemistrytutor), [Tyler DeWitt](https://www.youtube.com/user/tdewitt451), [Allery Chemistry](https://www.youtube.com/channel/UCPtWS4fCi25YHw5SPGdPz0g), [Khan Academy AP Chemistry](https://www.khanacademy.org/science/ap-chemistry-beta), [Organic Chemistry etext](https://www.chem.ucalgary.ca/courses/351/Carey5th/Carey.html) or [PeriodicVideos](http://www.periodicvideos.com/) - Chemistry Lessons
* [ChemistrySteps](https://www.chemistrysteps.com/), [⁠ChemQuiz](https://chemquiz.net/), [Science Geek](https://www.sciencegeek.net/) or [DocBrown](https://docbrown.info/) - Chemistry Practice / Guides
* [Cliffnotes Chemistry](https://www.cliffsnotes.com/study-guides/chemistry/chemistry/elements/discovery-and-similarity) / [Organic Chemistry I](https://www.cliffsnotes.com/study-guides/chemistry/organic-chemistry-i) / [Organic Chemistry II](https://www.cliffsnotes.com/study-guides/chemistry/organic-chemistry-ii) or [chemguide](https://www.chemguide.co.uk) - Study Guides
* [ReactionFlash](https://play.google.com/store/apps/details?id=ch.reaxys.reactionflash&hl=en-US) / [iOS](https://apps.apple.com/us/app/reactionflash/id432080813) - Chemical Reaction Flashcards
* [⁠Compound Interest](https://www.compoundchem.com/infographics/) - Chemistry Infographics
* [Sciencenotes](https://sciencenotes.org) - Periodic Tables / Chemistry Projects and Questions
* [Organic Chemistry](https://www.organic-chemistry.org) or [Synarchive](https://synarchive.com/) - Organic Reactions
* [CommonOrganicChemistry](https://www.commonorganicchemistry.com) - Common Reactions / Common Reagents
* [name-reaction](https://www.name-reaction.com) - List of Name Reactions
* [ChemTube3D](https://www.chemtube3d.com) - Interactive 3D Chemistry Animations
* [ChemSpider](https://www.chemspider.com/) - Chemical Structures
* [⁠ChemOCR](https://github.com/kunal1320k/ChemOCR) - Extract Chemical Structures + Data from Images
* [Merck Index](https://merckindex.rsc.org/) - Online Merck Index
* [Organic Chemistry Data](https://organicchemistrydata.org/) - Organic Chemistry Data
* [IGOC](https://www.chem.ucla.edu/~harding/IGOC/IGOC.html) - Illustrated Glossary of Organic Chemistry
* [Not Voodoo ReduX](https://www.chem.rochester.edu/notvoodoo/) - Organic Chemistry Laboratory Techniques Guide
* [Colorado Chemistry Simulations](https://phet.colorado.edu/en/simulations/filter?subjects=chemistry&type=html%2Cprototype) - Chemistry Animations
* [Chemical Forums](https://www.chemicalforums.com/) - Chemistry Forums
* [ISODN Chemistry](https://discord.gg/cf7RN82) - ISODN Chemistry Discord Community
* [Arkivoc](https://www.arkat-usa.org/) - Journals
* [WebQC Balance Calculator](https://webqc.org/balance.php) - Chemical Equation Balance Calculator
* [Chemexper Chemical Directory](https://www.chemexper.com/) - Chemical Directory
* [OrgSyn](https://orgsyn.org/Default.aspx) - Chemistry Prep Guides

***

## ▷ Periodic Tables

* ⭐ **[Ptable](https://ptable.com/)** - Interactive Table
* ⭐ **[⁠Zperiod](https://zperiod.app/)** - Interactive Table / [Discord](https://discord.gg/xfKQD65udk)
* ⭐ **[Images of Chemical Elements](https://images-of-elements.com/)** - Element Images
* ⭐ **[periodic-table.org](https://www.periodic-table.org/)** or **[Material Properties](https://material-properties.org/)** - Material / Element Learning Resources
* [Atom Animation](https://atomanimation.com/) / [GitHub](https://github.com/matt765/atom-animation) or [3D Periodic Table](https://artsexperiments.withgoogle.com/periodic-table/) - 3D Visualizations of Atoms
* [Atomic](https://play.google.com/store/apps/details?id=com.jlindemann.science) - Periodic Table Mobile App
* [periodic-table.io](https://periodic-table.io/) - Interactive Table
* [WebElements](https://www.webelements.com) - Interactive Table
* [⁠Photographic Periodic Table](https://periodictable.com/) - Image-Based Periodic Table w/ Physical Examples

***

## ▷ Biology

* 🌐 **[⁠Awesome Bioinformatics](https://github.com/danielecook/Awesome-Bioinformatics)** - Bioinformatics Learning Resources + Tools
* ⭐ **[Wikispecies](https://species.wikimedia.org/)** or [The Catalogue of Life](https://www.catalogueoflife.org/) - Species Databases
* ⭐ **[OneZoom](https://www.onezoom.org/)** or [⁠Ptree](https://ptree.org/) - Tree of Life Reference / Explorers
* ⭐ **[Lost and Found Nature](https://www.lostandfoundnature.com/)** - Rediscovered Animal / Plant Database
* [A-Z Animal](https://a-z-animals.com/) - Animal Encyclopedia
* [⁠Wayne's Word](https://www.waynesword.net/) - Biology and Botany Information / Learning
* [Biology Online](https://www.biologyonline.com/) - Biology Articles
* [⁠Nature This Week](https://naturethisweek.com/) - View Nature / Biology News from any Location
* [Science Geek](https://www.sciencegeek.net/) - Biology Study Guides
* [LibreTexts Biology](https://bio.libretexts.org/Bookshelves) - Biology Learning / Guides
* [⁠HHMI BioInteractive](https://www.biointeractive.org/) - Interactive Biology Learning
* [Bodily Oddities](https://bodilyoddities.com/) - Human Anatomy Oddities Catalog
* [Project ⁠Alveus Sanctuary](https://www.alveussanctuary.org/) - 24/7 Educational Wildlife Live Streams / Conservation Project
* [⁠BioNinja](https://ib.bioninja.com.au/) - IB Biology Reference / Study Guide
* [⁠The Biology Project](https://biology.arizona.edu/) - Biology Problem Sets & Tutorials
* [Biodiversity Heritage Library](https://www.biodiversitylibrary.org/) - Biodiversity Research
* [Alien](https://alien-project.org/) - Artificial Life Simulator / [Video](https://youtu.be/w9R6zrdl6jM) / [GitHub](https://github.com/chrxh/alien)
* [⁠Map of Life](https://mol.org/) - Interactive Map of Species Distributions
* [⁠Movebank](https://www.movebank.org/cms/webapp) - Animal Tracking Map / Database
* [Metazooa](https://metazooa.com/) - Species Connection Game
* [⁠Phenome10K](https://www.phenome10k.org/) - Biological / Palaeontological 3D Scans
* [RecentlyExtinctSpecies](https://recentlyextinctspecies.com/) - Recently Extinct Species Database
* [UniProt](https://www.uniprot.org/) - Protein Database
* [iNaturalist](https://www.inaturalist.org/) - Organism Identification
* [Ocearch](https://www.ocearch.org/?list) - Track Marine Life
* [The Deep Sea](https://neal.fun/deep-sea/) - Interactive Deep Sea Life Guide
* [Pattern Radio](https://patternradio.withgoogle.com/) - Listen to Whale Songs
* [eBird](https://ebird.org/), [Audubon](https://www.audubon.org/) or [AllAboutBirds](https://www.allaboutbirds.org/) - Bird Species Databases / IDs
* [⁠BirdLife DataZone](https://datazone.birdlife.org/) - Bird Conservation Information
* [EuroBirdPortal](https://www.eurobirdportal.org/) - European Bird Distribution Map
* [⁠Koreaves](https://koreaves.com/gis/) - Korean Regional Bird Evidence Explorer
* [BirdSounds](https://experiments.withgoogle.com/ai/bird-sounds/view/) - Thousands of Bird Sounds Visualized
* [Merlin](https://play.google.com/store/apps/details?id=com.labs.merlinbirdid.app), [BirdNET](https://birdnet.cornell.edu/) or [whoBIRD](https://f-droid.org/fr/packages/org.woheller69.whobird/) - Bird Picture / Sound Identification
* [Featherbase](https://www.featherbase.info/en/home) - Bird Feather Database
* [BugGuide](https://bugguide.net/) - Insect Identification Community
* [AntWeb](https://www.antweb.org/) - Ant Species Database
* [Spider ID](https://spiderid.com/) - Spider Species Database / Identification Community
* [Macroinvertebrates](https://www.macroinvertebrates.org/) - Freshwater Macroinvertebrates Atlas
* [Life Under the Ice](https://lifeundertheice.org/) - View Antarctic Microbes
* [Pteros](https://www.pteros.com/) - Pterosaur Database
* [WFO](https://www.worldfloraonline.org/) - Plant Database
* [The Ferns](https://tropical.theferns.info/) - Tropical Plant Database
* [ISODN Biology](https://discord.gg/AzCQYY7) - ISODN Biology Discord Community

***

## ▷ Med School

* 🌐 **[r/MedicalSchool Wiki](https://www.reddit.com/r/medicalschool/wiki/resources)** - Med School Resources
* ↪️ **[Health Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25BA_health)**
* ⭐ **[Khan Academy](https://www.khanacademy.org/science/health-and-medicine)** - Physiology / Pathology Overviews
* ⭐ **[Radiopaedia](https://radiopaedia.org/)** or [Radiology Assistant](https://radiologyassistant.nl/) - Radiology Resources
* ⭐ **[⁠Stop the Bleed](https://www.stopthebleed.org/get-trained/)** - Free First Aid Video Courses / Resources
* [MDCalc](https://www.mdcalc.com/), [MSD Manuals](https://www.msdmanuals.com/) or [Epocrates](https://www.epocrates.com/) - Medical Reference Sites / Tools
* [Geeky Medics](https://geekymedics.com/), [UC San Diego CG](https://sites.ucsd.edu/clinicalmedguide/) or [Easy Auscultation](https://www.easyauscultation.com/) - Clinical Guides
* [LibreTexts Med](https://med.libretexts.org/Bookshelves) - Medical Learning / Guides
* [Get Body Smart](https://www.getbodysmart.com/), [Kenhub](https://www.kenhub.com/) or [University of Michigan Anatomy](https://sites.google.com/a/umich.edu/bluelink/curricula) - Anatomy Guides
* [AnatomyLearning](https://anatomylearning.com/), [⁠Clara Atlas](https://claraseg.com/) or [BioDigital](https://human.biodigital.com/index.html) - 3D Human Anatomical Models
* [NIH Print](https://3d.nih.gov/) - Biomedical Science 3D Models
* [Sectional Anatomy](https://www.sectional-anatomy.org/) - Cross Sectional Educational MRI / CT Scans
* [University of Minnesota Histology](https://www.histologyguide.org/index.html) - Histology Guides
* [Tulane University Pharmacology](https://tmedweb.tulane.edu/pharmwiki/doku.php/start) - Pharmacology Info & Quizzes
* [Litfl](https://litfl.com/ecg-library/) or [Healio ECG Review](https://www.healio.com/cardiology/learn-the-heart/ecg-review) - ECG Information
* [The ECG Course](https://www.youtube.com/playlist?list=PLVRaFpHAzzCgJdurDKLdG464Z2sMAy4oY) - ECG Video Course
* [ECG Wave-Maven: Self-Assessment Program](https://ecg.bidmc.harvard.edu/maven/mavenmain.asp) - ECG Practice / Learning
* [Hyper Heart](https://library.med.utah.edu/kw/pharm/hyperheart/#animation_container) - Massey University Heart Animation
* [Emergency Medicine Cases](https://emergencymedicinecases.com/) - EM Case Index
* [EMCrit](https://emcrit.org/) - Emergency Medicine Information
* [DeployedMedicine](https://deployedmedicine.com/) (Sign-Up) or [TCCC](https://tccc.org.ua/en) - Combat Medicine Guide / Manuals / Videos
* [EMRap](https://www.emrap.org/hd) - Emergency Medicine Videos
* [⁠Lifesaver](https://lifesaver.org.uk/) - Interactive CPR / First Aid Training Videos
* [Calgary Guide](https://calgaryguide.ucalgary.ca/) - Disease Pathophysiology / Manifestation Flow-Charts
* [MalaCards](https://www.malacards.org/) - Human Disease Database
* [⁠Folding@home](https://foldingathome.org/) - Donate Idle PC to Disease Research
* [Epidemic Calculator](https://gabgoh.github.io/COVID/index.html) - COVID Data
* [Pathology Outlines](https://www.pathologyoutlines.com/) - Pathology Info
* [University of Utah Pathology](https://webpath.med.utah.edu/webpath.html) - Pathology Guide
* [The Iowa Virtual Slidebox](https://www.mbfbioscience.com/iowavirtualslidebox) - Pathology Atlas Software
* [Nextstrain](https://nextstrain.org/) - Pathogen Evolution Tracking
* [⁠HemOnc](https://hemonc.org/) - Hematology / Oncology Reference Site
* [DermNet](https://dermnetnz.org/) - Dermatology Reference Site
* [⁠EyeWiki](https://eyewiki.org/) - Eye Encyclopedia
* [Passmedicine](https://www.passmedicine.com/ucat/) - UCAT Practice Questions
* [UCAT Score](https://codepen.io/souramoo/full/OJMQzVm) - UCAT Score Converter
* [r/medicalschoolanki](https://www.reddit.com/r/medicalschoolanki/) - Community for Medical Anki Cards
* [Erowid](https://www.erowid.org/), [dose.wiki/](https://dose.wiki/) or [Shroomery](https://www.shroomery.org/) - Educational Psychoactive Substance Reference
* [PsychonautWiki](https://psychonautwiki.org/wiki/Main_Page) - Educational Psychonautics & Pharmacology Database

***

# ► Space

* ⭐ **[r/Space](https://reddit.com/r/Space)** - Space Subreddit
* ⭐ **[Space Dashboard](https://spacedashboard.com/)** - Space Live Stream Dashboard
* ⭐ **[NASA](https://www.nasa.gov/)** - National Aeronautics and Space Administration Website / [Images](https://images.nasa.gov/) / [Audio](https://www.nasa.gov/audio-and-ringtones/) / [Documents](https://ntrs.nasa.gov/search) / [APIs](https://api.nasa.gov/) / [History](https://www.nasa.gov/history/)
* ⭐ **[March to the Moon](https://tothemoon.im-ldi.com/)**, [Apollo Image Atlas](https://www.lpi.usra.edu/resources/apollo/) or [ApolloArchive](https://apolloarchive.com/) / [Flickr](https://www.flickr.com/photos/projectapolloarchive/albums/) - Apollo (Missions) Images
* [Apollo in Realtime](https://apolloinrealtime.org/) or [FirstMenOnTheMoon](https://www.firstmenonthemoon.com/) - Interactive Apollo Missions
* [Artemis II Photo Timeline](https://artemistimeline.com/) - Artemis II Photo & Video Timeline
* [⁠Lunaserv Global Explorer](https://data.im-ldi.com/lunaserv.html) - Interactive LROC / Moon Exploration Tool
* [Marspedia](https://marspedia.org/) - Mars Wiki
* [ESA](https://www.esa.int/) - European Space Agency Website / [X](https://x.com/ESA_Webb)
* [JAXA](https://global.jaxa.jp/) - Japanese Space Agency Website / [Images / Videos](https://jda.jaxa.jp/?lang=e)
* [CSA](https://www.asc-csa.gc.ca/eng/) - Canadian Space Agency Website
* [ISRO](https://www.isro.gov.in/) - Indian Space Research Organization
* [Space.com](https://www.space.com/) - Space News
* [⁠Russian Space Web](https://russianspaceweb.com/) - Russian Space Program News / History / [X](https://x.com/russianspaceweb)
* [⁠Mental Landscape](http://mentallandscape.com/) - Soviet Space Exploration Archive / [X](https://x.com/DonaldPMitchell)
* [Encyclopedia Astronautica](http://www.astronautix.com/) - Space Encyclopedia
* [NASA+](https://plus.nasa.gov/) - Official NASA Streaming Service
* [NASA History](https://www.nasa.gov/history/history-publications-and-resources/) / [X](https://x.com/NASAhistory) or [NASA Ebooks](https://www.nasa.gov/ebooks/) - NASA Books
* [⁠Ask an Astronaut](https://askanastronaut.issinrealtime.org/) - Astronaut Interview Q&A Search
* [⁠Cosmos2025](https://cosmos2025.iap.fr/fitsmap.html), [Map of the Universe](https://mapoftheuniverse.net/), [⁠Your Eyes In Space](https://www.youreyesinspace.com/), [Universe Atlas](https://universeatlas.org/), [Scale of the Universe](https://scaleofuniverse.com/), [AndroidCelestia](https://github.com/celestiamobile/AndroidCelestia/) or [SpaceEngine](https://spaceengine.org/) - 3D Universe Scale Explorers & Simulators
* [NASA's Eyes](https://science.nasa.gov/eyes/) or [Celestia](https://celestiaproject.space/) - 3D Space Visualizations / [Solar System](https://eyes.nasa.gov/apps/solar-system/#/home)
* [RGV Aerial Photography](https://discord.gg/wsFxEw9g4X) - Aerial Photography Community / News / [X](https://x.com/RGVaerialphotos)
* [TheCMB](http://thecmb.org/) - 3D Cosmic Microwave Background Model
* [ISODN Earth Science](https://discord.gg/ujvMHFV) - ISODN Earth Science Discord Community

***

## ▷ Astronomy

* 🌐 **[Astronomy Resources](https://er-cryptid.tumblr.com/post/176809097526/free-astronomy-resources)** - Astronomy Resources
* ⭐ **[NASA2Explore](https://www.flickr.com/photos/nasa2explore/)**, [ESO Images](https://www.eso.org/public/images/) or [Astrobin](https://www.astrobin.com/search/) - Astronomy Images
* ⭐ **[JPL Photojournal](https://science.nasa.gov/photojournal/)** or [JPL Images](https://www.jpl.nasa.gov/images) - JPL Planetary Image Archives
* ⭐ **[In The Sky](https://in-the-sky.org/)** - Astronomy News / Interactive Guides
* [ISODN Astronomy & Astrophysics](https://discord.gg/8DJrk78) - ISODN Astronomy & Astrophysics Discord Community
* [ViewSpace](https://viewspace.org/) - Space Videos and Digital Interactives
* [Sky Calendar](https://www.skycalendar.com/skycal/calendar) - Astronomy Calendar
* [Nights on Earth](https://nightsonearth.com/) - Astronomical Event Calendar
* [SolarHam](https://solarham.com/), [⁠Space Weather (gov)](https://www.spaceweather.gov/) or [SpaceWeather](https://spaceweather.com/) - Space Weather News & Updates
* [SunCalc](https://www.suncalc.org/), [ShadeMap](https://shademap.app/) or [MoonCalc](https://www.mooncalc.org/) - Sun / Moon Position
* [Earth and Moon Viewer](https://www.fourmilab.ch/cgi-bin/Earth) - Earth / Moon Latitude and Longitude Viewer
* [SDO Dashboard](https://sdo.gsfc.nasa.gov/data/dashboard/) - Live Sun Feed
* [SkyViewer](https://skyviewer.app/) or [100,000 Stars](https://stars.chromeexperiments.com/) - Interactive Star Visualizations
* [⁠Space Time](https://space.pointdynamics.com/) or [⁠SpaceSim](https://spacesim.co/) - 3D Solar System / Star System Simulators
* [TheSkyLive](https://theskylive.com/), [Solar System Scope](https://www.solarsystemscope.com/), [⁠Luna Space Simulator](https://luna.watermelonson.com/) or [Atlas of Space](https://atlasof.space/) - Solar System Simulators / Information
* [CelesTrack](https://celestrak.org/) - Earth Orbit Visualization
* [Space Object Comparison](https://mr21.github.io/space-object-comparison/) - Compare Sizes Of Celestial Objects
* [1 Pixel moon](https://www.joshworth.com/dev/pixelspace/pixelspace_solarsystem.html), [LightYear](https://www.lightyear.fm/) or [OMG SPACE](https://omgspace.net/) - Solar System Scale Model
* [Astrogeology](https://astrogeology-usgs.hub.arcgis.com/pages/map-search) - Planetary Maps
* [⁠Eyes on Exoplanets](https://eyes.nasa.gov/apps/exo) or [ExoplanetExplore](https://exoplanetexplore.vercel.app) - Interactive Exoplanet Explorers / Viewers
* [ExoplanetArchive](https://exoplanetarchive.ipac.caltech.edu/) - Exoplanet Database
* [AndroidPlanisphere](https://github.com/tengel/AndroidPlanisphere) - Android Star Chart
* [Aladin](https://aladin.cds.unistra.fr/) - Astronomical Image Viewer / [Lite Version](https://aladin.cds.unistra.fr/AladinLite/)
* [Siril](https://siril.org/) - Astronomical Image Processor
* [ESAsky](https://sky.esa.int/esasky/) - Public Astronomical Data
* [Stellarium-Web](https://stellarium-web.org/) or [Stellarium](https://stellarium.org/) / [GitHub](https://github.com/Stellarium/stellarium) - Virtual Stellariums
* [WorldwideTelescope](https://worldwidetelescope.org/) - Interactive Telescope Data / [Home Page](https://worldwidetelescope.org/home/) / [GitHub](https://github.com/WorldWideTelescope)
* [ESA Hubble](https://esahubble.org/) / [X](https://x.com/hubble_space), [SpaceTelescopeLive](https://spacetelescopelive.org/) / [X](https://x.com/spacetelelive) or [HubbleSite](https://science.nasa.gov/mission/hubble/) / [X](https://x.com/NASAHubble) - Hubble Telescope Images
* [James Webb Space Telescope](https://science.nasa.gov/mission/webb/) / [X](https://x.com/nasawebb) or [ESAWebb](https://esawebb.org/) / [X](https://x.com/ESA_Webb) - Webb Space Telescope Sites
* [Webb Compare](https://www.webbcompare.com/) - Webb / Hubble Images / [GitHub](https://github.com/JohnEdChristensen/WebbCompare/tree/gh-pages)
* [APOD](https://science.nasa.gov/apod/) - Daily NASA Astronomy Images
* [r/SpacePorn](https://www.reddit.com/r/spaceporn/) or [r/Astrophotography](https://www.reddit.com/r/astrophotography/) - Astrophotography Subreddits
* [Meteor Showers](https://www.meteorshowers.org/) - 3D Meteor Shower Visualization
* [Live Meteors](https://www.livemeteors.com/) - Live Meteor Radio Echoes
* [Clear Dark Sky](https://cleardarksky.com/) - Star Gazing Weather Forecasts
* [Dark Site Finder](https://darksitefinder.com/), [DarkSkyMap](https://darkskymap.com/) or [GoStarGazing](https://gostargazing.co.uk/) - Star Gazing Site Locators
* [Light Pollution Map](https://lightpollutionmap.info/) or [lightpollutionmap](https://lightpollutionmap.app) - Light Pollution Maps

***

## ▷ Spacecraft

* ↪️ **[Aerospace Engineering Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25BA_aerospace_engineering)**
* ↪️ **[Satellite / Earth Data](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_satellite_.2F_earth_data)**
* ⭐ **[EarthData](https://worldview.earthdata.nasa.gov/)** - Daily Satellite Replays
* ⭐ **[Earth Observatory](https://science.nasa.gov/earth/earth-observatory/)**, [Copernicus Browser](https://browser.dataspace.copernicus.eu/), [SpaceFromSpace](https://spacefromspace.com/), [GOES-16 Satellite Imagery](https://slider.cira.colostate.edu/) or [Sentinel Hub](https://www.sentinel-hub.com/) - Satellite Imagery
* [NASASpaceFlight](https://www.nasaspaceflight.com/) - Launch Livestreams / News / [Forum](https://forum.nasaspaceflight.com/) / [X](https://x.com/NASASpaceflight) / [YouTube](https://www.youtube.com/@NASASpaceflight)
* [⁠Next Spaceflight](https://nextspaceflight.com/) / [X](https://x.com/NextSpaceflight) / [Discord](https://discord.gg/nextspaceflight), [⁠Space Notices](https://space-notices.com/), [nextrocket.space](https://nextrocket.space/) or [RocketLaunch](https://rocketlaunch.org/) - Rocket Launch & Spaceflight Schedules / Trackers
* [TonyBela Infographics](https://tonybela.com/) - Spacecraft / Rocket Infographics / [X](https://x.com/InfographicTony)
* [⁠Historic Spacecraft](https://historicspacecraft.com/) - Spacecraft / Rocket Photos & illustrations
* [⁠HeroicRelics](http://heroicrelics.org/) - Spacecraft Technical Information Archive
* [⁠Encyclopedia Astronautica](http://www.astronautix.com/) - Spaceflight & Rocketry History Encyclopedia
* [⁠Starship Telemetry](https://telemetry.starshipspaceprogram.com/) - Starship Flight Test Replays + Telemetry / [X](https://x.com/fael097) / [Discord](https://discord.gg/2VeySaYN3x)
* [⁠Ringwatchers](https://ringwatchers.com/) - Starship Diagrams / Articles / Community / [X](https://x.com/ringwatchers) / [Discord](https://discord.com/invite/ringwatchers)
* [Energia-Buran Archive](https://buranarchive.space/) - Energia-Buran Image Archive / [X](https://x.com/11K25_Energia)
* [Andegraf Rockets](https://rockets.andegraf.com/) - Rocket Diagrams
* [⁠Gunter's Space Page](https://space.skyrocket.de/) - Satellite Encyclopedia / Launch Database / [X](https://x.com/Skyrocket71)
* [⁠Sven's Space Place](https://www.svengrahn.pp.se/) - Space Mission Technical Analysis
* [Orbiter](https://www.orbiter-forum.com/) - Open Source Spaceflight Simulator / [Subreddit](https://www.reddit.com/r/Orbiter/) / [GitHub](https://github.com/orbitersim/orbiter)
* [Sen](https://www.sen.com/) - ISS Live Feed + Video Archive / [YouTube](https://www.youtube.com/@Sen) / [X](https://x.com/sen)
* [ISS In Realtime](https://issinrealtime.org/) - Historical ISS Mission Replays / Database
* [ISS Sim to SPACEX](https://iss-sim.spacex.com/) - ISS Docking Simulator / [X](https://x.com/spacex)
* [Transit Finder](https://transit-finder.com/), [ISS Tracker](https://isstracker.pl/en), [Spot The Station](https://www.nasa.gov/spot-the-station/) or [Where The ISS At?](https://wheretheiss.at/) - ISS Transit Tracking
* [Satellite Map](https://satellitemap.space/), [KeepTrack](https://keeptrack.space/) / [GitHub](https://github.com/thkruz/keeptrack.space/), [SGP4](https://sgp4gl-demo.vercel.app/) / [GitHub](https://github.com/Kayhan-Space/sgp4gl-demo), [KeepTrackSpace](https://www.keeptrack.space/), [⁠Track The Sky](https://trackthesky.com/), [Find Starlink](https://findstarlink.com/), [Space Atlas](https://www.spaceatlas.tech/) / [X](https://x.com/ApoStructura), [⁠Périgée](https://dlamarre-dev.github.io/Perigee/?lang=en), [⁠azmth](https://azmth.space/) or [Look4Sat](https://github.com/rt-bishop/Look4Sat) - Satellite Orbit Maps / Trackers
* [See A Satellite Tonight](https://james.darpinian.com/satellites/) - Satellite Viewing Schedule / Locations
* [⁠Visual Satellite Observer](https://www.satobs.org/) - Satellite Viewing Guides / Information
* [Spacebook](https://www.spacebook.com/) - Evaluates / Tracks Satellite Collision Risks & Maneuvers
* [Leolabs Space](https://platform.leolabs.space/visualization) - Low Earth Orbit Simulator / [X](https://x.com/leolabs_space)

***

# ► Aerospace Engineering

* 🌐 **[⁠Star Rocketry](https://starrocketry.github.io/archive/AE4L/)** or **[Awesome Aerospace Engineering](https://github.com/mahran-sayed/awesome-aerospace-engineering/)** - Aerospace Engineering Learning Resources
* 🌐 **[Awesome Flying FPV](https://github.com/Matthias84/awesome-flying-fpv)** - Remote Copter / Plane Resources
* ↪️ **[Spacecraft Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7_spacecraft)**
* ↪️ **[Flight Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_flights)**
* [⁠r/AerospaceEngineering](https://www.reddit.com/r/AerospaceEngineering/) - Aerospace Engineering Community
* [⁠AerospaceWeb](https://aerospaceweb.org/) - Aerospace Info Database / Calculators / Q&A
* [⁠JetPhotos](https://www.jetphotos.com/) / [Forums](https://forums.jetphotos.com/) / [X](https://x.com/jetphotos), [AirHistory](https://www.airhistory.net/) or [PlaneSpotters](https://www.planespotters.net/) - Aircraft Indexes / Images
* [Flight Mechanics](https://www.aircraftflightmechanics.com) - Aircraft Flight Mechanics Learning
* [eCalc](https://www.ecalc.ch/) - Aerospace Engineering Calculators / [X](https://x.com/eCalc_e)
* [⁠Av8n](https://www.av8n.com/) - Aviation Physics Textbook
* [SmartCockpit](https://www.smartcockpit.com/) - Aircraft Systems / Technical Manuals
* [⁠F-16.net](https://www.f-16.net/) - F-16 Information, History, Images, Stories & more
* [⁠HeliStart](http://www.helistart.com/) - Helicopter Aerodynamics / Flight Mechanics Guides + History
* [⁠V2Rocket](https://www.v2rocket.com/) - A-4 & V-2 Rocket History / Resources
* [Boeing 737 Technical Site](http://www.b737.org.uk/) - B737 Technical Engineering Guides / History / [X](https://x.com/B737Tech) / [YouTube](https://www.youtube.com/@ChrisBrady737)
* [OpenVSP](https://www.openvsp.org/) - Aircraft Geometry Tool / [GitHub](https://github.com/OpenVSP/OpenVSP)
* [UIUC Applied Aerodynamics Group](https://m-selig.ae.illinois.edu/ads.html) - Airfoil Coordinates / Aerodynamic Research
* [XFLR5](https://www.xflr5.tech/) - Airfoils Analysis Tool
* [Outerzone](https://outerzone.co.uk/) or [⁠AeroFred](https://www.aerofred.com/) - Model Airplane Plans
* [Airfoil Tools](http://airfoiltools.com/) - Airfoil Coordinates / Dat Files

***

## ▷ Rocketry

* [⁠The Rocketry Forum](https://www.rocketryforum.com/) or [Ye Olde Rocket Forum](https://www.oldrocketforum.com/) - Rocketry Forums / Community
* [⁠r/rocketry](https://www.reddit.com/r/rocketry/) - Rocketry Community / [Discord](https://discord.com/invite/Ezgs4TGXvx)
* [Nakka Rocketry](https://nakka-rocketry.net/) - Rocket Technical Archive
* [JCRocket](https://www.jcrocket.com) - Rocketry Technical Information / [YouTube](https://www.youtube.com/@JohnLCoker)
* [Half Cat Rocketry](https://www.halfcatrocketry.com/) - Liquid Rocket Guide / Info / Resources / Documentation / [X](https://x.com/HalfCatRocketry) / [Discord](https://discord.gg/y2AH6ZegBX) / [GitHub](https://github.com/HalfCatRocketry)
* [Robert’s Rocket Project](https://watzlavick.com/robert/rocket/) - LOX/Kerosene Liquid Rocket Info / Resources / Documentation
* [⁠OpenRocket](https://openrocket.info/) - Rocket Simulator / [Wiki](https://wiki.openrocket.info) / [Discord](https://discord.gg/qD2G5v2FAw) / [GitHub](https://github.com/openrocket/openrocket)
* [⁠RocketReviews](https://www.rocketreviews.com/) - Rocket Reviews / Test Results
* [ThrustCurve](https://github.com/JohnCoker/thrustcurve3) - Rocket Motor Performance Database
* [⁠MIT Rocket Team](https://wikis.mit.edu/confluence/display/RocketTeam/MIT+Rocket+Team+Home) - Official MIT Rocket Team Wiki / Wiki / Resources
* [⁠Jacobs Rocketry](https://www.jacobsrocketry.com/) - Rocketry Info / Manuals
* [Tripoli Rocketry](https://www.tripoli.org/) or [⁠NAR](https://www.nar.org/) / [Facebook](https://www.facebook.com/groups/2255560886/) - High-Powered Rocket Resources / Info
* [⁠Hot Nozzle Society](https://www.hotnozzlesociety.org/) - High-Power Rocketry Guide / Community / [X](https://x.com/HotNozzleSummer) / [Discord](https://discord.gg/ryjP9bUmkY)
* [⁠RocketPy](https://docs.rocketpy.org/) - High-Powered Rocket Simulator / [Discord](https://discord.gg/b6xYnNh) / [GitHub](https://github.com/RocketPy-Team/RocketPy)
* [openMotor](https://github.com/reilleya/openMotor) - Internal Ballistics Simulator

***

## ▷ Drones

* [⁠UAVs FYI](https://www.uavs.fyi/) - Drone Information, Resources, Hardware & Supply Chain Analysis / [X](https://x.com/osoraku_1997)
* [⁠OscarLiang.com](https://oscarliang.com/) - FPV Drone Tutorials / Reviews / [X](https://x.com/OscarLiang1)
* [RCPlanes Online](https://rcplanes.online/) - RC Plane Aerodynamics / Guides
* [⁠My Balsa & Glass Workshop](https://balsaandglass.com/Balsa_Builds.html) - RC Model Builds
* [OpenDroneMap](https://www.opendronemap.org/) / [GitHub](https://github.com/OpenDroneMap/) or [WebODM](https://webodm.org/) - Drone Mapping Software
* [Open Drone Logbook](https://opendronelog.com/) - FOSS Drone Log / [X](https://x.com/ArpanDesign) / [Discord](https://discord.gg/YKgKTmSm7B) / [GitHub](https://github.com/arpanghosh8453/drone-logbook)
* [Stolen Drone](https://stolendrone.info/) - Stolen Drone Info

***

## ▷ Simulators

* [Falcon BMS](https://www.falcon-bms.com/) - Falcon 4.0 Modernization Project / [Manuals](https://wiki.falcon-bms.com/en/manuals) / [Wiki](https://wiki.falcon-bms.com/) / [Forum](https://forum.falcon-bms.com/) / [YouTube](https://www.youtube.com/@falcon-bms) / [Subreddit](https://www.reddit.com/r/falconbms/) / [Discord](https://discord.gg/KQNHQBz)
* [FlightGear](https://www.flightgear.org/) - Open-Source Flight Simulator / [X](https://x.com/flightgearsim) / [GitLab](https://gitlab.com/flightgear/flightgear)
* [Phoenix RC](https://www.rc-thoughts.com/phoenix-sim/) - RC Plane + Helicopter Simulator
* [SeligSIM](https://www.seligsim.com/) or [PicaSim](https://www.rowlhouse.co.uk/PicaSim/) / [GitHub](https://github.com/Rowlhouse/PicaSim) - Flight Simulators for RC Planes
* [CKAN](https://github.com/KSP-CKAN/CKAN) - Kerbal Space Program Mod / Dependency Manager
* [Luna Multiplayer](https://lunamultiplayer.com/) - Kerbal Space Program Multiplayer Mod / [Discord](https://discord.gg/wKVMhWQ) / [GitHub](https://github.com/LunaMultiplayer/LunaMultiplayer)
* [⁠SatModeler](https://satmodeler.com/) - Satellite Mission Simulation Software / Signup Required

***

# ► History

* ↪️ **[Historical Film Archives](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25B7_film_archives)**
* ↪️ **[History Books](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/reading/#wiki_.25B7_history_books)**
* ↪️ **[Historical Maps](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_historical_maps)** - Map Resources
* ⭐ **[Historic Films](https://www.historicfilms.com/)** or [National Film Preservation Foundation](https://www.filmpreservation.org/) - Historic Footage / Films
* ⭐ **[Histography](https://histography.io/)** - History Timelines
* ⭐ **[MorbidKuriosity](https://morbidkuriosity.com/)** - Dark History, Conspiracies, Crime, Myths, etc.
* [LibreTexts History](https://human.libretexts.org/Bookshelves/History) - History Learning Texts
* [Smithsonian Institution Archives](https://siarchives.si.edu/), [⁠Princeton Digital Collections](https://digital-collections.princeton.edu/) or [Rare Historical Photos](https://rarehistoricalphotos.com/) - Historical Photos / Documents
* [Museo](https://museo.app/) - Museum Search
* [⁠The Rest is History Archive](https://archive.therestishistory.com/) - Era-Based Historical Podcast
* [⁠Arachne](https://arachne.dainst.org/) - Archaeology Object Database
* [Wonderous](https://play.google.com/store/apps/details?id=com.gskinner.flutter.wonders) - Learn About Ancient Structures
* [⁠Pantheon](https://pantheon.world/) - Historical Figure Database + Trivia
* [Shorpy](https://shorpy.com/) - Historical Photos
* [⁠Historic Aerials](https://www.historicaerials.com/) - US Historical Aerial Imagery / Maps
* [EyewitnesstoHistory](http://www.eyewitnesstohistory.com/index.html) - Historical Eyewitness Testimonies
* [HMDB](https://www.hmdb.org/) - Historical Marker Database
* [⁠London Remembers](https://www.londonremembers.com/) - London Historical Marker Database
* [⁠dark-tourism](https://dark-tourism.com/) - Respectful / Non-Sensationalist Guide to Historical, Memorial & Dark Tourism Sites
* [ManuscriptMiniatures](https://manuscriptminiatures.com/) - Medieval Manuscript Images
* [Emblematica Online](http://emblematica.grainger.illinois.edu/) - Renaissance Emblem Book & Image Archive
* [⁠Ancient Graffiti](https://ancientgraffiti.org/) - Early Roman Handwritten Inscriptions
* [BlackPast](https://www.blackpast.org/) - African History Encyclopedia
* [Athena](https://athena.unige.ch/athena/) - Greek History Encyclopedia
* [Mission US](https://www.mission-us.org/) - American History Learning Games
* [On This Day](https://www.onthisday.com/) - What Happened on Specific Days
* [Royal Constellations](https://royalconstellations.visualcinnamon.com/) - Royal Family Ancestral Visualization
* [⁠WildWinds](https://www.wildwinds.com/) - Ancient Numismatics / Coin Database
* [The Food Timeline](https://www.foodtimeline.org/) - Food History Timeline
* [Historical Recipes](https://l-lists.com/en/lists/55cbww.html) or [Tasting History](https://www.tastinghistory.com/) - Historical Recipes
* [⁠Gode Cookery](http://www.godecookery.com/godeboke/godeboke.htm) - Authentic Medieval Recipes & Historical Info
* [⁠The Food Historian](https://www.thefoodhistorian.com/) - Food History Blog
* [SmartHistory](https://smarthistory.org/) - Art / Cultural Object History
* [Gwulo](https://gwulo.com/) - Historical Hong Kong Photo Archive
* [CARI](https://cari.institute/) or [CARI Are.na](https://www.are.na/consumer-aesthetics-research-institute/channels) - Design Aesthetics History
* [ChinesePosters](https://chineseposters.net/) - Chinese Propaganda Poster History
* [⁠Fashion History Timeline](https://fashionhistory.fitnyc.edu/) or [Historical Fashion](https://docs.google.com/document/d/1R8eulTsb9Zlc7h2H917dNJZS9s0rIq9OAu7LpSS9F2k/) - Historical Fashion Resources / History
* [PessimistsArchive](https://pessimistsarchive.org/) - Historical Technological Pessimism Archive
* [⁠Anthropeum](https://anthropeum.com/) - Historical Artifact Guessing Game
* [Time Portal](https://www.eggnog.ai/entertimeportal), [⁠WenWare](https://wen-ware.com/) or [TimeGuessr](https://timeguessr.com/) - Historical Time-Period GeoGuessr
* [Forebears](https://forebears.io/) or [Behind the Name](https://www.behindthename.com/) - Name Etymologies

***

## ▷ Tech History

* ↪️ **[Gaming History / Preservation](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools#wiki_.25B7_history_.2F_preservation)**
* ⭐ **[⁠Historical Tech Tree](https://www.historicaltechtree.com/)** / [Discord](https://discord.gg/e96JwQjUmX) or [Calculating Empires](https://calculatingempires.net/) - Historical Discovery / Tech Timelines
* [ETHW](https://ethw.org/) - Engineering and Technology History Wiki
* [Museum of Obsolete Media](https://obsoletemedia.org/) - Physical Media Format Wiki / History
* [BetaWiki](https://betawiki.net/wiki/Main_Page) / [Discord](https://discord.com/invite/XPz5Zm42tR) - Operating System / Software History
* [Old Computer Museum](https://oldcomputers.net/) - Computer History
* [The Retro Web](https://theretroweb.com/) / [Discord](https://discord.gg/HWWH7hsk2p) / [GitLab](https://gitlab.com/ultimateretro/ultimateretro) or [⁠Hardware Museum](https://hw-museum.cz/) - Computer Hardware History
* [⁠HP Computer Museum](https://www.hpmuseum.net/) or [The HP 9845 Project](https://www.hp9845.net/) - HP Computer History
* [Folklore](https://www.folklore.org) / [X](https://x.com/ComputerHistory) or [TheAppleWiki](https://theapplewiki.com/) / [Discord](https://discord.com/invite/zk2HggAw89) - Apple Computer History
* [Crypto Museum](https://www.cryptomuseum.com/) - Cryptographic Machine History
* [VGA Museum](https://www.vgamuseum.info/) - Graphic Cards History
* [Virus Encyclopedia](http://virus.wikidot.com/) - Computer Virus History
* [MobilePhoneMuseum](https://www.mobilephonemuseum.com/) - Mobile Phone History / Info
* [⁠ObsoleteSony](https://www.obsoletesony.com/) or [WalkmanLand](https://walkman.land/) - Portable Audio Player History / Databases
* [⁠Web Rewind](https://web-rewind.com/) - Interactive Web History 
* [⁠Web Screenshots](https://www.dmdev.it/webscreens/) - Website Screenshot Archive
* [InfoMesh](https://infomesh.org/) - Web History / Info
* [VersionMuseum](https://www.versionmuseum.com/) - Website History / Info
* [info.cern](https://info.cern.ch/) - First Website on the Internet
* [TubeVault](https://tubevault.app/) - Archive of Oldest YouTube Users & Videos
* [⁠rip.so](https://rip.so/), [Killed By Google](https://killedbygoogle.com/), [Killed by Mozilla](https://killedbymozilla.com/), [Microsoft Graveyard](https://microsoftgraveyard.com/) or [Sued by Nintendo](https://www.suedbynintendo.com/) - Dead Project Archives

***

## ▷ Military / Conflict History

* 🌐 **[⁠WW2 Links](https://ww2links.ca/)** - Educational WW2 Resources
* [De Re Militari](https://deremilitari.org/articles/) - Medieval Military History
* [Royal Armouries Collections](https://royalarmouries.org/collection/) - Armaments Museum / [X](https://x.com/Royal_Armouries)
* [⁠Battle Order](https://www.battleorder.org/) - Historical Military Infographics / [X](https://x.com/battle_order)
* [⁠TracesOfWar](https://www.tracesofwar.com/) - Military History & Battlefield Landmark Archive / [Subreddit](https://www.reddit.com/r/TracesOfWarHQ/) / [X](https://x.com/tracesofwar)
* [⁠World War II Database](https://ww2db.com/) or [⁠HyperWar](https://www.ibiblio.org/hyperwar/) - WW2 History Databases
* [WW2 in 100 Objects](https://www.tweedewereldoorlog.nl/100voorwerpen/en/virtual-tour/) - WW2 Museum Virtual Tour
* [Smithsonian Institution Archives](https://siarchives.si.edu/) - WW1 and WW2 Image Archive
* [⁠Little Friends](https://www.littlefriends.co.uk/) - WW2 8th Air Force History Archive
* [U-boat Archive](https://uboatarchive.net/) - WW2 Battle of the Atlantic Historical Archive / [X](https://x.com/uboatarchive)
* [Nuremberg Trials Project](https://nuremberg.law.harvard.edu/) - Nuremberg Trials Document / Transcript Archive
* [⁠CherriesWriter](https://cherrieswriter.com/) - Vietnam War Stories, Photos, Videos and more
* [⁠VietnamGear](https://www.vietnamgear.com/) - Vietnam War Gear Info / Photos
* [⁠Center of Military History](https://history.army.mil/) - U.S. Military History / Collection
* [⁠Vintorez](https://vintorez.com/) - Russian & Soviet Military Gear Info / Photos / [X](https://x.com/RusforK)
* [Imperial War Museums](https://www.iwm.org.uk/) - British & Commonwealth War Footage / [X](https://x.com/I_W_M)
* [⁠Anzac Portal](https://anzacportal.dva.gov.au/) - Australian Military History / Stories
* [Tank Archives](https://www.tankarchives.com/) - WW2 Armoured Warfare Documents / [X](https://x.com/Tank_Archives)
* [NHHC](https://www.history.navy.mil/), [⁠RNRA](https://www.royalnavyresearcharchive.org.uk/), [⁠NavSource](https://www.navsource.net/), [WarshipsResearch](https://warshipsresearch.blogspot.com/) or [⁠The Dreadnought Project](https://www.dreadnoughtproject.org/) / [X](https://x.com/NavyHistorian) - Naval & Maritime History Sites
* [⁠NavWeaps](https://www.navweaps.com/) - Naval Weapons, Technology and Reunion History
* [⁠Coast Guard Historian's Office](https://www.history.uscg.mil/) - U.S. Coast Guard History / Collection
* [Shipbucket](https://www.shipbucket.com/) - Scale Drawings & Blueprints of Naval Ships / [Discord](https://discord.com/invite/5PHq8Dk)
* [⁠Warbirds Resource Group](https://www.warbirdsresourcegroup.org/) - Military Aviation History Encyclopedia
* [⁠RAF Museum](https://www.rafmuseum.org.uk/our-collection/) - Royal Air Force Historical Collection / Stories
* [Harald Joergens Panoramas](https://www.haraldjoergens.com/panoramas.php) - Aircraft Virtual Tours
* [⁠Warbird Alley](http://www.warbirdalley.com/) or [⁠Forgotten Aviation](https://forgottenaviation.com/) - Historical Archives of Military Aircraft
* [⁠F-16.net](https://www.f-16.net/) - F-16, F-22 and F-35 Info, History, Images, Stories & more
* [The History of Maritime Piracy](http://www.cindyvallar.com/pirates.html) - Piracy History Blog
* [Byzantine Military](https://byzantinemilitary.blogspot.com/) - Byzantine Military History
* [911 Realtime](https://911realtime.org/) - 9/11 in Real-Time / [GitHub](https://github.com/Keeping-History/rt911)
* [Atom Central](https://www.atomcentral.com/) - Historical Archive of Atomic & Nuclear Tests / [YouTube](https://www.youtube.com/@atomcentral)
* [NuclearWeaponArchive](https://nuclearweaponarchive.org/) - Nuclear Weapons History

***

## ▷ Mythology / Folklore

* ⭐ **[GodChecker](https://www.godchecker.com/)** - Historical Mythology Encyclopedia
* ⭐ **[Theoi](https://www.theoi.com/)** - Greek Mythology
* [⁠Mythopedia](https://mythopedia.com/) - Historical Mythology Encyclopedia
* [Germanic Mythology](https://www.germanicmythology.com/index.html) - Germanic Mythology
* [Inuit Myths](https://www.inuitmyths.com/index.htm) - Inuit Mythology
* [ObscUrban Legend Wiki](https://obscurban-legend.fandom.com/) - Mythology / Urban Legends
* [Encyclopedia Mythica](https://pantheon.org/) - Mythology / Folklore / Religion
* [FolkTexts](https://sites.pitt.edu/~dash/folktexts.html) - Mythology / Folklore
* [Mythology.net](https://mythology.net/) - Mythology / Religion
* [Japanese Mythology](https://japanesemythology.wordpress.com/) or [Yokai](https://yokai.com/) - Japanese Mythology / Folklore
* [ABookOfCreatures](https://abookofcreatures.com/) or [Bestiary](https://bestiary.ca/beasts.htm) - Mythical Creature Encyclopedias
* [BlackDrago](https://www.blackdrago.com/) - Dragon Encyclopedia

***

# ► Humanities

***

## ▷ World Data

* 🌐 **[Awesome Datasets](https://github.com/awesomedata/awesome-public-datasets)** - Public Datasets
* ⭐ **[Worldometer](https://www.worldometers.info/)**, [TheScaleOfLife](https://www.thescaleoflife.com/), [WorldBank](https://databank.worldbank.org/), [US Census](https://data.census.gov/), [DataUSA](https://datausa.io/), [Data.gov](https://data.gov/), [Worlddata](https://www.worlddata.info/), [⁠OpenFactBook](https://openfactbook.org/) or [UN Data](https://data.un.org/) - World Data & Statistics
* ⭐ **[Our World in Data](https://ourworldindata.org/)** - World Problem Database
* [Data Commons](https://datacommons.org/) or [Engaging Data](https://engaging-data.com/) - World Data Visualizations
* [If It Were My Home](https://www.ifitweremyhome.com/), [GlobalEdge](https://globaledge.msu.edu/) or [MyLifeElsewhere](https://www.mylifeelsewhere.com/) - Country Data Comparisons
* [⁠CityPopulation](https://citypopulation.de/) - Location / Population Data
* [City Data](https://www.city-data.com/) - US City Data
* [⁠Pantheon](https://pantheon.world/) - Historical Figure Database + Trivia
* [Rulers.org](https://rulers.org/), [⁠World Statesmen](https://www.worldstatesmen.org/) or [EveryPolitician](https://everypolitician.org/) / [GitHub](https://github.com/opensanctions/everypolitician.org) - World Heads Of State & Government Databases
* [OpenSanctions](https://www.opensanctions.org/) - Government Sanctions Database / [GitHub](https://github.com/opensanctions/opensanctions)
* [World Births and Deaths](https://worldbirthsanddeaths.com/) - World Birth / Death Rates Visualization
* [SIPRI Database](https://www.sipri.org/databases) - Global Military Data
* [DataUNODC](https://data.unodc.org/) - Drug / Crime Statistics
* [Gun Violence Archive](https://www.gunviolencearchive.org/) - Gun Violence Statistics
* [Incarceration in Real Numbers](https://mkorostoff.github.io/incarceration-in-real-numbers/) - Incarceration Visualization / Facts
* [Climate Data](https://climate-data.org/), [⁠Climate Change Tracker](https://climatechangetracker.org/), [Climate.us](https://www.climate.us/) or [Climate Explorer](https://crt-climate-explorer.nemac.org/) - Climate Change Data
* [En-ROADS](https://en-roads.climateinteractive.org/scenario.html) - Climate Solutions Simulator
* [ExtremeWeatherWatch](https://www.extremeweatherwatch.com/) - Extreme Weather Data / Tracking
* [Global Volcanism Program](https://volcano.si.edu/) - Volcano Information Database

***

## ▷ Geography / Sociology

* 🌐 **[Soar](https://soaratlas.com/)**, [ArcGIS Living Atlas](https://livingatlas.arcgis.com/), [⁠WorldAtlas](https://www.worldatlas.com/) or [Cool Maps](https://coolmaps.esri.com/) - Atlases
* 🌐 **[Country Infographics](https://rentry.org/o4gq6cq5)** - Country Infographic Images
* ↪️ **[Historical / Modern Maps](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25BA_maps)**
* ↪️ **[GeoGuessr Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/games#wiki_.25B7_geoguessr)**
* ⭐ **[Ekvis](https://ekvis.com/)** / [Subreddit](https://www.reddit.com/r/Ekvis/) / [Discord](https://discord.gg/zU89VKknG4), [JetPunk Geography](https://www.jetpunk.com/tags/geography), [LizardPoint](https://lizardpoint.com/), [Teuteuf](https://teuteuf.fr/), [⁠Memorize Earth](https://memorizeearth.com/), [⁠GeoGrid](https://geographygrid.com/), [⁠OpenGuessr](https://education.openguessr.com/) or [WorldFindr](https://worldfindr.com/) - Geography Quiz / Guessing
* [LibreTexts Social Science](https://socialsci.libretexts.org/Bookshelves) - Social Science Learning
* [LibreTexts Geosciences](https://socialsci.libretexts.org/Bookshelves) - Geoscience Learning
* [⁠Cultural Atlas](https://theculturalatlas.org/) - World Culture / Religion Guides
* [AntipodesMap](https://www.antipodesmap.com/) - Find Antipodes
* [The True Size](https://thetruesize.com/) - Compare Country Size
* [UNESCO World Heritage](https://whc.unesco.org/en/list/) - World Heritage Location Index
* [GovTrack](https://www.govtrack.us/) - US Government Legislation Tracking / Votes
* [iCivics](https://www.icivics.org/games) - U.S. Law Learning Games
* [LGA World Database](https://database.ilga.org/) - LGBT Legal Rights Map / Policy Tracking
* [Trans Rights Map](https://transrightsmap.tgeu.org/) - Trans Legal Rights Map / Policy Tracking
* [8000ers](https://martin-laxenaire.fr/experiments/8000ers/#/everest) - Mountain Visualization & Info
* [WorldLicensePlates](http://www.worldlicenseplates.com/) - World License Plate Index
* [Symbols](https://www.symbols.com/) - Symbol Database

***

## ▷ Vexillology / Flags

* ⭐ **[Flags of the World](https://www.fotw.info/flags/index.html)**, [2](https://www.crwflags.com/fotw/flags/) / [Search](https://search.fotw.ethnia.org/), [Vexilo](https://vexilo.org/), [Flagid](https://flagid.org/) or [FlagLog](https://www.flaglog.com/) - Flag Databases
* ⭐ **[FAME](https://zeljko-heimer-fame.from.hr/descr/index.html)** - Flag / Coat of Arms Database
* [r/vexillology](https://www.reddit.com/r/vexillology//) or [⁠r/flags](https://www.reddit.com/r/flags/) - Vexillology / Flag Subreddits
* [Vexillology Discord](https://discord.gg/vex) - Vexillology / Flag Discord Community
* [Flag Stories](https://flagstories.co/) - Flag Design Breakdowns
* [Flag Meanings](https://www.reddit.com/r/vexillology/wiki/meaningof/) - Flag Meaning Breakdowns by r/vexillology
* [PrideFlags](https://www.prideflags.org/) - LGBT Flag Database
* [⁠HOTW](https://www.heraldry-wiki.com/) - Coat of Arms Database / Wiki
* [⁠r/heraldry](https://www.reddit.com/r/heraldry/) - Heraldry / Coat of Arms Subreddit
* [Flag Guesser](https://flagguesser.com/), [⁠Geotrivia (Flags)](https://geotrivia.com/world/flags), [⁠Flagle](https://flagle-game.com/), [FlagGuessr](https://flagguessr.app/), [Flagdle](https://www.flagdle.org/), [⁠flagdoku](https://flagdoku.com/) or [Flag Match](https://flagmatch.com/) - Flag Quizzes / Guessing
* [Vexle](https://vexle.org/) - Daily Flag Drawing Game

***

## ▷ Economics

* ↪️ **[Finance / Market Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_finance_.2F_savings)**
* ⭐ **[The Atlas of Economic Complexity](https://atlas.hks.harvard.edu/)** - Global Economic Growth Data
* ⭐ **[⁠Integrity Index](https://integrityindex.us/)** - US Political Finance Integrity Database / [Subreddit](https://www.reddit.com/r/politicalintegrity/) / [Discord](https://discord.gg/bvrwaDJveC)
* ⭐ **[⁠Wealth Shown to Scale](https://litekin.github.io/pixel-wealth/)** / [Source Code](https://codeberg.org/litekin/pixel-wealth/), [2](https://evolving-thoughts.github.io/1-pixel-wealth/) / [GitHub](https://github.com/Evolving-Thoughts/1-pixel-wealth) - Global Wealth Inequality Visualization
* [⁠CORE Econ](https://www.core-econ.org/) - Economics Textbooks
* [OEC](https://oec.world/en), [⁠UNCTAD](https://unctad.org/) or [UN Comtrade](https://comtradeplus.un.org/) - Global Trade Data
* [⁠CountryEconomy](https://countryeconomy.com/) - Country Economic Data
* [OEC Games](https://oec.world/en/games) - Trade Data Games
* [Statista](https://www.statista.com/) - Market Statistics
* [BLS](https://www.bls.gov/) - U.S. Bureau of Labor Statistics
* [⁠OilPrice](https://oilprice.com/) - Oil / Energy Price Tracking + News
* [OpenSecrets](https://www.opensecrets.org/) - Government Money Tracking
* [WorldPoverty](https://worldpoverty.io/) - World Poverty Data
* [Expatistan](https://www.expatistan.com/) - Cost of Living Calculator
* [Cost of Living](https://www.numbeo.com/cost-of-living/) - Cost of Living Map
* [MoveMap](https://www.movemap.io/) - North America Property Costs Map
* [⁠Opportunity Atlas](https://www.opportunityatlas.org/) - Interactive Future Success Impact Map
* [HungerMap](https://hungermap.wfp.org/) - Global Hunger Map
* [⁠Wealth Inequality in America](https://dreamagainusa.org/) - America Wealth Inequality Visualization
* [Unequal Scenes](https://unequalscenes.com/) - Scenes of Inequality Around the World
* [Dollar Street](https://www.gapminder.org/dollar-street) - Compare Homes by Country / Income
* [Netblocks](https://netblocks.org/cost/) - Find Impact of Internet Shutdown on Economy
* [⁠Is AI Profitable Yet?](https://isaiprofitable.com/) - Track Total Amount Spent / Revenue of AI Companies

***

## ▷ Philosophy

* ⭐ **[Stanford Encyclopedia of Philosophy](https://plato.stanford.edu/index.html)**, [IEP](https://iep.utm.edu/) or [nLab Philosophy](https://ncatlab.org/nlab/show/philosophy) - Philosophy Encyclopedias / [Search](https://www.visualizingsep.com/)
* ⭐ **[Early Modern Texts](https://www.earlymoderntexts.com)** - Early Modern Philosophy
* [Philosophy Bro](https://www.philosophybro.com/), [LibreTexts Philosophy](https://human.libretexts.org/Bookshelves/Philosophy), [Reasoned](https://www.reasoned.org/dir/), [TheDailyIdea](https://thedailyidea.org/) or [PhilosophyBasics](https://www.philosophybasics.com/) - Philosophy Resources / Learning
* [Wireless Philosophy](https://www.wi-phi.com/) - Philosophy Videos
* [⁠The Internet Classics Archive](https://classics.mit.edu/) - Classic Philosophy Literature
* [⁠1000-Word Philosophy](https://1000wordphilosophy.com/) - 1000-Word Essays on Philosophical Topics
* [Untools](https://untools.co/) - Better Thinking Tools
* [⁠Landscape of Consciousness](https://loc.closertotruth.com/) - Consciousness Theory Index
* [Brainkit](https://www.braink.it/) - Learn Helpful Principles
* [Art of Manliness](https://www.artofmanliness.com/) - Develop Life Skills
* [Sketchplanations](https://www.sketchplanations.com/) - Explanation Sketches
* [IEoP](https://iep.utm.edu/fallacy/), [YouLogicalFallacyIs](https://yourlogicalfallacyis.com/), [FallacyFiles](https://fallacyfiles.org/index.html) or [LogicalFallacies](https://www.logicalfallacies.org/) - Learn about Logical Fallacies
* [RationalWiki](https://rationalwiki.org/) - Pseudoscience Refutation Wiki
* [YourBias.is](https://yourbias.is/) - Learn about Biases
* [⁠The Cognitive Bias Codex](https://upload.wikimedia.org/wikipedia/commons/6/65/Cognitive_bias_codex_en.svg) - Interactive Cognitive Bias Infographic
* [⁠Philosophy Stack Exchange](https://philosophy.stackexchange.com/) - Philosophy Forum
* [Kialo](https://www.kialo.com/) - Debates / Discussion
* [⁠Effective Altruism Forum](https://effectivealtruism.org/) - ⁠Effective Altruism Learning / [Forum](https://forum.effectivealtruism.org/)
* [Open Logic Project](https://openlogicproject.org/) - Math Logic Teaching Materials
* [Umsu](https://www.umsu.de/trees/) - Analytic Tableaux Generator
* [Proofs](https://proofs.openlogicproject.org/) - Natural Deduction Proof Checker
* [PropCalc](https://www.inf.unibz.it/~franconi/teaching/propcalc/) - Propositional Logic Calculator
* [ModalLogic](https://rkirsling.github.io/modallogic/) - Model Logic Playground
* [Logitext](http://logitext.mit.edu/tutorial) - Sequent Calculus Tutorial
* [WikEnigma](https://wikenigma.org.uk/) - 'Known Unknowns' Wiki
* [⁠Philosophy Experiments](https://www.philosophyexperiments.com/) - Interactive Philosophy Experiments
* [The Trolley Problem Game](https://newfastuff.com/the-trolley-problem-game/) - The Trolley Problem
* [Social Engineers](https://web.archive.org/web/20221208021915/https://www.socialengineers.net) - Social Engineering Guides

***

# ► Skills / Hobbies / DIY

* ↪️ **[Photography / Cameras](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25BA_photography_.2F_cameras)**
* ↪️ **[Fashion / Clothing](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25BA_fashion_.2F_clothing)**
* ↪️ **[Typing Tests / Games](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools#wiki_.25B7_typing_lessons)**
* ↪️ **[Puzzle Games](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/games#wiki_.25BA_puzzle_games)**
* ⭐ **[Knots 3D](https://knots3d.com/)**, [Animated Knots](https://www.animatedknots.com/) or [NetKnots](https://www.netknots.com/) - Learn to Tie Knots
* [Ian's Shoelace Site](https://www.fieggen.com/shoelace/) - Learn to Tie Shoelaces
* [Make it Yourself](https://makeityourself.org/), [Instructables](https://www.instructables.com/) or [CreativePark](https://creativepark.canon/en/index.html) - DIY Projects / Crafts
* [⁠Low Tech Magazine](https://solar.lowtechmagazine.com/) - Sustainable DIY Tech Guides
* [Toys from Trash](https://www.arvindguptatoys.com/toys.html) - Use Everyday Items to Make Toys
* [⁠Craft Yarn Council](https://www.craftyarncouncil.com/instructions_kn.php3) or [Crocheting101](https://crocheting101.com/) / [2](https://discord.com/invite/uDqE9SQCdZ) - Knitting + Crochet Learning
* [Antique Pattern Library](https://www.antiquepatternlibrary.org/) - Antique Pattern Library / Knitting + Crochet
* [⁠BraceletBook](https://www.braceletbook.com/) - DIY Bracelet Pattern Database
* [HamExam](https://hamexam.org/), [AA9PW](https://www.aa9pw.com/) or [HamStudy](https://hamstudy.org/) - Ham Radio Practice Exams
* [ARRL](https://www.arrl.org/) - Amateur Radio Resources / Learning / [Exam Search](https://www.arrl.org/find-an-amateur-radio-license-exam-session) / [Question Pools](https://www.arrl.org/question-pools)
* [QRZ](https://www.qrz.com/db/) - Amateur Radio Call Sign Database / [Forums](https://forums.qrz.com/)
* [Perry Morse](https://www.perry.qa/morse), [Morse Typing Trainer](https://morse.withgoogle.com/learn/) or [ICWO](https://lcwo.net/) - Learn / Practice Morse Code
* [Lock Picking 101](https://www.lockpicking101.com/) - Lock Picking Forum
* [LibraryOfJuggling](https://libraryofjuggling.com/) - Juggling Technique Database
* [diyhpluswiki](https://diyhpl.us/wiki/) - DIY Biohacking
* [⁠Online Coin Club](https://onlinecoin.club/) - Coin Collectors Database / Info
* [⁠WildWinds](https://www.wildwinds.com/) - Ancient Numismatics / Coin Database
* [Activist Handbook](https://activisthandbook.org/) or [Privacy Guides Activism](https://www.privacyguides.org/en/activism/) - Campaigning / Activism Guides
* [Bridge Command](https://www.bridgecommand.co.uk/) - Bridge Command Ship Simulator
* [UER](https://www.uer.ca/forum_showcats.asp) - Urban Exploration / Abandoned Place Forum / [MAP](https://www.uer.ca/locations/gmaps/)
* [PaperToys](https://www.papertoys.com/) - Printable Paper Toys
* [Fold N Fly](https://www.foldnfly.com/) - Paper Airplane Guides
* [AXM Paper Space Scale Models](https://axmpapermodels.com/) - Spacecraft Paper Models
* [⁠ExplOri 22.5](https://225.designorigami.net/) - 22.5 Degree Origami Design Tool / [Discord](https://discord.com/invite/5YcGh8b9yC)
* [HypnosisChatBooks](https://t.me/HypnosisChatBooks) - Hypnosis / Telegram

***

## ▷ Survival / Preparedness

* ↪️ **[Map Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25BA_maps)**
* ⭐ **[Survivor Library](https://www.survivorlibrary.com/)**, [Kiwix Library](https://browse.library.kiwix.org/#lang=eng&category=&q=prep) or [OffGridDownload](https://t.me/offgriddownload) - Survival Book Collections
* [SurvivalManual](https://github.com/ligi/SurvivalManual) - Survival Manual / [App](https://survivalmanual.github.io/)
* [ExploreMarMaris](http://www.exploremarmaris.com/read/Survival/) - Survival PDFs
* [Trail Sense](https://kylecorry.com/Trail-Sense/) - Wilderness Survival App / [GitHub](https://github.com/kylecorry31/Trail-Sense)
* [⁠Wikiciv](https://wikiciv.org/) - Survival / Civilization Rebuilding Wiki / [Discord](https://discord.gg/ZzdmgSKtrE)
* [CD3WD Project](https://www.cd3wdproject.org/) - Sustainable Development Information
* [The Preparedness Encyclopedia](https://www.fluidicice.com/tpe) - Preparedness Encyclopedia
* [r/Preppers](https://www.reddit.com/r/preppers/) - Preparedness Subreddit
* [r/PrepperFileShare](https://reddit.com/r/PrepperFileShare) - Preparedness File Sharing
* [Project NOMAD](https://www.projectnomad.us/) - Self-Contained Offline Knowledge + Off-Grid Database / [GitHub](https://github.com/Crosstalk-Solutions/project-nomad)

***

## ▷ Music

* 🌐 **[Awesome Music Theory](https://github.com/vpavlenko/study-music)** - Music Theory Resources
* ↪️ **[Sheet Music / Notation](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/audio#wiki_.25B7_sheet_music_.2F_notation)**
* ⭐ **[Muted](https://muted.io/)**, **[Open Music Theory](https://viva.pressbooks.pub/openmusictheory/)** / [2](https://openmusictheory.github.io/), [Chromatone](https://chromatone.center/), [Teoria](https://www.teoria.com/index.php), [SimplifyingTheory](https://www.simplifyingtheory.com/), [⁠Teoria](https://www.teoria.com/), [LightNote](https://www.lightnote.co/) or [Music Theory](https://www.musictheory.net/) - Music Theory Learning
* [LibreTexts Music](https://human.libretexts.org/Bookshelves/Music) - Music Learning
* [⁠Z-Tonnetz](https://ztonnetz.com/) - Music Visualization Tool
* [AudioZ](https://audioz.download/tutorials/) - Audio Courses / [Forum](https://audiosex.pro/)
* [ProducerLibrary](https://producerlibrary.carrd.co/) - Audio Production Tutorials
* [Helio](https://helio.fm/) / [GitHub](https://github.com/helio-fm/helio-sequencer) or [NoteHeads](https://noteheads.net/) - Music Composition Tools
* [Circle of Fifths](https://muted.io/circle-of-fifths/) - Visualize Notes, Chords and Keys
* [ScoreCloud](https://scorecloud.com/), [ChordReader2](https://github.com/AndInTheClouds/chordreader2) or [Chordify](https://chordify.net/) - Chord Detection / Transcriber
* [Arpeggiator](https://codepen.io/jakealbaugh/full/qNrZyw), [Chordi](https://chordi.co/), [Chord Player](https://www.onemotion.com/chord-player/) or [AutoChords](https://autochords.com/) - Chord Progression Generators
* [HookTheory](https://www.hooktheory.com/trends) - Chord Progression Library
* [LilyPond](https://lilypond.org/) - Music Engraving Program
* [Piano Scribe](https://laqieer.github.io/piano-scribe/) - Piano Transcriber
* [Learning Music](https://learningmusic.ableton.com/) or [Musicca](https://www.musicca.com/) - Music-Making Lessons
* [Midiano](https://midiano.com/) / [Discord](https://discord.com/invite/SfFdbunEm2), [Piano Trainer](https://midi-piano-trainer.netlify.app/) / [GitHub](https://github.com/Floopdible/piano_trainer), [ZaneH Piano Trainer](https://zaneh.itch.io/piano-trainer) / [GitHub](https://github.com/ZaneH/piano-trainer), [Chord Nebula](https://chords.yottanami.com/), [sightread](https://sightread.dev/), [⁠Playsheet](https://playsheet.app/) or [PianoCheetah](https://pianocheetah.app) - Piano Practice / Learning
* [⁠Fundamentals of Piano Practice](http://www.pianopractice.org/) - Piano Practice Book
* [TrueToneGuitar](https://www.truetoneguitar.co.uk/tools/guitar-practice-routine-generator), [Songsterr](https://www.songsterr.com/) / [Downloader](https://www.songsterr-downloader.com/), [FAChords](https://www.fachords.com/) or [ChordBook](https://chordbook.com/) - Guitar Tools
* [FretFlip](https://fretflip.com/guitar-scales), [Oolimo](https://www.oolimo.com/en/index.php), [StringScales](https://stringscales.com/), [My Fretboard Trainer](https://myfretboardtrainer.com/home/), [QFGM](https://quinnfetrowsguitarmachines.com/) or [GuitarScale](https://www.guitarscale.org/) - Learn Guitar Scales / Chords
* [JamStart](https://jamstart.app/) - Spotify Chord Charts
* [#fretflip](https://fretflip.com/) - Create / Print Guitar Scales & Chord Charts
* [JustinGuitar](https://www.justinguitar.com/) or [Warlock Guitar](https://warlockguitar.com/) - Guitar Lessons
* [Ultimate Guitar](https://www.ultimate-guitar.com/) - Guitar Tabs
* [Chorder](https://www.chorder.com/guitar-chords/) - Guitar Chord Finder
* [Guitar Fretboard](https://muted.io/guitar-fretboard/), [Fretastic](https://fretastic.com/guitar) or [Gitori](https://www.gitori.com/) - Virtual Fretboards / Guitar Lessons
* [⁠StudyBass](https://www.studybass.com/) - Online Bass Lessons
* [coop3rdrumm3r](https://www.drumeo.com/coop3rdrumm3r/) or [FreeDrumLessons](https://www.youtube.com/c/freedrumlessons) - Drum Lessons
* [911tabs](https://www.911tabs.com/) or [Finger Tabs](https://fingertabs.com/) - Tabs
* [Jazz Improvisor](https://www.cs.hmc.edu/~keller/jazz/improvisor/) - Improvised Jazz
* [LearningSynths](https://learningsynths.ableton.com/) - Synthesizers
* [Sight Singing Factory](https://www.sightreadingfactory.com/) - Sight Singing Practice
* [PerfectPitch](https://artistaiden.com/perfectpitch) - Pitch Recognition Practice
* [MusicStaff](https://musicstaff.com/) - Music Teacher Search
* [ChiffAndFipple](https://www.chiffandfipple.com/) - Irish Traditional Music Forum
* [MIMO](https://mimo-international.com/MIMO/) - Musical Instrument Database
* [VGM Sound Sources](https://docs.google.com/spreadsheets/d/1JJBlHHDc65fhZmKUGLrDTLCm6rfUU83-kbuD8Y0zU0o/) - VGM Sound Sources / [Discord](https://discord.gg/m4qzYNGHuS)
* [⁠NTS Field Recording Guide](https://www.nts.live/projects/field-recordings-submission/pdf/NTS_Field_Recording_Guide_20210311.pdf) - Field Recording Guide

***

## ▷ Art / Editing

* 🌐 **[Creator Resources](https://www.newgrounds.com/wiki/creator-resources/)** - Art & Animation Resource Index
* 🌐 **[AwesomeAnimeResearch](https://github.com/SerialLain3170/AwesomeAnimeResearch)** - Anime Machine Learning
* ↪️ **[Digital Art Collections](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7_art_galleries_.2F_collections)**
* ⭐ **[Art Study Guide](https://drive.google.com/file/d/1cK9q7oeFRE58MVaSgUql662iGqCXC8Ah/)** - Art Study Guides / Tips
* ⭐ **[Drawabox](https://drawabox.com/)** / [Discord](https://discord.com/invite/drawabox), [Drawing Starter Pack Playlist](https://www.youtube.com/playlist?list=PL7KO8uN5A9PJsQIJzecnohhKjtMnSuFtR) or [FarsiTuts](https://t.me/farsituts) - Drawing Lessons
* ⭐ **[Proko](https://www.youtube.com/user/ProkoTV/videos)** - Figure Drawing Lessons
* ⭐ **[PaintingTube](https://painting.tube)**, [MarcoBucci](https://www.youtube.com/@marcobucci), [Alphonso Dunn](https://www.youtube.com/c/ALPHONSODUNN/videos?view=0&sort=p&flow=grid), [Feng Zhu FZD](https://www.youtube.com/user/FZDSCHOOL/videos), [⁠Ctrl+Paint](https://www.ctrlpaint.com/), [Art Fundamentals](https://www.youtube.com/playlist?list=PLVgLT-e3jXPDgeED0pD0BPq8kY1VAZAGa) or [Circle Line Art](https://www.youtube.com/user/circlelinemedia/videos) - Art Video Tutorials
* [Ubu](https://ubuweb.com/) - Avant-Garde Artifacts
* [Online-Courses](https://online-courses.club/) - Art / Design Courses
* [TutsPlus](https://tutsplus.com/) - Creative Courses
* [Curriculum for the Solo Artists](https://alexhuneycutt.gumroad.com/l/free_curriculum) - Self-Taught Artist Curriculum
* [DoArtDaily](https://dad.gallery) - Daily Art Challenges
* [Character Design References](https://characterdesignreferences.com/visual-library) - Character Design Visual Library
* [FloobyNooby](http://www.floobynooby.com/comp1.html), [JMMStoryboardTips](https://jimmortensen.gumroad.com/l/JMMStoryboardTips) or [A Guide to Storyboards](https://magicbunnyart.gumroad.com/l/fjvKA) - Storyboard Guides
* [Settei Dreams](https://setteidreams.net/) - Anime Production Materials
* [Anime Study General](https://discord.gg/3bwdfRk) - Anime Production Community
* [McLelun](https://www.mclelun.com/p/tutorial.html) - Anime Style Background Tutorial
* [AnimeOutline](https://www.animeoutline.com/) - Anime / Manga Drawing Tutorials
* [Design Tuts](https://t.me/designfreetuts) - Design Tutorials
* [PhotoshopTutorials.ws](https://www.photoshoptutorials.ws/) - Photoshop Tutorials
* [DomDesigns](https://www.youtube.com/c/DomDesigns/) - Illustrator Tutorials
* [PhotoshopTraining](https://www.youtube.com/@PhotoshopTrainingChannel), [Phlearn](https://www.youtube.com/@phlearn) or [PiXimperfect](https://www.youtube.com/@PiXimperfect) - Photoshop YouTube Tutorials
* [⁠Practice Drawing This](https://practicedrawingthis.com/) - Drawing Practice
* [The Bézier Game](https://bezier.method.ac/) - Pen Tool Practice
* [ArtWithFlo](https://artwithflo.com/) - Procreate Tutorials
* [Paintable](https://paintable.cc/) - Digital Art Tutorials
* [Pedro's Pixel Art Tutorials](https://saint11.art/blog/pixel-art-tutorials/) or [SLYNYRD](https://www.slynyrd.com/gallery-animated) - Pixel Art Tutorials
* [MetPublications](https://www.metmuseum.org/met-publications/all) - Art Learning Books
* [GraphicsCodex](https://graphicscodex.com/) - 3D Computer Graphic Guides
* [⁠The Etherington Brothers](https://theetheringtonbrothers.blogspot.com/) - Drawing / Animation Tutorials
* [DrawingNow](https://www.drawingnow.com/) or [⁠Drawing Tutorials](https://www.drawingtutorials101.com/) - Learn to Draw
* [Drawingbooks.org](https://www.drawingbooks.org/) - Old Drawing Books
* [Line of Action](https://line-of-action.com/), [Timed Figure Poses](https://www.youtube.com/playlist?list=PL7EWYwaF6E-FZ8JiBlz2tF1DQUCw-GCmn), [LoveLifeDrawing](https://www.lovelifedrawing.com/) or [Daily Life Drawing Sessions](https://www.youtube.com/playlist?list=PL7EWYwaF6E-Exv72kVT4yYJM2lX-Xf66I) - Figure Sketch Tools / Lessons
* [AnatomyArchive](https://www.anatomyarchive.org/) - Human Anatomy Drawing Tutorials
* [Artist Reference](https://artist-reference.com) - Photo References for Artists
* [x6ud](https://x6ud.github.io/#/) - Animal Photo Reference Search
* [Thomas Romain Perspective](https://ibb.co/album/chGtPJ?sort=name_asc) - Perspective Guide
* [Dimensions](https://www.dimensions.com/) - Object Dimension Reference
* [⁠Storied Colors](https://storiedcolors.com/) - Historical Catalog of Colors / Pigments
* [DevinKorwin Color Guide](https://x.com/devinkorwin/status/1278049901709012995) - Color in Paintings Guide
* [Draw Mix Paint](https://www.drawmixpaint.com/) or [⁠Ran Art Blog](https://ranartblog.com/) - Learn Oil Painting
* [Painting Demos](https://paintingdemos.com/) - Painting Demonstrations
* [cg_tuts](https://t.me/cg_tuts) or [cgreferenceshub](https://t.me/cgreferenceshub) - CG Tutorials
* [Seven Camels](https://sevencamels.blogspot.com/) - Storyboarding Tips / Learning by Disney's Head of Story
* [Agora](https://agora.community/) - Animation Learning Community / Tutorials / [Discord](https://discord.com/invite/9hJxMyR)
* [AMV101](https://www.amv101.com/) - Animated Music Video-Making Guides

***

## ▷ Rubiks Cube

* 🌐 **[Cubing.net](https://www.cubing.net/)** - Cubing Tools
* 🌐 **[Rubiks Cube Guide](https://rentry.co/cubingguide)** - Guide to Rubiks Cube / Resources
* ↪️ **[Cube Simulators / Solvers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/games/#wiki_.25B7_rubiks_cube)**
* ⭐ **[J Perm](https://jperm.net/)**, [CubeSkills](https://www.cubeskills.com/), [RubiksTrainer](https://rubikstrainer.com/) or [Easiest Solve](https://easiestsolve.com/) - Cubing Tutorials / Practice Resources
* ⭐ **[CubeDesk](https://cubedesk.io/)** or **[csTimer](https://cstimer.net/)** - Feature-Rich Cubing Timers
* ⭐ **[SpeedCubeDB](https://speedcubedb.com/)** - Algorithm Database
* [F2L Trainer](https://f2l-trainer.top/) - F2L Rubiks Trainer
* [⁠crystalcube](https://crystalcuber.com/) - CFOP Cross Trainer / Edge Orientation Trainer
* [⁠ZZ Method](https://www.zzmethod.com/) - Learn / Practice ZZ 3x3 Rubiks Speedrunning Method
* [Roux Trainers](https://onionhoney.github.io/roux-trainers/) - Learn Roux Solving Method
* [SpeedSolving](https://www.speedsolving.com/) / [Wiki](https://www.speedsolving.com/wiki) or [Ruwix](https://ruwix.com/) - Cubing Wiki / Community Forum
* [World Cube Association](https://www.worldcubeassociation.org/) - Cubing Competitions & Records
* [alg.cubing.net](https://alg.cubing.net/), [CubeDB](https://cubedb.net/), or [Tao Yu Trainer](https://tao-yu.github.io/Alg-Trainer/) - Algorithm Animators / Visualizers
* [F2L Trainer](https://expertcuber.by/f2l.php) - Algorithm-Specific Trainers
* [BlindTrainer](https://blindtrainer.com/) - Blindfolded Rubik's Trainer
* [Hypercubing](https://hypercubing.xyz/) - Hypercubing Wiki
* [Speedcube.app](https://speedcube.app/) - Cubing Timer (Mobile-Friendly)
* [SolveTheCube](https://solvethecube.com/timer) - Cubing Timer
* [qqTimer](https://www.qqtimer.net/) - Cubing Timer

***

## ▷ Chess

* 🌐 **[TheChessDirectory](https://thechessdirectory.com/)**, [Immortal Chess Network](https://t.me/Immortal_Chess_Network) or [Chess Resources](https://redd.it/u43nrc) - Chess Resources
* 🌐 **[/m/Chess](https://www.reddit.com/user/korfor/m/chess/)** or [r/Chess](https://reddit.com/r/chess) - Chess Subreddits
* 🌐 **[r/Chess Books](https://reddit.com/r/chess/wiki/books)** - Community Recommended Books
* ↪️ **[Play Chess Online](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/games#wiki_.25B7_chess)**
* ⭐ **[Pawn Appétit](https://github.com/Pawn-Appetit/pawn-appetit)** or [En Croissant](https://encroissant.org/) - Modern Chess GUI & Database Manager / [GitHub](https://github.com/franciscoBSalgueiro/en-croissant) / [Databases](https://encroissant.org/docs/assets/databases)
* ⭐ **[Lucas Chess](https://lucaschess.pythonanywhere.com/)** - Chess Training Software
* ⭐ **[Chess Tempo](https://chesstempo.com/)** - Tactics Training / Endgame Solver
* ⭐ **[Scid vs. PC](https://scidvspc.sourceforge.net/)** - Chess Database Software
* ⭐	**[Lumbra's Gigabase](https://lumbrasgigabase.com/)** - Cleaned Master Game Database
* ⭐	**[OpeningTree](https://www.openingtree.com/)** - Opening Repertoire Tree & Scouting Tool for Lichess & Chess.com
* [Maia Chess](https://www.maiachess.com/) - Human-Like AI Training Opponent & Blunder Modeling
* [Listudy](https://listudy.org/en) - Spaced Repetition Openings, Blind Tactics & Endgames
* [Blitz Tactics](https://blitztactics.com/) - Fast-Paced Chess Puzzle Training
* [Tactic or Not](https://tacticornot.com/) - Evaluate Tactics / [Discord](https://discord.gg/2WWgsuZmag)
* [⁠Chessort](https://chessort.com/) - Chess Move Evaluation Training
* [Shâh Kur](https://shahkur.specr.net/) - Blindfolded Chess Practice
* [TheChessWebsite](https://www.thechesswebsite.com/) - Learn / Practice Chess
* [⁠Chess Frog](https://chessfrog.com/) - Chess Challenges
* [ChessLab](https://chesslab.me/) - Learning Community / [Discord](https://discord.com/invite/AA5G5f9wKC)
* [Chess Coach](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_modded_apks) - Chess Coaching App
* [Chess Vision](https://chessvision.ai/) or [Chess OCR](https://helpman.komtera.lt/chessocr/) - Scan Chessboard Diagrams & Images Into Engine Analysis
* [Chess Monitor](https://www.chessmonitor.com/) - Performance & Analytics Dashboard for Lichess and Chess.com
* [WintrChess](https://wintrchess.com/), [Chesskit](https://chesskit.org/) / [GitHub](https://github.com/GuillaumeSD/Chesskit) or [Chess Analysis](https://chess-analysis.org/) / [Discord](https://discord.gg/hvrEXhX8qA) - Web Game Review & Engine Analysis
* [ChessBlunders](https://chessblunders.org/) - Analyze Match Mistakes
* [ChessMD](https://chessmd.org/) - Chess Training / Match Analysis / [GitHub](https://github.com/ChessMD/ChessMD)
* [Syzygy Tables](https://syzygy-tables.info/) - 7-Piece Endgame Tablebase Explorer
* [The Week In Chess](https://theweekinchess.com/) - Weekly PGN Chess Game Archives
* [ChessGames](https://www.chessgames.com/) - Historic Master Games Archive & Discussion
* [Chess Results](https://chess-results.com/) - FIDE Tournament Results Database
* [⁠Chess Second](https://chess-second.com/) - FIDE Player Stats, Rating Histories & Opponent Scouting
* [⁠Olympiad Stats](https://www.olympiadstats.fun/) - Chess Olympiad Statistics / Round Analysis
* [365Chess](https://www.365chess.com/) - Chess Database / Opening Explorer
* [2700chess](https://2700chess.com/) - Live Ratings for Super Grandmasters
* [YottaChess](https://www.yottachess.com/) - Professional Player Database
* [ChessBase](https://en.chessbase.com/) / [India](https://www.chessbase.in/) - Chess News, Articles & Tournaments
* [Visual History of Chessmen](https://chesshistory.github.io/) - Chessmen History Guide

***

## ▷ Go / Baduk / Weiqi

* 🌐 **[Go Magic: How to Play Go](https://gomagic.org/how-to-play-go-rules/)** - Beginner Go Tutorial
* 🌐 **[r/baduk](https://old.reddit.com/r/baduk/)** - Reddit community for Go / Baduk / Weiqi
* ⭐ **[Online Go Server (OGS)](https://online-go.com/)** - Modern Online Go Platform / [GitHub](https://github.com/online-go)
* ⭐ **[Sensei's Library](https://senseis.xmp.net/)** - Comprehensive Go Wikipedia
* ⭐ **[Sabaki](https://sabaki.yichuanshen.de/)** - Go Board & SGF Editor
* [⁠Kaya](https://kayago.app/) - Go (Baduk/Weiqi) Board Analysis Tool / [GitHub](https://github.com/kaya-go/kaya)
* [Black to Play](https://blacktoplay.com/) - Go Puzzles
* [KataGo](https://katagotraining.org/) or [KaTrain](https://github.com/sanderland/katrain) - Open-Source Neural Network Go AI
* [The Interactive Way To Go](https://playgo.to/en) - Interactive Beginner Tutorial
* [Josekipedia](https://www.josekipedia.com/) - Dictionary for Corner Openings
* [Waltheri's Go Pattern Search](https://ps.waltheri.net/) - Pro Game Pattern Search Engine
* [GoProblems](https://goproblems.com/) - Tactical Puzzle Database
* [GoKibitz](https://gokibitz.com/) - Game Reviews and Community Feedback
* [Baduk.club](https://baduk.club/map/) - Map of Go clubs and Players
* [KGS Go Server](https://www.gokgs.com/) - Classic server / Teaching Community
* [Igowin](https://smart-games.com/igowin.html) - 9x9 Desktop Go AI for Beginners

***

## ▷ Dungeons & Dragons

* ↪️ **[D&D Building Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools/#wiki_.25B7_rpg_worldbuilding)** - Map Editors, Campaign Managers, Worldbuilding, etc.
* ⭐ **[D&D Compendium](https://www.dnd-compendium.com/)** or [RPGBOT](https://rpgbot.net/) - D&D Tools & Learning Resources
* ⭐ **[5etools](https://5e.tools/)**, [⁠DM Screen](https://www.linepup.com/dm-screen/) or [The Acaeum](https://www.acaeum.com/) - Rules & Content References
* ⭐ **[D&D Beyond](https://www.dndbeyond.com/)** - Official Toolset for 5E
* ⭐ **[Kobold+ Fight Club](https://koboldplus.club/)** - Encounter Builder & Balancer
* [Avrae](https://avrae.io/) - D&D Automation Discord Bot
* [DnD-Books(4e,5e,5.5e)](https://github.com/nazdridoy/dnd-public) or [D&D 5e BR](https://dnd5ed.github.io) / Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators) - D&D 4E/5E Rulebooks / Manuals
* [⁠The Homebrewery](https://www.naturalcrit.com/) / [GitHub](https://github.com/naturalcrit/homebrewery) or [GM Binder](https://www.gmbinder.com/) - Custom Rulebook & Document Creators
* [r/UnearthedArcana](https://www.reddit.com/r/UnearthedArcana/) - D&D Homebrew Content Subreddit
* [Cruinne's D&D Reading Room](https://arcadia.net/Cruinne/DnD/Articles/worldbuilding.html) - D&D Worldbuilding Checklist
* [⁠DiceCloud](https://dicecloud.com/) - D&D 5e Character Manager / [GitHub](https://github.com/ThaumRystra/DiceCloud/)
* [⁠DMHeroes](https://dmheroes.com/) - D&D NPC Generator / [Classic](http://classic.dmheroes.com/)
* [Tetra-cube](https://tetra-cube.com/dnd/dnd-statblock.html) - Monster Statblock Generator

***

## ▷ LEGO

* 🌐 **[Awesome Lego](https://github.com/ad-si/awesome-lego)** - LEGO Resources
* [⁠Rebrickable](https://rebrickable.com/) - LEGO Collection Manager / Build Ideas
* [⁠Mecabricks Workshop](https://www.mecabricks.com/en/workshop), [LeoCAD](https://www.leocad.org/) / [GitHub](https://github.com/leozide/leocad) or [BrickLink Studio](https://www.bricklink.com/v3/studio/download.page) - Virtual LEGO Building / 3D Editors
* [Brickset](https://brickset.com/), [⁠BrickEconomy](https://www.brickeconomy.com/) or [Bricklink](https://www.bricklink.com/) - LEGO Set Database / Reviews / Marketplaces
* [⁠Brickfact](https://brickfact.com/) - LEGO Set Database / Price Tracker
* [⁠Brick Hound](https://brickhound.com/) - LEGO Deal Alerts
* [Brickognize](https://brickognize.com/) - LEGO Brick / Minifigure Identification Tool
* [⁠MinifigScan](https://pacolabs.com/MinifigScan/) - LEGO Minifigure Blind Box Identification Tool

***

# ► Language Learning

## ▷ Multi-Language

* 🌐 **[Language Links](https://docs.google.com/spreadsheets/d/1EGPFLFJdyKGKjh8LXXA099ddf1yB6ZQgr_mmtBnYCy8)**, [LibreTexts Languages](https://human.libretexts.org/Bookshelves/Languages), [/int/ Guide](https://4chanint.miraheze.org/), [⁠MondeLibrary](https://library.mondecast.com/?price=free) or [r/LanguageLearning Resources](https://www.reddit.com/r/languagelearning/wiki/resources/) - Language Learning Resources
* 🌐 **[Speechling](https://speechling.com/tools)** - Language Learning Tools
* 🌐 **[LexiLogos](https://www.lexilogos.com/english/index.htm)** or [Dictionary Index](https://lyricstranslate.com/en/resources) - Language Dictionary Indexes
* 🌐 **[Talking Dictionaries](https://talkingdictionary.swarthmore.edu/)** - Endangered Language Dictionary Index
* 🌐 **[Comprehensible Input Wiki](https://comprehensibleinputwiki.org/)** - Learn Languages via Comprehensible Input
* ↪️ **[Translation Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools#wiki_.25B7_translators)**
* ⭐ **[Language Transfer](https://www.languagetransfer.org/)** - Language Learning Lectures
* ⭐ **[Yomitan](https://yomitan.wiki/)** - Popup Dictionary / [Japanese + Chinese](https://github.com/MarvNC/yomitan-dictionaries) / [Discord](https://discord.gg/3v22CATnyr)
* ⭐ **[Language Reactor](https://www.languagereactor.com/)**, [Dreaming](https://dreaming.com/) / [Subreddit](https://www.reddit.com/r/dreamingspanish/), [2](https://www.reddit.com/r/DreamingFrench/), [LLPlayer](https://github.com/umlx5h/LLPlayer), [Trancy](https://www.trancy.org/) or [Easysubs](https://easysubs.cc/) - Learn Languages via Videos
* ⭐ **[Readlang](https://readlang.com/)** - Learn a Language via Web Browsing
* ⭐ **[Omniglot](https://omniglot.com/)** - Writing System & Language Encyclopedia
* [⁠Lute](https://luteorg.github.io/lute-manual) - Learn a Language via Reading / [GitHub](https://github.com/LuteOrg/lute-v3)
* [⁠Chimahon](https://github.com/sohilsayed/chimahon) - Learn Languages via Manga, Novels & Anime / Android
* [⁠Lingotype](https://www.lingotype.app/) - Learn Languages via Typing
* [Language Learners](https://forum.language-learners.org/) - Language Learning Forum / Community
* [WordReference](https://www.wordreference.com/), [⁠dict.cc](https://www.dict.cc/), [Glosbe](https://glosbe.com/), [⁠WikDict](https://www.wikdict.com/) or [Reverso](https://reverso.net/) - Translation Dictionaries
* [ReverseDictionary](https://reversedictionary.org/) or [OneLook Reverse](https://onelook.com/reverse-dictionary.shtml) - Search for Words Using Their Meanings
* [Languagelearning.site](https://languagelearning.site/) - Language Learning Torrents
* [Refold](https://refold.la/) - Language Learning Roadmap
* [⁠Lengualytics](https://www.lengualytics.com/) - Comprehensible Input Tracker / Resources
* [LingoDeer](https://www.lingodeer.com/) or [Busuu](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_modded_apks) (search) - Language Learning Lessons
* [Language Drops](https://languagedrops.com/) / [Premium](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_modded_apks) (search) or [OkyDoky](https://www.okydoky.app/) - Language Learning App with Thematic Vocab
* [Yojik](https://fsi-languages.yojik.eu/index.html) or [FSI Language Courses](https://www.fsi-language-courses.org/), [2](https://www.livelingua.com/fsi/) / [X](https://x.com/fsi_languages) - Language Learning Courses
* [DLIFLC](https://gloss.dliflc.edu/) - Language Learning Quizzes
* [⁠Danobang](https://danobang.com/), [⁠Digital Dialects](https://www.digitaldialects.com/) or [Ba Ba Dum](https://babadum.com/) - Language Learning Games / Interactive
* [LanguageGuide](https://www.languageguide.org/) - Visual Language Learning
* [clozemaster](https://www.clozemaster.com/) - Context-Based Language Learning
* [Sounter](https://sounter.com/), [LingoClip](https://lingoclip.com/) or [LyricFluent](https://lyricfluent.com/) - Learn Languages via Music
* [MORT](https://github.com/killkimno/MORT) or [Textractor](https://github.com/Artikash/Textractor) - Learn Languages via Games
* [Language Roadmap](https://languageroadmap.com/) - Foreign Language Media Difficulty Guide
* [LearnWithOliver](https://www.learnwitholiver.com/) or [⁠Rosetta Stone (Flashcards)](https://www.rosettastone.com/flashcards) - Language Learning Flashcards
* [MyLanguages](https://mylanguages.org/), [VocabTest](https://www.vocabtest.com/), [My Little Word Land](https://mylittlewordland.com/) or [50Languages](https://www.50languages.com/) - Grammar / Vocabulary Language Learning
* [Vocatra](https://esite.ch/vocatra/), [⁠Conjuguemos](https://www.conjuguemos.com/) or [QuizFlow](https://apt.izzysoft.de/fdroid/index/apk/jdm.apps.quizflow/) - Vocabulary Trainers
* [ListLang](https://www.listlang.com/) - Most Used Words in Any Language
* [LingYourLanguage](https://omniglot.eu/) or [Language Squad](https://www.languagesquad.com/) - Language Identification Test
* [⁠Elara Archive](https://www.elararchive.org/) - Endangered Language Video + Audio Archive
* [IPA Reader](https://ipa-reader.com/) - International Phonetic Alphabet Reader
* [Interactive IPA Chart](https://www.ipachart.com/) - Learn Phonetic Alphabet Symbols
* [DialectArchive](https://www.dialectsarchive.com/globalmap) - Listen to Accents
* [TeachMeHebrew](https://www.teachmehebrew.com/) - Learn Hebrew
* [wehewehe](https://wehewehe.org/) - Hawaiian Dictionary
* [⁠Thai-Language](http://www.thai-language.com/) - Thai Learning Resources / Dictionary
* [Tōku Reo](https://www.tokureo.maori.nz/) - Māori Language Learning Show / [Info](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/mori-note.md)
* [Itchy Feet Comic](https://files.catbox.moe/lq6s85.png) - Asian Script Differentiation Guide

***

## ▷ Language Exchange

* 🌐 **[The Language Exchange Network](https://redd.it/5m5426)**, [2](https://docs.google.com/document/d/14is9MfGfKC-ptDhXGWLQFYSAaWTJSnUxj6zK0RGqNIk/) - Language Exchange Communities / [Discord](https://discord.gg/jxcVmHJ)
* 🌐 **[Language Learning Discord Index](https://www.reddit.com/r/languagelearning/wiki/discord)** - Language Learning Discord Servers
* [InterPals](https://www.interpals.net/)
* [Episoden](https://www.episoden.com/)
* [Tandem](https://www.tandem.net/)
* [Conversation Exchange](https://www.conversationexchange.com/)
* [RhinoSpike](https://rhinospike.com/)
* [HiNative](https://hinative.com/)
* [LangX](https://Langx.io/) / [GitHub](https://github.com/langx/langx)
* [Polyglot](https://polyglotclub.com/)
* [ISODN Linguistics](https://discord.gg/8RVtshPPTh) - ISODN Linguistics Discord Community

***

## ▷ English

* 🌐 **[Many Things](https://www.manythings.org/)** - ESL Resources
* 🌐 **[ESOL](https://www.esolcourses.com/)** - English Learning Resources
* [youglish](https://youglish.com/) or [YouDict](https://youdict.co/) - YouTube Word Pronunciations
* [Forvo](https://forvo.com/) or [HowJSay](https://howjsay.com/) - Pronunciation Dictionary
* [The Internet TESL Journal](http://iteslj.org/) - Resources for EFL and ESL Teachers
* [EFSET](https://www.efset.org/) - English Proficiency Test
* [Spellcheck](https://spellcheck.xyz) - English Spelling Game
* [Learn English Online](https://www.learn-english-online.org/), [ESLFast](https://www.eslfast.com/), [AntiMoon](https://www.antimoon.com/), [Oxford Online](https://www.oxfordonlineenglish.com/free-english-lessons), [⁠Learn English](https://learnenglishteens.britishcouncil.org/) or [Cambridge Online](https://www.cambridgeenglish.org/learning-english/) - English Lessons
* [EnglishCentral](https://www.englishcentral.com/), [BBC English](https://www.bbc.co.uk/learningenglish/), [EngVid](https://www.engvid.com/) or [Voscreen](https://voscreen.com/) - English Video Lessons
* [Frenglish](https://frenglish.ru/), [BooksMania](https://t.me/booksmania) or [English E-Reader](https://english-e-reader.net/) - English Learning Books
* [elllo](https://www.elllo.org/) or [Listening Lab](https://www.esl-lab.com/) - English Listening Lessons / Practice
* [TalkEnglish](https://www.talkenglish.com/) or [Stimuler IELTS Speaking Buddy](https://play.google.com/store/apps/details?id=com.stimuler) - Improve Spoken English
* [WriteAndImprove](https://writeandimprove.com/) - Improve English Writing
* [Elsaspeak](https://elsaspeak.com/en/) - Practice English Conversations
* [Spanish-English](https://discord.com/invite/spanish-english) or [English Chat](https://discord.gg/english) - English Learning Community / Discord
* [Jumpinto](https://rentry.co/FMHYB64#jumpinto) or [IELTS69](https://www.ielts69.com/) - Cambridge English Practice Tests
* [⁠IELTS Liz](https://ieltsliz.com/) - IELTS Test Preparation
* [yell0wsuit](https://yell0wsuit.page/english.html) or [OxfordLearnersDictionaries](https://www.oxfordlearnersdictionaries.com/) - Word Learning Site
* [⁠English Phrasal Verbs](https://little-brother.github.io/english-phrasal-verbs/) - English Phrasal Verb Practice
* [Podcasts in English](https://www.podcastsinenglish.com/) - English Learning Podcasts
* [Langeek](https://langeek.co/) - Grammar / Vocabulary Language Learning
* [EnglishAccentMap](https://www.englishaccentsmap.com/) - English Accent Videos / Map
* [EnglishBanana](https://www.englishbanana.com/) - English Learning Worksheets
* [Free4Talk](https://www.free4talk.com/) - English Learning Communities

***

## ▷ Japanese

* 🌐 **[yame dame](https://yameda.me/)**, [Tatsumoto](https://tatsumoto-ren.github.io/), [GaijinRyman](https://github.com/GaijinRyman/LearningJapaneseResources), [Nihongo](https://nihongo-e-na.com/eng/), [Japanese Resources](https://forum.wordreference.com/threads/japanese-resources-%E2%80%94-constantly-updated.787986/) or [AnimeCards](https://animecards.site/) - Learning Resources
* ↪️ **[Japanese Learning Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_japanese_learning_sites)** / [YouTube Channels](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_youtube_channels)
* ↪️ **[Dictionaries / Translation](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_dictionaries_.2F_translation)**
* ↪️ **[Kanji Learning Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_kanji_learning)**
* ⭐ **[⁠Tsunahiro](https://tsunagarujp.mext.go.jp/?lang_id=EN)** - Japanese Learning Videos
* [Manatan](https://manatan.com/) / [GitHub](https://github.com/KolbyML/Manatan), [⁠Bettermelon](https://bettermelon.ru/), [JapaneseWithAnime](https://www.japanesewithanime.com/) or [Immersion Kit](https://www.immersionkit.com/) - Learn Japanese via Anime, Manga & Light Novels
* [Nihongo con Teppei](https://nihongoconteppei.com/) - Japanese Beginners Podcast
* [JapaneseTab](https://github.com/Anupya/JapaneseTab) - Japanese Learning Extension
* [⁠Sakana Translate](https://chat.sakana.ai/translate) - English > Japanese Translator
* [Minato](https://minato-jf.jp/) - Japanese Courses
* [Memento](https://ripose-jp.github.io/Memento/) - Japanese Learning Video Player
* [Supernative](https://supernative.tv/) or [LearnNatively](https://learnnatively.com/) - Learn Japanese via Media
* [jidoujisho](https://github.com/arianneorpilla/jidoujisho) or [Manabi](https://reader.manabi.io/) - Learn Japanese via Books
* [⁠VNClub](https://vnclub.org/) - Learn Japanese via Visual Novels
* [Learn Japanese Grammar](https://kimallen.sheepdogdesign.net/) or [BunPro](https://bunpro.jp/) - Learn Japanese Grammar
* [OJAD](https://www.gavo.t.u-tokyo.ac.jp/ojad/eng/pages/home) - Japanese Accent Dictionary
* [DelvinLanguage](http://delvinlanguage.com/) - Fill in Missing Japanese Words
* [Jlpt N3](https://dethitiengnhat.com/en/) or [JapaneseTest4You](https://japanesetest4you.com/) - Jlpt Exam Questions / [Grammar](https://jlptgrammarlist.neocities.org/)
* [GetKanda](https://getkana.com/app/), [Nihonoari](https://github.com/aeri/Nihonoari-App), [⁠Kana](https://vedxyz.github.io/kana/) or [RealKana](https://realkana.com/) - Learn Kana

***

## ▷ Korean

* ⭐ **[Learn Korean](https://discord.gg/e3H9Pde)** - Korean Learning Discord
* [Read Korean Letters](https://readkoreanletters.com/) - Learn Korean Characters
* [KR Dict](https://krdict.korean.go.kr/eng/) - Korean Learning Dictionary
* [HowToStudyKorean](https://www.howtostudykorean.com/) - Korean Lessons / Practice
* [iksi](https://www.iksi.or.kr/) - Korean Classes
* [TalkToMeInKorean](https://courses.talktomeinkorean.com/) - Korean Learning Courses
* [Sogang](https://korean.sogang.ac.kr/) or [90 Day Korean](https://www.90daykorean.com/) - Korean Learning Lessons
* [Mirinae](https://mirinae.io/) - Korean Word Breakdown
* [National Institute of Korean Language](https://www.korean.go.kr/front_eng/main.do) - Korean Dictionaries / Expression Practice
* [⁠LetsLearnHangul](http://letslearnhangul.com/) - Hangul Learning
* [Hangul Practice](https://hangul.gay/) - Hangul Recognition Test
* [UltimateKorean](https://ultimatekorean.com/) - Korean Grammar / Vocab Lessons
* [KoreanKeyboardLearner](https://monikasun88.github.io/KoreanKeyboardLearner/) - Korean Typing Practice
* [Korean Trainer](https://koreantrainer.mloesch.it/) - Korean Numbers & Date Practice
* [Hangul](https://hangul.cool/) - Korean Typing Practice

***

## ▷ Chinese

* 🌐 **[YellowBridge](https://www.yellowbridge.com/)** or [DigMandarin](https://www.digmandarin.com/) - Chinese Learning Tools
* 🌐 **[⁠Heavenly Path](https://heavenlypath.notion.site/)** / [Discord](https://discord.gg/chinesejourney), [Cantonese Sheik](https://www.cantonese.sheik.co.uk/), [⁠Baúl Chino](https://www.baulchino.com/), [⁠Refold Mandarin](https://zenith-raincoat-5cf.notion.site/Refold-Mandarin-Resources-d54bfade358b4d0a88b5600acb99582b) or [SinoSplice](https://www.sinosplice.com/) - Chinese Learning Resources
* ⭐ **[r/ChineseLanguage](https://www.reddit.com/r/ChineseLanguage/)** - Chinese Learning Community / [Discord](https://discord.gg/PAjBET7)
* ⭐ **[Zhongwen](https://zhongwen.com/gudian.htm)** - Learn via Classic Chinese Literature
* [Train Chinese](https://www.trainchinese.com/), [ChineseSkill](https://www.chineseskill.com/) or [HelloChinese](https://hellochinese.cc/) - Chinese Learning Apps
* [KongLongMandarin](https://www.konglongmandarin.com/), [DU Chinese](https://www.duchinese.net/) or [Dong Chinese](https://www.dong-chinese.com/) - Chinese Lessons
* [Stroke Order](https://stroke-order.learningweb.moe.edu.tw/?la=1), [LexList](https://www.edbchinese.hk/lexlist_en/index.jsp), [ArchChinese](https://www.archchinese.com/) or [Hanzi Grids](https://www.hanzigrids.com/) - Chinese Writing Lessons / Stroke Orders
* [LexList](https://www.edbchinese.hk/lexlist_en/index.jsp), [⁠Hanly](https://www.hanlyapp.com/) or [Chinese Character Database](https://humanum.arts.cuhk.edu.hk/Lexis/lexi-mf/) - Learn Chinese Characters
* [Dictionary Variants](https://dict.variants.moe.edu.tw/?la=1) - Dictionary of Chinese Character Variants
* [⁠Sakana Translate](https://chat.sakana.ai/translate) - English > Chinese Translator
* [HackingChinese](https://www.hackingchinese.com/archive-2/) - Chinese Learning Articles
* [Cantonese.ca](https://cantonese.ca/), [CantoScrolls](https://cantoscrolls.com/) or [Laoshi](https://laoshi.io/) - Chinese Vocabulary
* [Lindict](https://humanum.arts.cuhk.edu.hk/Lexis/Lindict/), [CantoWords](https://cantowords.com/), [MDBG](https://www.mdbg.net/), [LexList](https://www.edbchinese.hk/lexlist_en/index.jsp), [Revised Dictionary](https://dict.revised.moe.edu.tw/index.jsp), [Concised Dictionary](https://dict.concised.moe.edu.tw/), [Mini Dictionary](https://dict.mini.moe.edu.tw/) or [zdict](http://zdic.net/) - Chinese Dictionaries
* [Maorma](https://www.maorma.net/) - Chinese Tone Practice
* [The Chairman's Bao](https://www.thechairmansbao.com/) - Chinese Reading Practice / News Articles
* [Pleco](https://www.pleco.com/) - Chinese Flashcards / Dictionary
* [Chinese Flashcards](https://www.chineseflashcards.io/) - Chinese Flashcards

***

## ▷ Cantonese

* 🌐 **[Cantonese Sheik](https://www.cantonese.sheik.co.uk/)** - Cantonese Learning Resources
* [Live Lingua Cantonese](https://www.livelingua.com/courses/Cantonese) - Free Cantonese Courses
* [⁠A Brief Cantonese Manual](https://schmitztimo.wordpress.com/2026/04/07/a-brief-cantonese-manual/) - Cantonese Beginners Manual
* [EdUHK](https://corpus.eduhk.hk/cantonese/e_index.html), [OpenCantonese](https://opencantonese.org/), [polyu](https://www.polyu.edu.hk/clc/cantonese/home/?lang=en) or [eMini_MOOC2k](https://www.eduhk.hk/cle/resources/Mini_MOOC2/index.htm) - Cantonese Learning / Practice
* [Cantonese.ca](https://cantonese.ca/) or [CantoScrolls](https://cantoscrolls.com/) - Cantonese Vocabulary
* [Beginner's Cantonese](https://ywjt2.user.srcf.net/cantonese/) - Cantonese Grammar Lesson
* [CantoWords](https://cantowords.com/) or [LexList](https://www.edbchinese.hk/lexlist_en/index.jsp) - Cantonese Dictionary
* [HKDict](https://hkdict.megaexplorer.net/) - Contemporary Cantonese-English Dictionary
* [Cantonese Character Database](https://humanum.arts.cuhk.edu.hk/Lexis/lexi-mf/)
* [OnlineCantonese](https://www.ilc.cuhk.edu.hk/workshop/Chinese/Cantonese/OnlineCantonese/) - Cantonese Tone Practice
* [CanPro](https://play.google.com/store/apps/details?id=com.app.can_pro) / [iOS](https://apps.apple.com/hk/app/cantonese-pronunciation-app/id1625045916) - Cantonese Pronunciation App
* [Jyutping](https://jyutping.org/en/) or [LearnDuck](https://chaaklau.github.io/LearnDuck/) - Learn Cantonese Romanization System

***

## ▷ European

* 🌐 **[French Comprehensible Input](https://docs.google.com/spreadsheets/d/e/2PACX-1vS35pIJ5A3g5tBSyOcYY6RXhkfGyHGYUc_iD08MYbRmZta8R4ydXbMyrgOpy9Ignq7iyrqyThusQ8mu/pubhtml)** or **[⁠Refold French](https://docs.google.com/document/d/1lcc5v2y8m-s7b5P6OI5xtvZiPUULohxyP1rN8hrtuig/)** - French Comprehensible Input Resources
* 🌐 **[⁠Thesaurus Autumnalis](https://docs.google.com/document/d/13JLLzsLUmMa_jD1WOMXeTvSS9WKHjnOjwxygXtjAkcc)** - Latin Learning Resources
* ⭐ **[StudySpanish](https://studyspanish.com/)** - Learn Spanish
* ⭐ **[SpanishDict](https://www.spanishdict.com/)** or [⁠Linguee](https://www.linguee.es/) - Spanish Translation Dictionaries
* [Spanish-English](https://discord.com/invite/spanish-english) - Spanish Learning Community / Discord
* [SpanishChecker](https://spanishchecker.com/) - Spanish Grammar Check
* [FluentWithStories](https://www.fluentwithstories.com/) - Learn Spanish via Stories
* [The French Tutorial](http://www.frenchtutorial.com/) - French Learning Tutorials
* [⁠TV5MONDE](https://apprendre.tv5monde.com/en/) - French Learning Videos
* [LCSpeakFrench](https://t.me/LCSpeakFrench) - Live French Lessons
* [Uusi Kielemme](https://uusikielemme.fi/) - Finnish Learning
* [Finnish Flashcards](https://finnishflashcards.com/) - Finnish Flashcards / [Resources](https://finnishflashcards.com/resources)
* [The People's Dictionary](https://folkets-lexikon.csc.kth.se/folkets/folkets.en.html) - Swedish Translation Dictionary
* [⁠Easy Croatian](https://www.easy-croatian.com/) or [⁠HR4EU](https://www.hr4eu.hr/) - Croatian Language Learning
* [⁠OpaLingo](https://www.opalingo.com/) - Macedonian Learning Site
* [⁠Icelandic Online](https://icelandiconline.com/) - Icelandic Learning Courses
* [⁠Latin & Ancient Greek](https://discord.com/invite/Latin) - Latin & Ancient Greek Learning Community / Discord
* [⁠EIEOL](https://lrc.la.utexas.edu/) - Early Indo-European Language Lessons & Lexicon

***

## ▷ German

* 🌐 **[⁠German Learning Roadmap](https://learngerman.pages.dev/)** or **[German Resources](https://docs.google.com/document/d/1J5PJK0qStw2DHQHdRHuKIfq_bJrZkFarQVT7fkz13tg/edit#heading=h.biavq1413l4t)** - German Language Resources
* ⭐ **[German Discord](https://discord.gg/german)** - German Learning Community
* ⭐ **[DW German Course](https://learngerman.dw.com/en/learn-german/s-9528)** - German Learning Course
* ⭐ **[VHS Lernportal](https://www.vhs-lernportal.de/)** - German Learning Course / [Mobile](https://play.google.com/store/apps/developer?id=Deutscher+Volkshochschul-Verband)
* [Seedlang](https://seedlang.com/) - German Learning App
* [Linguee](https://www.linguee.de/) / [2](https://www.linguee.com/) or [Dict.cc](https://m.dict.cc/) - German Translation Dictionaries
* [VerbForm](https://github.com/kmoragap/verbform) - Create German Verb Anki Flashcards

***

## ▷ South Asian

* 🌐 **[Urdu Resources](https://docs.google.com/document/d/1GRTK_E0YGybMNYZjFToM40sOHNkR1NJXc_dL8HW2Q_0/)** or [UrduNotes](https://urdunotes.com/) - Urdu Learning Resources
* 🌐 **[Mga Nagmamarunong's Masterlist](https://docs.google.com/spreadsheets/d/1R9P2nt0sQbL8GqEO_hcPjwIZcM-4s0BbJifm-1AJ0Bc/)** - Tagalog Learning Resources
* 🌐 **[Learn Sanskrit](https://www.learnsanskrit.org/)** or **[Sanskrit Studio](https://sanskritstudio.wordpress.com/)** - Sanskrit Lessons and Tools
* ⭐ **[Rekhta Dictionary](https://www.rekhtadictionary.com/)** - Urdu Dictionary
* [South Asian Languages](https://discord.gg/TrdqTDdMba) - South Asian Language Learning
* [Urdupod101](https://www.urdupod101.com/blog/2021/03/18/urdu-grammar-overview/) - Urdu Grammar Overview / [Video](https://youtu.be/X5J_kXigPWE)
* [⁠Speak Pashto](https://www.speakingpashto.com/) - Pakistani Pukhto Learning Guide
* [Sanskrit Subreddit](https://www.reddit.com/r/sanskrit/) / [Resources](https://www.reddit.com/r/sanskrit/comments/kx3xyu/sanskrit_resources_compilation_post/) - Sanskrit Resources / Discussion
* [Ambuda](https://ambuda.org/texts/) - Sanskrit Dictionaries / Texts

***

## ▷ Sign Languages

* ⭐ **[SpreadTheSign](https://spreadthesign.com/)**, [Sign Dictionary](https://signacademy.org/) or [SL Dictionary](https://www.sldictionary.org/) - Multi-Language Dictionaries
* ⭐ **[ASL Dictionary](https://www.signasl.org/)**, [Anysign](https://www.anysign.app/en/dictionary), [WhatsThatSign](https://www.whatsthatsign.com/), [StrongASL](https://www.strongasl.com/), [LifePrint](https://lifeprint.com/), [ASLDict](https://www.masterstech-home.com/ASLDict.html), [ASLCore](https://aslcore.org/), [Sign Language 101](https://www.signlanguage101.com/asl/dictionary) or [HandSpeak](https://www.handspeak.com/) - American Sign Language Dictionaries
* ⭐ **[BSL Dictionary](https://www.signbsl.com/)**, [SignDeaf](https://www.signdeaf.com/), [BSL Signbank](https://bslsignbank.ucl.ac.uk/), [MobileSign](http://www.mobilesign.org/) or [Signd](https://signd.co.uk/) - British Sign Language Dictionaries
* [SignWiki](http://signwiki.org/) - Sign Language Wiki Index / Multi Language
* [Text to Sign](https://wecapable.com/tools/text-to-sign-language-converter/) - Convert Text to Fingerspelling in ASL or BSL
* [Rochester ASL / LSF](https://projects.lib.rochester.edu/lsf-asl-app/) - ASL / LSF / Click Dictionary
* [SignLex](https://signlex.framer.website/) - Interactive Sign Dictionary / Learning
* [⁠Helping Hands](https://helpinghands.gg/) - VR-Based Sign Language Practice / Classes / [Discord](https://discord.com/invite/helpinghands)
* [Signbank](https://auslan.org.au/) - Australian Sign Language Dictionary
* [NZSL](https://nzsl.nz/) - New Zealand Sign Language Dictionary
* [SSC](https://www.ssc.education.ed.ac.uk/BSL/) - BSL Academic Term Dictionary
* [BKS](https://bks.org.uk/) - British Key Word Signs
* [International Sign](https://sonastik.ead.ee/rahvusvaheline/en) - International Sign Language
* [DeafTec](https://deaftec.org/stem-dictionary/) or [Tachyo](https://www.tachyo.org/) - STEM Sign Dictionaries / Search
* [Interpreter Services](https://alb-accmedia.austincc.edu/signs) - Specialized ASL Dictionary
* [ASL Learning](https://asl.ms/), [SignSchool](https://www.signschool.com/) or [PocketSign](https://www.pocketsign.org/) - ASL Learning Sites
* [Sign AIP](https://www.sign-aip.net/sign-aip/en/) - Sign-Language Learning Videos
* [Fingerspell](https://fingerspell.net/) - ASL Fingerspelling Practice
* [The ASL Calendar](https://discord.gg/QU6vMSYN7y) or [ASL Discord](https://discord.gg/dH7jGejAz9) - ASL Learning Discord Communities / Resources
* [⁠SooSL](https://www.soosl.net/) - Create Custom Sign Language Dictionaries
* [ASL-LEX](https://asl-lex.org/) - ASL Visual Connections Map / [Visualization](https://asl-lex.org/visualization/)
* [DeafVideo](https://www.deafvideo.tv/) - ASL Vlogs + Videos / YouTube Style Site for Deaf Content
* [⁠Iltyem-iltyem](https://www.iltyemiltyem.com/) - Australian Indigenous Sign Language Learning
* [Learn NZSL](https://learn.nzsl.nz/) - NZSL Learning Site
* [⁠Fundacion CNSE](https://fundacioncnse-dilse.org/) - Spanish Sign Language Dictionary
* [Diccionario de LESCO](https://diccionario.handsonlesco.com/) or [⁠Diccionario LESCO](https://lesco.cenarec.go.cr/index.php/diccionariolesco) - Costa Rican Sign Language Dictionaries
* [⁠Danfish Gold](https://isl.danfishgold.com/#en) - Israeli Sign Language Dictionary
* [⁠RealSASL](https://www.realsasl.com/) - South African Sign Language Dictionary
* [HandyBSL](https://handybsl.co.uk/) - Learn / Practice BSL
* [SignLearner](https://signlearner.com/) - Learn ASL or BSL while Browsing Internet / Chromium
* [Signs](https://signs-ai.com/) - ASL Learning AI
* [SignWriting](https://www.signwriting.org/) - Sutton SignWriting System Learning + Resources
* [Learn BSL in SignWriting](https://ankiweb.net/shared/info/1502698119)
* [DPAN](https://dpan.tv/), [Deaffest](https://deaffestonlinecinema.eventive.org/) (Sign-Up), [DMDb](https://deafmovie.org/free/) or [Lumo TV](https://lumotv.co.uk/) - Deaf Entertainment / News
* [DMDb](https://deafmovie.org/) or [Sign on Screen](https://signonscreen.com/all-films/) - Deaf Movie Databases / Sign Language Films / Deaf Actors

***

## ▷ Constructed Languages

* 🌐 **[⁠Links from Esperanto](https://ligil.ujo.moe/)** - Esperanto Learning Sites Index
* 🌐 **[⁠pona.la](https://pona.la/)** - Toki Pona Learning / Resources
* 🌐 **[Lojban.io](https://lojban.io/)** - Lojban Learning Resources / Focused on Logical Grammatical Structures
* 🌐 **[⁠Languages of Arda](https://rentry.co/languages-of-arda)** - Guide to Tolkien Languages
* [⁠Esperanto12](https://esperanto12.net/) or [⁠Esperanto in 17 Minutes](https://unua.leciono.org/) - Esperanto Learning
* [Toki Pona (.net)](https://tokipona.net/), [Toki Pona](https://tokipona.org/) / [Subreddit](https://www.reddit.com/r/tokipona/), [⁠mun!](https://mun.la/), [⁠lipu sona mi pi toki pona](https://lipu-sona.comforttiger.space/en/), [lipu sona pona](https://lipu-sona.pona.la/), [⁠Jan Lope Toki Pona](https://jan-lope.github.io/Toki_Pona_lessons_English/), [DuoStories Toki](https://duostories.org/tok-en) / [2](https://duostories.org/tok2-en) or [Wasona](https://wasona.com/) / [GitHub](https://github.com/wasona/wasona) - Toki Pona Learning Sites / Minimal Language
* [⁠ma pona pi toki pona](https://discord.com/invite/mapona) (discord) - Toki Pona Community / Learning / Resources
* [⁠sona pona](https://sona.pona.la/) - Toki Pona Wiki / Minimal Language
* [Toki Pona Dictionary](https://commons.wikimedia.org/wiki/File:Toki_Pona_Dictionary.pdf), [⁠nimi.li](https://nimi.li/) / [GitHub](https://github.com/cubedhuang/nimi.li) or [Linku](https://linku.la/) / [GitHub](https://github.com/lipu-linku/sona) / [Audio](https://mylittlewordland.com/course/351477/toki-pona-jan-lentan-s-course-with-audio) - Toki Pona Dictionaries
* [Semantic Spaces Dictionary](https://lipamanka.gay/essays/dictionary) - Toki Pona Word Explanations / Dictionary
* [⁠lipu tenpo](https://liputenpo.org/) - Toki Pona Magazine
* [Ithkuil by Example](https://v8.zsnout.com/ithkuil/learn/) - Ithkuil Learning
* [Ithkuil](https://ithkuil.net/) - Ithkuil Learning / Focused on Logical Precision
* [The Toaq Language](https://toaq.net/) - Toaq Learning Wiki / Course / Focused on Formal Logic / [Discord](https://discord.com/invite/BjRry9QtwY)
* [⁠Viossa Diskordserver](https://discord.com/invite/g3mG2gYjZD) (discord) - Viossa Language Learning Community / Artificial Pidgin Language
* [Eberban](https://eberban.github.io/eberban/) / [Discord](https://discord.gg/FChFEHEet8) or [Learn Eberban](https://learn-eberban.github.io/) - Eberban Language Learning / Focused on Simplicity, Expressiveness & Regularity
* [Xextan](https://xextan.github.io/) - Xextan Language Learning / Focused on Simplicity + Ease of Learning / [Wiki](https://xextan.miraheze.org/wiki/Main_Page) / [Discord](https://discord.gg/4Wz7EeQJ2g)
* [⁠Thuum](https://www.thuum.org/) - Guide to Dovahzul (The Elder Scrolls Language) 
* [Learn Na'vi](https://learnnavi.org/) - Guide to Na’vi (Avatar Language) / Community / [Forum](https://forum.learnnavi.org/) / [Discord](https://discord.gg/LearnNavi)

***

# ► Developer Learning

* 🌐 **[Project Based Learning](https://github.com/practical-tutorials/project-based-learning)** - Project Based Learning Resources
* 🌐 **[Awesome Certificates](https://panx.io/awesome-certificates/)** / [GitHub](https://github.com/PanXProject/awesome-certificates) - Dev Course Indexes
* 🌐 **[Awesome YouTubers](https://github.com/JoseDeFreitas/awesome-youtubers)** - YouTube Dev Channels Indexes
* 🌐 **[r/LearnProgramming Wiki](https://www.reddit.com/r/learnprogramming/wiki/faq#wiki_getting_started)**, [Programming Learning Index](https://github.com/bobeff/programming-math-science), [⁠awesome-opensource-documents](https://github.com/44bits/awesome-opensource-documents) or [A-to-Z-Resources-for-Students](https://github.com/dipakkr/A-to-Z-Resources-for-Students) - Programming Learning Resources
* 🌐 **[Roadmap](https://roadmap.sh/)** - Developer Roadmaps / [GitHub](https://github.com/kamranahmedse/developer-roadmap)
* 🌐 **[Path to Senior Engineer](https://github.com/jordan-cutler/path-to-senior-engineer-handbook)** or [Professional Programming](https://github.com/charlax/professional-programming) - Software Engineer Resources
* ↪️ **[Programming Books](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/reading#wiki_.25B7_programming_books)** - Read / Download Programming Books
* ⭐ **[freeCodeCamp](https://www.freecodecamp.org/)** - Programming / Courses / Interactive
* ⭐ **[git-cheat-sheet](https://github.com/arslanbilal/git-cheat-sheet)**, [Git Commands](https://gabrieldejesus.github.io/git-commands/) or [Git Cheatsheet](https://www.ndpsoftware.com/git-cheatsheet.html#loc=index;) - Git Command Lists
* ⭐ **[OpenVim](https://openvim.com/)** - Interactive Vim Tutorials
* ⭐ **[Build your own X](https://github.com/codecrafters-io/build-your-own-x)** - Advanced Coding Tutorials / [Discord](https://discord.gg/DeqUD2P)
* ⭐ **[StarSQL](https://selectstarsql.com/)**, [⁠SQL Practice](https://www.sql-practice.online/) or [Learn SQL](https://sqlbolt.com/) - SQL Lessons / Practice
* [⁠W3Schools](https://www.w3schools.com/), [Programiz](https://www.programiz.com/), [TutorialKart](https://www.tutorialkart.com/), [Ultimate Programming](https://www.codebreakthrough.com/ultimate-programming-all-in-one-tutorials?coupon=LEARNFORFREE), [Hackr.io](https://hackr.io/), [GeeksforGeeks](https://www.geeksforgeeks.org/) or [Tpoint Tech](https://www.tpointtech.com/) / [Telegram](https://t.me/tpointtech) - General Coding Tutorials
* [Guru99](https://www.guru99.com/) - Software / Web Development
* [Codelabs](https://codelabs.developers.google.com/) - Project Based Tutorials
* [The SHA-256 Project](https://github.com/oconnor663/sha256_project) - Learn to Develop SHA-256
* [calmcode](https://calmcode.io/) - Video Tutorials
* [zetcode](https://zetcode.com/) - Programming Notes / Ebooks
* [Ebook Foundation](https://ebookfoundation.github.io/free-programming-books/) - Programming Ebooks
* [First Timers Only](https://www.firsttimersonly.com/) - Contribution Guide for Beginners
* [Beej's Guide to Git](https://beej.us/guide/) or [Git Tips](https://github.com/git-tips/tips) - Git Guides / Tips
* [Oh My Git!](https://ohmygit.org/) or [Oh Shit, Git!?!](https://ohshitgit.com/) - Git Learning Game
* [Git Tutorial](https://4geeksacademy.github.io/git-interactive-tutorial/) - Interactive Git Tutorial
* [Learn Git Branching](https://learngitbranching.js.org/) - Interactive Git Branching Guide
* [Git Time](https://git.bradwoods.io/) - Git Learning Game
* [Hack Club](https://hackclub.com/) - Non-Profit High School Coding Community / Resources / [GitHub](https://github.com/hackclub)
* [DevToolTips](https://devtoolstips.org/) - Developer Tips
* [Checki0](https://checkio.org/) - Code Learning Games
* [Scrimba](https://scrimba.com/) or [⁠VittaScience](https://en.vittascience.com/code) - Interactive Programming Learning
* [CloudSkillsBoost](https://www.skills.google/paths) - Programming Courses
* [⁠MOOC.fi](https://www.mooc.fi/en/) - Programming Courses
* [EggHead](https://egghead.io/) - Programming Courses
* [TechSchool](https://techschool.dev/en) - Programming Courses / [Discord](https://discord.com/invite/C4abRX5skH)
* [⁠Josh Comeau](https://www.joshwcomeau.com/) - Programming Tutorials
* [Scratch](https://scratch.mit.edu/) / [Firefox Extension](https://scratchaddons.com/) / [Chrome Extension](https://www.scratchtools.app/) / [Package Projects](https://packager.turbowarp.org/) / [Increase Speed](https://turbowarp.org/), [2](https://github.com/TurboWarp/) / [Wiki / Guides](https://scratch-wiki.info/) / [GitHub](http://github.com/ScratchAddons/ScratchAddons) or [⁠MIT App Inventor](https://appinventor.mit.edu/) - Beginner Programming Learning
* [USACO Guide](https://usaco.guide/) - Competitive Programming Lessons
* [⁠Codeforces](https://codeforces.com/) - Competitive Programming
* [Beej's Guides](https://www.beej.us/guide/) or [LearnByExample](https://learnbyexample.github.io/) - Programming Guides
* [CodinGame](https://www.codingame.com/) - Games to Practice Coding / Programming
* [Advent of Code](https://adventofcode.com/) - Programming Puzzles
* [Interview University](https://github.com/jwasham/coding-interview-university) - Software Engineer Study Guides
* [System Design 101](https://github.com/ByteByteGoHq/system-design-101) or [system-design-primer](https://github.com/donnemartin/system-design-primer) - System Design Guides
* [CLIG](https://clig.dev/) - CLI Design Guide / [Discord](https://discord.gg/EbAW5rUCkE)
* [LearnToCloud](https://learntocloud.guide/) - Cloud Computing Guide
* [⁠Server Survival](https://pshenok.github.io/server-survival/) - Tower Defense Game for learning Cloud Architecture / [GitHub](https://github.com/pshenok/server-survival)
* [Swift Playgrounds](https://developer.apple.com/tutorials/swiftui) - Learn Swift UI / [Samples](https://developer.apple.com/tutorials/sample-apps)
* [⁠VimTricks](https://vimtricks.wiki/) - Vim + Neovim Tricks / Cheat Sheet
* [⁠Learn Vim](https://github.com/iggredible/Learn-Vim) - Vim + Vimscript Learning Guide
* [rTorr](https://vim.rtorr.com/) - Vim Editor Cheat Sheets
* [Vim University](https://github.com/wincent/vim-university) - Vim Tips
* [VimTip](https://vim.fandom.com/wiki/Category:VimTip) - Vim Editor Tips
* [⁠Learn Shell](https://www.learnshell.org/) - Interactive Shell Programming Tutorial
* [⁠Assembly Tutorial](https://github.com/mschwartz/assembly-tutorial) - AMD64 / Intel 64 bit Programming Tutorial
* [High Assurance Rust](https://highassurance.rs/) - Software Development Guide
* [LearningSEO.io](https://learningseo.io/) or [SEO Cheat Sheet](https://seo-cheat-sheet.9elements.com/) - SEO Learning
* [SQL PD](https://sqlpd.com/), [SQL Noir](https://www.sqlnoir.com/), [Lost at SQL](https://lost-at-sql.therobinlord.com/) or [SQL Easy](https://www.sql-easy.com/) - SQL Learning Games
* [PostgreSQL Tutorial](https://neon.com/postgresql/tutorial) - PostgreSQL Tutorial
* [MySQL Tutorial](https://www.mysqltutorial.org/) - MySQL Tutorial
* [LearnOpenGL](https://learnopengl.com/) - Learn OpenGL
* [Devops Exercises](https://github.com/bregman-arie/devops-exercises) - DevOps Exercises
* [90DaysOfDevOps](https://github.com/MichaelCade/90DaysOfDevOps) - Learn DevOps
* [Hasura](https://hasura.io/learn/) - GraphQL Courses
* [systemd-by-example](https://systemd-by-example.com/) - systemd Learning
* [The Linux Kernel](https://kernel.org/doc/) - Linux Kernel Development Guides / [Archives](https://kernel.org/)
* [Workbench](https://apps.gnome.org/Workbench) - Learn / Experiment with Gnome / [GitHub](https://github.com/workbenchdev/Workbench)
* [botwiki](https://botwiki.org/) - Learn How to Make Bots

***

## ▷ Programming Languages

* 🌐 **[Python Discord](https://pythondiscord.com/resources/)** - Python Learning Resources
* ⭐ **[30 Days Of Python](https://github.com/Asabeneh/30-Days-Of-Python)** - Python Programming Challenge
* [Hitchhiker's Guide to Python](https://docs.python-guide.org/) - Python Guide / [GitHub](https://github.com/realpython/python-guide)
* [Typing.io](https://typing.io/) or [Silver Dev's WPM](https://wpm.silver.dev/) - Programming Typing Practice / Sign-Up
* [A Byte of Python](https://python.swaroopch.com/) - Python Guide
* [Learn Python](https://www.learnpython.org/) - Interactive Python Guide
* [FutureCoder](https://futurecoder.io/) - Interactive Python Guide
* [⁠Genepy](https://genepy.org/) - Interactive Python Guide
* [Learn-Python](https://github.com/trekhleb/learn-python) - Python Playground / Cheatsheet
* [CS50](https://cs50.harvard.edu/python/) - Python Course
* [Tea Press](https://greenteapress.com/wp) - Python Learning Book
* [Pydroid 3](https://play.google.com/store/apps/details?id=ru.iiec.pydroid3) - Android Python IDE + Learning
* [Learn C](https://www.learn-c.org/) - C Tutorials
* [C++ Core Guidelines](https://isocpp.github.io/CppCoreGuidelines/CppCoreGuidelines) / [GitHub](https://github.com/isocpp/CppCoreGuidelines) or [modern-cpp-tricks](https://github.com/rachitiitr/modern-cpp-tricks) - C++ Tips
* [Learn C++](https://www.learncpp.com/) or [StudyPlan](https://www.studyplan.dev/) - C++ Lessons / Tutorials
* [Makefile Tutorial](https://makefiletutorial.com/) - Makefile Tutorial
* [AmigosCode](https://www.youtube.com/@amigoscode), [Java Design Patterns](https://java-design-patterns.com/), [Modern Java](https://javabook.mccue.dev/) or [learncs.online](https://www.learncs.online/) - Java / Kotlin Guides
* [Learn Next.js](https://nextjs.org/learn) - Next.js Learning Resources
* [LearnGo](https://github.com/inancgumus/learngo) or [Tour Go](https://go.dev/tour) - Learn Go Programming
* [Rust Learning](https://github.com/ctjhoa/rust-learning) - Rust Learning Resources
* [Poignant](https://poignant.guide/) or [Try Ruby](https://try.ruby-lang.org/) - Learn Ruby
* [Learn Perl](https://www.learn-perl.org/) - Learn Perl

***

## ▷ Web Development

* 🌐 **[MDN](https://developer.mozilla.org/)** or [Web Dev Resources](https://joshjoshuap-webdevresources.vercel.app/) - Web Dev Learning Resources
* ⭐ **[Odin Project](https://www.theodinproject.com/)**, [2](https://www.freecodecamp.org/learn/the-odin-project/) - Programming / Courses / Interactive / [Discord](https://discord.com/invite/fbFCkYabZB)
* ⭐ **[FullStackOpen](https://fullstackopen.com/en/)** - Full Stack Course / [Discord](https://study.cs.helsinki.fi/discord/join/fullstack)
* ⭐ **[LandChad](https://landchad.net/)**, [32bit](https://32bit.cafe/) or [learn.sadgrl.online](https://sadgrl.online/guides/) - Site Development Guides
* ⭐ **[Learn to Code HTML & CSS](https://learn.shayhowe.com/)**, [⁠CSS Tricks](https://css-tricks.com/), [CSS Tip](https://css-tip.com/) or [⁠HTML Hobbyist](https://www.htmlhobbyist.com/)- HTML/CSS Learning Sites
* ⭐ **[PHP: The Right Way](https://phptherightway.com/)**, [Learn PHP](https://odan.github.io/learn-php/) or [PHP Tutorial](https://www.phptutorial.net/) - Learn PHP
* ⭐ **[JavaScript.info](https://javascript.info/)**, [Patterns.dev](https://www.patterns.dev/) or [30 Days Of JavaScript](https://github.com/Asabeneh/30-Days-Of-JavaScript) - JavaScript Learning Sites
* [⁠Cloud Cost Handbook](https://handbook.vantage.sh/) - Public Cloud Hosting Cost Guide / [GitHub](https://github.com/vantage-sh/handbook.vantage.sh)
* [Web Dev for Beginners](https://microsoft.github.io/Web-Dev-For-Beginners/) - Web Dev Course
* [⁠Packet.School](https://packet.school/) - Interactive Networking Learning
* [Awesome Network Analysis](https://github.com/briatte/awesome-network-analysis) - Network Analysis Learning
* [Aquent Gymnasium](https://thegymnasium.com/) or [CodeAnalogies](https://www.codeanalogies.com/) - Web Dev Tutorials
* [Dash](https://dash.generalassemb.ly/) - Web Dev Courses
* [Web Skills](https://andreasbm.github.io/web-skills/), [Codeguage](https://www.codeguage.com/), [web.dev](https://web.dev/learn) or [Encodedna](https://www.encodedna.com/) - Web Dev Guides
* [Codevolution](https://www.youtube.com/@Codevolution) - Web Dev Video Lessons
* [⁠The Copenhagen Book](https://thecopenhagenbook.com/) - Web App Auth Guidelines
* [DOM Events](https://domevents.dev/) - Learn about DOM Events
* [WebRTCForTheCurious](https://webrtcforthecurious.com/) - WebRTC Guide / [GitHub](https://github.com/webrtc-for-the-curious/webrtc-for-the-curious)
* [backendlore](https://github.com/fpereiro/backendlore) or [Design Pattern for Humans](https://github.com/kamranahmedse/design-patterns-for-humans) - Backend Coding Guides
* [backend-challenges](https://github.com/CollabCodeTech/backend-challenges) - Backend Challenges for Practice
* [Backend Cheats](https://github.com/cheatsnake/backend-cheats) - Backend Cheatsheet / Guide
* [STPG](https://stpg-tk.netlify.app/guides/) - Startpage Creation Guides / [Discord](https://discord.com/invite/ExAGgVR)
* [Web Design in 4 Minutes](https://jgthms.com/web-design-in-4-minutes/) or [Strml](https://www.strml.net/) - Interactive Web Design Tutorial
* [WebGL and GLSL Workshop](https://mattdesl.github.io/workshop-webgl-glsl/) - Interactive WebGL / GLSL Tutorial
* [HEAD](https://htmlhead.dev/) - HTML head Element Guide
* [100DayCSS](https://100dayscss.com/), [CSS Challenges](https://css-challenges.com/) or [PlayCSS](https://playcss.app/) - CSS Challenges
* [⁠modern.css](https://modern-css.com/) - Modern CSS Snippet Comparisons
* [Codepip](https://codepip.com/games/), [Grid Garden](https://cssgridgarden.com/), [CSS Battle](https://cssbattle.dev/), [CSS Speedrun](https://css-speedrun.netlify.app/), [CodingFantasy](https://codingfantasy.com/) or [CSS Diner](https://flukeout.github.io/) - CSS Learning Games
* [Guess CSS](https://www.guess-css.app/) - CSS Guessing Game
* [Flexbox Froggy](https://flexboxfroggy.com/), [Flexbox Zombies](https://mastery.games/flexboxzombies), [FlexboxDefense](http://www.flexboxdefense.com/) or [KnightsoftheFlexboxTable](https://knightsoftheflexboxtable.com/) - CSS Flexbox Learning Games
* [DefensiveCSS](https://defensivecss.dev/) - CSS Tips
* [LearnCSSGrid](https://learncssgrid.com/) or [GridByExample](https://gridbyexample.com/) - CSS Grid Guides
* [You Don't Know JS](https://github.com/getify/You-Dont-Know-JS) or [EloquentJavaScript](https://eloquentjavascript.net/) - JavaScript Learning Books
* [JavaScript Questions](https://github.com/lydiahallie/javascript-questions) or [JavaScriptQuiz](https://javascriptquiz.com/) - JavaScript Questions for Practice
* [33 JS Concepts](https://github.com/leonardomso/33-js-concepts) - Useful JavaScript Concepts
* [You-Dont-Need-jQuery](https://github.com/camsong/You-Dont-Need-jQuery) - JavaScript Query Style Events Guide
* [Untrusted](https://untrustedgame.com/) - JavaScript Learning Game
* [HTMLDog](https://htmldog.com/) - HTML/CSS and JavaScript Tutorials
* [Sindresorhus Guides](https://github.com/sindresorhus/guides) - Linux Guides for Node.js Developers
* [Pixactly](https://pixactly.app/) - Test Pixel Dimension Orientation

***

## ▷ Computer Science

* 🌐 **[CompSciLib](https://www.compscilib.com/)** - Computer Science Tools
* ⭐ **[TeachYourselfComputerScience](https://teachyourselfcs.com/)** - Computer Science Book Recommendations
* ⭐ **[⁠The Borr Project](https://borr.dev/computer-science/)** / [Discord](https://discord.gg/uR2QS36pdH) or **[OSSU Comp Sci](https://github.com/ossu/computer-science)** / [PT-BR](https://github.com/ossu/computer-science-br) / [CN](https://github.com/ossu/computer-science-cn) / [Discord](https://discord.gg/wuytwK5s9h) - Computer Science Roadmap
* ⭐ **[⁠CEMC](https://cemc.uwaterloo.ca/resources/courseware)** - Computer Science Courses
* ⭐ **[CS50](https://cs50.harvard.edu/x/)** - Harvard Computer Science Course / [Subreddit](https://www.reddit.com/r/cs50/) / [Telegram](https://t.me/cs50x) / [Discord](https://discord.com/invite/cs50) / [GitHub](https://github.com/cs50)
* ⭐ **[NandGame](https://nandgame.com/)** - Computer Building Puzzle
* ⭐ **[CraftingInterpreters](https://www.craftinginterpreters.com/)** - Scripting Language Implementation Book / [GitHub](https://github.com/munificent/craftinginterpreters)
* [⁠CSRankings](https://csrankings.org/) - Publication Activity of Computer Science Colleges per Topic
* [CS1000](https://cs1000.surge.sh/) - Computer Science / Software Engineering
* [Tech Dev Guide](https://www.google.com/about/careers/applications/buildyourfuture/resources/) - Computer Science Google Courses
* [Big-O Cheatsheet](https://www.bigocheatsheet.com/) - Computer Science Complexities Cheatsheet
* [CSDIY](https://csdiy.wiki/en/), [awesome-low-level-design](https://github.com/ashishps1/awesome-low-level-design), [awesome-system-design-resources](https://github.com/ashishps1/awesome-system-design-resources) or [LearnAIFromScratch](https://learnaifromscratch.github.io/) - Computer Science Learning Guides
* [ProfessorMesser](https://www.professormesser.com/) - IT Courses
* [Code.org](https://code.org/) - Computer Science Courses
* [cs-video-courses](https://github.com/Developer-Y/cs-video-courses) - Computer Science Courses
* [Modern Computer Science Curriculum](https://functionalcs.github.io/curriculum/) - Computer Science Courses
* [⁠SEE](https://see.stanford.edu/) - Computer Science Courses
* [CollegeCompendium](https://collegecompendium.org/) - Computer Science Courses
* [Missing Semester](https://missing.csail.mit.edu/) - MIT Computing Skills Course / [GitHub](https://github.com/missing-semester/missing-semester)
* [Gwern.net](https://gwern.net/) - Gwern Branwen Essays (AI, Psychology, & Statistics)
* [Runestone Interactive](https://runestone.academy/) - Interactive Guides
* [Computerphile](https://www.youtube.com/@Computerphile/) or [CSDojo](https://www.youtube.com/@CSDojo) - Computer Science YouTube Channels
* [ApressOpen](https://link.springer.com/brands/apress/books) - Computer Science Books
* [Papers We Love](https://paperswelove.org/) - Computer Science Research Papers
* [⁠System Design Academy](https://github.com/systemdesign42/system-design-academy) - Large Scale System Design Learning
* [CS Academy](https://csacademy.com/) - Interactive Computer Science Lessons
* [From Nand To Tetris](https://www.nand2tetris.org/course) - Computer Building Lesson
* [Copetti](https://www.copetti.org/) - In-depth Console Architecture Analysis / [GitHub](https://github.com/flipacholas/Architecture-of-consoles)
* [⁠Lean](https://lean-lang.org/) - Theorem Prover and Programming Language / [Learning Games](https://adam.math.hhu.de/) / [Web](https://live.lean-lang.org/) / [GitHub](https://github.com/leanprover/lean4)
* [Rocq](https://rocq-prover.org/) - Theorem Prover and Proof Assistant / [GitHub](https://github.com/rocq-prover/rocq)
* [HOL](https://hol-theorem-prover.org/) - Theorem Prover for Higher-Order Logic / [GitHub](https://github.com/HOL-Theorem-Prover/HOL)
* [Web Browser Engineering](https://browser.engineering/) - Learn about Browser Engineering
* [OSDev Wiki](https://wiki.osdev.org/) - Operating System Dev Wiki
* [Wi is Fi](https://www.wiisfi.com/) - Wi-Fi Educational Guide
* [CPU Land](https://cpu.land/) - What Happens when you run Programs
* [Computer Science Lecture Links](https://github.com/riti2409/Resources-for-preparation-Of-Placements)
* [Eylenburg](https://eylenburg.github.io/) - Hardware / Software Comparisons + History

***

## ▷ Data Science

* 🌐 **[Awesome Data Science](https://github.com/academic/awesome-datascience)** - Data Science Resources
* 🌐 **[⁠Awesome Data Analysis](https://github.com/PavelGrigoryevDS/awesome-data-analysis)** - Data Analysis Resources
* 🌐 **[Data Engineer Handbook](https://github.com/DataExpert-io/data-engineer-handbook)** - Data Engineer Resources
* ⭐ **[OSSU Data Science](https://github.com/ossu/data-science)** - Data Science Roadmap / [Discord](https://discord.gg/wuytwK5s9h)
* [Mage](https://www.mage.ai/) - Data Science Pipelines
* [Deepnote](https://deepnote.com/) - Data Science Notebook
* [Visualization.info](https://visualization.info/) or [⁠Data Visualization Guide](https://data.europa.eu/apps/data-visualisation-guide/) - Learn About Data Visualization
* [365Datascience](https://365datascience.com/) - Data Science Courses
* [⁠Kaggle Learn](https://www.kaggle.com/learn) - Data Science Learning 
* [Data Science Intro Guide](https://florian-huber.github.io/data_science_course/) or [Data Science First Intro](https://python.datasciencebook.ca/) - Data Science with Python Intro Guides
* [Advanced R](https://adv-r.hadley.nz/) - R Guide / [Solutions](https://advanced-r-solutions.rbind.io/)
* [R Packages](https://r-pkgs.org/) - R Packages Guide
* [R for Data Science](https://r4ds.hadley.nz) - R Data Science Guide
* [ggplot2: Elegant Graphics for Data Analysis](https://ggplot2-book.org/index.html) - ggplot2 Guide
* [Scipy Lectures](https://lectures.scientific-python.org/) or [Virgilio](https://virgili0.github.io/Virgilio/) / [GitHub](https://github.com/virgili0/Virgilio) - Learn DataScience
* [Data Engineering Zoomcamp](https://github.com/DataTalksClub/data-engineering-zoomcamp) - Data Engineering Course
* [Data Engineering Practice Problems](https://github.com/danielbeach/data-engineering-practice) - Data Engineering Practice
* [Zasper](https://github.com/zasper-io/zasper) - Data Science IDE

***

## ▷ Data Structures

* ⭐ **[Leetcode](https://leetcode.com/)** - Coding Practice
* ⭐ **Leetcode Tools** - [Solutions](https://github.com/kamyu104/LeetCode-Solutions), [2](https://leetcode.ca/), [3](https://walkccc.me/LeetCode/), [4](https://leetcode.doocs.org/en/) / [Company Questions](https://rentry.co/FMHYB64#lcq) / [Animations](https://github.com/MisterBooo/LeetCodeAnimation) / [Anki Cards](https://github.com/fspv/leetcode-anki) / [Videos](https://github.com/fishercoder1534/Leetcode), [2](https://docs.google.com/spreadsheets/u/0/d/19ZIl3LeNLcKgEwNI9YF2hjkXL6ssGiFl/) / [Resources](https://github.com/ashishps1/awesome-leetcode-resources) / [Analytics](https://leetcode-company-questions.vercel.app/)
* [NeetCode](https://neetcode.io/) - Coding Interview Practice
* [Codility](https://app.codility.com/programmers/) - Coding Practice
* [ProjectLearn](https://projectlearn.io/) - Coding Practice
* [LintCode](https://www.lintcode.com/) or [CodeWars](https://www.codewars.com/) - Coding Practice
* [Coding Questions](https://platform.stratascratch.com/coding) or [Skilled.dev](https://skilled.dev/) - Coding Interview Questions
* [DevPost](https://devpost.com/), [HackTheEarth](https://www.hackerearth.com/challenges/), [EMKC](https://emkc.org/challenges), [AtCoder](https://atcoder.jp/) or [Toph.co](https://toph.co/) - Hackathon / Challenge Communities
* [Rosetta Code](https://rosettacode.org/wiki/Rosetta_Code), [CodeAbbey](https://www.codeabbey.com/), [Kattis](https://open.kattis.com/) or [Coding Problems](https://github.com/MTrajK/coding-problems) - Coding Problems / Solutions
* [Exercism](https://exercism.org/), [HackerRank](https://www.hackerrank.com/) or [CS Circles](https://cscircles.cemc.uwaterloo.ca/) - Programming Lessons
* [Hello Algo](https://www.hello-algo.com/en/) - Data Structures and Algorithms Course
* [Algorithms Books](https://algorithmsbook.com/) - MIT Algorithm Focused Books
* [algorithms](https://prashantbarahi.com.np/docs/algorithms/intro) - Code Algorithms & Data Structures Tutorials
* [JavaScript Algorithms](https://github.com/trekhleb/javascript-algorithms) - Algorithms and Data Structures in JavaScript
* [VisuAlgo](https://visualgo.net/) or [Data Structure Visualizations](https://www.cs.usfca.edu/~galles/visualization/Algorithms.html) - Data Structure & Algorithm Visualizations
* [Algorithm Visualizer](https://algorithm-visualizer.org/), [⁠Staying](https://staying.fun/en) or [Sorting Algorithms Visualizer](https://sadanandpai.github.io/algo-visualizers/#/sorting-visualizer/bubble) / [GitHub](https://github.com/sadanandpai/algo-visualizers) - Visualize Code Algorithms
* [CSES Problemset](https://cses.fi/problemset/) - Collection of Algorithmic Programming Problems
* [Memory Spy](https://memory-spy.wizardzines.com/) - Learn how Bytes Represent Variables

***

## ▷ UI / UX

* [design.tips](https://www.designer.tips/) or [Utopia](https://utopia.fyi/) - Design Tips
* [HackDesign](https://hackdesign.org/) or [Sky Design](https://github.com/josephgoksu/sky-design) - UI / Webdesign Courses
* [Can't Unsee](https://cantunsee.space/) - UI Design Test
* [UXTools](https://uxtools.co/) or [UXMovement](https://uxmovement.com/) - Learn UX Design
* [SitePoint](https://www.sitepoint.com/) - UX Design Courses & Books
* [delightful humane design](https://codeberg.org/teaserbot-labs/delightful-humane-design) - Humane Design Resources
* [Laws of UX](https://lawsofux.com/) - Maxims / Principles for UI Designers
* [Deceptive Patterns](https://www.deceptive.design/) - Deceptive User Experience Examples
* [UI Coach](https://uicoach.io/) - UI Design Challenge Generator
* [BFE.dev](https://bigfrontend.dev/) - Learn Frontend Development / Interactive
* [HTML Dog](https://htmldog.com/) - Frontend Tutorials & Examples
* [FrontEndMentor](https://www.frontendmentor.io/) - Frontend Design Challenges
* [Frontend Learning Kit](https://github.com/sadanandpai/frontend-learning-kit) - Frontend Learning Index
* [Frontend Bootcamp](https://microsoft.github.io/frontend-bootcamp/) - Frontend Workshop

***

## ▷ Cybersecurity

* 🌐 **[Free Cyber Resources](https://github.com/gerryguy311/Free_CyberSecurity_Professional_Development_Resources)**, [BlueTeam Tools](https://github.com/A-poc/BlueTeam-Tools) or [Applied Cybersecurity](https://www.nist.gov/itl/applied-cybersecurity/nice/resources/online-learning-content) - Cybersecurity Learning Resources
* 🌐 **[Awesome Infosec](https://github.com/onlurking/awesome-infosec)** - Infosec Learning Resources
* 🌐 **[Official Cybersecurity YouTube Channels](https://github.com/superlincoln953/Free-Official-Youtube-Content?tab=readme-ov-file#tech--security)**
* 🌐 **[CTF Sites](https://ctfsites.github.io/)**, [echoCTF.RED](https://echoctf.red/), [CTF101](https://ctf101.org/), [CTF Beginners Guide](https://jaimelightfoot.com/blog/so-you-want-to-ctf-a-beginners-guide/), [CTFtime](https://ctftime.org/) or [CTFLearn](https://ctflearn.com/) - CTF Resources / Guides
* 🌐 **[Awesome Sites to Test On](https://github.com/BMayhew/awesome-sites-to-test-on)** - Cybersecurity Practice Sites
* ⭐ **[HackTricks](https://hacktricks.wiki/en/index.html)** - Practical Penetration Testing & Security Auditing Tips
* ⭐ **[PortSwigger Academy](https://portswigger.net/web-security)** - Web Security Learning
* ⭐ **[OWASP Cheatsheet](https://cheatsheetseries.owasp.org/)** - Application Security Guide
* [Hackers101](https://www.hacker101.com/), [SmashTheStack](https://smashthestack.org/) or [WebHacking](https://webhacking.kr/) - Cybersecurity Challenges
* [Skills for All](https://www.netacad.com/) or [90DaysOfCyberSecurity](https://github.com/farhanashrafdev/90DaysOfCyberSecurity) - Cybersecurity Courses
* [⁠Cybersecurity Mastery Roadmap](https://github.com/Hamed233/Cybersecurity-Mastery-Roadmap) - Cybersecurity Learning Roadmap
* [TryHackMe](https://tryhackme.com/), [⁠Root Me](https://www.root-me.org/?lang=en) / [Discord](https://discord.com/invite/rootme), [HackTheBox](https://www.hackthebox.com/) or [OpenSecurityTraining2](https://opensecuritytraining.info/) - Cybersecurity Lessons / Learning
* [Addielamarr](https://publish.obsidian.md/addielamarr/) or [Cyber Talent Kids](https://cybertalentskids.com/) - Learn About Cybersecurity
* [⁠Cyber Intel Handbook](https://www.shenouda.nl/cti-handbook/) - OSINT & Threat Intelligence Guide
* [pwn.college](https://pwn.college/) - Cybersecurity Practice
* [⁠WeChall](https://www.wechall.net/) - Cybersecurity Practice Games + Rankings
* [⁠BreachLab](https://breachlab.org/) - Learn Offensive Security
* [OverTheWire](https://overthewire.org/wargames/) - Cybersecurity Learning Game
* [Hacksplaining](https://www.hacksplaining.com/) - Developer Security Lessons
* [⁠Software Sandboxing](https://blog.emilua.org/2025/01/12/software-sandboxing-basics/) - Software Sandboxing Guide
* [x86re](https://x86re.com/) or [Reverse-Engineering](https://github.com/mytechnotalent/Reverse-Engineering) - Reverse Engineering Guides
* [CrackMyApp](https://crackmy.app/) / [Discord](https://discord.gg/cx3sMjKhch) or [crackmes](https://crackmes.one/) / [Discord](https://discord.com/invite/2pPV3yq) - Reverse Engineering Challenges
* [⁠Reverse Engineering Academy](https://reverseengineering.vercel.app/) - Interactive Reverse Engineering Lessons
* [⁠Nightmare](https://guyinatuxedo.github.io/) - Binary Exploitation Defense / Reverse Engineering Course
* [John Hammond](https://www.youtube.com/@_JohnHammond) - Cybersecurity YouTube Tutorials
* [Pentesting Bible](https://github.com/blaCCkHatHacEEkr/PENTESTING-BIBLE) or [Juice Shop](https://owasp.org/projects/juice-shop) - Learn Pentesting
* [How DNS Works](https://howdns.works/) - Learn DNS
* [How DNSSEC Works](https://howdnssec.works/) - Learn DNSSEC
* [CryptoPals](https://cryptopals.com/), [Overview of Cryptography](https://www.garykessler.net/library/crypto.html) or [cryptohack](https://cryptohack.org/) - Cryptography Learning
* [⁠CrypTool](https://www.cryptool.org/) - Interactive Cryptology Learning / Puzzles
* [How HTTPS Works](https://howhttps.works/) - Learn HTTPS

***

## ▷ Game Development

* 🌐 **[Awesome-Gamedev](https://github.com/FronkonGames/Awesome-Gamedev)**, [Learn Gamedev](https://github.com/notpresident35/awesome-learn-gamedev), [MagicTools](https://github.com/ellisonleao/magictools), [Newgrounds Wiki: Game Dev Resources](https://www.newgrounds.com/wiki/creator-resources/game-dev-resources) or [The VG Resource](https://www.vg-resource.com/) - Learning Resources
* ↪️ **[Game Dev Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/dev-tools/#wiki_.25BA_game_dev_tools)**
* ⭐ **[Brackeys](https://brackeys.com/)** - Game Dev Tutorials
* ⭐ **[r/gamedev](https://www.reddit.com/r/gamedev/)** - Reddit Community / [Discord](https://discord.com/invite/reddit-gamedev)
* [⁠20 Games Challenge](https://20_games_challenge.gitlab.io/) - Beginner Game Dev Challenges
* [CodeWisp](https://codewisp.ai/) - Interactive Beginner Game Dev Learning
* [⁠GameDev](https://gamedev.net/) - Game Dev Learning / Community / [Discord](https://discord.gg/tgEGVNy)
* [Amit’s Game Programming](http://www-cs-students.stanford.edu/~amitp/gameprog.html) - Game Programming Guide
* [GameProgramBooks](https://rentry.co/FMHYB64#gameprogrambooks) - Game Programming Books
* [PICO-8](https://mboffin.itch.io/pico8-educational-toolset) - Basic Game Dev Concepts / [Web Version](https://www.pico-8-edu.com/)
* [From Zero To Hero](https://therealpenaz91.itch.io/2dgd-f0th) - 2D Game Dev Book
* [Web Game Dev](https://www.webgamedev.com/) - Game Dev Guides / [Discord](https://discord.com/invite/5Z28wjTeyh)
* [SebastianLague](https://www.youtube.com/c/SebastianLague/playlists?view=50&sort=dd&shelf_id=4) - Game Dev Tutorials
* [⁠Vulkan Guide](https://vkguide.dev/) - Vulkan Learning Guide
* [Level Design Book](https://book.leveldesignbook.com/) - Level Design Guide / Book
* [Trig for Games](https://demoman.net/?a=trig-for-games) - Trigonometry Lessons for Games
* [Shadertoy](https://www.shadertoy.com/) - Real-Time Shader Dev Platform
* [Game Math](https://gamemath.com/book/intro.html) - Mathematics Lessons for Game Devs
* [The Book of Shaders](https://thebookofshaders.com/) - Fragment Shaders Guide
* [EmuDev](https://emudev.org/) - Emulator Development Information / [Discord](https://discordapp.com/invite/dkmJAes)
* [⁠EmuDevs](https://afska.github.io/emudevz/) - NES Emulator Development Learning Game
* [QB64SourceCode](https://www.qb64tutorial.com/) - QB64 Game Programming Tutorials
* [8bitWorkshop](https://8bitworkshop.com/) - Retro Game Programming Tutorials

***

## ▷ AI / ML Learning

* 🌐 **[Everything AI/ML](https://viveknaskar.github.io/everything-ai-ml/)** - LLM Learning Resources / [GitHub](https://github.com/viveknaskar/everything-ai-ml)
* ↪️ **[Machine Learning Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/ai#wiki_.25BA_machine_learning)**
* [Awesome Free AI Books](https://github.com/MarcosSete/awesome-free-ai-books), [AI-For-Beginners](https://github.com/microsoft/AI-For-Beginners), [mlsysbook](https://www.mlsysbook.ai/), [udlbook](https://udlbook.github.io/udlbook/) / [GitHub](https://github.com/udlbook/udlbook/), [ML Engineering](https://github.com/stas00/ml-engineering), [Beginner Guides](https://microsoft.github.io/generative-ai-for-beginners/) or [HF Learn](https://huggingface.co/learn) - Machine Learning Books / Guides
* [LLM Course](https://github.com/mlabonne/llm-course), [DeepLearningWizard](https://www.deeplearningwizard.com/), [IAILab](https://iailab.kaist.ac.kr/teaching/deep-learning), [Handson ML3](https://github.com/ageron/handson-ml3) or [⁠Anthropic Courses](https://anthropic.skilljar.com/) - Machine Learning Courses
* [Deep Learning Drizzle](https://deep-learning-drizzle.github.io/) - Machine Learning Courses on YouTube
* [Machine Learning Roadmap](https://rentry.org/machine-learning-roadmap) - Machine Learning Roadmap / Guide
* [⁠ML For Beginners](https://github.com/microsoft/ML-For-Beginners) - Machine Learning Beginner Lessons
* [⁠aman.ai](https://aman.ai/) - Artificial Intelligence / Deep Learning Stanford Notes
* [Awesome Generative AI Guide](https://github.com/aishwaryanr/awesome-generative-ai-guide) - LLM Research Resources / Guide
* [LLM Visualization](https://bbycroft.net/llm), [KO MicroGPT](https://ko-microgpt.vercel.app/) / [GitHub](https://github.com/woduq1414/ko-microgpt) or [⁠Transformer Explainer](https://poloclub.github.io/transformer-explainer/) - Transformer and LLM Visualizations
* [ML Visualized](https://ml-visualized.com/) - Machine Learning Visualizations / [GitHub](https://github.com/gavinkhung/machine-learning-visualized)
* [Deep ML](https://www.deep-ml.com/) - Solve Machine Learning Problems
* [Wolfram Cloud](https://www.wolframcloud.com/) - Computational Intelligence

***

# ► Exam Prep

* 🌐 **[IBResources](https://ibresources.cc/)** - International Baccalaureate Resources
* ⭐ **[⁠AP FRQ Archive](https://apfrqs.com/)** or [CrackAP](https://www.crackap.com/) - Practice AP Exams
* [FreeOnlineTest](https://www.freeonlinetest.in/), [Examveda](https://www.examveda.com/), [SaveMyExams](https://www.savemyexams.com/), [Aglasem](https://aglasem.com/), [MajorTests](https://www.123helpme.com/), [⁠ExamsNet](https://examsnet.com/) or [Alloprof](https://www.alloprof.qc.ca/en/) - Exam Practice Tests
* [IndiaBIX](https://www.indiabix.com/) - Aptitude Tests
* [Science Career General](https://sciencecareergeneral.neocities.org/) - PhD / STEM Career Study Guides
* [DoubtNut](https://allen.in/dn) - Exam / Solutions / Help / [Ad-Bypass](https://greasyfork.org/en/scripts/534790)
* [Papers.Xtreme](https://papers.xtremepape.rs/) - Test Revision Notes & Answers
* [AllFreeDumps](https://www.allfreedumps.com/) or [⁠PDF Tube](https://pdf.tube/) - Exam Papers / Study
* [⁠Mojza](https://mojza.org/) - Exam Study Notes
* [⁠Get Sum Math](https://www.getsummath.com/) - GED Prep / Practice
* [CaieFinder](https://caiefinder.com/) - Previous Cambridge Test Answers
* [Exam Downloader](https://rentry.co/FMHYB64#et-dl) - Exam Download Tool
* [ITExams](https://www.itexams.com/) - IT Exam Collection
* [Pearson's AP Universe](https://drive.google.com/drive/folders/1kG84_tEPph4bEQqu2GnYx84xUzbdFGLw) - AP Exam Guides / Community / [Discord](https://discord.com/invite/sTanvkAZbN)
* [r/APStudents Course Survey](https://docs.google.com/spreadsheets/u/6/d/1s-YM81RvD11h9UOTba_XsBKEy-NW8PEXim2UxSLwdRE/edit#gid=1924688511) - AP Exam Comparison Spreadsheet
* [r/CATpreparation](https://www.reddit.com/r/CATpreparation/) - CAT Test Prep / [Discord](https://discord.gg/CAvHUZY6rH)
* [Revisely](https://www.revisely.com/) - GCSE Exam Help
* [⁠free-clep-prep](https://free-clep-prep.com/) or [ModernStates](https://modernstates.org/) - Free CLEP / DSST Exam Prep
* [nzqa.toasting](https://nzqa.toasting.me/) - Download NZQA Past Papers
* [CatchaScience](https://catchascience.wordpress.com/), [IGCSEResources](https://sites.google.com/view/igcseresources/home), [r/IGCSE](https://www.reddit.com/r/igcse/) or [ZNotes](https://znotes.org/) - IGCSE Study Notes / Resources
* [IGCSE Papers](https://igcse.net/igcse-past-papers-download/), [⁠exam-mate](https://www.exam-mate.com/pastpapers), [⁠Study Hatch](https://studyhatch.com/), [RevisionScience](https://revisionscience.com/) or [Physics & Maths Tutor](https://www.physicsandmathstutor.com/) - Download Past GCSE / IGCSE Papers
* [⁠ISC.exe](https://class-12-isc.vercel.app/) - Indian School Certificate Examinations (ISC) Resources / Study Material
* [Holy Grail](https://grail.moe/) - Singaporean Exam Study Notes / Papers
* [anthropology](https://t.me/anthropology) - UPSC Telegram Channel

***

## ▷ SAT Testing

* 🌐 **[Digital SAT Resources](https://redd.it/zzsgzl)** - SAT Resources
* [SAT Slayer](https://www.satslayer.org/), [2](https://satslayer.vercel.app/) - SAT Practice Exams / Questions
* [⁠Mcelroy Tutoring](https://www.mcelroytutoring.com/lower.php?url=44-official-sat-pdfs-and-82-official-act-pdf-practice-tests-free) - SAT Practice Exams / Questions
* [⁠Sat DB](https://www.satdbfor.me/) - SAT Practice Exams / Questions / Requires Sign-Up
* [DSATuz](https://t.me/DSATuz) - SAT Practice Exams / Questions / [Telegram](https://t.me/DSATuzchat)
* [The SAT: Practice Tests](https://satsuite.collegeboard.org/practice/practice-tests) - SAT Practice Exams / Questions
* [1600.lol](https://1600.lol/) - SAT Practice Exams / Questions
* [⁠Bluebooky](https://bluebooky.org/) - SAT Practice Exams / Questions / Signup Required
* [SATArchive](https://www.satarchive.com/) - Previous SAT Test Archive
* [SAT Reading](https://rentry.co/satreading) - Suggested SAT Reading

***

## ▷ India Exam Prep

* 🌐 **[r/JEENEETards Index](https://www.reddit.com/r/JEENEETards/wiki/index)** - Guides / Study Material
* ⭐ **[PhysicsWallah](https://www.pw.live/)**, [Pirate Wallah](https://rentry.co/FMHYB64#pwallah-studystark) or [StudyShark](https://rentry.co/FMHYB64#pwallah-studystark) - Exam Prep / [YouTube](https://www.youtube.com/c/PhysicsWallah/)
* ⭐ **[PirateHive](https://phantomcodex9.github.io/piratehive/)** - Guides / Study Material
* ⭐ **[ExamSide](https://questions.examside.com/)** - PYQ Solutions
* [JEE Hub](https://jeehub.vercel.app/) - JEE / NEET PYQs
* [JEE Books](https://t.me/+iHmGydsEO343ODk1) - JEE Books Archives
* [Genetry](https://genetry.carrd.co/) or [Lec.Branch](https://t.me/addlist/pgaJblpaVWIwYjFl) - JEE Lectures
* [YouTube Lengths](https://redd.it/1614jn5), [Fastlane Lengths](https://redd.it/17d1qt3) or [Normal Lane Lengths](https://redd.it/183er1y) - Lecture Lengths / Data
* [MarksAPP](https://web.getmarks.app/) - Guides / Study Material / [Telegram](https://telegram.me/getmarksapp)
* [DoubtNut](https://allen.in/dn) - Solutions / Help / [Ad-Bypass](https://greasyfork.org/en/scripts/534790)

***

# ► Educational Tools

* 🌐 **[nanoHUB](https://nanohub.org/)** - Nanotechnology Tools
* ↪️ **[Note-Taking Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools#wiki_.25B7_note-taking)**
* ↪️ **[Whiteboards / Handwritten Notes](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools#wiki_.25B7_whiteboards_.2F_handwritten)**
* ↪️ **[Presentation / Slideshare Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_presentation_tools)**
* ↪️ **[Data Visualization](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_data_visualization_tools)**
* ↪️ **[Grammar / Spell Check](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools#wiki_.25B7_grammar_check)**
* [FreeForStudent](https://freeforstudents.org/), [⁠StudentBeans](https://www.studentbeans.com/) or [⁠Student Offers](https://www.studentoffers.co/) - Free Student Deals / Discounts
* [Temp .edu Mail](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools#wiki_.25B7_temp_mail) - Temp .edu Email Addresses
* [Edu VPN](https://www.eduvpn.org/) - Institute Access VPN
* [BachelorStudies](https://bachelorstudies.com/) - Bachelor Degree Search
* [Niche](https://www.niche.com/), [TheUniGuide](https://www.theuniguide.co.uk/), [Alumnius](https://alumnius.net/) or [Top Universities](https://www.topuniversities.com/) - University / School Comparisons
* [RateMyDorm](https://ratemydorm.com) or [:)](https://docs.google.com/document/d/14Mn1CrA-CV5YZAkOZtrMKTmn2O4oL-2EhIXhzXZbO0A/edit#) - College Dorm Reviews
* [RateMyProfessor](https://www.ratemyprofessors.com/) - Professor Ratings
* [ExpertFile](https://expertfile.com/) or [ExpertiseFinder](https://expertisefinder.com/) - Industry / Academic Expert Search
* [⁠Scholarship Roar](https://scholarshiproar.com/) - Scholarship Database
* [⁠Extracurriculars.org](https://extracurriculars.org/) / [Discord](https://discord.gg/SGEtqcaSRu), [snow.day](https://www.snow.day/) or [Talem](https://www.talem.org/extracurriculars) - Extracurricular Search
* [Wordwall](https://wordwall.net/) - Lesson Creator
* [Internet-In-A-Box](https://internet-in-a-box.org/) - Create Free Offline Learning Hotspots / [GitHub](https://github.com/iiab/iiab)
* [MassiveMark](https://www.bibcit.com/en/massivemark) - Convert LLM Chats to DOCX / [Discord](https://discord.gg/fPtQAQYmqq)

***

## ▷ Study Tools

* ⭐ **[StudyLion](https://lionbot.org)** - Study Tracker / Productivity Discord Bot / [Discord](https://discord.gg/the-study-lions-780195610154237993) / [GitHub](https://github.com/StudyLions/StudyLion)
* ⭐ **[StudyKit](https://studykit.app/)** / [Discord](https://discord.gg/3xY797eH3E), [Studocu](https://www.studocu.com/) / [Downloader](https://github.com/danieltyukov/studocuhack), [Knowt](https://knowt.com/), [Quizlet](https://quizlet.com/) / [Show Hidden](https://greasyfork.org/en/scripts/423872), [⁠Blooket](https://www.blooket.com/), [Shmoop](https://www.shmoop.com/), [Bitesize](https://www.bbc.co.uk/bitesize) or [SparkNotes](https://www.sparknotes.com/) - Quiz / Study Platforms
* ⭐ **[OpenSyllabus](https://opensyllabus.org/)** - Syllabus Search / Info
* ⭐ **[Coursicle](https://www.coursicle.com/)** - Class Schedule Tracker / Android, iOS
* [⁠Helium](https://www.heliumedu.com/) - Class Schedule Tracker / Grade Tracker / Planner / Android, iOS, Web / [GitHub](https://github.com/HeliumEdu)
* [Driftly](https://github.com/DP-Hridayan/Driftly) - Class Attendance Tracker / Android
* [Graded](https://github.com/NightDreamGames/Graded) - Grades Tracker / Android, iOS
* [GradesCalculator](https://calculatecgpa.com) - Calculate CGPA & GPA
* [⁠StudyKit](https://studytoolkit.vercel.app/) - Online Study Tools
* [⁠Schoolhouse](https://schoolhouse.world/) - Free Online Tutoring
* [MammothMemory](https://mammothmemory.net/index.html) - Visual Memory-Based Solutions
* [Cheatography](https://cheatography.com/) - Educational Cheat Sheets
* [GradesFixer](https://www.gradesfixer.com/) - Essay Samples
* [LearnedEasy](https://learnedeasy.com/) - Create Summaries / Quizzes from Books
* [⁠Free Numerade Videos](https://discord.gg/nEYfaceEcU) - Homework Help Videos
* [Brainly](https://brainly.com/) - Homework Help Bots / Communities / [Limit Bypass](https://greasyfork.org/en/scripts/430355)
* [StudyStream](https://www.studystream.live/) or [⁠Yeolpumta](https://www.yeolpumta.com/en) - Online Study Groups
* [⁠Study Together](https://discord.gg/study) - Study / Productivity Focused Server
* [⁠Studyn](https://studyn.org/) - Discord Bot w/ Study Tracking, Stats, Anki Integration and more
* [Space Finder](https://spacefinder.lib.cam.ac.uk/) - UK Study Space Search
* [⁠Modern Classroom](https://chromewebstore.google.com/detail/modern-classroom/bbeejocagpeechkgliijfedcbeggncne) - Google Classroom Enhancement Extension
* [Better Canvas](https://github.com/UseBetterCanvas/bettercanvas) - Canvas Enhancement Extension

***

## ▷ Research Tools

* 🌐 **[Awesome Research](https://github.com/emptymalei/awesome-research)**, [Scolary](https://scolary.com/) or [KausalFlow](https://tools.kausalflow.com/) - Research Tool Indexes
* ↪️ **[Documents / Articles](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/reading#wiki_.25B7_documents_.2F_articles)** / **[Academic Papers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/reading#wiki_.25B7_academic_papers)**
* ↪️ **[Research Paper Chatbots](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/ai#wiki_.25B7_specialized_chatbots)**
* ⭐ **[Zotero](https://www.zotero.org/)**, **[Mendeley](https://www.mendeley.com/)** / [Data](https://data.mendeley.com/) / [Reference Manager](https://www.mendeley.com/download-reference-manager/) or [⁠JabRef](https://www.jabref.org/) / [GitHub](https://github.com/JabRef/jabref) - Research Managers
* ⭐ **[Wolfram Alpha](https://www.wolframalpha.com/)** or [Wolfram Mobile](https://rentry.co/FMHYB64#wolfram-mobile) - Searchable Knowledge Base
* ⭐ **[Refseek](https://www.refseek.com/)** or [Merlot](https://www.merlot.org/merlot/index.htm) - Academic Search Engines
* [⁠Paper Trails](https://www.papertrailshq.com/) or [ResearchRabbit](https://www.researchrabbit.ai/) - Academic Article / Paper Trackers
* [Lurnby](https://www.lurnby.com) - Research Highlighting Tool / [GitHub](https://github.com/Roznoshchik/Lurnby)
* [Co-STORM](https://storm.genie.stanford.edu/) - Generate Scientific Articles
* [OpenRefine](https://openrefine.org/) - Data Cleaning
* [Foam](https://foambubble.github.io/) - Knowledge Management System
* [Scrible](https://www.scrible.com/) - Research / Writing Platform
* [CATMA](https://catma.de/) - Research Markup & Analysis Tool
* [GROBID](https://grobid.readthedocs.io) - Extract / Organize Scientific Document Info
* [General Index](https://archive.org/details/GeneralIndex) - Article Metadata Mining Project
* [Papertag](https://www.papertag.app/) - Attach Digital Content to Paper
* [Taguette](https://app.taguette.org/) - Data Analysis Document Tagging
* [Inciteful](https://incitefulmed.com/academic/) - Find Connected Literature via Citations
* [Publish or Perish](https://harzing.com/resources/publish-or-perish) - Citation Analyzer
* [⁠Citation Tree](https://citationtree.org/) - Paper Citation Trees
* [MyBib](https://www.mybib.com/), [CiteMaker](https://www.citemaker.com/), [Formatically](https://formatically.com/), [ZoteroBib](https://zbib.org/), [CitationMachine](https://citationmachine.net/), [⁠BibGuru](https://www.bibguru.com/), [Scribbr](https://www.scribbr.com/citation/generator/), [CiteFast](https://www.citefast.com) or [Cite This For Me](https://www.citethisforme.com/) - Citation Generators / [Chrome](https://chromewebstore.google.com/detail/cite-this-for-me-web-cite/nnnmhgkokpalnmbeighfomegjfkklkle)
* [PlagiarismDetector](https://plagiarismdetector.net/) or [Duplichecker](https://www.duplichecker.com/) - Plagiarism Checkers

***

## ▷ Flashcards

* ⭐ **[Anki](https://apps.ankiweb.net/)** - Flashcard App / [Subreddit](https://www.reddit.com/r/Anki/) / [Discord](https://discord.gg/jUvBM2sEs4) / [GitHub](https://github.com/ankitects/anki)
* ⭐ **Anki Tools** - [Add-ons](https://ankiweb.net/shared/addons) / [Decks](https://ankiweb.net/shared/decks) / [Resources](https://docs.ankiweb.net/resources.html), [2](https://github.com/tianshanghong/awesome-anki)
* [Anki Android](https://github.com/ankidroid/Anki-Android) or [AnkiWeb (iOS)](https://ankiweb.net/decks) - Anki Mobile Apps / [Discord](https://discord.gg/qjzcRTx)
* [StudyCraft](https://studycraft.dev/) - Flashcard App / [GitHub](https://github.com/rodmarkun/StudyCraft)
* [StudyLib](https://www.studylib.net/) - Online Flashcards
* [Flippity](https://www.flippity.net/) - Online Flashcards
* [revisiondojo](https://www.revisiondojo.com/) - Online Flashcards
* [Flashka](https://www.flashka.ai/) - Online Flashcards
* [NoteKnight](https://www.noteknight.com) - Online Flashcards
* [RemNote](https://www.remnote.com/) - Flashcard App
* [Flashcard Machine](https://www.flashcardmachine.com/) - Flashcard App
* [Gizmo](https://gizmo.ai/) - Flashcard App
* [SearchifyX](https://github.com/daijro/SearchifyX) - Search Flashcards

***

## ▷ Calculators

* ⭐ **[WolframAlpha](https://www.wolframalpha.com/examples/mathematics)** - Calculators
* ⭐ **[Omni Calculator](https://www.omnicalculator.com/)** - Calculators
* ⭐ **[OpenCalc](https://github.com/clementwzk/OpenCalc)**, [NerdCalci](https://github.com/vishaltelangre/NerdCalci), [yetCalc](https://github.com/Yet-Zio/yetCalc) or [microMathematics](https://github.com/mkulesh/microMathematics) - Android Calculators
* ⭐ **[GeoGebra](https://www.geogebra.org/)** or [Desmos](https://www.desmos.com/) - Graphing Calculators
* ⭐ **[Rink](https://rinkcalc.app/)**, [Converter Pro](https://f-droid.org/packages/com.ferrarid.converterpro/), [⁠OnlineConversion](https://onlineconversion.com/), [Frink](https://frinklang.org/fsp/frink.fsp) or [ConvertAll](https://convertall.bellz.org/) - Unit Converters / Calculators
* [CEmu](https://github.com/CE-Programming/CEmu) or [TI 84 Calculator](https://ti84calc.com/) - TI-84 Calculators
* [⁠CalcPlex](https://calcplex.com/) - Graphing Calculator Guides
* [TICalc](https://www.ticalc.org/pub/) - TI Graphing Calculator Files
* [arTIfiCE](https://yvantt.github.io/arTIfiCE/) - TI CE Calculator Jailbreak
* [numbr.dev](https://numbr.dev/) - Calculators
* [Aqua Calc](https://www.aqua-calc.com/) - Calculators
* [PlanetCalc](https://planetcalc.com/) - Calculators
* [vCalc](https://vcalc.com/) - Calculators
* [MatrixCalc](https://matrixcalc.org/en/) - Matrix Calculator
* [Qalculate](https://qalculate.github.io/) - Desktop Calculator
* [QwikTape](https://github.com/4silvertooth/QwikTape) - Note Style Calculator
* [Kalker](https://kalker.xyz/), [⁠SpeedCrunch](https://heldercorreia.bitbucket.io/speedcrunch/index.html), [Learnbin Lab](https://lab.learnbin.net/) or [Numbat](https://numbat.dev/) - Scientific Calculators
* [⁠Numla](https://numla.app/) / [GitHub](https://github.com/davidesantangelo/numla) or [Math Notepad](https://mathnotepad.com/) - Live Calculative Notepads
* [PhotoMath](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_modded_apks) (search), [Mathway](https://www.mathway.com/), [MathDF](https://mathdf.com/), [Tiger Algebra](https://www.tiger-algebra.com/), [⁠Maxima](https://maxima.sourceforge.io/) or [Symbolab](https://www.symbolab.com/) - Math / Algebra Problem Solvers

***

## ▷ Dictionaries / Thesaurus

* ⭐ **[OneLook](https://onelook.com/)** - Multi-Source Dictionary / Thesaurus Search
* ⭐ **[Wiktionary](https://www.wiktionary.org/)** - Multi-Language Dictionary / Thesaurus / Etymology
* ⭐ **[Merriam-Webster](https://www.merriam-webster.com/)** - Dictionary / Thesaurus / Etymology
* ⭐ **[GoldenDict](https://xiaoyifang.github.io/goldendict-ng/)** / [2](https://sourceforge.net/projects/goldendict/) - Dictionary / Windows, macOS, Linux
* ⭐ **[NGrams](https://books.google.com/ngrams/)** or [Netspeak](https://netspeak.org/) - Word Usage Trackers
* ⭐ **[The Piracy Glossary](https://fluffle.cc/piracyglossary)** - Piracy Dictionary
* ⭐ **[UrbanDictionary](https://www.urbandictionary.com/)** or [Slangit](https://slang.net/) - Slang Word / Phrase Dictionaries
* [⁠Lexicoff](https://lexicoff.com/) - Offline Dictionary
* [Wordnik](https://www.wordnik.com/) - Dictionary
* [Oxford English Dictionary](https://oed.com/) - Dictionary / [Bypass](https://rentry.co/freeoed)
* [Cambridge Dictionary](https://dictionary.cambridge.org/) - Dictionary
* [Ozdic](https://ozdic.com/) - Multi-Dictionary / Thesaurus
* [Collins Dictionary](https://collinsdictionary.com/) - Dictionary / Thesaurus
* [PowerThesaurus](https://www.powerthesaurus.org/) - Thesaurus
* [Moby Thesaurus](https://moby-thesaurus.org/) - Thesaurus
* [Historical Thesaurus of English](https://ht.ac.uk/) - Historical Thesaurus
* [⁠Congeegator](https://congeegator.com/) (offline) or [Verbix](https://www.verbix.com/) - Verb Conjugators
* [Phrases.org](https://phrases.org.uk/) - Phrase Dictionary
* [Time Traveler](https://www.merriam-webster.com/time-traveler) - Find Words First Printed Usage
* [EtymOnline](https://www.etymonline.com/) - Etymologies
* [StarlingDB](https://starlingdb.org/) - Advanced Linguistics Dictionary
* [Phrontistery](https://phrontistery.info/) - Obscure Word Dictionary
* [Lexipedia](https://www.lexipedia.com/) or [VisuWords](https://visuwords.com/) - Word Connections / Visualizers
* [Eunoia](https://eunoia.world/) - Words with No Translation
* [Affixes.org](https://www.affixes.org/) - Affixes
* [Fraze.it](https://fraze.it/) - Sentence Search
* [Feeels](https://feelu.vercel.app/) - Emotion Synonym Chart
* [TheDevilsDictionary](https://www.thedevilsdictionary.com/) - Cynical Dictionary
* [WordSafety](http://wordsafety.com/) - Swear Word Indexes
* [PyGlossary](https://github.com/ilius/pyglossary) or [DSL Converter](https://dictz.github.io/dsl_converter.html) - Convert Dictionary Files

***

## ▷ Encyclopedias

* 🌐 **[List of Encyclopedias](https://wikipedia.org/wiki/List_of_online_encyclopedias)** - Online Encyclopedia Index
* ⭐ **[Wikipedia](https://www.wikipedia.org/)** - Encyclopedia / [Content List](https://wikipedia.org/wiki/Wikipedia:Contents/Lists)
* ⭐ **[Wolfram Alpha](https://www.wolframalpha.com/)** - Searchable Knowledgebase
* [Omniglot](https://www.omniglot.com/index.htm) - Writing Systems & Languages Encyclopedia
* [Simple Wiki](https://simple.wikipedia.org/wiki/Main_Page) - Simplified Wikipedia
* [namuwiki](https://en.namu.wiki/) - Korean Encyclopedia
* [⁠Encyclopedia 2000](https://encyclopedia2000.com/) - 2000s-Style Desktop Encyclopedia / [GitHub](https://github.com/sburton0/encyclopedia-2000)
* [Britannica](https://www.britannica.com/)
* [EverybodyWiki](https://en.everybodywiki.com/)
* [Encyclopedia](https://www.encyclopedia.com/)
* [New World Encyclopedia](https://www.newworldencyclopedia.org/)
* [Citizendium](https://citizendium.org/)
* [Wikitia](https://wikitia.com/)
* [Infoplease](https://www.infoplease.com/)
* [Refdesk](https://www.refdesk.com/factency.html)
* [HandWiki](https://handwiki.org/)

***

## ▷ Wikipedia Tools

* 🌐 **[Wiki Portals](https://rentry.co/wikiportals)** - Wiki Portals Navigation
* [HatNote](https://top.hatnote.com/) - Top Pages
* [Reversepedia](https://reversepedia.org/) - Page Connections Search
* [⁠Wikigraph](https://tobypenner.com/wikigraph/) - Page Connections Visualizer
* [⁠Compend](https://compend.org/) - Comments / Reviews for Wikipedia Articles
* [wik](https://github.com/yashsinghcodes/wik) - Wiki TUI
* [CDPedia](https://cdpedia.python.org.ar/index.en.es.html) - Offline View
* [Substance](https://substance.reorx.com/) - Extract Markdown
* [URL Shortener](https://meta.wikimedia.org/wiki/Special:UrlShortener) - Shorten URLs
* [WikiNearby](https://wikinearby.toolforge.org/) - Location Search
* [⁠Cite Unseen](https://meta.wikimedia.org/wiki/Cite_Unseen) - Adds Reliability Symbols to Sources / Account Required
* [EntiTree](https://www.entitree.com/) - WikiData Visualization Tool / [GitHub](https://github.com/codeledge/entitree)
* [Wiki Timeline](https://wiki-timeline.com/) - Create Timelines from Wiki Articles
* [The ⁠Museum of All Things](https://may.as/moat/) / [GitHub](https://github.com/m4ym4y/museum-of-all-things) or [⁠The Endless Museum](https://theendlessmuseum.com/)- 3D Virtual Wikipedia Museums