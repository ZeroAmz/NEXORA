***
***
**[◄◄ Back to Wiki Index](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/tools-index)**
***
***

# ► System Tools

* **Warning** - It's not recommended to use debloaters unless you know what you're doing. Always research first, never just "Apply All" randomly.

***

* 🌐 **[Awesome Windows 11](https://github.com/awesome-windows11/windows11)** - Windows 11 Resources
* 🌐 **[PC-Optimization-Hub](https://github.com/BoringBoredom/PC-Optimization-Hub)** - System Optimization Resources
* ↪️ **[Gaming Optimization](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools#wiki_.25B7_optimization_tools)**
* ⭐ **[PowerToys](https://learn.microsoft.com/en-us/windows/powertoys/)** - System Tools / [Search](https://github.com/lin-ycv/EverythingPowerToys) / [Plugins](https://github.com/hlaueriksson/awesome-powertoys-run-plugins) / [GitHub](https://github.com/microsoft/PowerToys/)
* ⭐ **[Sysinternals](https://learn.microsoft.com/en-us/sysinternals/)** - Advanced System Tools
* ⭐ **[SuperF4](https://stefansundin.github.io/superf4/)** / [GitHub](https://github.com/stefansundin/superf4) or [FKill](https://github.com/sindresorhus/fkill-cli) - Process Killers
* ⭐ **[CPU-Z](https://www.cpuid.com/softwares/cpu-z.html)**, [CPU Fetch](https://github.com/Dr-Noob/cpufetch), [Glow](https://github.com/turkaysoftware/glow) or [GPU-Z](https://www.techpowerup.com/download/techpowerup-gpu-z/) - System Info Tools
* ⭐ **[Bulk Crap Uninstaller](https://www.bcuninstaller.com/)** / [GitHub](https://github.com/BCUninstaller/Bulk-Crap-Uninstaller), [Revo Uninstaller](https://www.revouninstaller.com/products/revo-uninstaller-free/) or [GeekUninstaller](https://geekuninstaller.com/) - Bulk Uninstallation Tools
* [NanaRun](https://github.com/M2Team/NanaRun) - System Admin Tools
* [BleachBit](https://www.bleachbit.org/) - Clean System Storage / [GitHub](https://github.com/bleachbit/bleachbit)
* [PolicyPlus](https://github.com/Fleex255/PolicyPlus) - Local Group Policy Editor
* [GhostBuster](https://bitbucket.org/wvd-vegt/ghostbuster/src/master/) or [Device Cleanup Tool](https://www.majorgeeks.com/files/details/device_cleanup_tool.html) - Remove Non-Present Devices
* [Why Is This Running?](https://github.com/pranshuparmar/witr) - Process Tracing / Debugging
* [nyrna](https://nyrna.merritt.codes) - Suspend Apps / Games / [GitHub](https://github.com/Merrit/nyrna)
* [ThrottleStop](https://www.techpowerup.com/download/techpowerup-throttlestop/) - Laptop CPU Monitor / Optimizer
* [RegExp](https://github.com/zodiacon/TotalRegistry), [RegScanner](https://www.nirsoft.net/utils/regscanner.html), [ripgrep-all](https://github.com/phiresky/ripgrep-all) or [Registry-Finder](https://registry-finder.com/) - Registry Explorers / Scanners
* [Winbindex](https://winbindex.m417z.com/) - Windows System Files / Binaries / [GitHub](https://github.com/m417z/winbindex)
* [OfflineInsiderEnroll](https://github.com/abbodi1406/offlineinsiderenroll), [2](https://gitlab.com/stdout12/offlineinsiderenroll), [3](https://codeberg.org/stdout12/offlineinsiderenroll) - Enable Windows Insider without Account
* [Rhasspy](https://rhasspy.readthedocs.io/en/latest/) - Voice Assistant
* [OpenRecall](https://github.com/openrecall/openrecall) or [Windrecorder](https://github.com/yuka-friends/Windrecorder/) - Memory Search App / System Recorders
* [Time.is](https://time.is/) - Check Accuracy of System Clock
* [⁠LenovoLegionToolkit](https://github.com/LenovoLegionToolkit-Team/LenovoLegionToolkit) - Lenovo Vantage + Hotkeys Replacement for Lenovo Legion Laptops
* [ASUS G-Helper](https://github.com/seerge/g-helper) - Armoury Crate Replacement for ASUS Laptops
* [⁠PreySense](https://github.com/hammadzaigham/PreySense) - Armoury Crate Replacement for Acer Predator Laptops

***

## ▷ System Tweaks

* ⭐ **[Windhawk](https://windhawk.net/)** / [Discord](https://discord.com/invite/windhawk-923944342991818753) / [GitHub](https://github.com/ramensoftware/windhawk), [MajorGeeks Windows Tweaks](https://www.majorgeeks.com/files/details/majorgeeks_registry_tweaks.html) or [Winaero](https://winaero.com/) / [2](https://winaerotweaker.com/) - System Tweaking Tools / **[Warning](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/general-tweak-critical.md)**
* ⭐ **[StartAllBack](https://www.startallback.com/)** - Tweaked Start Menu & Taskbar / Windows 11 / [Fix](https://rentry.co/FMHYB64#startxback)
* ⭐ **[Open Shell](https://open-shell.github.io/Open-Shell-Menu/)** or [StartIsBack](https://startisback.com/) / [Fix](https://rentry.co/FMHYB64#startxback) - Classic Start Menus
* ⭐ **[EarTrumpet](https://eartrumpet.app/)** / [GitHub](https://github.com/File-New-Project/EarTrumpet), [Volumey](https://github.com/G-Stas/Volumey), [BetterTrumpet](https://bettertrumpet.com/) / [Subreddit](https://www.reddit.com/r/Bettertrumpet/) / [GitHub](https://github.com/xammen/BetterTrumpet) or [Volume2](https://github.com/irzyxa/Volume2) - Tweaked Volume Mixer
* ⭐ **[AltSnap](https://github.com/RamonUnch/AltSnap)** - Tweaked Windows Dragging
* ⭐ **[Edge-Uninstall](https://gist.github.com/ave9858/c3451d9f452389ac7607c99d45edecc6)** - Microsoft Edge Removal Script
* [BatUtil](https://github.com/abbodi1406/BatUtil) / [2](https://gitlab.com/stdout12/batutil) / [3](https://codeberg.org/stdout12/BatUtil) or [TechNet-Gallery](https://github.com/MScholtes/TechNet-Gallery) - System Scripts
* [Wintoys](https://apps.microsoft.com/store/detail/wintoys/9P8LTPGCBZXD) - System App Tweaking
* [Wox](https://github.com/Wox-launcher/Wox), [Vicinae](https://www.vicinae.com/) / [GitHub](https://github.com/vicinaehq/vicinae), [Listary](https://www.listary.com/), [Raycast](https://www.raycast.com/) / [FMHY Search](https://www.raycast.com/akshit_mehta/fmhy-search), [Flow Launcher](https://www.flowlauncher.com/) / [FMHY Search](https://github.com/iamshamit/fmhy-search-flow-launcher), [Asyar](https://asyar.org/) / [GitHub](https://github.com/Xoshbin/asyar), [Ueli](https://ueli.app/) / [GitHub](https://github.com/oliverschwendener/ueli) - Keystroke / App Launchers
* [Kando](https://kando.menu/) - App Launcher / Pie Menu / [Discord](https://discord.gg/hZwbVSDkhy) / [GitHub](https://github.com/kando-menu/kando)
* [Cerebro App](https://cerebroapp.com/) - Tweaked System Navigation / [GitHub](https://github.com/cerebroapp/cerebro)
* [SmartSystemMenu](https://github.com/AlexanderPro/SmartSystemMenu) - Tweaked System Menu
* [Shell](https://nilesoft.org/) / [GitHub](https://github.com/moudey/shell) or [RCWM](https://github.com/GChuf/RCWM) - Tweaked / Custom Context Menus
* [Explorer Tab Utility](https://github.com/w4po/ExplorerTabUtility) - Improved / Tweaked File Explorers
* [Quick Access Popup](https://www.quickaccesspopup.com/) - File Manager
* [Spencer](https://www.the-sz.com/products/spencer/) - Classic Start Menu
* [yasb](https://yasb.dev/) - Tweaked Taskbar / [GitHub](https://github.com/amnweb/yasb)
* [Taskbar Tweaker](https://ramensoftware.com/7-taskbar-tweaker) - Taskbar Advanced Features / Win 10 / [GitHub](https://github.com/m417z/7-Taskbar-Tweaker)
* [⁠AppGroup](https://github.com/iandiv/AppGroup) - Create Taskbar App Groups / Folders
* [RBTray](https://github.com/benbuck/rbtray) - Minimize any App to Tray
* [Taskbar Hide](https://www.eusing.com/hidewindows/bosskey.htm) - Easily Hide / Show Taskbar
* [QuickLook](https://github.com/QL-Win/QuickLook) - macOS Quick Look for Windows / [Scan Note](https://github.com/QL-Win/QuickLook/issues/1576#issuecomment-2816980688)
* [MSEdgeRedirect](https://github.com/rcmaehl/MSEdgeRedirect) - Redirect Microsoft Edge
* [TopNotify](https://github.com/SamsidParty/TopNotify) - Move Windows Notifications

***

## ▷ Package Managers

* ⭐ **[WinGet](https://learn.microsoft.com/en-us/windows/package-manager/winget)** - CLI Package Manager / [Browse](https://winstall.app/) / [Manifest Creator](https://github.com/microsoft/winget-create) / [Auto Update](https://github.com/Romanitho/Winget-AutoUpdate) / [GitHub](https://github.com/microsoft/winget-cli)
* ⭐ **[UniGetUI](https://devolutions.net/unigetui/)** - GUI for Popular Package Managers / [GitHub](https://github.com/Devolutions/UniGetUI)
* ⭐ **[Scoop](https://scoop.sh/)** - Portable Package Manager / [GitHub](https://github.com/ScoopInstaller/Scoop)
* [Chocolatey](https://chocolatey.org/) - Package Manager / [GUI](https://github.com/chocolatey/ChocolateyGUI) / [GitHub](https://github.com/chocolatey/choco)
* [Topgrade](https://github.com/topgrade-rs/topgrade) - CLI Package Manager
* [sfsu](https://github.com/winpax/sfsu/) or [hok](https://github.com/chawyehsu/hok) - Fast Scoop Utilities
* [Zero Install](https://0install.net/) - Decentralized Cross-Platform Package Manager
* [portableapps](https://portableapps.com/download) - Package Manager for Portable Apps
* [Baulk](https://github.com/baulk/baulk) - Minimalist Package Manager
* [NirLauncher](https://launcher.nirsoft.net/) - Portable Package Manager for NirSoft Utilities
* [⁠bin](https://github.com/marcosnils/bin) - Binary Manager

***

## ▷ Task Automation

* ⭐ **[AutoHotkey](https://www.autohotkey.com/)** / [Resources](https://github.com/ahkscript/awesome-AutoHotkey) / [Discord](https://discord.com/invite/Aat7KHmG7v) / Windows / [GitHub](https://github.com/AutoHotkey/AutoHotkey)
* [Scheduler](https://www.splinterware.com/products/scheduler.html), [⁠FluentTaskScheduler](https://github.com/TRGamer-tech/FluentTaskScheduler) or [TaskRunner](https://www.keyefficiency.com/) - System Task Scheduler / Windows
* [AutoIt](https://www.autoitscript.com/) / Windows
* [TinyTask](https://tinytask.net/) - Find "Free" Button on Homepage / Windows
* [⁠CrossMacro](https://alper-han.github.io/CrossMacro/) / Windows, macOS, Linux / [GitHub](https://github.com/alper-han/CrossMacro)
* [OculiX](https://oculix.org/) / Windows, macOS, Linux / [GitHub](https://github.com/oculix-org/Oculix)
* [ChoEazyCopy](https://github.com/Cinchoo/ChoEazyCopy) / Windows
* [MacroRecorder](https://www.macrorecorder.com/) / Windows, macOS
* [Organize](https://organize.readthedocs.io) - Automated File Manager / Windows, macOS, Linux, Docker / [GitHub](https://github.com/tfeldmann/organize)

***

## ▷ Terminal / CLI

* 🌐 **[Awesome TUI](https://github.com/rothgar/awesome-tuis)** - TUI App Index
* 🌐 **[⁠Awesome Terminals](https://github.com/cdleon/awesome-terminals)** - Terminal Emulator List
* 🌐 **[Command Line Tools](https://github.com/learn-anything/command-line-tools)** - Command Line Resources
* ⭐ **[ss64](https://ss64.com/)** - Command Line Reference Index
* [Windows Terminal](https://www.microsoft.com/store/productId/9N0DX20HK701) / [GitHub](https://github.com/microsoft/terminal/), [Tabby](https://tabby.sh/) / [GitHub](https://github.com/eugeny/tabby), [MobaXterm](https://mobaxterm.mobatek.net/) or [WezTerm](https://wezfurlong.org/wezterm/) / [Plugins](https://github.com/michaelbrusegard/awesome-wezterm) / [GitHub](https://github.com/wezterm/wezterm) - Terminal Emulators / Windows
* [psmux](https://psmux.pages.dev/) - Windows Tmux / Windows / [GitHub](https://github.com/psmux/psmux)
* [Zellij](https://zellij.dev/) - Terminal Multiplexer / Windows, macOS, Linux / [GitHub](https://github.com/zellij-org/zellij)
* [PowerShell](https://github.com/powershell/powershell) - Microsoft PowerShell / Windows, macOS, Linux
* [BusyBox](https://frippery.org/busybox/) - Unix Commands for Windows / Windows / [GitHub](https://github.com/rmyorston/busybox-w32) / [GitLab](https://gitlab.com/rmyorston/busybox-w32)
* [Clink](https://github.com/chrisant996/clink) - Command Line Editing / Windows
* [Nushell](https://www.nushell.sh/) - Alt Shell / Windows, macOS, Linux / [GitHub](https://github.com/nushell/nushell)
* [⁠procs](https://github.com/dalance/procs) - ps (Process Status) Replacement / Windows, macOS, Linux
* [⁠WTF](https://wtfutil.com/) - Terminal Dashboard / Windows, macOS, Linux, Docker / [GitHub](https://github.com/wtfutil/wtf)
* [Command Challenge](https://cmdchallenge.com/) - Command Line Learning / Web
* [Mintty](https://mintty.github.io/) - Cygwin Terminal Emulator / Windows
* [GetDNote](https://www.getdnote.com/) - Command Line Notebook / Windows, macOS, Linux, Docker / [GitHub](https://github.com/dnote/dnote)
* [LeanandMean](https://github.com/AveYo/LeanAndMean) - Powershell Snippets / Use with Caution
* [PowerShell Scripts](https://github.com/fleschutz/PowerShell), [PowershellGallery](https://www.powershellgallery.com/) or [WindowsPowerShell](https://github.com/stevencohn/WindowsPowerShell) - Shell Scripts

***

## ▷ Remote Desktop

* ⭐ **[Parsec](https://parsec.app/)** / Windows, macOS, Linux, Android, Web / [X](https://x.com/parsecteam) / [Discord](https://discord.com/invite/cQjEGFy) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/parsec.md)
* ⭐ **[RustDesk](https://rustdesk.com/)** / All Platforms / [Subreddit](https://www.reddit.com/r/rustdesk/) / [Discord](https://discord.com/invite/nDceKgxnkV) / [GitHub](https://github.com/rustdesk/rustdesk)
* ⭐ **[Aspia](https://aspia.org/)** / Windows, macOS, Linux / [Telegram](https://t.me/aspia_talks) / [GitHub](https://github.com/dchapyshev/aspia)
* ⭐ **[Sunshine](https://app.lizardbyte.dev/Sunshine/)** or [Apollo](https://github.com/ClassicOldSong/Apollo) - Remote Server for Moonlight / Windows, macOS, Linux / [Discord](https://discord.com/invite/d6MpcrbYQs) / [GitHub](https://github.com/LizardByte/Sunshine)
* [Moonlight](https://moonlight-stream.org/) or [Artemis](https://github.com/ClassicOldSong/moonlight-android) (android) - Gaming Remote Desktop Client / Windows, macOS, Linux, Android, iOS / [Discord](https://discord.com/invite/CGg5JxN) / [GitHub](https://github.com/moonlight-stream)
* [Kasm](https://kasm.com/) - Container Streaming Platform / Resource Intensive / Windows, Linux / [GitHub](https://github.com/kasmtech/KasmVNC)
* [HopToDesk](https://www.hoptodesk.com/) / Windows, macOS, Linux, Android, iOS / [GitLab](https://gitlab.com/hoptodesk/hoptodesk)
* [p2p.kiwi](https://p2p.kiwi/) / Windows, macOS, Linux / [GitHub](https://github.com/dont-be-evil-company/p2p.kiwi)
* [⁠DWS](https://www.dwservice.net/) / Windows, macOS, Linux
* [Remote Desktop Connection](https://support.microsoft.com/en-us/windows/how-to-use-remote-desktop-5fe128d5-8fb1-7a23-3b8a-41e636865e8c) - Built Into Windows / Windows / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/rdc.md)
* [Remotly](https://remotly.com/) / Windows, Linux
* [ChromeRemoteDesktop](https://remotedesktop.google.com/) - Browser
* [InputDirector](https://www.inputdirector.com/) - Multi-Computer Client / Windows
* [Mouse Without Borders](https://www.microsoft.com/en-us/garage/wall-of-fame/mouse-without-borders/) - Multi-Computer Client / Windows
* [Screensy](https://screensy.marijn.it/) - Web-Based / [GitHub](https://github.com/screensy/screensy)
* [Screego](https://app.screego.net/) - Web-Based / [GitHub](https://github.com/screego/server/)
* [Screen-Sharing](https://share-your-screen.vercel.app/) - Web-Based / [GitHub](https://github.com/tonghohin/screen-sharing)
* [TigerVNC](https://tigervnc.org/) - VNC Client / Windows, Linux / [GitHub](https://github.com/TigerVNC/tigervnc)
* [TightVNC](https://www.tightvnc.com/) - VNC Client
* [noVNC](https://novnc.com/info.html) - JavaScript VNC Client / [GitHub](https://github.com/novnc/noVNC)

***

## ▷ Clipboard Managers

* ⭐ **[Ditto](https://ditto-cp.sourceforge.io/)** / Windows / [GitHub](https://sabrogden.github.io/Ditto/)
* [PasteBar](https://www.pastebar.app/) / Windows, macOS / [GitHub](https://github.com/PasteBar/PasteBarApp)
* [CrossPaste](https://crosspaste.com/) / Windows, macOS, Linux / [GitHub](https://github.com/crosspaste/crosspaste-desktop)
* [UniClipboard](https://www.uniclipboard.app/) / Windows, macOS, Linux, Android, iOS / [GitHub](https://github.com/UniClipboard/UniClipboard)
* [ArsClip](https://www.joejoesoft.com/vcms/97/) / Windows
* [ClipAngel](https://sourceforge.net/projects/clip-angel/) / Windows
* [CopyQ](https://hluk.github.io/CopyQ/) / Windows, macOS, Linux / [GitHub](https://github.com/hluk/CopyQ) - Clipboard Manager with Editing and Scripting Features
* [MultiClipBoardSlots](https://www.softwareok.com/?seite=Microsoft/MultiClipBoardSlots) - Extend Clipboard by 10 Memory Slots / Windows

***

## ▷ Window Managers

* ⭐ **[GlazeWM](https://github.com/glzr-io/glazewm)** - Tiling Window Manager
* ⭐ **[Komorebi](https://github.com/LGUG2Z/komorebi)** - Tiling Window Manager
* [⁠Seelen UI](https://github.com/eythaann/Seelen-UI) - Tiling Window Manager / [Discord](https://discord.gg/ABfASx5ZAJ)
* [Whim](https://github.com/dalyIsaac/Whim/) - Pluggable Dynamic Window Manager
* [DWM](https://github.com/prabirshrestha/dwm-win32) - Port of X11 dwm to Windows

***

## ▷ Virtual Machines

* 🌐 **[Awesome Web Desktops](https://github.com/syxanash/awesome-web-desktops)** or [Simone's Computer](https://simone.computer/#/webdesktops) - Browser Operating Systems / VMs
* 🌐 **[Virtual OS Museum](https://virtualosmuseum.org/)** - Multi Virtual Machine Compilation (1700+)
* ↪️ **[Emulators on Android](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_emulators_on_android)**
* ⭐ **[VMware Workstation](https://www.techpowerup.com/download/vmware-workstation-pro/)** - Virtual Machine / [macOS VM](https://rentry.co/FMHYB64#vmware-workstation)
* ⭐ **[QEMU](https://www.qemu.org/)** - Virtual Machine / Use w/ Virt-Manager or Vagrantup / [Docker Container](https://github.com/qemus/qemu) / [GitLab](https://gitlab.com/qemu-project/qemu)
* ⭐ **[VirtualBox](https://www.virtualbox.org/)** - Virtual Machine / [GitHub](https://github.com/VirtualBox/virtualbox)
* ⭐ **[Virt-Manager](https://virt-manager.org/)** / [GitHub](https://github.com/virt-manager/virt-manager), [Dexpot](https://www.dexpot.de/) or [Vagrantup](https://developer.hashicorp.com/vagrant) / [GitHub](https://github.com/hashicorp/vagrant) - Virtual Machine Managers
* [Looking Glass](https://looking-glass.io/) - Kernel-Based Virtual Machine for VGA PCI Pass-Through / [GitHub](https://github.com/gnif/LookingGlass)
* [Hyper-V](https://learn.microsoft.com/en-us/virtualization/hyper-v-on-windows/) - Virtual Machine
* [OSBoxes](https://www.osboxes.org/) - Preinstalled Virtual Machine
* [JSLinux](https://bellard.org/jslinux/) - Online Linux Virtual Machines
* [QuickEmu](https://github.com/quickemu-project/quickemu) - Virtual Machine Creator
* [WSL](https://learn.microsoft.com/en-us/windows/wsl/) - Run Linux on Windows / [Resources](https://github.com/sirredbeard/Awesome-WSL) / [Wayland / X Server](https://github.com/microsoft/wslg) / [GitHub](https://github.com/microsoft/WSL)
* [⁠Dockur](https://github.com/dockur) - Run Windows / macOS in Docker Containers
* [Virtual x86](https://copy.sh/v86/) - x86-compatible OS Emulators
* [PCjs Machines](https://www.pcjs.org/) - Classic Computer Emulators
* [InfiniteMac](https://infinitemac.org/) - Apple OS Emulators
* [winevdm](https://github.com/otya128/winevdm) - 16-bit Windows on 64-bit Systems
* [Blink](https://github.com/jart/blink) - Linux Emulator for Windows
* [Dockerholics](https://github.com/petersem/dockerholics) - Docker Apps

***

## ▷ Hackintosh

* **Note** - Generating a unique SMBIOS is crucial for Apple services like iMessage and iCloud to function properly. Keep in mind macOS Tahoe 26 will be the last working version on x86_64 hardware.

***

* ⭐ **[Hackintosh](https://hackintosh.com/) / [Subreddit](https://www.reddit.com/r/hackintosh/) / [Discord](https://discord.gg/u8V7N5C)** - Hackintosh Building Guides
* ⭐ **[Dortania](https://dortania.github.io/OpenCore-Install-Guide/)** - Hackintosh Installation Guide
* [⁠Hackmate](https://github.com/riftaway7-code/hackmate) - Hackintosh Bootable USB Automation
* [OpenCore-Legacy-Patcher](https://dortania.github.io/OpenCore-Legacy-Patcher) - macOS on Unsupported Hardware
* [OneClick-macOS](https://github.com/notAperson535/OneClick-macOS-Simple-KVM) - macOS VM with QEMU
* [Emaculation](https://www.emaculation.com/) - Virtual macOS Environments
* [Hackintosh Tools](https://rentry.org/hackintosh-tools)

***

# ► Hardware Tools

* ↪️ **[PC Hardware / Building](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_pc_hardware_.2F_building)**
* ⭐ **[PSU Calculator](https://www.newegg.com/tools/power-supply-calculator/)** - Find Compatible Power Supplies
* [DeviceTests](https://devicetests.com/) - Multiple Device Tests
* [BES](https://mion.yosei.fi/BES/) or [Process Lasso](https://bitsum.com/) - CPU Optimizer
* [Ozone3D](https://www.ozone3d.net/index_softwares.php), [UNIGINE Benchmarks](https://benchmark.unigine.com/) or [OCCT](https://www.ocbase.com/occt-personal-use) - System Benchmarking
* [Testmem5](https://www.overclock.net/threads/memory-testing-with-testmem5-tm5-with-custom-configs.1751608/) - Memory Benchmarking
* [⁠SilverBench](https://silver.urih.com/) - In-Browser CPU Stress Test
* [MemTest](https://www.memtest.org/) or [⁠RAMMap](https://learn.microsoft.com/en-us/sysinternals/downloads/rammap) - Memory Diagnostic Tools / Usage Trackers
* [SDIO](https://glenn.delahoy.com/snappy-driver-installer-origin), [Drivers Collection](https://driverscollection.com/), [Driverscape](https://www.driverscape.com/) or [DriverStoreExplorer](https://github.com/lostindark/DriverStoreExplorer) - Update / Install Missing Drivers / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/driver-note.md)
* [VOGONS Drivers](https://vogonsdrivers.com/) - Vintage Computer Hardware Forum / [Forums](https://www.vogons.org/)
* [⁠PCI Lookup](https://pcilookup.com/) - PCI Vendor ID Lookup

***

## ▷ Hardware Monitors

* ⭐ **[HWiNFO](https://www.hwinfo.com/)** - System Info & Monitoring / Windows
* [Traffic Monitor](https://github.com/zhongyang219/TrafficMonitor/) - Network & Hardware Monitor / Use Lite Version / Windows
* [HWMonitor](https://www.cpuid.com/softwares/hwmonitor.html) - Hardware Monitor / Windows
* [BatteryMode](https://en.bmode.tarasovlabs.com/) - System Tray Battery Percentage / Managers / Windows / [GitHub](https://github.com/tarcode-apps/BatteryMode)
* [fastfetch](https://github.com/fastfetch-cli/fastfetch) - Command Line System Info & Monitoring / Windows, macOS, Linux, Android
* [⁠btop4win](https://github.com/aristocratos/btop4win) - System Info & Monitoring / Windows
* [⁠NeoHtop](https://abdenasser.github.io/neohtop/) or [NeoHtop-cli](https://github.com/Abdenasser/neohtop-cli) - Task Manager Alt / Windows, macOS, Linux
* [Task Manager DeLuxe](https://www.mitec.cz/tmx.html), [⁠AppControl](https://www.appcontrol.com/) / [Discord](https://discord.gg/txdQZtW8AV) or [System Informer](https://systeminformer.sourceforge.io/) / [GitHub](https://github.com/winsiderss/systeminformer/) - Task Manager Alts / Windows
* [Libre Hardware Monitor](https://github.com/LibreHardwareMonitor/LibreHardwareMonitor) - Updated Fork of Open Hardware Monitor / Windows
* [FanControl](https://getfancontrol.com/) / [GitHub](https://github.com/Rem0o/FanControl.Releases) or [FanCtrl](https://github.com/lich426/FanCtrl) - PC Fan Controllers / Windows
* [bottom](https://bottom.pages.dev) / [GitHub](https://github.com/ClementTsang/bottom) or [Glances](https://nicolargo.github.io/glances/) / [GitHub](https://github.com/nicolargo/glances) - Terminal Hardware Monitors / Windows, macOS, Linux

***

## ▷ GPU Tools

* ⭐ **[NVTOP](https://github.com/Syllo/nvtop)** - GPU / Accelerator Process Monitor
* ⭐ **[NVCleanstall](https://www.techpowerup.com/download/techpowerup-nvcleanstall/)** or [NVSlimmer](https://forums.guru3d.com/threads/nvslimmer-nvidia-driver-slimming-utility-continued.457504/) - NVIDIA Driver Packages
* [Display Driver Uninstaller](https://www.wagnardsoft.com/display-driver-uninstaller-ddu-), [2](https://www.guru3d.com/download/display-driver-uninstaller-download) - Display Driver Removal Tool / [GitHub](https://github.com/Wagnard/display-drivers-uninstaller)
* [TinyNvidiaUpdateChecker](https://github.com/HawaiiBeach/TinyNvidiaUpdateChecker) - NVIDIA GPU Update Checker
* [nvidiaProfileInspector](https://github.com/Orbmu2k/nvidiaProfileInspector) or [NvidiaProfileInspectorRevamped](https://github.com/xHybred/NvidiaProfileInspectorRevamped) - Modify / View Hidden NVIDIA Settings / [Guide](https://youtu.be/XncmeD8khKY)
* [RadeonSoftwareSlimmer](https://github.com/GSDragoon/RadeonSoftwareSlimmer) - Debloat AMD Drivers
* [R.ID](https://rdn-id.com/) - AMD 3rd Party Drivers / [Discord](https://discord.gg/rdnid)
* [PresentMon](https://github.com/GameTechDev/PresentMon) - GPU Benchmarking
* [Universal x86 Tuning Utility](https://amdaputuningutility.com/) - Laptop GPU Controller / [GitHub](https://github.com/JamesCJ60/Universal-x86-Tuning-Utility)
* [RyzenAdj](https://github.com/FlyGoat/RyzenAdj) - Ryzen Laptop GPU Controller

***

## ▷ Disk Tools

* 🌐 **[Awesome Storage](https://github.com/okhosting/awesome-storage)** - File Storage Resources
* ⭐ **[WizTree](https://www.diskanalyzer.com/)**, **[WinDirStat](https://windirstat.net/)** / [GitHub](https://github.com/windirstat/windirstat/), or [TreeSize](https://www.jam-software.com/treesize) - Disk Usage Analyzers
* ⭐ **[CrystalDiskMark](https://crystalmark.info/en/software/crystaldiskmark/)** or [CCISOBench](https://ccsiobench.com/) - Disk Benchmarking Tools
* ⭐ **[GParted](https://gparted.org/)** / [GitLab](https://gitlab.gnome.org/GNOME/gparted/), [MiniTool Partition Wizard](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/download#wiki_.25BA_software_sites) (Search) or [AOMEI Partition Assistant](https://www.diskpart.com/) / [Features](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/download#wiki_.25BA_software_sites) (search) - Partition Managers
* ⭐ **[Validrive](https://www.grc.com/validrive.htm)** - Check True Storage Size of USB Devices
* [TrueNAS](https://www.truenas.com/) - Storage System
* [QDirStat](https://github.com/shundhammer/qdirstat) - Directory Statistics
* [CrystalDiskInfo](https://crystalmark.info/en/software/crystaldiskinfo/) / [Warning](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/crystaldiskinfo-critical.md), [Scrutiny](https://github.com/AnalogJ/scrutiny), [GSmartControl](https://gsmartcontrol.shaduri.dev/) / [GitHub](https://github.com/ashaduri/gsmartcontrol) or [smartmontools](https://www.smartmontools.org/) - Drive Diagnostics
* [Macrorit Partition Expert](https://macrorit.com/partition-magic-manager/partition-expert-download.html) - Disk Usage Analyzer
* [Diskovery](https://diskovery.io/) - Disk Usage Analyzer
* [Gdu](https://github.com/dundee/gdu) or [dua](https://lib.rs/crates/dua-cli) - Disk Usage Analyzer with Parallel Processing
* [Erdtree](https://github.com/solidiquis/erdtree) - Cross-Platform Disk Usage Analyzer
* [PC Manager](https://pcmanager.microsoft.com/) - Disk Managers / Cleanup
* [Air Live Drive](https://www.airlivedrive.com/en/) - Mount Cloud Drives as Local Disks
* [SFTPDrive](https://www.callback.com/sftpdrive) - Mount SFTP Servers as Local Disks

***

## ▷ Monitor Tools

* ↪️ **[Monitor Comparisons](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_tv_.2F_monitors)**
* ⭐ **[DisplayFusion](https://www.displayfusion.com/)** or [Dual Monitor Tool](https://sourceforge.net/projects/dualmonitortool/) - Dual Monitor Tools
* ⭐ **[f.lux](https://justgetflux.com/)**, [LightBulb](https://github.com/Tyrrrz/LightBulb) or [ScreenTemperature](https://github.com/massaiTHEdog1/ScreenTemperature) - Auto-Adjust Display Color / Temperature
* ⭐ **[Monitorian](https://github.com/emoacht/Monitorian)**, **[Twinkle Tray](https://twinkletray.com/)** / [GitHub](https://github.com/xanderfrangos/twinkle-tray) or [Dimmer](https://www.nelsonpires.com/software/dimmer) - Adjust Monitor Brightness
* [EIZO](https://www.eizo.be/monitor-test/), [Monitor](https://www.monitortests.com/) or [LCDTech](https://displaytech.org/en/tests/) - Monitor Performance Tests
* [TestUFO](https://www.testufo.com/) - Monitor Framerate Test
* [LittleBigMouse](https://github.com/mgth/LittleBigMouse) - DPI Test
* [Scalizer](https://github.com/wonmor/Scalizer-Windows) - Auto DPI Scaling / [YouTube](https://youtu.be/f_3XWlmyat4)
* [Display Calc](https://www.tools.rodrigopolo.com/DisplayCalc/) - Display Distance / Dimension Calculator
* [Multi-Monitor Calculator](https://multimonitorcalculator.com/) - Dual-Monitor Setup Planning / Tests
* [Wide Gamut](https://www.wide-gamut.com/) - Color Compatibility Test
* [⁠ICC Profiles Guide](https://gist.github.com/Overimagine1/c0e5ebe60838e7dd0417549ea7aae260) - Guide for Finding ICC Profiles
* [Dead.Pixel](https://displaytech.org/en/tests/dead.pixel.htm) - Dead Pixel Test
* [JScreenFix](https://www.jscreenfix.com/) - Repair Stuck Pixels
* [CenterOfMyScreen](https://centerofmyscreen.com/) - Find Center of Monitor
* [ShowDesktopOneMonitor](https://github.com/ruzrobert/ShowDesktopOneMonitor) - Show Desktop for Only One Monitor
* [⁠Virtual Display Driver](https://github.com/VirtualDrivers/Virtual-Display-Driver) - Virtual Display Driver
* [Deskreen](https://deskreen.com/) / [GitHub](https://github.com/pavlobu/deskreen), [⁠BetterCast](https://bettercast.online/) or [SpaceDesk](https://www.spacedesk.net/) - Use Mobile Device / Tablet as Secondary Monitor
* [ShaderGlass](https://github.com/mausimus/ShaderGlass) - Custom Screen Shaders
* [DaltonLens](https://daltonlens.org/) or [Toptal](https://www.toptal.com/designers/colorfilter) - Color Blindness Filters
* [NVDA](https://www.nvaccess.org/download/) - Screen Reader for Blind Users / [GitHub](https://github.com/nvaccess/nvda)

***

## ▷ Mouse / Keyboard

* 🌐 **[r/MechanicalKeyboards Wiki](https://www.reddit.com/r/MechanicalKeyboards/wiki/index)** - Mechanical Keyboard Resources
* 🌐 **[⁠Keebfolio](https://keebfolio.netlify.app/)** - Mechanical Keyboard Project Index / [GitHub](https://github.com/Keycapsss/awesome-mechanical-keyboard)
* ↪️ **[Mouse / Keyboard Comparisons](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_keyboards_.2F_mice)**
* ⭐ **[KeyCombiner](https://keycombiner.com/)** or [Use The Keyboard](https://usethekeyboard.com/) - Hotkey Cheatsheets
* ⭐ **[VIA](https://www.caniusevia.com/)** / [GitHub](https://github.com/the-via/app), [SharpKeys](https://github.com/randyrants/sharpkeys/), [Kanata](https://github.com/jtroo/kanata), [keymapper](https://github.com/houmain/keymapper), [Mahou](https://gitea.com/BladeMight/Mahou) - Custom Keyboard Layouts / Remapping
* ⭐ **[geekhack](https://geekhack.org/)** or [KeebTalk](https://www.keebtalk.com/) - Keyboard Forums
* [Ergogen](https://ergogen.xyz/) - Design / Make Ergonomic Keyboards
* [⁠Keyboard Tester](https://keyboardtest.io/) or [Key Test](https://en.key-test.ru/) - Keyboard Testers
* [HotkeyP](https://sourceforge.net/projects/hotkeyp/) or [CheatKeys](https://cheatkeys.com/cheatsheet) - Hotkey Remapping
* [OpenMouse](https://openmouse.app/) / [Discord](https://discord.com/invite/yxC9jzMdw6) / [GitHub](https://github.com/OpenMouse-Project) or [Piper](https://github.com/libratbag/piper) - Mouse Config Tools
* [⁠Onboard Memory Manager](https://support.logi.com/hc/en-gb/articles/360059641133-Onboard-Memory-Manager) - Modify Logitech G Mouse Memory
* [⁠Mouse Tester](https://mousetester.io/) - Mouse Testing Tools
* [X-Mouse Button Control](https://www.highrez.co.uk/downloads/XMouseButtonControl.htm) - Re-Map Mouse Buttons / Scroll Wheel
* [MoveMouse](https://github.com/sw3103/movemouse/) or [MouseJiggler](https://github.com/arkane-systems/mousejiggler) - Simulate User Activity
* [Raw Accel](https://github.com/RawAccelOfficial/rawaccel) - Mouse Acceleration Tool
* [StrokeIt](https://www.tcbmi.com/strokeit/) - Mouse Gestures
* [Espanso](https://espanso.org/) - Typing Shortcuts / [GitHub](https://github.com/espanso/espanso)
* [win-vind](https://pit-ray.github.io/win-vind/) - Vim Style Keybindings for Windows
* [Vial](https://get.vial.today/) - Custom Keyboard Config Tool
* [KeyViz](https://github.com/mulaRahul/keyviz) - Keystroke Visualizer
* [Plover](https://www.openstenoproject.org/plover/) - Stenography Engine / [Discord](https://discord.gg/NAzMz7C3wq) / [GitHub](https://github.com/openstenoproject/plover)
* [WhatPulse](https://whatpulse.org/) - Mouse / Keyboard Usage Analyzer
* [Kmonad](https://github.com/kmonad/kmonad) - Keyboard Manager
* [Deskhop](https://github.com/hrvach/deskhop) - Quickly Switch Devices between Computers
* [⁠Deskflow](https://github.com/deskflow/deskflow) - Mouse + Keyboard Sharing
* [Is this good?](https://wiki.keyboard.gay/) - Custom Keyboard Guides
* [DreyMaR's](https://dreymar.colemak.org/) - Keyboard Tips and Resources
* [KDB](http://xahlee.info/kbd/keyboarding.html) - Mechanical Keyboard Building Guides
* [Cosmos](https://ryanis.cool/cosmos/) - Create Custom Keyboards
* [Keyboard Simulator](https://keyboardsimulator.xyz/) - Design & Test Virtual Keyboards

***

## ▷ System Audio

* ↪️ **[Audio Equipment Comparisons](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_audio_equipment)**
* ⭐ **[Equalizer APO](https://sourceforge.net/projects/equalizerapo/)**, [2](https://equalizerapo.com/) / [GUI](https://sourceforge.net/projects/peace-equalizer-apo-extension/) / [7.1 Surround](https://hesuvi.net/) / [Dolby Access](https://apps.microsoft.com/detail/9n0866fs04w8) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/dolby-access-atmos-note.md) or [FXSound](https://www.fxsound.com/) - Audio Equalizers
* ⭐ **[VoiceMeeter](https://vb-audio.com/Voicemeeter/index.htm)** - Audio Mixers / Multi-Device Playback / [Banana](https://vb-audio.com/Voicemeeter/banana.htm)
* ⭐ **[AutoEQ](https://autoeq.app/)**, [⁠EQ By Ear](https://eqbyear.com/) or [⁠PEQdB](https://peqdb.com/) / [Discord](https://discord.gg/B7e8cM76PM) - Create Custom Equalizer Presets
* ⭐ **[AudioRelay](https://audiorelay.net/)** / [Mobile](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_modded_apks) (search), [SnapCast](https://github.com/badaix/snapcast) or [SonoBus](https://sonobus.net/) - Sync Audio Input/Output between Devices
* [⁠IEM EQ Guide](https://iem-eq-guide.pages.dev/) - In-Ear Monitor Equalizer Guide
* [SteelSeries Sonar](https://steelseries.com/gg/sonar) or [noise-suppression-for-voice](https://github.com/werman/noise-suppression-for-voice) - Noise Cancelling Software
* [SoundSwitch](https://soundswitch.aaflalo.me/) - Switch Audio Device with Hotkey / [GitHub](https://github.com/Belphemur/SoundSwitch)
* [Audiocheck](https://www.audiocheck.net/) - Audio Tests
* [SonyHeadphonesClient](https://github.com/mos9527/SonyHeadphonesClient) - Sony Headphones Clone
* [VB-Audio](https://vb-audio.com/Cable/) - Virtual Audio Cable / Select Download on Homepage / Donation is Optional
* [LowAudioLatency](https://github.com/spddl/LowAudioLatency/) - Reduce Audio Latency
* [DigitalFeed](https://abx.digitalfeed.net/) - Lossless Audio Sound System Test
* [Online Mic Test](https://onlinemictest.com/) or [Check Mic](https://webcammictest.com/mic/) - Mic Test
* [Sound Meter](https://mybrowseraddon.com/sound-meter.html) or [REW](https://www.roomeqwizard.com) - Measure Surrounding Sound Level
* [AirPods Dirty Secret](https://docs.kenp.io/) - AirPods Repair Directory

***

# ► Windows ISOs

* ⭐ **[Windows Install / Debloat Guide](https://wispydocs.pages.dev/windows/)**
* ⭐ **[Genuine Installation Media](https://massgrave.dev/genuine-installation-media)** - Windows ISOs / [Clean Install Guide](https://massgrave.dev/clean_install_windows) / [Discord](https://discord.gg/4mFR9y9Snw)
* [files.rg-adguard](https://files.rg-adguard.net/) or [MVS dump](https://awuctl.github.io/mvs/) - Verify ISO Legitimacy
* [OS.click](https://os.click/en) - Windows ISOs
* [MyDigitalLife](https://forums.mydigitallife.net/) - Windows ISOs / Forums
* [Microsoft SD](https://www.microsoft.com/en-us/software-download/) - Windows ISOs / Official Site
* [Old School OS](https://www.oldschoolos.com/), [OS Vault](https://osvault.weebly.com/directory.html), [VETUSWARE](https://vetusware.com/) or [WinWorldPC](https://winworldpc.com/) - Oldschool ISOs
* [Fido](https://github.com/pbatard/Fido) - ISO Powershell Script
* [NetBoot](https://netboot.xyz/) - iPXE Network Boot
* [⁠MrChromebox](https://docs.mrchromebox.tech/), [Chrultrabook](https://docs.chrultrabook.com/) or [CoolStar](https://coolstar.org/chromebook/windows-install.html) - Install Windows / Linux on Chromebook

***

## ▷ USB / Bootloaders

* ⭐ **[Rufus](https://rufus.ie/)** - Create Bootable USB Drives / [GitHub](https://github.com/pbatard/rufus)
* [MediaCreationTool](https://github.com/AveYo/MediaCreationTool.bat) - Windows Deployment Automation
* [USBTreeView](https://www.uwe-sieber.de/usbtreeview_e.html) - USB Device Tree Viewer
* [CloverBootloader](https://github.com/CloverHackyColor/CloverBootloader/) - Bootloaders / [Config](https://mackie100projects.altervista.org/)
* [EtchDroid](https://etchdroid.app/) / [GitHub](https://github.com/etchdroid/etchdroid) or [⁠Ventoid](https://github.com/GPLaider/Ventoid) - Create Bootable USB Drives via Android
* [⁠Grub2Win](https://sourceforge.net/projects/grub2win/) - Windows > Linux Dual-Booting Tool

***

## ▷ Windows Activation

* ⭐ **[MAS](https://rentry.co/FMHYB64#mas)** - Windows & Office Activation / [Subreddit](https://www.reddit.com/r/MAS_Activator) / [X](https://x.com/massgravel) / [Discord](https://discord.gg/4mFR9y9Snw), [2](https://discord.gg/j2yFsV5ZVC) / [GitHub](https://github.com/massgravel/Microsoft-Activation-Scripts)
* [Office Tool Plus](https://rentry.co/FMHYB64#tool-plus) - Office Activation / Version Manager / Deployment / Offline
* [OfficeRTool](https://rentry.co/FMHYB64#officertool-project) - Office Activation / Offline

***

## ▷ Windows Updates

* ⭐ **[Windows 10 After EOL](https://massgrave.dev/windows10_eol)** - Receive Windows Updates After Win10's End-Of-Life / [Discord](https://discord.gg/4mFR9y9Snw)
* ⭐ **[ChangeWindows](https://www.changewindows.org/timeline)** - Latest Windows Update Info
* [VCRedist](https://github.com/abbodi1406/vcredist), [2](https://gitlab.com/stdout12/vcredist), [3](https://codeberg.org/stdout12/vcredist) - AIO Repack for Microsoft Visual C++ Redists
* [LegacyUpdate](https://legacyupdate.net/) - Fix Windows Updates for Legacy Versions / [Discord](https://discord.com/invite/Y9rbXDtDnr) / [GitHub](https://github.com/LegacyUpdate/LegacyUpdate)
* [WURefresh](https://github.com/AveYo/MediaCreationTool.bat/blob/main/bypass11/windows_update_refresh.bat) - Reset Windows Update Components
* [UUP Dump](https://uupdump.net/) or [Microsoft Update Catalog](https://www.catalog.update.microsoft.com/) - Download Previous Windows Updates
* [PC Health Check](https://aka.ms/GetPCHealthCheckApp) or [WhyNotWin11](https://github.com/rcmaehl/WhyNotWin11) - Identify why your PC isn't Ready for Windows 11
* [FlashMyBoard](https://flashmyboard.com/) - Receive Motherboard Update Notifications

***

## ▷ Windows Repair

* [MagNumDB](https://www.magnumdb.com/), [ErrorLookup](https://github.com/henrypp/errorlookup) or [Microsoft Error Lookup](https://learn.microsoft.com/en-us/windows/win32/debug/system-error-code-lookup-tool) - Windows Debugging Tools
* [Troubleshooting Flowcharts](https://www.fonerbooks.com/pcrepair.htm) - PC Troubleshooting Flowcharts
* [Medicat](https://medicatusb.com/) / [GitHub](https://github.com/mon5termatt/medicat_installer), [⁠SergeiStrelec](https://sergeistrelec.name/) or [Hiren's BootCD PE](https://www.hirensbootcd.org/) - WinPE / Recovery Toolkits
* [PhoenixPE](https://github.com/PhoenixPE/PhoenixPE) - WinPE Builder Tool
* [r/TechSupport](https://www.reddit.com/r/techsupport/) / [Wiki](https://rtech.support/) - Tech Support Subreddit / [Discord](https://discord.gg/2EDwzWa)
* [PC Help Hub](https://discord.gg/pchh) - Tech Support Discord
* [Hardforum](https://hardforum.com/), [TechGuy](https://www.techguy.org/), [Eleven Forums](https://www.elevenforum.com/) or [Ten Forums](https://www.tenforums.com/) - Tech Support Forums

***

# ► Customization

* 🌐 **[Frutiger Aero Archive](https://frutigeraeroarchive.org/)** or [Heliohost Guide](https://ninjasr.varesia.com/w/lb/windows) - Windows Customization Resources
* ⭐ **[Rainmeter](https://www.rainmeter.net/)** / [Discord](https://discord.com/invite/rainmeter) or [⁠Seelen UI](https://github.com/eythaann/Seelen-UI) / [Discord](https://discord.gg/ABfASx5ZAJ) - Desktop Customization Environments
* ⭐ **[OpenRGB](https://openrgb.org/)**, **[WLED](https://kno.wled.ge/)**, [Aurora](https://www.project-aurora.com/), [LiquidCTL](https://github.com/liquidctl/liquidctl), [Artemis](https://artemis-rgb.com/) or [FireLight](https://github.com/nicolasdeory/firelight) - RGB Lighting Control
* ⭐ **[VSThemes](https://vsthemes.org/en/)**, [WindowsCustomization](https://windowscustomization.com/) or [7Themes](https://7themes.su/) - Theme Collections
* Styled Themes - [Anime](https://winmoes.com/) / [Modern Style](https://www.vinstartheme.com/) / [macOS Style](https://redd.it/pd5ha6) / [Old School Style](https://winclassic.boards.net/), [2](https://forum.spacehey.com/topic?id=94545)
* [VirtualCustoms](https://virtualcustoms.net/), [⁠WinClassic](https://winclassic.net/) or [winthemers](https://discord.com/invite/8FFWAqdtc4) - Customization Communities
* [Desktops](https://deskto.ps/) - Customization Showcases
* [⁠ExplorerPatcher](https://github.com/valinet/ExplorerPatcher) - Win 10 Style Customization App for Win 11
* [SecureUxTheme](https://github.com/namazso/SecureUxTheme) or [UltraUXThemePatcher](https://mhoefs.eu/software_uxtheme.php?ref=syssel&lang=en) - UX Patcher
* [MechvibesDX](https://github.com/hainguyents13/mechvibes-dx) or [MechaKeys](https://mechakeys.robolab.io/) - Keyboard Sound Effects
* [ElectricSheep](https://electricsheep.org/) or [After Dark CSS](https://www.bryanbraun.com/after-dark-css/) - Screensavers
* [⁠Wallpapers Clan](https://wallpapers-clan.com/), [FolderMarker](https://foldermarker.com/), [Flaired Folder](https://www.flaredfolders.com/) or [CustomFolder](https://www.gdzsoft.com/) - Custom Folder Icons
* [Recycle Bin Themes](https://github.com/sdushantha/recycle-bin-themes) - Custom Recycle Bin Icons
* [msstyleEditor](https://github.com/nptr/msstyleEditor) - Visual Style Editor
* [Taskbar Tweaker](https://tweaker.ramensoftware.com/), [TranslucentTB](https://github.com/TranslucentTB/TranslucentTB) / [Discord](https://discord.gg/translucenttb), [NiceTaskbar](https://www.microsoft.com/en-us/p/nicetaskbar/9pkl2s93xwb5) - Taskbar Customization / [Old School Style](https://github.com/dremin/RetroBar)
* [⁠Sweezy Cursors](https://sweezy-cursors.com/) - Custom Animated Cursors / Requires no Extension
* [AccentColorizer](https://github.com/krlvm/AccentColorizer) - Accent Color Customization
* [BeautySearch](https://github.com/krlvm/BeautySearch) - Search Customization
* [ElevenClock](https://www.marticliment.com/elevenclock/) - Clock Customization
* [HackBGRT](https://github.com/Metabolix/HackBGRT) - Boot Logo Changer
* [ExplorerBlurMica](https://github.com/Maplespe/ExplorerBlurMica) - File Explorer Effects
* [QTTabBar](https://github.com/indiff/qttabbar) - Windows File Explorer Enhancement
* [WinSetView](https://lesferch.github.io/WinSetView/) - Globally Set Explorer Folder Views / [GitHub](https://github.com/LesFerch/WinSetView)
* [MicaForEveryone](https://github.com/MicaForEveryone/MicaForEveryone) - Title Bar Effects
* [FluentFlyout](https://fluentflyout.com/) / [GitHub](https://github.com/unchihugo/FluentFlyout) (use github) or [ModernFlyouts](https://modernflyouts-community.github.io) - Modernized Flyout Menus
* [Alternative Windows Shells Wiki](https://wikipedia.org/wiki/List_of_alternative_shells_for_Windows) - Alt Windows Shells
* [Aerial](https://github.com/OrangeJedi/Aerial) - Apple TV Screensaver
* [ExcelDarkThemeFix](https://github.com/matafokka/ExcelDarkThemeFix) - Fix Excel on Themed Windows
* [⁠FontWizard](https://github.com/karnyadavdev/FontWizard) - Change Windows System Fonts
* [MacType](https://www.mactype.net/) - macOS Style System Font for Windows / [GitHub](https://github.com/snowie2000/mactype)

***

## ▷ App Themes

* ⭐ **[Catppuccin](https://catppuccin.com/)** - Custom App Theme / [Discord](https://discord.gg/r6Mdz5dpFc)
* ⭐ **[Dracula](https://draculatheme.com/)** - Custom App Theme / [Discord](https://discord.com/invite/yDcFsrYuq9)
* [Rosé Pine](https://rosepinetheme.com/) - Custom App Theme
* [Aura Theme](https://github.com/daltonmenezes/aura-theme) - Custom App Theme
* [theme.park](https://theme-park.dev/) - Custom App Theme
* [⁠Tokyo Night](https://tokyonight.org/) - Custom App Theme
* [gruvbox](https://github.com/morhetz/gruvbox) - Custom App Theme / [GitHub](https://github.com/morhetz/gruvbox-contrib)
* [⁠Flexoki](https://stephango.com/flexoki/) - Custom App Theme / [GitHub](https://github.com/kepano/flexoki)
* [Totally Awesome List](https://forum.spacehey.com/topic?id=94545) - Old School App Themes
* [Pokemon Terminal](https://github.com/LazoCoder/Pokemon-Terminal) - Pokémon Terminal Themes
* [Traffic Monitor](https://github.com/zhongyang219/TrafficMonitor/) - System Monitor Themes
* [terminal.sexy](https://terminal.sexy/), [TerminalSplash](https://terminalsplash.com/) or [WindowsTerminalThemes](https://windowsterminalthemes.dev/) - Terminal Themes

***

## ▷ Wallpapers

* 🌐 **[WallSync](https://roigoatzzz.netlify.app/)**, [2](https://wallsync.pages.dev/) - Wallpaper Site Index / [GitHub](https://github.com/leroiduflow/Wallsync)
* ⭐ **[wallhaven.cc](https://wallhaven.cc/)** - Search Wallpapers / Some NSFW / [Downloader](https://github.com/eramdam/WallbaseDirectDownloader)
* ⭐ **[⁠WallWidgy](https://www.wallwidgy.app/)** / [GitHub](https://github.com/not-ayan/wallwidgy), [Simple Desktops](https://simpledesktops.com/) or [Minimalistic Wallpaper](https://minimalistic-wallpaper.demolab.com/) - Minimalist Wallpapers
* ⭐ **[Studio Ghibli Wallpapers](https://www.ghibli.jp/info/013772)** - Studio Ghibli Wallpapers
* ⭐ **[LWP](https://github.com/jszczerbinsky/lwp)**, [DesktopHut](https://www.desktophut.com/) / [Discord](https://discord.com/invite/QzgnQtJdfs), [r/LivingBackgrounds](https://reddit.com/r/LivingBackgrounds), [WALLegend](https://wallegend.net/en/) or [MoeWalls](https://moewalls.com/) - Live Wallpapers
* [WallpaperCave](https://wallpapercave.com/) - Search Wallpapers
* [⁠WallsCloud](https://wallscloud.net/en/) - Search Wallpapers
* [WallpapersCraft](https://wallpaperscraft.com/) - Search Wallpapers
* [⁠WallBrowser](https://wallbrowser.com/) - Search Wallpapers
* [VSThemes](https://vsthemes.org/en/) - Search Wallpapers
* [⁠Wallpapers Clan](https://wallpapers-clan.com/) - Search Wallpapers
* [Wallpaper Abyss](https://wall.alphacoders.com/) - Search Wallpapers
* [r/Wallpaper](https://www.reddit.com/r/wallpaper/) - Wallpapers Subreddit
* [r/WallpaperRequests](https://www.reddit.com/r/WallpaperRequests/) - Wallpaper Request Subreddit
* [Perfect Hue](https://perfecthue.com/) - Hand-Made Frutiger Aero Wallpapers ⁠Perfect
* [Frutiger Aero Archive](https://frutigeraeroarchive.org/) - 2000s Style Wallpapers
* [Basic Apple Guy](https://basicappleguy.com/basicappleblog/category/Wallpaper) / [2](https://basicappleguy.com/haberdashery/category/Wallpaper) - Apple Wallpaper Interpretations
* [⁠WSupercars](https://www.wsupercars.com/) - Car Wallpapers
* [⁠Kawaii Hoshi](https://kawaiihoshi.com/) - Cute Wallpapers
* [4K Wallpapers](https://4kwallpapers.com/) - High Resolution Wallpapers
* [DualMonitorBackgrounds](https://www.dualmonitorbackgrounds.com/) - Dual Monitor Wallpapers
* [CoolBackgrounds](https://coolbackgrounds.io/) - Customizable Wallpapers
* [Aesthetic Wallpapers](https://github.com/D3Ext/aesthetic-wallpapers) - Aesthetic Wallpapers
* [Xbox Wallpapers](https://www.xbox.com/en-us/wallpapers/) - Xbox Wallpapers
* [Mandelnaut](https://techmatt.github.io/fractals/explorer/) - Fractal Wallpaper Generator
* [Anime Pictures](https://anime-pictures.net/), [WallpaperWaifu](https://wallpaperwaifu.com/) or [MyLiveWallpapers](https://mylivewallpapers.com/) - Anime Wallpapers
* [WallsPic](https://wallspic.com/), [WallpaperFlare](https://www.wallpaperflare.com/), [HDQwalls](https://hdqwalls.com/) or [UHD Wallpaper](https://www.uhdpaper.com/) - Misc Wallpapers
* [G_Walls](https://t.me/G_Walls) - Telegram Wallpaper Channels
* [Engine Workshop File](https://discord.com/invite/KMbdezWjKY) - Wallpaper Engine Wallpapers

***

## ▷ Wallpaper Tools

* ⭐ **[Wallpaper Engine](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/games/#wiki_.25BA_download_games)** / [2](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent/) (search) - Wallpaper / Live Wallpaper Manager
* ⭐ **Wallpaper Engine Tools** - [PKG to Zip](https://github.com/TheRioMiner/Wallpaper-Engine-Pkg-to-Zip) / [Collections](https://www.wallpaperengine.space/collections), [2](https://steamcommunity.com/sharedfiles/filedetails/?id=2801058904)
* ⭐ **[Lively](https://www.rocksdanister.com/lively/)** / [GitHub](https://github.com/rocksdanister/lively) or [ScreenPlay](https://screen-play.app/) - Live Wallpaper Manager
* [backiee](https://apps.microsoft.com/store/detail/backiee-wallpaper-studio-10/9WZDNCRFHZCD) - Wallpaper Manager
* [SuperPaper](https://github.com/hhannine/superpaper) - Cross-Platform Multi-Monitor Wallpaper Manager
* [Wallhaven Slideshow](https://github.com/nitishengineer/Wallhaven-Slideshow), [Background Switcher](https://johnsad.ventures/software/backgroundswitcher/), [WinDynamicDesktop](https://github.com/t1m0thyj/WinDynamicDesktop) or [Dynamic Theme](https://apps.microsoft.com/detail/9nblggh1zbkw) - Wallpaper Slideshow / Auto-Change Apps
* [AutoWall](https://github.com/SegoCode/AutoWall) - Turn Videos / GIFs to Live Wallpapers
* [Awesome Wallpaper](https://awesome-wallpaper.com/) - Show System Information on Wallpaper
* [GoWall](https://github.com/Achno/gowall) - Wallpaper Color Scheme Converter