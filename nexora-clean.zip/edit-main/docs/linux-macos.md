***
***
**[◄◄ Back to Wiki Index](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/index)**
***
***

# ► Linux Guides

* **Note** - Keep in mind that install guides can usually be found on each distro's doc page. You can find doc pages on each distro's site, or through their [DistroWatch](https://distrowatch.com/dwres.php?resource=popularity) pages.

***

* ⭐ **[ArchWiki](https://wiki.archlinux.org/)** - Linux Guides / [Manuals](https://man.archlinux.org/)
* [Linux Journey](https://labex.io/linuxjourney) or [Tilde](https://tilde.club/) - Interactive Linux Guides
* [HowToLinux](https://howtolinux.vercel.app) - Linux Desktop Guides
* [⁠tony, btw](https://tonybtw.com/) - Linux Tutorials / Guides / [Discord](https://discord.gg/nXZwDb8HB5)
* [Linuxtopia](https://www.linuxtopia.org/) - Linux Guides
* [Linux Roadmap](https://roadmap.sh/linux) - Linux Learning Roadmap
* [Erik Dubois](https://www.youtube.com/c/ErikDubois) - Arch-centric Linux Video Tutorials
* [Gentoo Wiki](https://wiki.gentoo.org/wiki/Main_Page) - Gentoo Wikis / Guides
* [Debian Wiki](https://wiki.debian.org/) - Debian Wiki / Guides
* [⁠Fedora Noble Guide](https://github.com/wz790/Fedora-Noble-Setup) - Fedora Setup Guide
* [Zero to Nix](https://zero-to-nix.com/) - Nix Learning Guide
* [Vim Tutorials](https://www.youtube.com/playlist?list=PL3cu45aM3C2DJVGfCjSBB1yD9YkC7q27-) - Vim Tutorial Playlist by Mental Outlaw
* [⁠Wikiman](https://github.com/filiparag/wikiman) - Offline Linux Documentation Search

***

## ▷ CLI Cheat Sheets

* ⭐ **[Linux Command Library](https://linuxcommandlibrary.com/)** - Searchable Linux Command Index / [GitHub](https://github.com/SimonSchubert/LinuxCommandLibrary)
* [Awesome for One Liner](https://github.com/sheepla/awesome-for-oneliner) - Curated One-Liner CLI Tools
* [You Don't Need GUI](https://github.com/you-dont-need/You-Dont-Need-GUI) - CLI Alts for GUI Tasks
* [CommandlineFU](https://www.commandlinefu.com/) - Community-Driven Command Snippets
* [cheat.sh](https://github.com/chubin/cheat.sh) - Terminal Commands
* [Bash Academy](https://guide.bash.academy/) - Bash Scripting Guide
* [ss64 Bash](https://ss64.com/bash/) - Alphabetical Command Reference
* [Bash Oneliner](https://onceupon.github.io/Bash-Oneliner/) - Bash One-Liner Collection
* [navi](https://github.com/denisidoro/navi) - Interactive Cheatsheet Tool

***

# ► Linux Communities

* **Note** - Keep in mind it's usually best to seek specific forums for your Distro if you need help with them.

***

* [LinuxQuestions](https://www.linuxquestions.org/questions/) - Linux Q&A Forum
* [Linux.Chat](https://discord.gg/linuxchat) - Linux Discord Server
* [Linux x Technology](https://linuxdiscord.com/) - Linux Discord Server
* [⁠Neon Genesis Linux](https://discord.gg/nglinux) - Linux Discord Server
* [Discord-Linux](https://discord.gg/discord-linux) - Linux Discord Server
* [Arch Linux Community](https://discord.gg/3m6dbPR) - Arch Discord Server / [Fluxer](https://fluxer.gg/mb4B39fZ)
* [Debian Community](https://discord.gg/debian) or [r/debian](https://www.reddit.com/r/debian/) - Debian Discord Server + Subreddit / [Fluxer](https://fluxer.gg/debian)
* [⁠Fedora Linux](https://discord.gg/fedora) - Fedora Discord Server
* [Linux.org](https://linux.org/) - Linux Forum / Invite Required for Account
* [Arch Forums](https://bbs.archlinux.org/) - Linux Forum
* [Gentoo Forums](https://forums.gentoo.org/) - Linux Forum
* [⁠phoronix](https://www.phoronix.com/forums/) - Linux Forum

***

# ► Linux Distros

* **Note** - We don't curate individual distros ourselves as we feel the indexes listed are good enough to stand on their own. Keep in mind that install guides can usually be found on each distro's doc page. You can find doc pages on each distro's site, or through their [DistroWatch](https://distrowatch.com/dwres.php?resource=popularity) pages.

***

* 🌐 **[DistroWatch](https://distrowatch.com/dwres.php?resource=popularity)** - Distro Index w/ News + Rankings / [Advanced Search](https://distrowatch.com/search.php#advanced)
* ⭐ **[DistroChooser](https://distrochooser.de/)** / [Beta](https://beta.distrochooser.de/) / [Discord](https://discord.com/invite/aDkCutfqak) / [GitHub](https://github.com/distrochooser/distrochooser) or [⁠Distro Fighter](https://distrofighter.com/) - Quiz-Based Distro Selectors
* [Linux Live Kit](https://www.linux-live.org/) - Create Live Distros from Installed Systems
* [OpenSourceFeed](https://www.opensourcefeed.org/) - Open-Source Distros
* [OS.click](https://os.click/en) - Fast Distro Downloads
* [LinuxTracker](https://linuxtracker.org/) - BitTorrent Distro Repo
* [Linux Comparisons](https://eylenburg.github.io/linux_comparison.htm) - Detailed Distro Comparison Charts
* [ArchiveOS](https://archiveos.org/) - Inactive / Open-Source OS Projects
* [DistroSea](https://distrosea.com/) - Test Distros / Cloud Virtual Machine / Allows Browsers

***

# ► Linux Apps

* 🌐 **[GNOME Shell Extensions](https://extensions.gnome.org/)**
* ↪️ **[Multi-Platform Readers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/reading/#wiki_.25B7_ebook_readers)** - Ebook Reader Index
* ↪️ **[Office Suites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools#wiki_.25B7_office_suites)**
* ⭐ **[Bottles](https://usebottles.com/)** - Manage Wine containers / [Discord](https://discord.com/invite/wF4JAdYrTR) / [GitHub](https://github.com/bottlesdevs/Bottles)
* ⭐ **[WineHQ](https://appdb.winehq.org/)** - Wine Compatibility Database
* ⭐ **[Q4Wine](https://sourceforge.net/projects/q4wine/)** - Wine GUI
* ⭐ **[AppImageLauncher](https://github.com/TheAssassin/AppImageLauncher)**, [GearLever](https://github.com/mijorus/gearlever) or [⁠AppManager](https://github.com/kem-a/AppManager) - Integrate AppImages to App Launchers
* ⭐ **[winetricks](https://github.com/Winetricks/winetricks)** - Wine Fixes
* ⭐ **[Vicinae](https://www.vicinae.com/)** / [GitHub](https://github.com/vicinaehq/vicinae), **[rofi](https://davatorium.github.io/rofi/)** / [Emoji Selector](https://github.com/Mange/rofi-emoji), [Fuzzel](https://codeberg.org/dnkl/fuzzel), [Ulauncher](https://ulauncher.io/) or [wofi](https://hg.sr.ht/~scoopta/wofi) - App Launchers / Keystroke Launchers
* ⭐ **[FreeRDP](https://www.freerdp.com/)** / [GitHub](https://github.com/FreeRDP/FreeRDP), [⁠Remmina](https://remmina.org/) or [⁠Apache Guacamole](https://guacamole.apache.org/) - Remote Desktop Clients
* ⭐ **[shell_gpt](https://github.com/TheR1D/shell_gpt)** or [shellgpt](https://github.com/jiacai2050/my-works/tree/main/shellgpt) - AI Terminal Chatbot / GPT
* [Darling](https://www.darlinghq.org/) - Run macOS Apps on Linux / [Discord](https://discord.com/invite/XRD3mQA) / [GitHub](https://github.com/darlinghq/darling)
* [innoextract](https://constexpr.org/innoextract/) - Windows Installer Unpacker / [GitHub](https://github.com/dscharrer/innoextract)
* [Autokey](https://autokey.github.io/index.html) - Linux Automation Utility / [GitHub](https://github.com/autokey/autokey)
* [ProtonTricks](https://github.com/Matoking/protontricks) - Run Winetricks Commands for Steam Play / Proton Games
* [Touchégg](https://github.com/JoseExposito/touchegg) - Multi-Touch Gesture Recognizer
* [⁠Neutron](https://neutronproject.org/) - Adobe Compatibility Engine
* [Ghostwriter](https://ghostwriter.kde.org/) or [Remarkable](https://remarkableapp.github.io/) - Markdown Editor
* [taskbook](https://github.com/klaudiosinani/taskbook) or [nb](https://xwmx.github.io/nb) / [GitHub](https://github.com/xwmx/nb) - Note Apps
* [Featherpad](https://github.com/tsujan/FeatherPad) or [gedit](https://gedit-text-editor.org/) - Text Editors
* [Kate Editor](https://kate-editor.org/) - Source Code Editor
* [TextPieces](https://gitlab.com/liferooter/textpieces) - Quick Text Transformations
* [clipboard-history](https://github.com/SUPERCILEX/clipboard-history) - Clipboard Manager
* [Durdraw](https://durdraw.org/) - ASCII Editor
* [ly](https://github.com/fairyglade/ly) - Display Manager with Console UI
* [GammaStep](https://gitlab.com/chinstrap/gammastep) - Adjust Screen Temperature
* [Weylus](https://github.com/H-M-H/Weylus) - Use Mobile Device as Trackpad
* [AudioSource](https://github.com/gdzx/audiosource) - Use Mobile Device as Microphone
* [Alpaca](https://jeffser.com/alpaca/) - Run LLMs on Linux
* [nyrna](https://nyrna.merritt.codes) - Suspend Apps / Games
* [Solaar](https://github.com/pwr-Solaar/Solaar) - Logitech Device Manager
* [bluetuith](https://github.com/darkhz/bluetuith) - Bluetooth Manager
* [libimobiledevice](https://libimobiledevice.org) - Communicate with iOS Devices
* [Linux-PowerToys](https://github.com/domferr/Linux-PowerToys) - PowerToys for Linux
* [Railway](https://flathub.org/apps/de.schmidhuberj.DieBahn) - Travel Info Manager
* [Wike](https://github.com/hugolabe/Wike) - Wikipedia App
* [Komikku](https://flathub.org/en/apps/info.febvre.Komikku), [Suwayomi-VaadinUI](https://github.com/Suwayomi/Suwayomi-VaadinUI) or [Manga Reader](https://flathub.org/apps/com.georgefb.mangareader) - Manga Readers
* [Mako](https://github.com/emersion/mako) or [dunst](https://dunst-project.org/) / [GitHub](https://github.com/dunst-project/dunst) - Customizable Notification Daemon
* [Eloquent](https://github.com/sonnyp/Eloquent) or [DidYouMean](https://github.com/hisbaan/didyoumean) - Grammar Check Apps
* [KTouch](https://apps.kde.org/ktouch/) or [typer](https://github.com/maaslalani/typer) - Typing Practice

***

## ▷ Software Sites

* 🌐 **[ArchWiki App Sites](https://wiki.archlinux.org/title/List_of_applications)** or **[Ultimate Cheatsheet](https://gist.github.com/bgoonz/be5c5be77169ef333b431bc37d331176)** - Linux Software / Site Index
* 🌐 **[Awesome Linux Software](https://luong-komorebi.github.io/Awesome-Linux-Software/)** - FOSS Linux Software
* 🌐 **[Awesome KDE](https://github.com/francoism90/awesome-kde)** - FOSS KDE Software
* 🌐 **[Awesome GNOME](https://github.com/Kazhnuz/awesome-gnome)** - FOSS GNOME Software
* 🌐 **[FOSS Software Packages](https://wikipedia.org/wiki/List_of_free_and_open-source_software_packages)** - FOSS Software Packages Index
* ⭐ **[Kapital Sin](https://www.kapitalsin.com/forum/index.php?board=5.0)** - Linux Software / Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators)
* ⭐ **[The Book of Secret Knowledge](https://github.com/trimstray/the-book-of-secret-knowledge)**
* ⭐ **[Linux Software CSE](https://cse.google.com/cse?cx=81bd91729fe2a412b)** - Multi-Site Software Search
* [⁠TuxMate](https://tuxmate.com/) - Bulk App Installer / [GitHub](https://github.com/abusoww/tuxmate)
* [Awesome Linux Minimalism](https://github.com/MindPatch/awesome-linux-minimalism) - FOSS Software
* [FOSS Torrents](https://fosstorrents.com/) - FOSS Software Torrents
* [Open Source Linux Programs](https://files.catbox.moe/o99qyz.jpg) - FOSS Software Chart
* [RUTracker Linux](https://rutracker.org/forum/viewforum.php?f=1376) - Linux Software
* [Rim's Linux Wiki](https://rlw.pages.dev/), [2](https://rimswiki.xyz/) - Linux Software / Tool Index / [Discord](https://discord.gg/pQVYgjzM3w)
* [KDE Applications](https://apps.kde.org/) or [KDE Store](https://store.kde.org/browse/) - KDE Apps & Themes
* [Flatpak](https://flatpak.org/) - Sandboxed Package Manager / [Manage Permissions](https://github.com/tchx84/flatseal)
* [SnapCraft](https://snapcraft.io/store) - Snap Repository
* [Nix](https://nixos.org/) / [Resources](https://github.com/nix-community/awesome-nix), [⁠Shelly](https://www.seafoam-labs.org/shelly-alpm), [pkgx](https://github.com/pkgxdev/pkgx) or [Homebrew](https://brew.sh/) / [GUI](https://github.com/Homebrew/BrewUI), [2](https://github.com/buresdv/Cork/) / [Casks GUI](https://github.com/alielsokary/CaskHub) / [X](https://x.com/MacHomebrew) - Package Managers
* [Nala](https://gitlab.com/volian/nala), [apt-fast](https://github.com/ilikenwf/apt-fast) or [APTUI](https://github.com/mexirica/aptui) - TUI Frontends for APT Package Manager
* [AM](https://github.com/ivan-hc/AM) - App Image Managers
* [Pkgs](https://pkgs.org/) - Searchable Linux Package Database
* [AppImageHub](https://www.appimagehub.com/) / [GUI](https://github.com/prateekmedia/appimagepool), [AppImages](https://appimage.github.io/) or [Get AppImage](https://g.srev.in/get-appimage/) - Download AppImages
* [Apps for GNOME](https://apps.gnome.org/) - GNOME Apps
* [emplace](https://codeberg.org/fosk/emplace) - System Package Sync
* [WTAKO AUR Audit](https://wtako.net/services/aur-audit) - AUR Package Audits
* [⁠Chaotic-AUR](https://aur.chaotic.cx/) - Automated Pre-Built AUR Packages
* [Pacstall](https://pacstall.dev/) - AUR-Inspired Package Manager for Ubuntu

***

## ▷ Linux System

* 🌐 **[Hardware for Linux](https://linux-hardware.org/)** - Linux Hardware Compatibility Database / [GitHub](https://github.com/linuxhw/)
* 🌐 **[Awesome Fetch](https://beucismis.github.io/awesome-fetch/)** - Command-Line Fetch Tool (System Info) Index / [GitHub](https://github.com/beucismis/awesome-fetch)
* ⭐ **[Btop](https://github.com/aristocratos/btop)** or [s-tui](https://github.com/amanusk/s-tui) - System Resource Monitors
* ⭐ **[MangoHud](https://github.com/flightlessmango/MangoHud)** - System Resource Monitor Overlay / [GUI](https://github.com/radiolamp/mangojuice)
* ⭐ **[⁠LACT](https://github.com/ilya-zlobintsev/LACT/)** - GPU Config + Monitor
* ⭐ **[fastfetch](https://github.com/fastfetch-cli/fastfetch)**, [Archey4](https://github.com/HorlogeSkynet/archey4), [Anifetch](https://github.com/Notenlish/anifetch), [Hyfetch](https://github.com/hykilpikonna/hyfetch) or [Macchina](https://github.com/Macchina-CLI/macchina) - System Info Displays / Fetch Tools
* ⭐ **[TimeShift](https://github.com/linuxmint/timeshift)** or [⁠Snapper](https://github.com/openSUSE/snapper) - System Restore / Backup / Snapshots
* [Impression](https://gitlab.com/adhami3310/Impression) or [Caligula](https://github.com/ifd3f/caligula) - Create Bootable USB Linux Drives
* [anuraOS](https://github.com/MercuryWorkshop/anuraOS) / [Instance](https://anura.pro/) - Linux Browser Emulator
* [SysmonForLinux](https://github.com/microsoft/SysmonForLinux) - Monitor / Log System Activity
* [htop](https://htop.dev/) or [Zenith](https://github.com/bvaisvil/zenith) - Interactive Process Viewers
* [CoolerControl](https://docs.coolercontrol.org/) - Cooling Device Monitor / Linux / [Discord](https://discord.gg/MbcgUFAfhV) / [GitLab](https://gitlab.com/coolercontrol/coolercontrol)
* [⁠TuxManager](https://github.com/benapetr/TuxManager) - Task Manager
* [screenFetch](https://github.com/KittyKatt/screenFetch) - Bash Screenshot Information Tool
* [Nanobench](https://github.com/andreas-abel/nanoBench) - CPU Microbenchmark / [Documentation](https://nanobench.ankerl.com/)
* [ScanMem](https://github.com/scanmem/scanmem) - Memory Scanner / Debugger
* [pacwall](https://github.com/Kharacternyk/pacwall) - Live Wallpaper Dependency Graph / Package Status
* [keyd](https://github.com/rvaiya/keyd) or [xremap](https://github.com/xremap/xremap) - Keyboard Remapping
* [LAN Mouse](https://github.com/feschber/lan-mouse) - Mouse & Keyboard Sharing
* [auto-cpufreq](https://github.com/AdnanHodzic/auto-cpufreq) - CPU Speed & Power Optimization Automation
* [Fan Control](https://github.com/wiiznokes/fan-control) - Fan Controller
* [⁠WinApps](https://github.com/winapps-org/winapps) - Run Windows Apps on Linux
* [Teleport](https://teleportsite.pages.dev/) - Windows App Compatibility Analyzer
* [NetBoot](https://netboot.xyz/) - iPXE Network Boot
* [CloverBootloader](https://github.com/CloverHackyColor/CloverBootloader/) - Windows, Mac & Linux Bootloader / [Config](https://mackie100projects.altervista.org/)
* [zfsBootMenu](https://docs.zfsbootmenu.org/) - ZFS Bootloader
* [coreboot](https://coreboot.org/), [Heads](https://osresearch.net/) / [GitHub](https://github.com/linuxboot/heads), [⁠Canoeboot](https://canoeboot.org/) or [Libreboot](https://libreboot.org/) - Replace Proprietary BIOS/UEFI Firmware
* [GParted](https://gparted.org/) - Partition Manager
* [CoreELEC](https://coreelec.org) / [GitHub](https://github.com/CoreELEC/CoreELEC) or [LibreELEC](https://libreelec.tv/) / [GitHub](https://github.com/LibreELEC/LibreELEC.tv) - Kodi-Based Operating System
* [Linux-KVM](https://www.linux-kvm.org/page/Downloads) - Virtualization Kernel module
* [WebVM](https://webvm.io/) - Browser Virtual Machine / [Discord](https://discord.gg/yTNZgySKGa) / [GitHub](https://github.com/leaningtech/webvm)
* [OSX-KVM](https://github.com/kholia/OSX-KVM), [OneClick-macOS-Simple-KVM](https://oneclick-macos-simple-kvm.notaperson535.is-a.dev/) or [macOS-Simple-KVM](https://github.com/foxlet/macOS-Simple-KVM) - macOS Virtual Machines
* [kmon](https://kmon.cli.rs/) - Kernel Manager and Activity Monitor
* [Kernel Map](https://makelinux.github.io/kernel/map/) - Interactive Linux Kernel Map
* [KernelNewbies](https://kernelnewbies.org/) - Kernel Developer Guides
* [SystemRescue](https://www.system-rescue.org/) or [Super Grub2 Disk](https://www.supergrubdisk.org/super-grub2-disk/) - Bootable System Rescue Toolkits
* [bt-dualboot](https://github.com/x2es/bt-dualboot) - Dual-Boot Bluetooth Sync Tool
* [open-gpu-kernel-modules](https://github.com/NVIDIA/open-gpu-kernel-modules) - NVIDIA Linux Open GPU Kernel Module
* [G-Helper Linux](https://github.com/utajum/g-helper-linux) - Armoury Crate Replacement for ASUS Laptops
* [systemctl-tui](https://github.com/rgwood/systemctl-tui) - TUI for systemd
* [nosystemd](https://nosystemd.org/) or [⁠Init Freedom](https://www.devuan.org/os/init-freedom) - Alternatives to systemd
* [greetd](https://sr.ht/~kennylevinsen/greetd/) - Login Manager Daemon

***

## ▷ Linux Video

* ↪️ **[Streaming Apps](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25BA_streaming_apps)** / **[Torrent Streaming](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25BA_streaming_apps)**
* ↪️ **[Media Servers / Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video-tools#wiki_.25BA_media_servers)**
* ⭐ **[mpv](https://mpv.io/)** or [VLC](https://www.videolan.org/) - Video Players
* ⭐ **[Haruna](https://apps.kde.org/haruna/)** / [GitHub](https://github.com/KDE/haruna), **[Celluloid](https://github.com/celluloid-player/celluloid)** or [Cine](https://flathub.org/apps/io.github.diegopvlk.Cine) - MPV Frontends
* ⭐ **[Kdenlive](https://apps.kde.org/kdenlive/)** / [GitHub](https://github.com/KDE/kdenlive), [Shrimply](https://github.com/soirihiroka/shrimply), [Pitivi](https://www.pitivi.org/), [⁠davincibox](https://github.com/zelikos/davincibox) or [Flowblade](https://jliljebl.github.io/flowblade/) / [GitHub](https://github.com/jliljebl/flowblade) - Video Editors
* [MultiPlex](https://github.com/pojntfx/multiplex) - Torrent Watch Party / Use [VPN](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_vpn)
* [MPV Shim](https://github.com/iwalton3/plex-mpv-shim) - Cast Plex to MPV
* [Gromit MPX](https://github.com/bk138/gromit-mpx) - Screen Annotation
* [⁠Spectacle](https://apps.kde.org/spectacle/) or [GPU Screen Recorder](https://github.com/BrycensRanch/gpu-screen-recorder-git-copr) - Screen Recorders
* [AV Linux](https://www.bandshed.net/avlinux/) - Video / Audio Editor
* [REAL Video Enhancer](https://github.com/TNTwise/REAL-Video-Enhancer) - Video Upscaling / [Discord](https://discord.com/invite/mRReVBMQtN)
* [4KTUBE](https://github.com/rishabh3354/4KTUBE-MEDIA-DOWNLOADER) or [Video Downloader](https://github.com/Unrud/video-downloader) - Video Downloaders
* [Linux-Fake-Background-Webcam](https://github.com/fangfufu/Linux-Fake-Background-Webcam/) - Fake Webcam Background
* [Trackma](https://github.com/z411/trackma/) - Anime Tracking App
* [LiveCaptions](https://github.com/abb128/LiveCaptions) - Real-Time Captions

***

## ▷ Linux Audio

* 🌐 **[Awesome Linux Audio](https://gitlab.com/nodiscc/awesome-linuxaudio)** - Live Audio Resources
* ⭐ **[SpotX-Bash](https://github.com/SpotX-Official/SpotX-Bash)** or [spotify-adblock](https://github.com/abba23/spotify-adblock) - Spotify Adblockers
* ⭐ **[Spicetify](https://spicetify.app/)** - Spotify Themes & Plugins / [Improved Lyrics](https://spicylyrics.org/) / [Discord](https://discord.gg/VnevqPp2Rr) / [GitHub](https://github.com/spicetify/cli) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/spicetify-note.md)
* ⭐ **[Shortwave](https://flathub.org/en/apps/de.haeckerfelix.Shortwave)** / [GitLab](https://gitlab.gnome.org/World/Shortwave) or [QMPlay2](https://github.com/zaps166/QMPlay2) - Radio Players
* ⭐ **[SongRec](https://songrec.fossplant.re/)** / [GitHub](https://github.com/marin-m/SongRec) or [Mousai](https://github.com/SeaDve/Mousai) - Song Identifiers
* ⭐ **[⁠LibrePods](https://github.com/kavishdevar/librepods)** - Use AirPod Features on Linux
* [puddletag](https://docs.puddletag.net/) - Metadata Organizer / [GitHub](https://github.com/puddletag/puddletag)
* [Tidal Hi-Fi](https://github.com/Mastermindzh/tidal-hifi) - Hi-Fi Tidal Player
* [⁠tuifi](https://git.sr.ht/~matf/tuifi) - Terminal Audio Player for Hi-Fi Tidal
* [BeatBoss](https://beatboss.thevolecitor.qzz.io/) - Plugin-Based Streaming / [Discord](https://discord.gg/85jnfZGfV5) / [GitHub](https://github.com/TheVolecitor/BeatBoss)
* [cmus](https://cmus.github.io/) - Audio Player
* [Tauon Music Box](https://tauonmusicbox.rocks/) - Audio Player / [Discord](https://discord.com/invite/v4EmhES) / [GitHub](https://github.com/Taiko2k/Tauon)
* [Lollypop](https://gitlab.gnome.org/World/lollypop) - Audio Player
* [Audacious](https://audacious-media-player.org/) - Audio Player / [GitHub](https://github.com/audacious-media-player)
* [Amberol](https://gitlab.gnome.org/World/amberol) - Audio Player
* [Gapless](https://gitlab.gnome.org/neithern/g4music) - Audio Player
* [dopamine](https://github.com/digimezzo/dopamine) - Audio Player
* [AudioTube](https://invent.kde.org/multimedia/audiotube), [ytermusic](https://github.com/ccgauche/ytermusic/), [⁠Mixtapes](https://github.com/m-obeid/Mixtapes) or [Monophony](https://gitlab.com/zehkira/monophony) - YouTube Music Clients
* [cliamp](https://www.cliamp.stream/) / [GitHub](https://github.com/bjarneo/cliamp), [MOC](https://moc.daper.net/) or [Kew](https://github.com/ravachol/kew) - TUI Audio Players
* [Deezer Linux](https://github.com/aunetx/deezer-linux) or [DZR](https://github.com/yne/dzr) - Deezer Clients / [Availability](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/deezer-availability.md)
* [MusicPod](https://github.com/ubuntu-flutter-community/musicpod) - Podcast / Radio Player
* [HeadsetControl](https://github.com/Sapd/HeadsetControl) - Headset Settings Manager
* [Pipewire](https://pipewire.org/) - Improved Video / Audio Handling / Multimedia API / [Effects](https://github.com/wwmm/easyeffects) / [TUI Audio Mixer](https://github.com/tsowell/wiremix)
* [Werman](https://github.com/werman/noise-suppression-for-voice), [⁠HushMic](https://github.com/Fovty/hushmic) or [NoiseTorch](https://github.com/noisetorch/NoiseTorch) - Noise Suppression Software
* [Qtractor](https://qtractor.org/) - Audio Editor
* [Calf Studio Gear](https://calf-studio-gear.org/) - Audio Production Plugins
* [Ensembles](https://github.com/ensemblesaw/ensembles-app) - Musical Performance Arranger
* [JDSP4Linux](https://github.com/Audio4Linux/JDSP4Linux) - Audio Processors
* [cava](https://github.com/karlstav/cava) - Console Audio Visualizer
* [Blanket](https://github.com/rafaelmardojai/blanket) - Ambient Sound Mixer for Linux

***

## ▷ Linux Image

* ↪️ **[Linux Image Editors](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25B7_editing_software)**
* ⭐ **[Flameshot](https://flameshot.org/)**, [⁠Spectacle](https://apps.kde.org/spectacle/), [Satty](https://github.com/Satty-org/Satty), [Gradia](https://gradia.alexandervanhee.be/) / [GitHub](https://github.com/AlexanderVanhee/Gradia) or [Scrot](https://github.com/resurrecting-open-source-projects/scrot) - Screenshot Tools
* [v4l2loopback](https://github.com/v4l2loopback/v4l2loopback) - Create Virtual Cameras
* [Drawing](https://maoschanz.github.io/drawing/) - Drawing App
* [Android Virtual Pen](https://github.com/androidvirtualpen/virtualpen) - Use Device as Linux Virtual Pen
* [Feh](https://feh.finalrewind.org/) or [NSXIV](https://github.com/nsxiv/nsxiv) - Image Viewer
* [Lightroom Classic on Linux](https://github.com/6im0n/lightroom-classic-on-linux) - Scripts to run Lightroom Classic on Linux
* [lsix](https://github.com/hackerb9/lsix) - View Images in Terminal
* [Upscaler](https://gitlab.gnome.org/World/Upscaler) - Image Upscaler
* [Trimage](https://trimage.org/) or [Curtail](https://github.com/Huluti/Curtail) - Image Compressor
* [Rapid](https://damonlynch.net/rapid/) - Quick Linux Photo Importer

***

## ▷ Productivity / Calendars

* [todo](https://github.com/sioodmy/todo/) or [Planify](https://github.com/alainm23/planify) - To-Do Apps
* [⁠Planify](https://useplanify.com/) - Task Manager / To Do App
* [Mindfulness at the Computer](https://fswb.codeberg.page/mindfulness-at-the-computer/) - Productivity Managers
* [GNOME Evolution](https://help.gnome.org/evolution/) - Desktop Calendar
* [dLine](https://github.com/jazz-it/dline) or [⁠calcurse](https://calcurse.org/) - CLI Calendars

***

## ▷ Linux Gaming

* ↪️ **[Linux Game Launchers / Downloaders](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools#wiki_.25B7_game_launchers)**
* ↪️ **[Steam Deck Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools#wiki_.25B7_steam_deck)**
* ⭐ **[Linux Gaming Wiki](https://linux-gaming.kwindu.eu/index.php?title=Main_Page)** or **[r/LinuxCrackSupport Wiki](https://www.reddit.com/r/LinuxCrackSupport/wiki/index)** - Linux Gaming Guides
* ⭐ **[protondb](https://www.protondb.com/)** - Game Compatibility Database / [Steam Extension](https://github.com/Trsnaqe/protondb-community-extension) / [Discord](https://discord.com/invite/uuwK9EV)
* ⭐ **[Bottles](https://usebottles.com/)** - Manage Wine Containers / [Discord](https://discord.com/invite/wF4JAdYrTR) / [GitHub](https://github.com/bottlesdevs/Bottles)
* ⭐ **[SLSsteam](https://cs.rin.ru/forum/viewtopic.php?f=29&t=146352&hilit=SLSsteam)** - Steamclient Mod w/ DLC Unlocker and Emulated Achievements / [Auto Install / Update](https://github.com/Deadboy666/h3adcr-b) / [Discord](https://discord.com/invite/j3ZzjeV4eQ) / [GitHub](https://github.com/AceSLS/SLSsteam)
* ⭐ **[Accela](https://github.com/ciscosweater/enter-the-wired)** - Steam Game + DLC Unlocker / [Setup Guide](https://redd.it/1tniqhc)
* ⭐ **[ProtonPlus](https://github.com/Vysp3r/ProtonPlus)** or [ProtonUp-QT](https://davidotek.github.io/protonup-qt/) / [GitHub](https://github.com/DavidoTek/ProtonUp-Qt/) - Linux Compatibility Tool Managers
* ⭐ **[GE-Proton](https://github.com/GloriousEggroll/proton-ge-custom)** - Custom Proton Version / [Discord](https://discord.com/invite/6y3BdzC)
* ⭐ **[Kapital Sin](https://www.kapitalsin.com/forum/index.php?board=4.0)** - Linux Games / Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators)
* ⭐ **[Torrminatorr](https://forum.torrminatorr.com/)** - Linux Games / Requires Sign-Up
* ⭐ **[johncena141](https://rentry.co/FMHYB64#johncena141)** - Linux Games / [Support](https://gitlab.com/jc141x/portal) / [Launcher](https://github.com/AbdelrhmanNile/UnderTaker141)
* [CS.RIN.RU](https://cs.rin.ru/forum) - Linux Games / Sign-Up / PW: `cs.rin.ru / csrin.org` / [.onion](http://csrinrutkb3tshptdctl5lyei4et35itl22qvk5ktdcat6aeavy6nhid.onion/forum)
* [RuTracker](https://rutracker.org/forum/viewforum.php?f=899) - Linux Games / Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators) / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent#wiki_.25BA_torrent_sites)
* [PhoeNix Games Lab](https://rentry.co/FMHYB64#native-linux-games) - Linux Games
* [⁠GamingOnLinux](https://www.gamingonlinux.com/) - Linux Gaming News
* [appnetica](https://appnetica.com/?platform=linux) - Linux Games
* [LinUwUx](https://github.com/brcly/linuwux-runtime) - LD_PRELOAD Library for Hypervisor(-less) Denuvo Bypass
* [LuaTools](https://lua.tools/) - Steam Game Unlocker w/ Multitool, DLC Unlocker + Auto Online Fix / [GitHub](https://github.com/madoiscool/LuaTools)
* [CreamLinux](https://github.com/anticitizn/creamlinux) - Steam DLC Unlockers / [Installer](https://github.com/Novattz/creamlinux-installer)
* [winesapOS](https://github.com/winesapOS/winesapOS) - Play Games on Storage Devices
* [⁠Conty](https://github.com/kron4ek/conty) - Single-File Gaming Container for Any Distro
* [wine-wayland](https://github.com/varmd/wine-wayland) - Play DX9/DX11 / Vulkan Games
* [⁠UMU](https://github.com/Open-Wine-Components/umu-launcher) - Run Non-Steam Games Through Proton
* [Luxtorpeda](https://codeberg.org/luxtorpeda/luxtorpeda) or [Boxtron](https://github.com/dreamer/boxtron) - Run Steam Games on Linux
* [⁠SteamTinkerLaunch](https://github.com/sonic2kk/steamtinkerlaunch) - Steam Wrapper w/ Custom Launcher Options
* [AdwSteamGtk](https://github.com/Foldex/AdwSteamGtk) - Steam Frontend
* [steam-tui](https://github.com/dmadisetti/steam-tui) - Rust TUI for Steam
* [RetroDECK](https://retrodeck.net/) - Emulator for Steam Deck
* [CryoUtilities](https://github.com/CryoByte33/steam-deck-utilities) - Steam Deck Utilities
* [SamRewritten](https://github.com/PaulCombal/SamRewritten) - Steam Achievement Manager
* [Steam for Linux](https://github.com/ValveSoftware/steam-for-linux) - Steam Linux Beta Issue Tracker
* [Minigalaxy](https://wijsman.de/minigalaxy/) - GOG Client
* [⁠Online-Fix Linux](https://github.com/ZzEdovec/onlinefix-linux) - Launch Games w/ ⁠Online-Fix Patches
* [⁠LVRA Wiki](https://vronlinux.org/) / [Discord](https://discord.gg/EHAYe3tTYa) - Linux VR Gaming Guides
* [Vice](https://github.com/eklonofficial/Vice) - Game Clipping App
* [⁠Amethyst Mod Manager](https://github.com/ChrisDKN/Amethyst-Mod-Manager) or [Limo](https://github.com/limo-app/limo) - Mod Managers
* [ssprea-nvidia-control](https://github.com/ssprea/ssprea-nvidia-control), [⁠LACT](https://github.com/ilya-zlobintsev/LACT/) or [CoreCtrl](https://gitlab.com/corectrl/corectrl) - GPU Overclocking Tools
* [⁠LeShade](https://github.com/Ishidawg/LeShade) - ReShade Manager
* [DXVK](https://github.com/doitsujin/dxvk) - Vulkan-Based Direct3D for Linux / Wine
* [⁠D7VK](https://github.com/WinterSnowfall/d7vk) - Vulkan-Based D3D7/6/5 for Linux / Wine
* [DLSS5VKLayer](https://www.phoronix.com/news/DLSS5VKLayer) - Vulkan DLSS 5 Neural Rendering Layer / [GitHub](https://github.com/bmitch87/DLSS5VKLayer)
* [⁠dxvk-gplasync](https://gitlab.com/Ph42oN/dxvk-gplasync/) or [DXVK-Sarek](https://github.com/pythonlover02/DXVK-Sarek/) - DXVK Forks w/ Async / Vulkan-Based Direct3D & D3D3-11 / Stutter Reduction
* [⁠lsfg-vk](https://lsfg-vk.dev/) - Lossless Scaling for Linux / [Source Code](https://git.lsfg-vk.dev/lsfg-vk)
* [vkBasalt](https://github.com/DadSchoorse/vkBasalt) - Game Post Processing Layer
* [Liquorix](https://liquorix.net/), [Xanmod](https://xanmod.org/) or [Frogging](https://github.com/Frogging-Family/linux-tkg) - Linux Gaming Kernels
* [Gamemode](https://github.com/FeralInteractive/gamemode) - Linux System Optimizer
* [LibreGaming](https://github.com/Ahmed-Al-Balochi/LibreGaming) - Linux Game Package Downloader
* [PortMaster](https://portmaster.games/) - Port Games to Linux Handheld Devices / [Discord](https://discord.gg/JxYBp9HTAY)
* [Gameboy.live](https://github.com/HFO4/gameboy.live) - Terminal Game Boy Emulator
* [QuickPassthrough](https://github.com/HikariKnight/quickpassthrough) - Simplified GPU Passthrough
* [⁠WiVRn](https://wivrn.github.io/) - Wirelessly Stream PC VR Games from Linux to Standalone VR Headset
* [⁠osu-winello](https://github.com/NelloKudo/osu-winello/) - osu! Installer for Linux
* [Sober](https://sober.vinegarhq.org/) or [⁠Nightcap](https://github.com/CoderDayton/nightcap) - Roblox on Linux / [Vinegar (Studio Only)](https://vinegarhq.org/)
* [⁠Touhou Linux Guide](https://daichungus.github.io/touhoulinuxguide/), [2](https://daichungus.codeberg.page/touhoulinuxguide/) - Touhou Game Series Linux Guide / [GitHub](https://github.com/daichungus/touhoulinuxguide)

***

# ► Linux Tools

## ▷ Adblock / Privacy

* ↪️ **[Linux 2FA](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25B7_password_privacy_.2F_2fa)**
* ↪️ **[Adblocking Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy)**
* ↪️ **[DNS Adblocking](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25B7_dns_adblocking)**
* ⭐ **[Arch Security Wiki](https://wiki.archlinux.org/title/Security)**, [Linux Hardening](https://vez.mrsk.me/linux-hardening) / [2](https://madaidans-insecurities.github.io/guides/linux-hardening.html) or [How to Secure a Linux Server](https://github.com/imthenachoman/How-To-Secure-A-Linux-Server) - Linux Security Guides
* ⭐ **[CryptSetup](https://gitlab.com/cryptsetup/cryptsetup)**, [gocryptfs](https://nuetzlich.net/gocryptfs) / [GitHub](https://github.com/rfjakob/gocryptfs) or [Tomb](https://dyne.org/software/tomb/) - File Encryption
* [Securely Wipe Disk](https://wiki.archlinux.org/title/Securely_wipe_disk) or [SSD Memory Cell Clearing](https://wiki.archlinux.org/title/Solid_state_drive/Memory_cell_clearing) - Linux Disk Wipe Guides
* [Lynis](https://github.com/CISOfy/lynis) - Linux Security Auditing Tool
* [Mistborn](https://gitlab.com/cyber5k/mistborn) - Manage Cloud Security Apps
* [OpenSnitch](https://github.com/evilsocket/opensnitch) - Linux Firewall
* [Tracee](https://aquasecurity.github.io/tracee/latest) - Runtime Security and Forensics
* [vnStat](https://github.com/vergoh/vnstat) - Network Monitors
* [Howdy](https://github.com/boltgolt/howdy) or [⁠Gaze](https://github.com/GunduLabs/gaze) - Linux Facial Authentication
* [USBGuard](https://github.com/USBGuard/usbguard) - Implement USB Device Authorization Policies
* [ShuffleStacks](https://shufflecake.net/) - Create Hidden Volumes
* [Collision](https://flathub.org/apps/dev.geopjr.Collision) - Check File Hashes
* [WhoAmI Project](https://owerdogan.github.io/whoami-project) - Privacy / Anonymity Tool / [GitHub](https://github.com/owerdogan/whoami-project)
* [Yubikey Full Disk Encryption](https://github.com/agherzan/yubikey-full-disk-encryption) - Use YubiKey to unlock a LUKS Partition
* [Firejail](https://firejail.wordpress.com/) or [Bubblewrap](https://github.com/containers/bubblewrap) - Sandboxing Tools
* [Googerteller](https://github.com/berthubert/googerteller) - Google Tracking Notifications

***

## ▷ Linux Internet

* ↪️ **[Linux Torrent Clients](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent#wiki_.25BA_torrent_clients)**
* ↪️ **[Linux Password Managers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools#wiki_.25B7_password_managers)**
* ⭐ **[Nicotine+](https://nicotine-plus.org/)** or [Soulseek](https://www.slsknet.org) - File Sharing App
* ⭐ **[Linux WiFi Hotspot](https://github.com/lakinduakash/linux-wifi-hotspot)** - Create WiFi Hotspots
* [BTFS](https://github.com/johang/btfs) - Bittorrent Filesystem
* [ElectronMail](https://github.com/vladimiry/ElectronMail), [Claws Mail](https://www.claws-mail.org/) or [dodo](https://github.com/akissinger/dodo) - Email Clients
* [Akregator](https://apps.kde.org/akregator/), [NewsBoat](https://newsboat.org/), [NewsFlash](https://gitlab.com/news-flash/news_flash_gtk), [Photon](https://git.sr.ht/~ghost08/photon) or [gorss](https://github.com/Lallassu/gorss) - RSS Readers
* [KGet](https://apps.kde.org/kget/), [⁠Surge](https://github.com/SurgeDM/Surge) or [GabutDM](https://github.com/gabutakut/gabutdm) - Download Managers
* [GDown](https://github.com/wkentaro/gdown) - Google Drive Downloader
* [google-drive-ocamlfuse](https://github.com/astrada/google-drive-ocamlfuse) - Mount Google Drive
* [aMule](https://www.amule.org/) - eMule-like P2P Client
* [⁠OpenWRT](https://openwrt.org/), [DD-WRT](https://wiki.dd-wrt.com/) or [FreshTomato](https://www.freshtomato.org/) - Linux Router Firmware
* [⁠dae](https://github.com/daeuniverse/dae) - Linux Router Performance Proxy App / [WebUI](https://github.com/daeuniverse/daed)
* [Linux Router](https://github.com/garywill/linux-router) - Set Linux as Router
* [Netcat](https://rentry.co/Netcat) - Networking Tool
* [Bandwhich](https://github.com/imsnif/bandwhich) - Terminal Bandwidth Utilization Tool
* [iperf](https://github.com/esnet/iperf) - Network Bandwidth Test
* [sttr](https://github.com/abhimanyu003/sttr) - Base64 Encryption / Decryption TUI
* [Netflix Proxy](https://github.com/ab77/netflix-proxy/) - Streaming Service Proxy
* [Teams for Linux](https://github.com/IsmaelMartinez/teams-for-linux) - Collaboration Platform
* [⁠Brave Origin](https://brave.com/origin/) - Lighter Version of Brave
* [Luakit](https://luakit.github.io/) - Lightweight Linux Browser
* [browsh](https://www.brow.sh/) - Text-Based Browser
* [mx moment](https://mx-moment.xyz/) - Encrypted Chat Client
* [Adium](https://adium.im/), [Polari](https://apps.gnome.org/Polari/) / [GitLab](https://gitlab.gnome.org/GNOME/polari), [Irssi](https://github.com/irssi/irssi) or [Weechat](https://weechat.org/) - IRC Clients
* [Dino](https://dino.im/) - XMPP Client
* [gurk-rs](https://github.com/boxdot/gurk-rs) - Signal Client
* [ZapZap](https://rtosta.com/zapzap/) - WhatsApp Client / [GitHub](https://github.com/rafatosta/zapzap)
* [YouTube-Viewer](https://github.com/trizen/youtube-viewer), [Pipe Viewer](https://github.com/trizen/pipe-viewer) or [Pipeline](https://gitlab.com/schmiddi-on-mobile/pipeline) - YouTube Clients
* [GrayJay](https://grayjay.app/) - YouTube, Twitch, Rumble, etc. / [Guide](https://youtu.be/EnZrv37u66c) / [Plugins](https://plugins.grayjay.app/) / [Add Platforms](https://grayjay-sources.github.io/), [2](https://github.com/grayjay-sources/grayjay-sources.github.io), [3](https://gitlab.futo.org/videostreaming/plugins) / [GitLab](https://gitlab.futo.org/videostreaming/grayjay)
* [Discover](https://github.com/trigg/Discover) - Discord Overlay
* [dvm](https://github.com/diced/dvm) - Discord Version Manager

***

## ▷ Server / Selfhosting

* 🌐 **[Awesome Selfhosted](https://awesome-selfhosted.net/)** / [2](https://gist.github.com/kvnxiao/27c14760cbec35b4e312e34c856b51a8) or [Awesome Selfhosted UI](https://awesomeselfhosted.netlify.app/) - Self-Hosted Software Index / [GitHub](https://github.com/awesome-selfhosted/awesome-selfhosted)
* 🌐 **[⁠Awesome Homelab](https://github.com/miantiao-me/awesome-homelab/)** - Homelab App Index
* 🌐 **[Selfh.st](https://selfh.st/apps/)** - Self-Hosted Software Index
* 🌐 **[selfhost.directory](https://selfhost.directory/)** - Self-Hosted Software Index
* 🌐 **[⁠RackRat](https://rackrat.net/)** - eBay Rackmount Server Prices / Comparisons
* ↪️ **[Media Servers / Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video-tools#wiki_.25BA_media_servers)**
* ↪️ **[Selfhosted Image Galleries](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25B7_offline_galleries)**
* ⭐ **[Homepage](https://gethomepage.dev/)** / [GitHub](https://github.com/gethomepage/homepage), **[Dashy](https://dashy.to/)** / [GitHub](https://github.com/Lissy93/dashy), [Flame](https://github.com/pawelmalak/flame), [Homer](https://github.com/bastienwirtz/homer), [Lab Dash](https://github.com/AnthonyGress/lab-dash), [mafl](https://mafl.hywax.space/), [Homarr](https://homarr.dev/) / [GitHub](https://github.com/homarr-labs/homarr) or [Organizr](https://github.com/causefx/Organizr) - Home Server Startpages / Dashboards
* [Glance](https://github.com/glanceapp/glance) - Feed Dashboard
* [⁠ThingsBoard](https://github.com/thingsboard/thingsboard) - IoT Device Manager / Visualizer / Data Collection
* [Self Managed Life](https://wiki.futo.org/) - FOSS / Self-Hosting Guide / [Video](https://youtu.be/Et5PPMYuOc8), [2](https://youtu.be/3fW9TV1WQi8)
* [r/SelfHosted Wiki](https://wiki.r-selfhosted.com/) - Self-Hosting Guides / Resources / Community / [Subreddit](https://www.reddit.com/r/selfhosted/) / [GitHub](https://github.com/r-selfhosted/wiki)
* [Server World](https://www.server-world.info/en/) - Network Server Guides
* [HowtoForge](https://www.howtoforge.com/) / [GitHub](https://github.com/lollipopkit/flutter_server_box) or [Comfy.Guide](https://comfy.guide/) - Linux Server Software Guides
* [serverbox](https://serverbox.lolli.tech/?lang=en), [⁠Termix](https://github.com/Termix-SSH/Termix) / [Discord](https://discord.gg/jVQGdvHDrf), [EasyPanel](https://easypanel.io/), [Webmin](https://webmin.com/) / [GitHub](https://github.com/webmin/webmin), [Cockpit Project](https://cockpit-project.org/), [ZimaOS](https://www.zimaspace.com/) or [1Panel](https://1panel.pro/) / [GitHub](https://github.com/1Panel-dev/1Panel) - Linux Server Managers / Status
* [Exo](https://github.com/exo-explore/exo/) - Run AI Clusters / [Telegram](https://t.me/+Kh-KqHTzFYg3MGNk) / [Discord](https://discord.gg/EUnjGpsmWw)
* [⁠LXD UI](https://github.com/canonical/lxd-ui) - Linux Container + Virtual Machine Manager
* [Proxmox](https://www.proxmox.com/) - Self-Hosted Server Tools / Virtual Environment / [Scripts](https://community-scripts.org/)
* [yet another bench script](https://github.com/masonr/yet-another-bench-script) - Server Performance Script
* [Docker-Jackett](https://github.com/linuxserver/docker-jackett) - Docker Jackett Container
* [arch-delugevpn](https://github.com/binhex/arch-delugevpn) - Docker with Torrent client and VPN on Arch Linux base
* [rtinst](https://github.com/arakasi72/rtinst) - Seedbox Installation Script for Ubuntu / Debian
* [SeedSync](https://github.com/ipsingh06/seedsync) - Sync your Seedbox
* [Linkwarden](https://linkwarden.app/) / [GitHub](https://github.com/linkwarden/linkwarden), [KaraKeep](https://karakeep.app/) / [GitHub](https://github.com/karakeep-app/karakeep), [Shaarli](https://github.com/shaarli/Shaarli), [LinkAce](https://www.linkace.org/), [⁠nextDash](https://github.com/jordibrouwer/nextdash) or [linkding](https://linkding.link/) / [GitHub](https://github.com/sissbruecker/linkding) - Self-Hosted Bookmark Managers
* [openmediavault](https://www.openmediavault.org/) / [GitHub](https://github.com/openmediavault/openmediavault/), [Cloudreve](https://cloudreve.org/) / [GitHub](https://github.com/cloudreve/Cloudreve/), [SeaFile](https://www.seafile.com/en/home/) or [Linux Server](https://github.com/ZizzyDizzyMC/linx-server/) - Self-Hosted Cloud Storage
* [Tube Archivist](https://www.tubearchivist.com/) - Self-Hosted YouTube Media Server / [GitHub](https://github.com/tubearchivist/tubearchivist)
* [⁠RaveBSD](https://ravebooksearch.com/) - Self-Hostable Book Search Engine
* [FileBrowser Quantum](https://filebrowserquantum.com/) / [GitHub](https://github.com/gtsteffaniak/filebrowser) or [⁠copyparty](https://github.com/9001/copyparty/) - Self-Hosted Web File Managers
* [⁠SilverBullet](https://silverbullet.md/) - Self-Hosted Markdown Note-Taking
* [Lightning](https://williamhorning.dev/lightning/) - Self-Hosted Cross-Platform Chatbot Framework
* [⁠ConvertX](https://github.com/C4illin/ConvertX) or [Transmute](https://transmute.sh/) / [GitHub](https://github.com/transmute-app/transmute) - Self-Hosted File Converters
* [SearXNG](https://docs.searxng.org/), [4get](https://git.lolcat.ca/lolcat/4get), [⁠Hister](https://hister.org/) / [Discord](https://discord.gg/6JzgjGKVFP) / [GitHub](https://github.com/asciimoo/hister) or [ZincSearch](https://zincsearch-docs.zinc.dev/) / [GitHub](https://github.com/zincsearch/zincsearch) - Self-Hosted Search Engines
* [Moe Memos](https://memos.moe/) (android) or [Kept](https://www.keepitkept.xyz/) / [GitHub](https://github.com/ericerkz/kept) - Self-Hosted Note-Taking
* [BookStack](https://www.bookstackapp.com/) / [GitHub](https://github.com/BookStackApp/BookStack), [NoteDiscovery](https://www.notediscovery.com/) / [GitHub](https://github.com/gamosoft/NoteDiscovery/) or [Siyuan](https://b3log.org/siyuan/en) / [GitHub](https://github.com/siyuan-note/siyuan) - Self-Hosted Info Managers
* [iRedMail](https://www.iredmail.org/), [Docker Mailserver](https://docker-mailserver.github.io/docker-mailserver/edge/), [Stalwart](https://stalw.art/) / [GitHub](https://github.com/stalwartlabs/stalwart), [UnInbox](https://github.com/un/inbox) or [Mail-in a Box](https://mailinabox.email/) - Self-Hosted Email Servers
* [⁠Mailflare](https://mailflare.co/) - Self-Hosted Custom Domain Email Workspace / [GitHub](https://github.com/hieunc229/mailflare)
* [⁠AIOStreams](https://docs.aiostreams.viren070.me/) - Multi-Source Addon + Debrid Aggregator / [Discord](https://discord.com/invite/zRq8dVh5rJ) / [GitHub](https://github.com/Viren070/AIOStreams)
* [⁠AIOMetadata](https://github.com/cedya77/aiometadata) - Multi-Source Metadata & Catalogs Addon / [Public Instances](https://uptime.ibbylabs.dev/aiometadata)

***

## ▷ File Tools

* ⭐ **[Warpinator](https://github.com/linuxmint/warpinator)**, [rQuickshare](https://github.com/Martichou/rquickshare), [Magic Wormhole](https://github.com/magic-wormhole/magic-wormhole), [syncthing](https://syncthing.net/) / [Tray Support](https://martchus.github.io/syncthingtray/), [portal](https://github.com/SpatiumPortae/portal), [Zrok](https://zrok.io/), [Cattail](https://github.com/nerdyslacker/cattail) or [Sharing](https://github.com/parvardegr/sharing) - File Sync / Transfer
* ⭐ **[lf](https://github.com/gokcehan/lf)**, [ranger](https://ranger.fm/) / [Source Code](https://codeberg.org/ranger/pages), [⁠broot](https://dystroy.org/broot) / [GitHub](https://github.com/Canop/broot), [nnn](https://github.com/jarun/nnn), [clifm](https://github.com/leo-arch/clifm), [Yazi](https://yazi-rs.github.io/) / [GitHub](https://github.com/sxyazi/yazi), [fm](https://github.com/mistakenelf/fm), [superfile](https://superfile.dev/) / [GitHub](https://github.com/yorukot/superfile), [walk](https://github.com/antonmedv/walk) or [Joshuto](https://github.com/kamiyaa/joshuto) - Terminal File Managers
* ⭐ **[Baobab](https://gitlab.gnome.org/GNOME/baobab)**, **[Filelight](https://apps.kde.org/en-gb/filelight/)** - Disk Usage Analyzers / GUI
* ⭐ **[dut](https://codeberg.org/201984/dut)**, **[gdu](https://github.com/dundee/gdu)**, **[NCDU](https://dev.yorhel.nl/ncdu)** - Disk Usage Analyzers / CLI
* [ANGRYsearch](https://github.com/DoTheEvo/ANGRYsearch), [gocatcli](https://github.com/deadc0de6/gocatcli/), [xplr](https://xplr.dev/) / [Discord](https://discord.com/invite/JmasSPCcz3) / [GitHub](https://github.com/sayanarijit/xplr), [logo-ls](https://github.com/Yash-Handa/logo-ls) or [ugrep](https://ugrep.com) / [GitHub](https://github.com/Genivia/ugrep) - File Explorers / Search
* [The Filesystem Hierarchy Standard](https://i.ibb.co/Mx53xj3R/image.png), [2](https://files.catbox.moe/2390ha.png), [3](https://i.imgur.com/0vfM4dm.png) - Linux Filesystem Chart
* [Dolphin](https://userbase.kde.org/Dolphin) / [Source Code](https://invent.kde.org/system/dolphin), [Strata](https://stratafiles.io/) / [GitHub](https://github.com/lgse/strata) or [SpaceFM](https://ignorantguru.github.io/spacefm/) - File Managers
* [PeaZip](https://peazip.github.io/) / [GitHub](https://github.com/peazip/PeaZip/), [pigz](https://zlib.net/pigz/) / [GitHub](https://github.com/madler/pigz), [p7zip](https://p7zip.sourceforge.net/) or [GNU Gzip](https://www.gnu.org/software/gzip/) - File Archivers / Unzippers / Compression
* [Collector](https://mijorus.it/projects/collector/) - File Drag & Drop
* [Zoxide](https://github.com/ajeetdsouza/zoxide) - Improved CD Command
* [lnav](https://lnav.org/) - Log File Viewer / Analyzer / [Discord](https://discord.gg/erBPnKwz7R) / [GitHub](https://github.com/tstack/lnav)
* [Pika Backup](https://gitlab.gnome.org/World/pika-backup/) or [RecoverPy](https://github.com/PabloLec/RecoverPy) - File Backup / Recovery Tools
* [fcp](https://github.com/Svetlitski/fcp) - Improved Linux File Copy
* [Boxxy](https://github.com/queer/boxxy) - Contain Files / Directories
* [Junction](https://github.com/sonnyp/Junction) - Change File Associations
* [Krename](https://apps.kde.org/en-gb/krename/) - Bulk File / Folder Renaming
* [FSLint](https://www.pixelbeat.org/fslint/), [kdiff3](https://apps.kde.org/en-gb/kdiff3/) or [fclones](https://github.com/pkolaczk/fclones) - Duplicate File Finder
* [xdg-ninja](https://github.com/b3nj5m1n/xdg-ninja) - Unwanted File Finder
* [rcm](https://github.com/thoughtbot/rcm) - Manage Dotfiles
* [PDF Mix](https://scarpetta.eu/pdfmixtool/) - PDF Editor
* [gscan2pdf](https://gscan2pdf.sourceforge.net/) - Turn Documents into PDFs

***

## ▷ Android on Linux

* ⭐ **[Waydroid](https://waydro.id/)** - Containerized Android on Linux / [Scripts](https://github.com/casualsnek/waydroid_script) / [WayDroid-ATV Images](https://github.com/WayDroid-ATV/waydroid-builds) / [GitHub](https://github.com/waydroid)
* [Redroid](https://github.com/remote-android/redroid-doc) or [Docker-Android](https://github.com/budtmo/docker-android) - Containerized Android on Linux
* [Genymotion](https://www.genymotion.com/) - Android Emulator
* [Android-x86](https://www.android-x86.org/) - Android-Based OS for PC
* [adbfs-rootless](https://github.com/spion/adbfs-rootless) - Mount Android on Linux via ADB

***

## ▷ Terminal / Shell

* 🌐 **[Awesome Shell](https://github.com/alebcay/awesome-shell)**, [tldr](https://tldr.inbrowser.app/) / [GitHub](https://github.com/tldr-pages/tldr) or [AltBox](https://altbox.dev/) - Linux Shell Resources
* 🌐 **[Awesome TUI](https://github.com/rothgar/awesome-tuis)** or [TerminalTrove](https://terminaltrove.com/) - TUI Indexes
* 🌐 **[⁠Awesome Terminal Recorder](https://github.com/orangekame3/awesome-terminal-recorder)** - Terminal Recorder Index
* ⭐ **[zsh](https://www.zsh.org/)**, **[bash](https://www.gnu.org/software/bash/)**, [fish](https://fishshell.com/), [Elvish](https://elv.sh/), [Es](https://wryun.github.io/es-shell/), [PowerShell](https://github.com/powershell/powershell), [Ion](https://gitlab.redox-os.org/redox-os/ion), [Xonsh](https://xon.sh/), [Nushell](https://www.nushell.sh/) or [oils](https://oils.pub/) / [GitHub](https://github.com/oils-for-unix/oils) - Command Line Shells
* ⭐ **zsh Tools** - [Plugins](https://github.com/unixorn/awesome-zsh-plugins) / [Customization](https://ohmyz.sh/) / [Theme](https://github.com/romkatv/powerlevel10k) / [Auto Setup](https://github.com/gustavohellwig/gh-zsh) / [Rich Framework](https://github.com/sorin-ionescu/prezto)
* ⭐ **[Alacritty](https://alacritty.org)**, **[Kitty](https://sw.kovidgoyal.net/kitty/overview/)**, **[Wezterm](https://wezterm.org)** / [Plugins](https://github.com/michaelbrusegard/awesome-wezterm) / [GitHub](https://github.com/wezterm/wezterm), [tabby](https://tabby.sh/), [foot](https://codeberg.org/dnkl/foot), [Simple Terminal](https://st.suckless.org/), [Wave](https://www.waveterm.dev/), [Ghostty](https://ghostty.org/), [yakuake](https://apps.kde.org/yakuake/) or [emacs-eat](https://codeberg.org/akib/emacs-eat) - Linux Terminal Emulators
* ⭐ **[LinuxCommand](https://www.linuxcommand.org/tlcl.php)**, [Terminal Guide](https://www.terminal.guide/), [Command Line Guide](https://github.com/jlevy/the-art-of-command-line) or [ManKier](https://www.mankier.com/) - Command-Line / Terminal Guides
* [⁠WebTerm](https://webterm.app/) - Terminal Learning Sandbox
* [⁠WTF](https://wtfutil.com/) / [GitHub](https://github.com/wtfutil/wtf) - Terminal Dashboards
* [Starship](https://starship.rs/) or [Liquidprompt](https://github.com/liquidprompt/liquidprompt) - Bash / Zsh Prompt
* [utils](https://github.com/Loupeznik/utils) or [UsefulLinuxShellScripts](https://github.com/jackrabbit335/UsefulLinuxShellScripts) - Linux Shell Tool Scripts
* [Gum](https://github.com/charmbracelet/gum) - Shell Script Creator
* [ShellCheck](https://www.shellcheck.net/) - Shell Script Bug Check
* [⁠ShellScript](https://www.shellscript.sh/) or [shell-scripting-tutorial](https://github.com/techarkit/shell-scripting-tutorial) - Shell Scripting Tutorials
* [Bash Crawl](https://gitlab.com/slackermedia/bashcrawl) - Linux Command Learning Game
* [bash_loading_animations](https://github.com/Silejonu/bash_loading_animations) - Bash Loading Animations
* [bash-it](https://github.com/Bash-it/bash-it) or [Bashly](https://bashly.dev/) - Bash Frameworks
* [zx](https://google.github.io/zx/) or [dax](https://github.com/dsherret/dax) - Write Complex Scripts
* [Basher](https://www.basher.it/) or [bpkg](https://bpkg.sh/) - Bash Package Manager
* [Distrobox](https://distrobox.it/) - Use Distros via Terminal
* [explainshell.com](https://explainshell.com/) - Match Command-Line Arguments to Help Text
* [Tmux](https://github.com/tmux/tmux) - Terminal Multiplexer / [Cheatsheet](https://tmuxcheatsheet.com/)
* [Zellij](https://zellij.dev/) - Terminal Workspace
* [atuin](https://atuin.sh/) - Shell History Management / [GitHub](https://github.com/atuinsh/atuin)
* [cbonsai](https://gitlab.com/jallbrit/cbonsai) - Generate Bonsai Trees in Terminal
* [pipes.sh](https://pipeseroni.github.io/) or [pipes-rs](https://github.com/lhvy/pipes-rs) - Animated Pipes in Terminal

***

## ▷ Raspberry Pi

* 🌐 **[Awesome Raspberry Pi](https://github.com/thibmaek/awesome-raspberry-pi)** - Raspberry Pi Tools / Resources
* 🌐 **[Pi-Apps](https://pi-apps.io/)** - Raspberry Pi App Store / [GitHub](https://github.com/Botspot/pi-apps)
* [Pinn](https://github.com/procount/pinn) - Raspberry Pi OS Installer
* [PiVPN](https://pivpn.io/) - Raspberry Pi VPN / [GitHub](https://github.com/pivpn/pivpn)
* [raspberrypiwireguard](https://github.com/adrianmihalko/raspberrypiwireguard) - Install WireGuard on Raspberry Pi
* [Raspberry Pi Connect](https://www.raspberrypi.com/software/connect/) - Raspberry Pi Remote Access
* [⁠Shairport Sync](https://github.com/mikebrady/shairport-sync) - AirPlay Audio Receiver for Raspberry Pi
* [CaribouLite](https://github.com/cariboulabs/cariboulite) - Raspberry Pi Tx/Rx 6GHz SDR
* [Piper](https://github.com/OHF-Voice/piper1-gpl) - Raspberry Pi Text-To-Speech
* [Pinout](https://pinout.xyz/) - Raspberry Pi GPIO Pins Guide

***

# ► Customization

* 🌐 **[Awesome Ricing](https://github.com/fosslife/awesome-ricing)**, **[⁠Awesome Linux Ricing](https://github.com/avtzis/awesome-linux-ricing)** or [Pling](https://www.opendesktop.org/s/All-Linux/browse/) - Linux Customization Resources
* ⭐ **[Elkowar's Wacky Widgets](https://elkowar.github.io/eww)**, **[Aylur's GTK Shell](https://github.com/Aylur/ags)** or [⁠Quickshell](https://quickshell.org/) - Widgeting Systems
* ⭐ **[unixporn](https://unixporn.github.io/)** - Customization Community / [Subreddit](https://reddit.com/r/unixporn) / [Discord](https://discord.gg/unixporn) / [GitHub](https://github.com/unixporn)
* [Fetch](https://asdesai.com/p/fetch/) - Custom 3D Rotating Distro Logo / [GitHub](https://github.com/areofyl/fetch)
* [dotfiles](https://dotfiles.github.io/) or [~/.config](https://dotfiles.lol/) - GitHub Dotfiles
* [⁠Chezmoi](https://www.chezmoi.io/) - Dotfile Managers
* [⁠Qylock](https://github.com/Darkkal44/qylock) - Custom Lockscreen Themes for SDDM + Quickshell

***

## ▷ Desktop Environment

* 🌐 **[Desktop Environment Comparison](https://eylenburg.github.io/de_comparison.htm)**
* [Extension Manager](https://mattjakeman.com/apps/extension-manager) - GNOME Shell Extension Manager
* [Material Shell](https://material-shell.com/) or [Forge](https://github.com/forge-ext/forge) - GNOME Tiling Extension
* [Pop!_OS Shell](https://github.com/pop-os/shell) - Pop-Shell for GNOME
* [Guillotine](https://gitlab.com/ente76/guillotine/) - Execute Commands from a Customizable Menu / GNOME Extension
* [Hardcode Tray](https://github.com/bilelmoussaoui/Hardcode-Tray) - Hardcoded Tray Icon Fix

***

## ▷ Window Managers

* 🌐 **[⁠Awesome Wayland](https://github.com/rcalixte/awesome-wayland)** - Wayland Resources
* 🌐 **[⁠Wayland.fyi](https://wayland.fyi/)** - Lightweight Wayland Resources
* 🌐 **[Window Manager Index](https://wiki.archlinux.org/title/Window_manager)** - List of Window Managers
* 🌐 **[Wayland Compositor Index](https://wiki.archlinux.org/title/Wayland#Compositors)** - List of Wayland Compositors
* 🌐 **[We Are Wayland Now](https://wearewaylandnow.com/)** - Wayland Ecosystem Components / [GitHub](https://github.com/gianklug/wearewaylandnow)
* ⭐ **[i3wm](https://i3wm.org)** - Manual Tiling Window Manager / [Reference Card](https://i3wm.org/docs/refcard.html) / [GitHub](https://github.com/i3/i3)
* ⭐ **[awesomewm](https://awesomewm.org)** / [GitHub](https://github.com/awesomeWM/awesome), **[xmonad](https://xmonad.org)**, [Qtile](https://qtile.org/) / [GitHub](https://github.com/qtile/qtile/) or [dwm](https://dwm.suckless.org) / [Source Code](https://git.suckless.org/dwm/log.html) - Dynamic Tiling Window Managers
* ⭐ **[Hyprland](https://hypr.land/)** - Dynamic Tiling Wayland Compositor / [Resources](https://github.com/hyprland-community/awesome-hyprland) / [Arch Wiki](https://wiki.archlinux.org/title/Hyprland) / [Simple Config](https://github.com/mylinuxforwork/dotfiles), [2](https://ii.clsty.link/en/) / [Test Configs](https://github.com/amarsbar/rice-cooker) / [Discord](https://discord.com/invite/hQ9XvMUjjr) / [GitHub](https://github.com/hyprwm/Hyprland)
* ⭐ **[niri](https://github.com/YaLTeR/niri)** - Scrollable-Tiling Wayland Compositor / [Config](https://github.com/srinivasr/nirimod)
* ⭐ **[Sway](https://github.com/swaywm/sway)** / [Arch Wiki](https://wiki.archlinux.org/title/Sway) or [SwayFx](https://github.com/WillPower3309/swayfx) - i3-compatible Wayland Compositors
* [Waycheck](https://gitlab.freedesktop.org/serebit/waycheck) - Lists Protocols Implemented by a Wayland Compositor
* [mangowm](https://mangowm.github.io/) - Dynamic Tiling Wayland Compositor / [Discord](https://discord.gg/CPjbDxesh5) / [GitHub](https://github.com/mangowm/mango)
* [BSPWM](https://github.com/baskerville/bspwm) - Hybrid Tiling Window Manager
* [herbstluftwm](https://herbstluftwm.org) - Manual Tiling Window Manager / [GitHub](https://github.com/herbstluftwm/herbstluftwm)
* [river](https://github.com/riverwm/river/) - Wayland Compositor
* [LabWC](https://github.com/labwc/labwc) - Wayland Compositor
* [wayfire](https://github.com/WayfireWM/wayfire/) - Wayland Compositor
* [⁠wayscriber](https://wayscriber.com/) - Wayland Screen Annotation / [GitHub](https://github.com/devmobasa/wayscriber)
* [picom](https://github.com/yshui/picom) - Compositor for Standalone X11 Window Managers / [Docs](https://picom.app/) / [GitHub](https://github.com/yshui/picom)
* [⁠Noctalia](https://github.com/noctalia-dev/noctalia-shell) - Customizable Wayland Desktop Shell
* [Polybar (X11)](https://polybar.github.io/) / [Themes](https://github.com/adi1090x/polybar-themes) / [GitHub](https://github.com/polybar/polybar), [Iron Bar](https://github.com/JakeStanger/ironbar) (Wayland) or [Waybar](https://github.com/Alexays/Waybar) (Wayland) - Customizable Status Bars

***

## ▷ Linux Themes

* 🌐 **[xfce-look](https://www.xfce-look.org/)** - XFCE Linux Themes
* 🌐 **[Gnome-Look](https://www.gnome-look.org/)** - GNOME Themes
* [Hellwal](https://github.com/danihek/hellwal) - Color Palette Generator for Customization
* [Themix](https://github.com/themix-project/themix-gui) - Linux Themes / GUI
* [Kvantum](https://github.com/tsujan/Kvantum) - Linux QT / KDE Theme Engine
* [⁠nwg-look](https://github.com/nwg-piotr/nwg-look) - GTK3 Settings Editor
* [Arc](https://github.com/jnsh/arc-theme) - Transparent Linux Theme
* [Ant](https://github.com/EliverLara/Ant) - Light Linux Theme
* [AeroThemePlasma](https://github.com/WackyIdeas/aerothemeplasma) / [2](https://gitgud.io/wackyideas/aerothemeplasma) or [VistaThemePlasma](https://gitgud.io/catpswin56/vistathemeplasma/) - Windows 7 / Vista Themes for KDE Plasma
* [XScreenSaver](https://www.jwz.org/xscreensaver/) - Linux Screensavers
* [⁠Waywallen](https://github.com/waywallen/waywallen), [varietywalls](https://github.com/varietywalls/variety) or [HydraPaper](https://hydrapaper.gabmus.org/) - Wallpaper Managers
* [⁠Wallpiper](https://github.com/shdwmtr/wallpiper) - Wallpaper Engine Translation Layer for Linux
* [Video Wallpaper](https://github.com/ghostlexly/gpu-video-wallpaper) or [Hidamari](https://github.com/jeffshee/hidamari) - Use Videos as Animated Wallpapers
* [⁠tint](https://github.com/ashish0kumar/tint) - Recolor Wallpapers for System Scheme / [GUI](https://github.com/lighttigerXIV/catppuccinifier)
* [Polychromatic](https://polychromatic.app/) or [OpenRazer](https://openrazer.github.io/) - Linux System Light Control
* [Burn My Windows](https://github.com/Schneegans/Burn-My-Windows) - Window Closing Effects
* [theme.sh](https://github.com/lemnos/theme.sh), [NotCurses](https://github.com/dankamongmen/notcurses) / [Wiki](https://nick-black.com/dankwiki/index.php/Notcurses) or [Shell Color Scripts](https://gitlab.com/dwt1/shell-color-scripts) - Custom Terminal Themes

***

# ► Mac Apps

* ↪️ **[Multi-Platform Readers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/reading/#wiki_.25B7_ebook_readers)** - Ebook Reader Index
* ↪️ **[Office Suites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools#wiki_.25B7_office_suites)**
* ⭐ **[gibMacOS](https://github.com/corpnewt/gibMacOS)** or [Mist](https://github.com/ninxsoft/Mist) - Download macOS
* ⭐ **[NearDrop](https://github.com/grishka/NearDrop)** - File Sharing App
* ⭐ **[shottr](https://shottr.cc/)** or [⁠Better Shot](https://www.bettershot.site/) / [GitHub](https://github.com/KartikLabhshetwar/better-shot) - Screenshot Tools
* ⭐ **[Aptonic](https://aptonic.com/)** - Drag-and-Drop Shelf / Quick File Access
* [Ghostty](https://ghostty.org/) - Terminal Emulator / [GitHub](https://github.com/ghostty-org/ghostty)
* [Ice Cubes](https://apps.apple.com/us/app/ice-cubes-for-mastodon/id6444915884) - Mastodon Client / [GitHub](https://github.com/Dimillian/IceCubesApp)
* [Sky.app](https://github.com/jcsalterego/Sky.app) - Bluesky Client
* [Beta Profiles](https://betaprofiles.com/) - Download Pre-Release Versions macOS
* [CloverBootloader](https://github.com/CloverHackyColor/CloverBootloader/) / [Config](https://mackie100projects.altervista.org/), [Boot Camp](https://support.apple.com/boot-camp) / [DL Script](https://github.com/timsutton/brigadier) or [OpenCore](https://github.com/acidanthera/OpenCorePkg) / [Config](https://mackie100projects.altervista.org/opencore-configurator/) / [Guide](https://dortania.github.io/OpenCore-Install-Guide/) - Bootloaders
* [rEFind](https://www.rodsbooks.com/refind/) - Boot Manager
* [Tart](https://tart.run/) - Virtual Machine Manager / [GitHub](https://github.com/openai/tart)
* [UTM](https://mac.getutm.app/), [LimaVM](https://lima-vm.io/) or [VMware](https://www.vmware.com/products/desktop-hypervisor/workstation-and-fusion) - Virtual Machines / Run Linux or Windows on macOS
* [VirtualBuddy](https://github.com/insidegui/VirtualBuddy) - Virtualize macOS 12 and later on Apple Silicon
* [Docker OSX](https://github.com/sickcodes/Docker-OSX) - Mac VM in Docker
* [Linux for T2](https://t2linux.org/) - Install Linux on Apple T2 Devices / [GitHub](https://github.com/t2linux)
* [CrossOver](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_software_sites2) (search) - Run Windows Software on Mac
* [PortingKit](https://www.portingkit.com/) - Run Windows Games / Programs on Mac
* [PlayCover](https://playcover.io/) - Run iOS Apps on Apple Silicon Macs / [GitHub](https://github.com/PlayCover/PlayCover)
* [SwiftUI Win11](https://jinxiansen.github.io/Windows11/) - Windows 11 Desktop Client for macOS
* [Latest](https://github.com/mangerlahn/latest) - Software Updater
* [OrbStack](https://orbstack.dev/) - Docker Client
* [Bookshelf](https://apps.apple.com/us/app/bookshelf-reading-tracker/id1469372414) - Book Tracker
* [Kexts](https://www.tonymacx86.com/resources/categories/kexts.11/) - UEFI Kexts
* [Adobe Downloader](https://github.com/X1a0He/Adobe-Downloader/blob/main/readme-en.md) - Adobe Product Downloader / [Telegram](https://t.me/X1a0He_bot)
* [ss64 macOS](https://ss64.com/mac/) - macOS Bash Commands
* [Left on Read](https://leftonread.me/) - iMessage Client
* [MacBing](https://goodsnooze.gumroad.com/l/macbing), [LlamaChat](https://www.llamachat.app/), [Oscilla](https://apps.apple.com/app/id6759628356), [Osaurus](https://osaurus.ai/) / [GitHub](https://github.com/osaurus-ai/osaurus), [⁠Atomic Chat](https://atomic.chat/) or [Mollama](https://apps.apple.com/app/mollama/id6736948278) - AI Chatbots
* [CodexBar](https://codexbar.app/) - Menu Bar AI Limit Tracker / [GitHub](https://github.com/steipete/CodexBar)
* [NetNewsWire](https://netnewswire.com/) or [ViennaRSS](https://www.vienna-rss.com/) - RSS Reader
* [Dialect](https://github.com/dialect-app/dialect) - Translator
* [Drafts](https://getdrafts.com/), [CotEditor](https://coteditor.com/), [Nebo](https://apps.apple.com/us/app/nebo-notes-pdf-annotations/id1119601770), [Strflow](https://strflow.app/), [⁠NotesPlus](https://www.notesplus.com/), [Voodoopad](https://www.voodoopad.com/), [Kyun](https://github.com/lennart-finke/kyun) or [Notenik](https://notenik.app/) - Text Editors / Notes
* [Clearly](https://clearly.md/) - Markdown Editor / [GitHub](https://github.com/Shpigford/clearly)
* [⁠TypeWhisper](https://www.typewhisper.com/en/) - Text to Speech / [Discord](https://discord.gg/pUFR4a65SD) / [GitHub](https://github.com/TypeWhisper)
* [Agenda](https://agenda.com/) - Date-Focused Note Organizer / [Forum](https://agenda.community/)
* [Things 3](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_software_sites2) (search) or [Taskpaper](https://www.taskpaper.com/) - To-Do Apps
* [BibDesk](https://bibdesk.sourceforge.io/) - Bibliography Manager
* [Hammerspoon](https://www.hammerspoon.org/) or [Bunch](https://bunchapp.co/) - Desktop Automation via Lua Scripts
* [MacScripter](https://www.macscripter.net/) - Automation Forum
* [pongoOS](https://github.com/checkra1n/pongoOS) - Mac Pre-Boot Executor
* [Later](https://getlater.app/) - Restore App Sessions / [GitHub](https://github.com/alyssaxuu/later)
* [MacVim](https://macvim.org/), [CodeEdit](https://www.codeedit.app/) or [AuroraEditor](https://auroraeditor.com/) - Code Editors
* [CHARL-E](https://www.charl-e.com/) - Stable Diffusion App
* [ColorSlurp](https://colorslurp.com/) or [Material-Colors-native](https://github.com/BafS/Material-Colors-native) - Color Picker
* [Use Contrast](https://usecontrast.com/) - Check Color Contrast Ratios
* [Sim Daltonism](https://michelf.ca/projects/sim-daltonism/) - Color Blindness Simulator
* [AnimeBox](https://www.animebox.es/) - Booru Client
* [Hachidori](https://malupdaterosx.moe/hachidori/) - Automatically Update MAL / Anilist / Kitsu Lists
* [Magit!](https://magit.vc/) - Git Text-Based UI
* [Does It Arm?](https://doesitarm.com/) - Apple Silicon App Compatibility Chart
* [SelfControlApp](https://selfcontrolapp.com/) - Website Blocker
* [Typist](https://apps.apple.com/us/app/typist/id415166115?ign-mpt=uo%3D4&mt=12) - Typing Practice
* [Sink It](https://apps.apple.com/us/app/sink-it-for-reddit/id6449873635) - Improved Reddit Comment Navigation
* [Grayscale Mode](https://github.com/rkbhochalya/grayscale-mode) - Grayscale Control
* [macOSicons](https://macosicons.com/) - macOS App Icons
* [equinux](https://equinux.github.io/) - OS X Certificate Fix
* [Lilu](https://github.com/acidanthera/Lilu) - Kext / Process Patcher
* [TopNotch](https://topnotch.app/) - Hide the Notch on MacBooks

***

## ▷ Software Sites

* 🌐 **[Awesome macOS](https://github.com/iCHAIT/awesome-macOS)**, [OpenSourceApple](https://opensource.apple.com/), [Awesome Mac](https://github.com/jaywcjlove/awesome-mac) or [Awesome OS Apps](https://github.com/serhii-londar/open-source-mac-os-apps) - FOSS App Indexes
* 🌐 **[Mac Menu Bar](https://macmenubar.com/)** - Menu Bar App Index
* ⭐ **[Homebrew](https://brew.sh/)** / [GUI](https://github.com/Homebrew/BrewUI), [2](https://github.com/buresdv/Cork/) / [Casks GUI](https://github.com/alielsokary/CaskHub) / [X](https://x.com/MacHomebrew), [Munki](https://www.munki.org/munki/), [MacApps](https://macapps.link/en/) or [Applite](https://applite.app/) - Package Managers
* ⭐ **[AppsTorrent](https://appstorrent.ru/)** - Downloads (not torrents) / Login Required for some Files
* [nMac](https://nmac.to/)
* [MacBB](https://macbb.org/)
* [Antibiotic's](https://t.me/AntibioticsChannel)
* [MacKed](https://macked.app/)
* [TorrentMac](https://www.torrentmac.net/) - **Use Adblock**
* [Macintosh Garden](https://macintoshgarden.org/) - Oldschool Software
* [MacintoshRepository](https://www.macintoshrepository.org/) - Oldschool Software
* [⁠OldAppleStuff](https://oldapplestuff.com/) - Oldschool Software + Apple II Software
* [ThriftMac](https://thriftmac.com/) - Freeware
* [Sindre Sorhus](https://sindresorhus.com/apps/free) - Freeware

***

## ▷ Mac Video

* ↪️ **[Streaming Apps](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25BA_streaming_apps)** / **[Torrent Streaming](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25BA_streaming_apps)**
* ↪️ **[Media Servers / Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video-tools#wiki_.25BA_media_servers)**
* ↪️ **[Editing Software](https://rentry.co/FMHYB64#quick-guide)**
* [IINA](https://iina.io/) - Video Player / [GitHub](https://github.com/iina/iina)
* [⁠Unwatched](https://apps.apple.com/app/unwatched-para-youtube/id6477287463) / [GitHub](https://github.com/fer0n/Unwatched) or [Yattee](https://github.com/yattee/yattee) - YouTube Players
* [REAL Video Enhancer](https://github.com/TNTwise/REAL-Video-Enhancer) - Video Upscaling / [Discord](https://discord.com/invite/mRReVBMQtN)
* [Cap](https://cap.so/) / [X](https://x.com/cap) / [Discord](https://discord.gg/y8gdQ3WRN3) / [GitHub](https://github.com/CapSoftware/Cap), [Kap](https://getkap.co) / [GitHub](https://github.com/wulkano/kap), [⁠Tight Studio](https://tight.studio/) / [Subreddit](https://www.reddit.com/r/TightStudio/) / [X](https://x.com/tight_studio) / [Discord](https://discord.gg/zNXQjXSJrJ) or [ScreenTimeLapse](https://github.com/wkaisertexas/ScreenTimeLapse) - Screen Recorders

***

## ▷ Mac Audio

* ⭐ **[SpotX-Bash](https://github.com/SpotX-Official/SpotX-Bash)** - Spotify Adblockers
* ⭐ **[Spicetify](https://spicetify.app/)** - Spotify Themes & Plugins / [Improved Lyrics](https://spicylyrics.org/) / [Discord](https://discord.gg/VnevqPp2Rr) / [GitHub](https://github.com/spicetify/cli) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/spicetify-note.md)
* [foobar2000](https://www.foobar2000.org/mac) or [VOX Mac Music Player](https://vox.rocks/mac-music-player) - Audio Players
* [cliamp](https://www.cliamp.stream/) - TUI Audio Player / [GitHub](https://github.com/bjarneo/cliamp)
* [Silicio](https://apps.apple.com/us/app/silicio-mini-player/id933627574) - Audio Mini Player
* [Alfred Spotify Mini Player](https://alfred-spotify-mini-player.com/) - Spotify Mini Player
* [SoundSeer](https://github.com/jonathangarelick/SoundSeer) - Spotify in Menu Bar
* [TheBoringNotch](https://theboring.name/) - Turn Notch into Audio Controller / Calendar / [Discord](https://discord.gg/GvYcYpAKTu) / [GitHub](https://github.com/TheBoredTeam/boring.notch/)
* [⁠Kaset](https://github.com/sozercan/kaset/) - YouTube Music Clients
* [Nuage](https://github.com/lbrndnr/nuage-macos) - SoundCloud Client
* [Garageband](https://apps.apple.com/us/app/garageband/id682658836?mt=12) - Audio Editor
* [EQMac](https://eqmac.app/) or [CoreEQ](https://github.com/andreypudov/core-eq) - Audio Equalizer
* [The Levelator](https://archive.org/details/conversationsnetwork_org-levelator) - Automatic Audio Level Adjustments
* [⁠Silkwave Clarity](https://www.silkwave.ai/silkwave-clarity) - Noise Suppression Software
* [Guitarix](https://guitarix.org/) - Virtual Guitar Amplifier / [Plugins](https://github.com/brummer10/GxPlugins.lv2)
* [XLD](https://sourceforge.net/projects/xld/) - Lossless Audio Transcoder
* [BlackHole](https://github.com/ExistentialAudio/BlackHole) - Pass Audio to Apps
* [Cuterdio](https://cuterdio.com/en) - Radio
* [Playlisty](https://apps.apple.com/us/app/playlisty-the-playlist-tool/id1459275972) - Transfer Apple Music Playlists to Spotify

***

## ▷ Mac Image

* ↪️ **[Mac Image Editors](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25B7_editing_software)**
* ↪️ **[Editing Software](https://rentry.co/FMHYB64#quick-guide)**
* [Gifski](https://sindresorhus.com/gifski) - Image to GIF Converter / [GitHub](https://github.com/sindresorhus/Gifski)
* [ImageOptim](https://imageoptim.com/mac) - Image Optimization
* [Perspec](https://github.com/ad-si/Perspec) - Correct Perspective of Images
* [Draw Things](https://apps.apple.com/us/app/draw-things-ai-generation/id6444050820) - AI Image Drawing Tool

***

## ▷ Mac Gaming

* ⭐ **[Torrminatorr](https://forum.torrminatorr.com/)** - Mac Games / Requires Sign-Up
* ⭐ **[AppsTorrent](https://appstorrent.ru/games/)** - Mac Games / Downloads (not torrents) / Login Required for some Files
* ⭐ **[CrossOver](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_software_sites2)** (search) - Run Windows Games on Mac
* ⭐ **[AppleGamingWiki](https://applegamingwiki.com/)** or [Mac Gaming DB](https://macgamingdb.app/) - Mac Game Fixes / Compatibility / [Discord](https://discord.gg/28CAAr6SpB)
* [CS.RIN.RU](https://cs.rin.ru/forum) - Mac Games / Sign-Up / PW: `cs.rin.ru / csrin.org` / [.onion](http://csrinrutkb3tshptdctl5lyei4et35itl22qvk5ktdcat6aeavy6nhid.onion/forum)
* [SCNLOG](https://scnlog.me/games/mac/) - Mac Games
* [RuTracker](https://rutracker.org/forum/viewforum.php?f=960) - Mac Games / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent#wiki_.25BA_torrent_sites)
* [appnetica](https://appnetica.com/?platform=mac) - Mac Games
* [MacintoshRepository](https://www.macintoshrepository.org/games/) - Oldschool Mac Games
* [MacSteam](https://github.com/crghofficial/macsteam) - Steam Game + DLC Unlocker
* [Mac Source Ports](https://www.macsourceports.com/) - Run Old Mac Games
* [PortingKit](https://www.portingkit.com/) - Run Windows Games on Mac
* [PlayOnMac](https://www.playonmac.com/en/) - Run Windows Games on Mac
* [⁠Highball](https://github.com/gauthierpiarrette/highball) - Run Windows Games on Apple Silicon
* [⁠Sikarugir](https://github.com/Sikarugir-App/Sikarugir) - Create Wine Wrapped Game Ports for Mac
* [⁠MacNativeGames](https://github.com/ly05010419/MacNativeGames) or [nxnative](https://github.com/seedds/nxnative) - Run Switch Games on macOS
* [Heroic Games Launcher](https://heroicgameslauncher.com/) - Epic / GOG / Prime Games Launcher / [Discord](https://discord.com/invite/rHJ2uqdquK) / [GitHub](https://github.com/Heroic-Games-Launcher/HeroicGamesLauncher)
* [Mythic](https://getmythic.app/) - Epic Games Launcher / [Discord](https://discord.gg/58NZ7fFqPy)
* [⁠MetalGoose](https://github.com/Stallion77RepoOfficial/MetalGoose) - Frame Generation + Upscaling Tool
* [r/MacGaming](https://www.reddit.com/r/macgaming/) - Mac Gaming Community / [Discord](https://discord.gg/MgJsb5m)
* [cemu.emiyl](https://cemu.emiyl.com/) - CEMU Compatibility List

***

# ► Mac Tools

## ▷ Mac Adblock / Privacy

* 🌐 **[Awesome OSX Security](https://github.com/ashishb/osx-and-ios-security-awesome)** - Mac Security Resources
* ↪️ **[Mac 2FA](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25B7_password_privacy_.2F_2fa)**
* ↪️ **[Adblocking Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy)**
* ↪️ **[DNS Adblocking](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25B7_dns_adblocking)**
* ⭐ **[Malwarebytes](https://www.malwarebytes.com/mac-download)**, [ESET](https://rentry.co/FMHYB64#eset), [BlockBlock](https://objective-see.org/products/blockblock.html) or [KnockKnock](https://objective-see.org/products/knockknock.html) - Antivirus
* [⁠uBO Lite Safari](https://apps.apple.com/app/ublock-origin-lite/id6745342698) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/ubo-lite.md), [AdGuard Mini](https://adguard.com/en/adguard-safari/overview.html) / [Guide](https://avieshek.wordpress.com/2024/07/07/how-to-filter-ads-and-block-popups-on-iphone-and-macos/) / [2](https://justpaste.it/adguard) or [wBlock](https://skula.me/project/wblock/) / [Discord](https://discord.com/invite/Y3yTFPpbXr) / [GitHub](https://github.com/0xCUB3/wBlock) - Safari Adblockers
* [Gas Mask](https://github.com/2ndalpha/gasmask) - Block Ads via Host Files
* [macOS Privacy Guide](https://github.com/drduh/macOS-Security-and-Privacy-Guide) - Mac Privacy & Security Guides
* [⁠ClashMac](https://github.com/666OS/ClashMac) - Proxy Client
* [DNS Party](https://encrypted-dns.party/) - Encrypted DNS Profiles
* [LuLu](https://objective-see.org/products/lulu.html) - Mac Firewall / [GitHub](https://github.com/objective-see/LuLu)
* [RansomWhere?](https://objective-see.org/products/ransomwhere.html) - Ransomware Blocker
* [OverSight](https://objective-see.org/products/oversight.html) - Webcam / Mic Monitor
* [SuspiciousPackage](https://www.mothersruin.com/software/SuspiciousPackage/get.html) - Analyze PKG Files
* [Santa](https://github.com/northpolesec/santa) - Binary Authorization System
* [DHS](https://objective-see.org/products/dhs.html) - Dylib Hijack Scanner
* [GPG Suite](https://gpgtools.org/) - Encrypt & Sign Data / Communications
* [What's Your Sign?](https://objective-see.org/products/whatsyoursign.html) - View File Cryptographic Signatures
* [Tracker Zapper](https://rknight.me/apps/tracker-zapper/) - Remove URL Tracking Elements
* [LinkLiar](https://halo.github.io/LinkLiar/) - Spoof MAC Address
* [Kextviewr](https://objective-see.org/products/kextviewr.html) - View All Kernel Modules
* [mac_apt](https://github.com/ydkhatri/mac_apt) - Artifact Parsing Tool
* [Tunnelblick](https://tunnelblick.net/) or [Passepartout](https://partout.io/passepartout/) - VPN Tunnel
* [MailTrackerBlocker](https://apparition47.github.io/MailTrackerBlocker/) - Privacy-Based Email Client
* [Status](https://status.app/) - Encrypted Messaging Client

***

## ▷ Mac Internet

* ↪️ **[Mac Torrent Clients](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent#wiki_.25BA_torrent_clients)**
* ↪️ **[Mac Password Managers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools#wiki_.25B7_password_managers)**
* [What Route](https://whatroute.net/) - Network Diagnostic Tool
* [ElectronMail](https://github.com/vladimiry/ElectronMail) - Email Client
* [Browserino](https://github.com/AlexStrNik/Browserino) - Browser Prompter
* [Orion](https://orionbrowser.com/) - Browser with Chrome + Firefox Extension Support / [Discord](https://discord.gg/Yk8Aj8AxGw)

***

## ▷ System Tools

* 🌐 **[AppleDB](https://appledb.dev/)** - Apple Device / Software Info Database
* 🌐 **[Mac Menu Bar](https://macmenubar.com/)** - Menu Bar App Directory
* ⭐ **[⁠Vorssaint](https://vorssaint.com/)** - Menu Bar Toolkit / [X](https://x.com/vorssaint) / [GitHub](https://github.com/vorssaint/vorssaint-utils)
* ⭐ **[Alfred](https://www.alfredapp.com/)**, [Raycast](https://www.raycast.com/) / [FMHY Search](https://www.raycast.com/akshit_mehta/fmhy-search), [Albert](https://albertlauncher.github.io/) / [GitHub](https://github.com/albertlauncher/albert), [Quicksilver](https://qsapp.com/), [⁠Tinycast](https://tinycast.dev/), [KeyboardCowboy](https://github.com/zenangst/KeyboardCowboy) or [SOL](https://sol.ospfranco.com/) - Keystroke Launchers / Spotlight Replacements / [Alfred Workflows / Themes](https://www.packal.org/)
* ⭐ **[CustomShortcuts](https://www.houdah.com/customShortcuts/)**, [Karabiner-Elements](https://karabiner-elements.pqrs.org/) or [ShortcutKeeper](https://shortcutkeeper.com/) - Custom Keyboard Shortcuts
* [⁠Mac Terminal for Humans](https://www.macterminal.cc/commands) - macOS Terminal Cheat Sheet
* [MuMuPlayer](https://www.mumuplayer.com/), [NoxPlayer](https://www.bignox.com/) or [Genymotion](https://www.genymotion.com/download/) - Android on macOS
* [Advanced macOS Commands](https://saurabhs.org/advanced-macos-commands) - Advanced Command-Line Tools
* [Conky](https://conky.cc/) / [GitHub](https://github.com/brndnmtthws/conky), [Stats](https://mac-stats.com/) / [GitHub](https://github.com/exelban/stats), [Mission Center](https://gitlab.com/mission-center-devs/mission-center) or [MacFetch](https://github.com/gantoreno/macfetch) - Hardware / System Monitors / [Conky Colors](https://github.com/helmuthdu/conky_colors)
* [Hot](https://github.com/macmade/hot) - CPU Monitor
* [TaskExplorer](https://objective-see.org/products/taskexplorer.html) - Task Manager / Viewer
* [Mole](https://github.com/tw93/Mole) - System Cleanup / Optimization Multi-Tool
* [Pearcleaner](https://itsalin.com/appInfo/?id=pearcleaner) - System Cleanup / Uninstaller / [GitHub](https://github.com/alienator88/Pearcleaner)
* [BetterDisplay](https://github.com/waydabber/BetterDisplay) - Display Controller / Custom Resolutions / HDR Control
* [DisplayPlacer](https://github.com/jakehilborn/displayplacer) - Dual Monitor Manager
* [OpenDisplay](https://opendisplay.app/) - Use iOS Device as Secondary macOS Monitor / [GitHub](https://github.com/peetzweg/opendisplay)
* [⁠EasyDMG](https://github.com/jeff-schumann/EasyDMG) - Automated DMG Installation Tool
* [KeyPad](https://apps.apple.com/in/app/keypad-bluetooth-keyboard/id1491684442) - Connect Mac Keyboard to Mobile Devices
* [Mos](https://mos.caldis.me/) / [GitHub](https://github.com/Caldis/Mos/blob/master/README.enUS.md), [LinearMouse](https://linearmouse.app/) or [MacMouseFix](https://macmousefix.com/) - Mouse Remapping / Smooth Scrolling
* [Pinch](https://github.com/danqing/Pinch) - Trackpad Pinch to Zoom Gesture
* [MiddleClick](https://github.com/artginzburg/MiddleClick) - Middle / Scroll Click via 3 Finger Tap
* [Scroll Reverser](https://pilotmoon.com/scrollreverser/) - Per-Device Scroll Settings
* [ProperTree](https://github.com/corpnewt/ProperTree) - GUI Plist Editor
* [macOS defaults](https://macos-defaults.com/) - macOS defaults Commands List / [GitHub](https://github.com/yannbertrand/macos-defaults)
* [KeyClu](https://sergii.tatarenkov.name/apps/keyclu/) - Shortcut CheatSheet for Current Application
* [KeyCastr](https://github.com/keycastr/keycastr) - Keystroke Visualizer
* [⁠FineTune](https://github.com/ronitsingh10/FineTune) - Volume Mixer / Per App Volume Control / Routing / EQ / Booster
* [MonitorControl](https://monitorcontrol.app/) - External Monitor Brightness / Volume Control
* [BackgroundMusic](https://github.com/kyleneideck/BackgroundMusic) - Volume Mixer / Auto-Pause
* [MacThrottle](https://github.com/angristan/MacThrottle) - Menu Bar Thermal Throttling Tracker
* [BatteryBuddy](https://batterybuddy.app/) - Cute Battery Indicator
* [AirBattery](https://github.com/lihaoyun6/AirBattery) or [CoconutBattery](https://www.coconut-flavour.com/coconutbattery/) - Device Battery Trackers
* [Macs Fan Control](https://github.com/crystalidea/macs-fan-control) - Fan Controller
* [WhatCable](https://whatcable.uk/) - Cable Capability Identifier / [GitHub](https://github.com/darrylmorley/whatcable)
* [Touché](https://redsweater.com/touche/) - Touch Bar Simulator
* [Sentinel](https://github.com/alienator88/Sentinel) - SwiftUI Gatekeeper Config GUI
* [⁠Nigate](https://github.com/hoochanlon/Free-NTFS-for-Mac) - NTFS Drive Read-Write Access + Mounting Tool
* [USBMap](https://github.com/corpnewt/USBMap) - Map macOS USB Ports
* [Actions](https://sindresorhus.com/actions) - Additional Shortcuts App Actions
* [Übersicht](https://tracesof.net/uebersicht/) - System Command Widgets
* [Itsycal](https://www.mowglii.com/itsycal/) - Menu Bar Calendar
* [Clocker](https://abhishekbanthia.com/clocker/) or [MeetingBar](https://meetingbar.app/) - Menu Bar Meetings Calendars
* [⁠Thaw](https://github.com/thaw-app/Thaw) - Menu Bar Manager
* [OnlySwitch](https://github.com/jacklandrin/OnlySwitch) - Menu Bar Toggle Switches
* [Sloth](https://github.com/sveinbjornt/Sloth) - Process Manager
* [Amphetamine](https://apps.apple.com/app/amphetamine/id937984704) - Prevent Sleep Mode / Highly Configurable
* [KeepingYouAwake](https://github.com/newmarcel/KeepingYouAwake) - Prevent Sleep Mode / Lightweight
* [Yabai](https://github.com/koekeishiya/yabai), [Amethyst](https://ianyh.com/amethyst/) / [GitHub](https://github.com/ianyh/Amethyst), [AeroSpace](https://github.com/nikitabobko/AeroSpace), [1Piece](https://app1piece.com/), [Loop](https://github.com/MrKai77/Loop), [Phoenix](https://kasper.github.io/phoenix/) or [Rectangle](https://rectangleapp.com/) - Window Managers
* [Maccy](https://maccy.app/), [ClipBook](https://clipbook.app/), [ClipPocket](https://github.com/dhahd/ClipPocket) - Clipboard Managers
* [Pictogram](https://pictogramapp.com/), [macOSicons](https://macosicons.com/) / [Discord](https://discord.gg/f4mTRyyTkT) or [IconChamp](https://www.macenhance.com/iconchamp.html) - Custom App Icons
* [Tintd](https://www.tintd.app/) - Change Folder Colors
* [MacPaper](https://github.com/naomisphere/macpaper/) - Mac Wallpaper Manager
* [Dynamic Wallpaper Club](https://dynamicwallpaper.club/) - Dynamic Wallpaper App / [Gallery](https://dynamicwallpaper.club/gallery)
* [wallpapper](https://github.com/mczachurski/wallpapper) or [Equinox](https://equinoxmac.com/) - Dynamic Wallpaper Creators
* [Plash](https://sindresorhus.com/plash) - Use Website as Wallpaper
* [DarkModeBuddy](https://github.com/insidegui/DarkModeBuddy) or [ThemeKit](https://github.com/luckymarmot/ThemeKit) - System Dark Mode Apps
* [⁠RemoveMacAI](https://github.com/omlahore/RemoveMacAI) - Script to turn off Apple Intelligence
* [Magic Trace](https://github.com/janestreet/magic-trace) - Performance Analysis with Intel PT

***

## ▷ File Tools

* ⭐ **[PeaZip](https://peazip.github.io/peazip-macos.html)** / [GitHub](https://github.com/peazip/PeaZip/), [⁠ShichiZip](https://github.com/idawnlight/ShichiZip), [The Unarchiver](https://theunarchiver.com/), [unxip](https://github.com/saagarjha/unxip) or [Keka](https://www.keka.io/en/) - File Archivers
* ⭐ **[Readdle](https://readdle.com/documents)** - Multipurpose File Tool
* [⁠Sushitrain](https://github.com/pixelspark/sushitrain) - iOS + macOS File Sync / SyncThing
* [Neodisk](https://neodisk.app/) - Disk Usage Analyzer / [GitHub](https://github.com/tkslucas/Neodisk)
* [OpenMTP](https://openmtp.ganeshrvel.com/) - macOS / Android File Transfer / [GitHub](https://github.com/ganeshrvel/openmtp)
* [Progress](https://github.com/Xfennec/progress) - Show Copied Data Progress
* [Bruji](https://www.bruji.com/) - Media Cataloging Software Suite
* [superfile](https://superfile.dev/) - Terminal File Manager / [GitHub](https://github.com/yorukot/superfile)
* [macFUSE](https://macfuse.github.io/) - Mac File Integration / [GitHub](https://github.com/macfuse/macfuse)
* [JDownloader](https://jdownloader.org/) - File Download Manager / [Debloat](https://clarasguide.valeena.workers.dev/Guides/jdownloader2/) / [Dark Theme](https://redd.it/q3xrgj), [2](https://github.com/moktavizen/material-darker-jdownloader/) / [Dracula Theme](https://draculatheme.com/jdownloader2)
* [Go Speed](https://gopeed.com/) - File Download Manager / [Extension](https://github.com/GopeedLab/browser-extension) / [Plugins](https://github.com/search?q=topic%3Agopeed-extension&type=repositories) / [GitHub](https://github.com/GopeedLab/gopeed)
* [Progressive Downloader](https://macpsd.net/) - File Download Manager
* [Transnomino](https://www.transnomino.com/) - Bulk File / Folder Renaming
* [fzf](https://github.com/junegunn/fzf), [⁠Television](https://github.com/alexpasmantier/television) or [skim](https://github.com/skim-rs/skim) - Fuzzy Finders
* [FlyingCarpet](https://github.com/spieglt/FlyingCarpet) - Cross-Platform AirDrop / [Guide](https://redd.it/vthltc)

***

# ► Unix-Like

* 🌐 **[Awesome-ttygames](https://github.com/ligurio/awesome-ttygames)** - Unix ASCII Games
* 🌐 **[Awesome BSD](https://github.com/DiscoverBSD/awesome-bsd)** - BSD Resources
* 🌐 **[Hardware for BSD](https://bsd-hardware.info/)** - BSD Hardware Compatibility Database / [GitHub](https://github.com/bsdhw/)
* [UnitedBSD](https://www.unitedbsd.com/) - BSD Forum / Community
* [FreeBSD Wiki](https://wiki.freebsd.org/) - FreeBSD Wiki / Guides / [Docs](https://docs.freebsd.org/en/books/handbook/)
* [Pkgs](https://pkgs.org/) - Searchable Unix-Like Package Database
* [GameShell](https://github.com/phyver/GameShell) - Unix Shell Learning Game
* [Modern Unix](https://github.com/ibraheemdev/modern-unix) - Unix Shells
* [wpgtk](https://deviantfero.github.io/wpgtk) - Fully Customizable Unix Color Schemer
* [Plan9Port](https://9fans.github.io/plan9port/) - Unix Port for Plan9 Libraries + Programs / [GitHub](https://github.com/9fans/plan9port)
* [⁠Is OpenBSD Secure?](https://isopenbsdsecu.re/) - Learn About OpenBSD Security Flaws