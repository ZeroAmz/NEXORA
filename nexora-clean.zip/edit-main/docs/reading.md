***
***
**[◄◄ Back to Wiki Index](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/index)**
***
***

# ► Ebooks

* 🌐 **[Open Slum](https://open-slum.org/)**, [2](https://open-slum.pages.dev/) - Book Site Index / Uptime Tracking
* ⭐ **[Anna's Archive](https://annas-archive.gl/)**, [2](https://annas-archive.pk), [3](https://annas-archive.gd) - Books / Comics / [Mirrors](https://en.wikipedia.org/wiki/Anna's_Archive) / [Deploy Locally](https://software.annas-archive.gl/AnnaArchivist/annas-archive) / [Matrix](https://matrix.to/#/#annas:archivecommunication.org) / [Subreddit](https://www.reddit.com/r/Annas_Archive/)
* ⭐ **[Z-Library](https://z-lib.gd/)**, [2](https://z-library.sk/), [3](https://1lib.sk/), [4](https://z-lib.fm/), [5](https://articles.sk/), [6](https://z-library.im/), [7](https://z-lib.sk/), [8](https://z-library.qa/), [9](https://z-library.gy/) - Books / Comics / [Apps / Extensions](https://go-to-library.sk/), [2](https://playtorrio.xyz/) / [.onion](http://loginzlib2vrak5zzpcocc3ouizykn6k5qecgj2tzlnab5wcbqhembyd.onion/), [2](http://bookszlibb74ugqojhzhg2a63w5i2atv5bqarulgczawnbmsb6s6qead.onion/) / [Subreddit](https://www.reddit.com/r/zlibrary/)
* ⭐ **[Mobilism](https://forum.mobilism.org)**, [2](https://forum.mobilism.me/) - Books / Audiobooks / Magazines / Newspapers / Comics / [Ranks](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/mobilism-ranks.md)
* ⭐ **[MyAnonaMouse](https://www.myanonamouse.net/)** - Books / Audiobooks / Comics / Sheet Music / Torrents / [Requires Invite](https://www.myanonamouse.net/inviteapp.php)
* ⭐ **[Library Genesis](https://libgen.li/)**, [2](https://libgen.gl/) - Books / Comics / Manga / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_libgen_tools) / [Mirrors](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage/#wiki_libgen_mirrors) / [Subreddit](https://reddit.com/r/libgen)
* ⭐ **[Unglue.it](https://unglue.it/)** - Books
* [JustFreeBooks](https://www.justfreebooks.info/), [Reading CSE](https://cse.google.com/cse?cx=006516753008110874046:s9ddesylrm8) / [2](https://cse.google.com/cse?cx=006516753008110874046:rc855wetniu) / [3](https://cse.google.com/cse?cx=e9657e69c76480cb8) / [4](https://cse.google.com/cse?cx=c46414ccb6a943e39) or [Recherche](https://recherche-ebook.fr/en/) - Multi-Site Book Search
* [Internet Archive](https://archive.org/details/texts) - Books / Audiobooks / Magazines / Newspapers / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage/#wiki_internet_archive_tools)
* [Open Library](https://openlibrary.org/) - Books / [GitHub](https://github.com/internetarchive/openlibrary)
* [WeLib](https://welib.org/) / [2](https://welib.st/) - Anna's Archive Mirror / Account Required for Downloads / [Unofficial](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/welib-note.md)
* [BookSee](https://en.booksee.org/) - Book Search / Download
* [BDeBooks](https://bdebooks.com/en/ebooks/) - Books / Download
* [⁠eBookoz](https://ebookoz.net/) - Books / Download / Forum
* [Manybooks](https://manybooks.net/) - Books
* [Bookstagram](https://vk.com/bookstagram_eng) - Books / Magazines / VK
* [dpgroup](https://www.dpgroup.org/) - Books / Magazines / Sign-Up
* [BAEN](https://www.baen.com/allbooks/category/index/id/2012)
* [Read From](https://readfrom.net/) or [BookFrom.net](https://www.bookfrom.net/) - Books / Online Reading
* [NovelsArchive](https://t.me/NovelsArchive) - Books / Telegram
* [⁠Dynasty](https://t.me/dynastyapprovals) - Books / Telegram
* [eBooks1001](https://ebooks1001.com/) - Books / Download / Requires [Debrid](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/download#wiki_.25BA_debrid_.2F_leeches)
* [FreeBannedBooks](https://freebannedbooks.org/) - US Banned Books
* [⁠Inventaire](https://inventaire.io/) - Community Library / Book Lending
* [⁠Shelfmark](https://github.com/calibrain/shelfmark) - Ebook Downloader
* [⁠Mayberry](https://joinmayberry.com/) - Ebook Sharing Network / Downloader
* [calibre](https://calibre-ebook.com/) - Plugin-Based Book Downloader / Manager / [Libraries / Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/reading#wiki_.25B7_calibre_libraries) / [GitHub](https://github.com/kovidgoyal/calibre)
* [Flibusta](https://flibusta.is/) / [.i2p](https://flibusta.i2p/), [2](http://zmw2cyw2vj7f6obx3msmdvdepdhnw2ctc4okza2zjxlukkdfckhq.b32.i2p/) - Russian Ebook Library / Sign-Up / Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators)
* [The Free Book Library](https://ebooks.i2p/) - Requires I2P
* [r/FreeEBOOKS](https://reddit.com/r/FreeEBOOKS) - Ebook Subreddit
* [⁠RaveBSD](https://ravebooksearch.com/) - Self-Hostable Book Search Engine
* [Book Search Guide](https://docs.google.com/document/d/1ZwWs8JOrlkrrqiHwkQSwc4_NM85Zbzc9t9ifQ1rHZgM/mobilebasic) - Guide to Finding Articles / Books
* <irc://irc.irchighway.net/ebooks> / [Request Guide](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/irc-highway-note.md)
* IRC Book Tools - [Guide](https://www.reddit.com/r/Piracy/comments/2oftbu/guide_the_idiot_proof_guide_to_downloading_ebooks/) / [mIRC](https://redd.it/znprct) / [Downloader](https://evan-buss.github.io/openbooks/)

***

## ▷ Public Domain

* ⭐ **[Project Gutenberg](https://www.gutenberg.org/)** or [Lex](https://lex-books.com/) - Historical Fiction / Nonfiction / [Australia](https://gutenberg.net.au/) / [Canada](https://gutenberg.ca/index.html) / [Nordic](https://runeberg.org/)
* [Wikisource](https://wikisource.org)
* [Standard EBooks](https://standardebooks.org/)
* [Global Grey](https://www.globalgreyebooks.com/index.html)
* [The Literature Network](https://www.online-literature.com/)
* [DPLA](https://dp.la/)
* [Fadedpage](https://www.fadedpage.com/)
* [E-Book Mecca](https://ebook-mecca.com/)
* [Loyal Books](https://www.loyalbooks.com/)
* [⁠By the Fireplace](https://bythefireplace.com/) - Classics
* [DigiLibraries](https://digilibraries.com/) - Classics
* [ExClassics](https://www.exclassics.com/) - Obscure Books
* [The H.P. Lovecraft Archive](https://www.hplovecraft.com/) - Complete H.P. Lovecraft Writings Archive
* [sherlock-holm.es](https://sherlock-holm.es/) - Complete Sherlock Holmes Canon
* [GrimmStories](https://www.grimmstories.com/) or [AndersenStories](https://www.andersenstories.com/) - Fairy Tales
* [Public Domain Review](https://publicdomainreview.org/) - Reviews / Essays of Public Domain Material
* [⁠Distributed Proofreaders](https://www.pgdp.net/) - Help Digitize Public Domain Books to Ebooks

***

## ▷ PDF Search

* ⭐ **[OceanOfPDF](https://oceanofpdf.com/)** - Books / Comics
* [pdfroom](https://pdfroom.com/) - Books / Comics
* [Ebook PDF](https://ebookpdf.com/) - Books
* [KuPDF](https://kupdf.net/) - Books
* [ePDF](https://epdf.pub/), [2](https://epdf.pub/) - Books
* [PDFCoffee](https://pdfcoffee.com) - Books
* [PDFCookie](https://pdfcookie.com/) - Books
* [iDoc](https://idoc.tips/) - Books
* [AWS S3](https://www.google.com/search?q=site%3As3.amazonaws.com+%3CSearch+term%3E+filetype%3Apdf) - Find PDFs on AWS

***

## ▷ Calibre Libraries

* ↪️ **[Calibre Libraries](https://rentry.co/FMHYB64#calibre-libraries)** - Requires Sign-Up
* ⭐ **[Ebook-Translator](https://translator.bookfere.com)** - Calibre Translators
* [Libgen for Calibre](https://github.com/poochinski9/libgen-calibre-store-plugin) - Libgen for Calibre
* [opencalibre](https://reddit.com/r/opencalibre) - Community Shared Calibre Libraries
* [Calibre-Web-Automated](https://github.com/crocodilestick/Calibre-Web-Automated) or [Calibre Web](https://github.com/janeczku/calibre-web) - Calibre Web Apps
* [acsm-calibre-plugin](https://github.com/Leseratte10/acsm-calibre-plugin) - ACSM Plugin

***

## ▷ Ebook Readers

* 🌐 **[Ebook Reader Index](https://wiki.mobileread.com/wiki/E-book_software)** or [Mobile Read](https://www.mobileread.com/) - Ebook Reader Indexes
* ↪️ **[Android](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25BA_android_reading) / [iOS](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25BA_ios_reading)** - Mobile Ebook Readers
* ⭐ **[Readest](https://readest.com/)** - Ebook Reader / All Platforms / [Subreddit](https://reddit.com/r/readest) / [Discord](https://discord.gg/gntyVNk3BJ) / [GitHub](https://github.com/readest/readest)
* ⭐ **[KOReader](https://koreader.rocks/)** - Ebook Reader / Linux, Android / [Plugins](https://kindlemodshelf.me/plugins), [2](https://github.com/koreader/contrib), [3](https://omer-faruq.github.io/koreader-plugin-index/) / [Settings Guide](https://rentry.co/koreadersettings) / [GitHub](https://github.com/koreader/koreader)
* ⭐ **[Koodo](https://www.koodoreader.com/)** - Ebook Reader / All Platforms / [GitHub](https://github.com/koodo-reader/koodo-reader)
* ⭐ **[Sumatra PDF](https://www.sumatrapdfreader.org/free-pdf-reader)** - Ebook & PDF Reader / Windows / [GitHub](https://github.com/sumatrapdfreader/sumatrapdf)
* [Sioyek](https://sioyek.info/) - PDF Reader / Windows, macOS, Linux / [GitHub](https://github.com/ahrm/sioyek)
* [Foxit](https://www.foxit.com/pdf-reader/) - PDF Reader / All Platforms / [Features](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/download#wiki_.25BA_software_sites)(search) / [Warning](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/foxit-critical.md)
* [⁠BookOrbit](https://bookorbit.app/) / [GitHub](https://github.com/bookorbit/bookorbit) or [⁠Grimmory](https://grimmory.org/) / [GitHub](https://github.com/grimmory-tools/grimmory) - Ebook Managers / Readers / Self-Hosted
* [PlayTorrio](https://playtorrio.xyz/), [2](https://playtorrio.pages.dev/) - Ebook Reader / Windows, macOS, Linux, Android, iOS / [Subreddit](https://www.reddit.com/r/PlayTorrio/) / [Discord](https://discord.gg/bbkVHRHnRk)
* [EBook Reader](https://epub-reader.online/) - Ebook Reader / Windows, macOS, Android, iOS
* [Jane Reader](https://janereader.com/) - Ebook Reader / Windows, macOS
* [FBReader](https://fbreader.org/) - Ebook Reader / Windows, Android, iOS
* [Anx Reader](https://anx.anxcye.com/) - Ebook Reader / Windows, macOS, Android, iOS / [GitHub](https://github.com/anxcye/anx-reader)
* [Alexandria](https://github.com/btpf/Alexandria) - Ebook Reader / Windows, macOS, Linux
* [Librum](https://librumreader.com) - Ebook Reader / Windows, macOS, Linux / [GitHub](https://github.com/Librum-Reader/Librum)
* [Thorium](https://www.thoriumreader.com/) - Ebook Reader / Windows, macOS, Linux / [Discord](https://discord.com/invite/84wgWhFKDY) / [GitHub](https://github.com/edrlab/thorium-reader/)
* [Okular](https://okular.kde.org/) - PDF Reader / Windows, macOS, Linux / [GitLab](https://invent.kde.org/graphics/okular)
* [Aquile Reader](https://www.aquilereader.in/) - Ebook Reader / Windows, Android
* [Icecream Reader](https://icecreamapps.com/Ebook-Reader/) - Ebook Reader / Windows
* [Foliate](https://johnfactotum.github.io/foliate/) - Ebook Reader / Linux / [GitHub](https://github.com/johnfactotum/foliate)
* [qPDFview](https://launchpad.net/qpdfview) - PDF Reader / Windows, Linux / [Source Code](https://git.launchpad.net/qpdfview)
* [MuPDF](https://mupdf.com/) - PDF Reader / Windows, Linux, Android
* [⁠Zathura](https://pwmt.org/projects/zathura/) - PDF Reader / Linux / [GitHub](https://github.com/pwmt/zathura)
* [Evince](https://apps.gnome.org/Evince/) - PDF / DjVu Reader / Linux / [GitLab](https://gitlab.gnome.org/GNOME/evince)
* [Yomu](https://www.yomu-reader.com/) - Ebook Reader / macOS, iOS
* [WinDjView](https://windjview.sourceforge.io/) - DjVu Reader / Windows
* [DjVuLibre](https://djvu.sourceforge.net/) - DjVu Reader / Windows
* [Bookworm](https://github.com/babluboy/bookworm) - Elementary OS Ebook Reader
* [AnyFlip](https://anyflip.com/) - Interactive Flipbook Reader

***

## ▷ Browser Ebook Readers

* ⭐ **[Reader View](https://webextension.org/listing/chrome-reader-view.html)**, [2](https://mybrowseraddon.com/reader-view.html)
* ⭐ **[Google Play Books](https://play.google.com/books)** - Manage Books / Auto Metadata / Allows 1000 Uploads
* [Anna’s Archive Reader](https://annas-archive.gl/view), [2](https://annas-archive.pk/view), [3](https://annas-archive.gd/view)
* [Flow](https://www.flowoss.com/)
* [Online Cloud File Viewer](https://www.fviewer.com/)
* [Readwok](https://readwok.com/)
* [ePub Reader Online](https://www.ofoct.com/viewer/epub-reader-online.html)
* [Ebook Reader](https://reader.ttsu.app/manage)
* [foliate-js](https://github.com/johnfactotum/foliate-js)
* [Litera Reader](https://litera-reader.com/)
* [Readest](https://web.readest.com/)
* [Speeedy](https://speeedy.pages.dev/) / [GitHub](https://github.com/sami-29/speeedy), [Spreeder](https://www.spreeder.com/app.php?intro=1), [Speed Reader](https://speed-reader.com/), [BR Script](https://greasyfork.org/en/scripts/465635), [PlayText](https://www.playtext.com/), [AccelaReader](https://accelareader.com/), [SwiftRead](https://swiftread.com/), [Notation](https://github.com/numanzamandipuu/Notation), [⁠ogma](https://github.com/0hAodha/ogma) or [SpeedRead](https://github.com/pasky/speedread) - Speed Reading Tools / Note These Are Not Good for Comprehension
* [Cubari](https://cubari.moe/) - Image Proxy / Reader
* [Firefox Reader](https://support.mozilla.org/en-US/kb/firefox-reader-view-clutter-free-web-pages), [Tranquility](https://addons.mozilla.org/en-GB/firefox/addon/tranquility-1/), [txtdot](https://txt.dc09.xyz/) / [Instances](https://github.com/TempoWorks/instances) / [GitHub](https://github.com/TempoWorks/txtdot) or [Reader Mode](https://readermode.io/) - Browser Read-Mode / Text-Only Tools
* [Open Media Library](https://openmedialibrary.com/) - Online Book Manager
* [⁠Doqment](https://github.com/shivaprsd/doqment) - Firefox PDF Reader Dark Mode

***

## ▷ E-Reader Tools

* ⭐ **[calibre](https://calibre-ebook.com/)** - E-Reader Book Manager / Downloader / [Libraries / Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/reading#wiki_.25B7_calibre_libraries) / [GitHub](https://github.com/kovidgoyal/calibre)
* ⭐ **[Kindle Comic Converter](https://github.com/ciromattia/kcc)** - Multi-Format Converter
* ⭐ **[EinkBro](https://github.com/plateaukao/einkbro)** - E-Ink Browser
* [ComparisonTabl.es](https://comparisontabl.es/e-readers/) - Compare E-Readers
* [⁠eBook Fonts Showcase](https://ebook-fonts.nicoverbruggen.be/) - Custom E-Reader Typography + Font Preview Tool
* [KoboCloud](https://github.com/fsantini/KoboCloud) - Sync Kobo to Cloud Services
* [⁠ReaderBackdrop](https://www.readerbackdrop.com/) - Wallpapers for E-Readers
* [The Open Book](https://github.com/joeycastillo/The-Open-Book) - DIY Ebook Reader
* [⁠Manga & Comic Converter](https://www.mangaconverter.com/) - Convert Manga / Comic Files to E-Reader Formats / [GitHub](https://github.com/NilsLeo/kcc-cloud)

***

## ▷ Kindle Tools

* **Note** - Your Kindle needs to be jailbroken before you can use most things in this section. You can follow the guide below to learn how.

***

* 🌐 **[Kindle Jailbreak Guide](https://kindlemodding.org/jailbreaking/index.html)** - Jailbreak Guides / Index
* ⭐ **[KOReader](https://koreader.rocks/)** - Ebook Reader / [Minimal UI](https://github.com/AnthonyGress/zen_ui.koplugin) / [Plugins](https://kindlemodshelf.me/plugins), [2](https://github.com/koreader/contrib), [3](https://omer-faruq.github.io/koreader-plugin-index/) / [Settings Guide](https://rentry.co/koreadersettings) / [Patches](https://kindlemodshelf.me/patches) / [App Store](https://github.com/omer-faruq/appstore.koplugin) / [GitHub](https://github.com/koreader/koreader)
* [Kindle Modding Community](https://discord.com/invite/wDbbZTF5QF) - Kindle Modding / Jailbreak Discord
* [FreeReadFeed](https://www.freereadfeed.com/) or [eReaderIQ](https://www.ereaderiq.com/freebies) - Free Kindle Releases
* [LARK](https://kindlemodshelf.me/lark) - Libre Audiobook Player
* [KTerm](https://github.com/bfabiszewski/kterm) - Kindle Terminal Emulator
* [KindleModShelf Image Packs](https://kindlemodshelf.me/images), [Kindle Walls](https://kindlewalls.tumblr.com/), [Reader Backdrop](https://www.readerbackdrop.com/), [Kindle Screensavers](https://kindlescreensavers.tumblr.com/) or [bezos.click](https://bezos.click/) - Kindle Screensaver Image Gallery / [Editor](https://kindlemodshelf.me/imageeditor)
* [Kindle Comic Converter](https://github.com/ciromattia/kcc) - Comic and Manga Converter
* [Kindle to PDF](https://redd.it/bm837l) - Kindle to PDF Conversion Guide
* [Send to Kobo/Kindle](https://send2ereader.net/) - Send Ebooks to Kindle / [GitHub](https://github.com/daniel-j/send2ereader)
* [Amazon Kindle EPUB Fix](https://kindle-epub-fix.netlify.app/) - Fix EPUB to work with Send to Kindle
* [KAnki](https://github.com/crizmo/KAnki) – Kindle Flashcard App / [Editor](https://kindlemodshelf.me/editor)
* [SOX Media Player](https://kindlemodshelf.me/sox) - Bluetooth Audio Player
* [Focus Reading](https://github.com/gmacahia/focus-reading.lua) - Bionic Reading / Guided Dots for Kindle
* [KWordle](https://github.com/crizmo/KWordle/) - Wordle for Kindle
* [Simon Tatham's Puzzles](https://github.com/kbarni/kindlepuzzles) – Kindle Port of [Simon Tatham's Puzzles](https://www.chiark.greenend.org.uk/~sgtatham/puzzles/)
* [⁠kindle-weather-dashboard](https://kindle.hrincar.eu/weather/config.html) - Weather Display for Kindle / Requires Jailbreak / [GitHub](https://github.com/matopeto/kindle-weather-dashboard)

***

# ► Special Interest

* ↪️ **[Survival / Preparedness](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7_survival_.2F_preparedness)**
* ⭐ **[The Anarchist Library](https://theanarchistlibrary.org/special/index)** - Anarchism
* [FreeSFOnline](https://www.freesfonline.net/) - Sci-Fi / Fantasy
* [eBookHunter.net](https://www.ebookhunter.net/) or [EpubPuB](https://www.epub.pub/) - Romance / Fantasy
* [byGosh](https://bygosh.com), [StoryWhale](https://www.storywhale.com/), [Baldwin Library](https://ufdc.ufl.edu/juv) or [BookDash](https://github.com/bookdash/bookdash-android-app) - Children's Books
* [Artbooks Archive](https://t.me/archive_artbooks), [ArtFacultas](https://t.me/ArtFacultas), [FreeArt](https://t.me/free_art_book) or [TheArtbooks](https://t.me/theartbooks) - Artbooks
* [VGArtbooks](https://vk.com/vgartbooks) - Video Game Artbooks
* [The Eldritch Dark](http://www.eldritchdark.com/) - Clark Ashton Smith
* [Booklet Library](https://bookletlibrary.org/) - Booklet Library
* [Auto-Brochures.com](https://www.auto-brochures.com/) - Auto Brochures
* [Project Aon](https://www.projectaon.org/en/Main/Home) - Lone Wolf Gamebooks
* [⁠Sherwood Forest](https://www.sherwoodforestzinelibrary.org/) - Underground Zines Collection
* [Anarchist FAQ](https://www.anarchistfaq.org/) - Anarchism / Translations
* [Archive.Leftove.rs](https://archive.leftove.rs/) - Protest Documents
* [Marxists Internet Archive](https://www.marxists.org/) - Socialism / Communism
* [Liberation School](https://liberationschool.org/) - Communism
* [Red Texts](https://redtexts.org/) - Communism
* [Communism Essays / FAQs](https://dessalines.github.io/essays) - Communism
* [Avalon Library](https://avalonlibrary.net/) - Conspirology Books

***

## ▷ Light Novels

* 🌐 **[Wotaku](https://wotaku.wiki/websites#novels)** - Light Novel Site Index / [Discord](https://discord.gg/vShRGx8ZBC)
* 🌐 **[EverythingMoe](https://everythingmoe.com/section/novel)** - Light Novel Sites Index / [Subreddit](https://www.reddit.com/r/everythingmoe/) / [Discord](https://discord.gg/GuueaDgKdS)
* 🌐 **[The Index](https://theindex.moe/library/novels)** - Light Novel Site Index / [Discord](https://discord.gg/Snackbox) / [Wiki](https://thewiki.moe/)
* ⭐ **[NovelCool](https://www.novelcool.com/)** - Online Reading
* ⭐ **[WuxiaClick](https://wuxia.click/)** - Online Reading
* ⭐ **[⁠NovelFire](https://novelfire.net/)** or [NovelPhoenix](https://novelphoenix.com/) - Online Reading
* [LNORI](https://lnori.com/) - Online Reading / Downloads
* [Wuxiabox](https://www.wuxiabox.com/) - Online Reading
* [⁠Cyrisia](https://cyrisia.com/) - Online Reading
* [WuxiaSpot](https://www.wuxiaspot.com/) - Online Reading
* [⁠ReChapters](https://www.rechapters.com/) - Online Reading
* [WTR-LAB](https://wtr-lab.com/) - Online Reading / Requires Sign-Up for AI Translations
* [Translated Light Novels](https://rentry.co/FMHYB64#translated-light-novels) - Downloads
* [⁠jnovels](https://jnovels.com/) - Downloads
* [MP4DIRECTS](https://mp4directs.com/) - Downloads
* [⁠Light Novel World](https://lightnovelworld.org/) - Online Reading
* [Wuxia World](https://wuxiaworld.site/) - Online Reading
* [Ranobes](https://ranobes.top/) - Online Reading
* [NovelBuddy](https://novelbuddy.me/) - Online Reading
* [ReadNovelFull](https://readnovelfull.com) - Online Reading
* [Just Light Novels](https://www.justlightnovels.com/) - Downloads
* [LightNovelHeaven](https://lightnovelheaven.com), [AllNovel](https://novelfull.com/), [NovelFull](https://novelfull.com/) or [NOVGO](https://novgo.net/) - Online Reading
* [NovelGo](https://novelgo.id) - Online Reading
* [Armaell's Library](https://armaell-library.net/) - Downloads
* [Baka-Tsuki](https://www.baka-tsuki.org) - Online Reading
* [NovelArchive](https://novelarchive.cc/) - Online Reading / Downloads
* [WuxiaWorld.com](https://www.wuxiaworld.com/) - Online Reading
* [⁠WuxiaDreams](https://wuxiadreams.com/) - Online Reading
* [AsianHobbyist](https://www.asianhobbyist.com/) - Online Reading
* [Ocean of EPUB](https://oceanofepub.net/) - Downloads
* [Light Novel Archive](https://t.me/LightNovelArchives) or [LN_Index](https://t.me/LN_Index) - Telegram / Downloads
* [Book Smelting Bot](https://t.me/epub_smelter_bot) - Telegram / Bot
* [⁠NovelYra](https://novelyra.com/) - Light Novels + Web Novels
* [FreeWebNovel](https://freewebnovel.com/) - Web Novels
* [WebNovel.com](https://www.webnovel.com/) - Web Novels
* [Royal Road](https://www.royalroad.com/) - Web Novels
* [Scribblehub](https://www.scribblehub.com/) - Web Novels
* [Novels.pl](https://www.novels.pl/) - Novels / Audio Recordings
* [Baka-Tsuki](https://www.baka-tsuki.org/project/?title=Main_Page) - Novels / Audio Recordings
* [LN-Crawler-Colab](https://colab.research.google.com/github/HongYue1/LightNovel-Crawler-Colab/blob/main/lightnovel_crawler.ipynb) / [GitHub](https://github.com/HongYue1/LightNovel-Crawler-Colab), [Lightnovel Crawler](https://github.com/dipu-bd/lightnovel-crawler/), [novel-downloader](https://greasyfork.org/en/scripts/406070) or [anime-dl](https://github.com/vrienstudios/anime-dl) - Light Novel Downloaders
* [WebToEpub](https://github.com/dteviot/WebToEpub) - Novel to EPUB Converter
* [LNMTL](https://lnmtl.com/) or [Omni](https://app.readomni.com/) - Light Novel Translators

***

## ▷ Fanfiction / Stories

* ⭐ **[Archive of Our Own](https://archiveofourown.org/)** - Fanfiction Archive / [Enhancements](https://github.com/jsmnbom/ao3-enhancements/)
* ⭐ **[Short Stories](https://short-stories.co/)**
* [SCP Foundation](https://scp-wiki.wikidot.com/) - Fictional Story Collabs / [Wiki](https://wikipedia.org/wiki/SCP_Foundation) / [Subreddit](https://www.reddit.com/r/SCPDeclassified/)
* [Everything2](https://everything2.com/) - Short Stories / Poetry / Writing Help
* [Fork Read](https://forkread.com/) - Publish Short Stories
* [Booksie](https://www.booksie.com/) - Short Stories
* [Vestal Review](https://www.vestalreview.net/) - Short Stories
* [Library of Short Stories](https://www.libraryofshortstories.com/) - Short Stories
* [Vocal Media](https://vocal.media/fiction/) - Short Stories
* [xpressenglish](https://xpressenglish.com/) - Short Stories
* [ClassicShorts](https://www.classicshorts.com/) - Classic Short Stories
* [Pulp Magazines Project](https://www.pulpmags.org/) - Classic Fiction Story Magazine
* [Poop Fiction](https://readpoopfiction.com/) - Random Short Stories
* [the Wanderers' Library](https://wanderers-library.wikidot.com/) - Fictional Story Collabs
* [RPC Authority](http://rpc-wiki.net/) - Fictional Story Collabs
* [OrionsArm](https://www.orionsarm.com/) - Fictional Story Collabs
* [Fanfiction.net](https://www.fanfiction.net/) - Fanfiction
* [SquidgeWorld](https://squidgeworld.org/) - Fanfiction
* [FanMTL](https://www.fanmtl.com/) - Fanfiction
* [Inkitt](https://www.inkitt.com/fanfiction) - Fanfiction
* [Wattpad](https://wattpad.com/) - Fanfiction / [Downloader](https://wpd.my/)
* [Royal Road](https://royalroad.com/) - Fanfiction
* [FictionPress](https://www.fictionpress.com/) - Fanfiction
* [Quotev](https://www.quotev.com/stories/c/Fanfiction) - Fanfiction
* [⁠Asianfanfics](https://www.asianfanfics.com/) - Asian Fanfiction
* [AlternateHistory](https://www.alternatehistory.com/forum/) - Historical "What if?" Fiction
* [Liminal Archives](http://liminal-archives.wikidot.com/), [The Backrooms Wiki](https://backrooms-wiki.wikidot.com/) or [The Voidclusters](http://voidclusters.wikidot.com/) - Liminal Space Stories
* [Potions and Snitches](https://www.potionsandsnitches.org/) - Harry Potter Fanfiction
* [Fim Fiction](https://www.fimfiction.net/) - MLP Fanfiction
* [fiction.live](https://fiction.live/) - Fanfiction

***

## ▷ Newspapers

* 🌐 **[Veridian](https://veridiansoftware.com/collections/)** - Newspaper Archive List
* ↪️ **[Bypass Newspaper Paywalls](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools#wiki_.25B7_paywall_bypass)**
* ↪️ **[Worldwide News Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25BA_news)**
* ⭐ **[Mobilism Newspapers](https://forum.mobilism.org/viewforum.php?f=123)** / [User Ranks](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/mobilism-ranks.md)
* ⭐ **[Google Newspaper Search](https://news.google.com/newspapers)**
* [SoftArchive](https://softarchive.download/newspapers)
* [Meta-Press](https://www.meta-press.es/) - Newspaper Search
* [EngNewspapers](https://vk.com/engnewspapers) - Telegram
* [newspaper_archive](https://t.me/newspaper_archive) - Telegram
* [Chronicling America](https://www.loc.gov/collections/chronicling-america/titles/)
* [Kiosko](https://en.kiosko.net/)
* [FultonHistory](https://fultonhistory.com/Fulton.html)
* [Loc.gov Newspapers](https://www.loc.gov/newspapers/)
* [Newspapers](https://newspapers.com/)
* [ThoughtCo](https://www.thoughtco.com/us-historical-newspapers-online-by-state-1422215)
* [Library of Congress Newspapers](https://guides.loc.gov/foreign-newspapers/digital-resources)
* [Archive.org Newspapers](https://rentry.co/FMHYB64#archiveorg-newspapers)
* [World-Newspapers](https://world-newspapers.com/), [NewsPaperIndex](https://www.newspaperindex.com/) or [Paperboy](https://www.thepaperboy.com/) - Online Newspaper Indexes
* [LA Times](https://latimes.newspapers.com/)
* [Front Pages](https://www.frontpages.com/) - Newspaper Front Pages
* [Elephind](https://www.elephind.com/) - Historical Newspaper Archive
* [Europeana Newspapers](https://www.europeana.eu/en/collections/topic/18-newspapers) - European Historical Newspapers
* [Newspaper Map](https://newspapermap.com/) - Find / Translate Worldwide Newspapers

***

# ► Audiobooks

## ▷ Downloading

* ⭐ **[Mobilism Audiobooks](https://forum.mobilism.org/viewforum.php?f=124)**, [2](https://forum.mobilism.me/viewforum.php?f=124) / [User Ranks](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/mobilism-ranks.md)
* ⭐ **[AudiobookBay](https://audiobookbay.lu/)** - Torrents / **[Warning / Link Fix](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/audiobookbay-critical.md)**
* ⭐ **[MyAnonaMouse](https://www.myanonamouse.net/)** - Torrents / [Invites](https://www.myanonamouse.net/inviteapp.php) / [Ratio Warnings](https://greasyfork.org/en/scripts/416189)
* [Audiobook CSE](https://cse.google.com/cse?cx=006516753008110874046:cwbbza56vhd) - Multi-Site Audiobook Search
* [LearnOutLoud](https://www.learnoutloud.com/Free-Audiobooks)
* [Golden Audiobooks](https://goldenaudiobooks.com/)
* [LibriVox](https://librivox.org/)
* [Book Radio](https://bookradio.vercel.app/)
* [Audiobooks For Soul](https://audiobooks4soul.com/)
* [LitGu.ru](https://litgu.ru/) - Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators)
* [⁠Dynasty](https://t.me/dynastyapprovals) - Telegram
* [FreeClassicAudiobooks](https://www.freeclassicaudiobooks.com/) - Classic Audiobooks
* [Storynory](https://www.storynory.com/) - Children Audio Stories
* [Audiobooks Poetry](https://archive.org/details/audio_bookspoetry) - Audiobooks / Poetry
* [audiobook-dl](https://github.com/jo1gi/audiobook-dl) or [PlayTorrio](https://playtorrio.xyz/), [2](https://playtorrio.pages.dev/) / [Subreddit](https://www.reddit.com/r/PlayTorrio/) / [Discord](https://discord.gg/bbkVHRHnRk) - Audiobook Download Apps
* [AudioBooksBee](https://audiobooksbee.com/) / Requires [Debrid](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/download#wiki_.25BA_debrid_.2F_leeches)

***

## ▷ Streaming

* ⭐ **[NEPU Audiobooks](https://nepu.io/ebooks)**, [2](https://nepu.io/ebooks), [3](https://nepu.app/ebooks), [4](https://nepu.is/ebooks) / [Status](https://rar.to/) / [Discord](https://discord.gg/nepu)
* [FullLengthAudiobooks](https://fulllengthaudiobooks.com/)
* [Mapple](https://mapple.fun/audiobooks)
* [HotAudioBooks](https://hotaudiobooks.com/)
* [BookAudiobook](https://bookaudiobooks.com/)
* [CozyAudiobooks](https://cozyaudiobooks.com/category/) / Some NSFW
* [Audiozaic](https://audiozaic.com/)
* [Audio AZ](https://audioaz.com/)
* [r/audiobooksonyoutube](https://reddit.com/r/audiobooksonyoutube)
* [Project Gutenberg](https://www.gutenberg.org/browse/categories/1) or [Lex](https://lex-books.com/) - Historical Fiction / Nonfiction
* [PlayTorrio](https://playtorrio.xyz/), [2](https://playtorrio.pages.dev/) - Audiobook App / Windows, macOS, Linux, Android, iOS / [Subreddit](https://www.reddit.com/r/PlayTorrio/) / [Discord](https://discord.gg/bbkVHRHnRk)
* [Spotify Audiobooks](https://open.spotify.com/artist/1FSWXfsYsosTxjcV9WoLax) - Select Playlists

***

## ▷ Audiobook Tools

* ↪️ **[Audiobook Generators / TTS](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/ai#wiki_.25B7_text_to_speech)**
* [AudioBookConverter](https://github.com/yermak/AudioBookConverter) - Audiobook Format Converter
* [Audible Tools](https://audible-tools.kamsker.at/), [AaxAudioConverter](https://github.com/audiamus/AaxAudioConverter) or [Libation](https://getlibation.com/) / [Mobile](https://github.com/Promises/LibriSync) - Audible DRM Remover / Manager
* [AudiobookShelf](https://www.audiobookshelf.org/) / [Multi-Platform Client](https://github.com/Vito0912/abs_flutter) / [Mobile](https://github.com/advplyr/audiobookshelf-app), [2](https://github.com/GrakovNe/lissen-android/) / [Installer / Manager](https://github.com/mikiher/audiobookshelf-windows) or [BookSonic](https://booksonic.org/) - Self-Hosted Audiobook Servers

***

# ► Visual Media

* ↪️ **[Visual Novel Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools#wiki_.25B7_visual_novel_tools)**

## ▷ Comics

* ⭐ **[BatCave](https://batcave.biz/)** - May Require VPN / [Telegram](https://t.me/+0Fcqxn4BK4Q1NzM1)
* ⭐ **[GetComics](https://getcomics.org/)** - Download Comics / [Bulk Downloader](https://github.com/moistfella/comic-book-downloader) / [Discord](https://discord.com/invite/G7UwGPZDJ7)
* ⭐ **[ComicBookPlus](https://comicbookplus.com/)** - Golden Age Comics
* ⭐ **[Explosm](https://explosm.net/rcg)** - Cyanide & Happiness Webcomics
* ⭐ **[xkcd](https://xkcd.com/)** or [findxkcd](https://xkcd-search.typesense.org/) - xkcd Webcomics / [Explanations](https://www.explainxkcd.com/wiki/index.php/Main_Page)
* ⭐ **[Comic CSE](https://cse.google.com/cse?cx=006516753008110874046:p4hgytyrohg)** - Multi-Site Comic Search
* [Cover](https://frenchfrysoftware.com/cover/), [Comic Library Utilities](https://clucomics.org/) / [GitHub](https://github.com/allaboutduncan/comic-utils), [MComix](https://sourceforge.net/projects/mcomix/), [CBR Reader](https://www.cdisplayex.com/), [Stump](https://www.stumpapp.dev/), [⁠GonVisor](https://www.gonvisor.com/), [comic-book-reader](https://github.com/binarynonsense/comic-book-reader), [OpenComic](https://github.com/ollm/OpenComic) or [YACReader](https://yacreader.com/) - Comic Readers / Managers
* [XOXO Comics](https://xoxocomic.com/)
* [Read Comics Online](https://readcomicsonline.ru/)
* [OceComic](https://ocecomic.com/)
* [4chan /co/](https://boards.4chan.org/co/catalog#s=official%20win) - Weekly Downloads
* [ZipComic](https://www.zipcomic.com/)
* [⁠ComicsCodes](https://comics.codes/) - Comic Downloads
* [⁠YSK Comics](https://www.ysk-comics.com/en) - Download Comics / Signup Required
* [OldComicsWorld](https://oldcomicsworld.blogspot.com/) - Golden Age Comic Downloads
* [DigitalComicMuseum](https://digitalcomicmuseum.com/) - Golden Age Comic Downloads
* [Comics Kingdom](https://comicskingdom.com/) - Comics Strips
* [GoComics](https://www.gocomics.com/) - Comics Strips / [Site Fix](https://ludditus.com/2025/04/19/bypassing-gocomics-paywall/)
* [⁠SMBC](https://www.smbc-comics.com/) - Webcomics
* [The Oatmeal](https://theoatmeal.com/) - Webcomics
* [Comic Rocket](https://www.comic-rocket.com/) - Webcomics / Some NSFW
* [Hiveworks Comics](https://www.thehiveworks.com/) - Webcomics
* [Loading Artist](https://loadingartist.com/) - Webcomics
* [⁠Comic Studio](https://comic.studio/browse) - Webcomics
* [Comic Book Library](http://nv3x2jozywh63fkohn5mwp2d73vasusjixn3im3ueof52fmbjsigw6ad.onion/) - Requires Tor
* [ComicEater](https://github.com/kanjieater/ComicEater) - Comic Archiving Tools
* [Comics Downloader](https://github.com/Girbons/comics-downloader), [⁠yoink](https://github.com/Rigil-Kent/yoink-go), [Comic Library Utilities](https://clucomics.org/) / [GitHub](https://github.com/allaboutduncan/comic-utils), [Mylar3](https://github.com/mylar3/mylar3) - Comic Downloaders
* [ComicReader](https://comicreader.netlify.app/) or [KThoom](https://github.com/codedread/kthoom) - Online Comic Reader
* [ComicFury](https://comicfury.com/) - User-Made Comics
* [Comic Translate](https://github.com/ogkalu2/comic-translate) - Comic Translator
* [Webcomix](https://github.com/J-CPelletier/webcomix) - Webcomics Downloader
* [Komga](https://komga.org/) - Comic / Manga Media Server / [Discord](https://discord.gg/TdRpkDu) / [GitHub](https://github.com/gotson/komga)
* [ComicTagger](https://github.com/comictagger/comictagger) - Comic Metadata Tagger

***

## ▷ Manga

* **Note** - Keep in mind many manga sites may also include adult content, some allow you to filter it out in their settings.

***

* 🌐 **[Wotaku](https://wotaku.wiki/websites#manga)** - Manga Site Index / [Discord](https://discord.gg/vShRGx8ZBC)
* 🌐 **[The Index](https://theindex.moe/library/manga)** - Manga Site Index / [Wiki](https://thewiki.moe/) / [Discord](https://discord.gg/Snackbox)
* 🌐 **[EverythingMoe](https://everythingmoe.com/section/manga)** - Manga Site Index / [Subreddit](https://www.reddit.com/r/everythingmoe/) / [Discord](https://discord.gg/GuueaDgKdS)
* 🌐 **[⁠JustIndex](https://justindex.cc/)** - Manga Site Index / [Mirrors](https://projectjust.xyz/) / [Subreddit](https://www.reddit.com/r/ProjectJust) / [Discord](https://discord.gg/P3yqksmGun)
* 🌐 **[Rawmangaz](https://clarasguide.valeena.workers.dev/Guides/rawmangaz/)** - List of Raw Manga Sites
* ⭐ **[Kagane](https://kagane.org/)** / [Discord](https://discord.gg/kaganeto)
* ⭐ **[MangaDot](https://mangadot.net/)**, [2](https://manga.st/), [3](https://mangadot.st/) / [Matrix](https://fuckdm.ca/)
* ⭐ **[Weeb Central](https://weebcentral.com/)**
* ⭐ **[Atsumaru](https://atsu.moe/)** / [Discord](https://discord.gg/Tj4QmEF4uV)
* ⭐ **[Toonkotsu](https://toonkotsu.com/)**
* ⭐ **[⁠OniSaga](https://onisaga.com/)**
* ⭐ **[MangaDex](https://mangadex.org/)** - Account Required / [Downloader](https://mangadex-dl.mansuf.link/) / [Wiki](https://wikidex.tr25.es/) / [Subreddit](https://www.reddit.com/r/mangadex/) / [Discord](https://discord.gg/mangadex)
* ⭐ **[⁠Comix](https://comix.to/)**, [2](https://comix.ws/) / [Subreddit](https://reddit.com/r/comix) / [Discord](https://discord.com/invite/kZgWWHUj22)
* ⭐ **[Nyaa Manga / LNs](https://nyaa.si/?f=0&c=3_0&q=)** - Torrents
* [MangaFire](https://mangafire.to/) / [Subreddit](https://www.reddit.com/r/Mangafire/) / [Discord](https://discord.com/invite/KRQQKzQ6CS)
* [MangaNato](https://www.manganato.gg/), [2](https://www.nelomanga.net/), [3](https://www.mangakakalot.gg), [4](https://www.natomanga.com/) / [Discord](https://discord.gg/Qhz84GGvE9)
* [Nyora](https://web.nyora.xyz/) - Multi-Site Manga Aggregator
* [⁠Tobari](https://tobari.moe/) - Multi-Site Manga Aggregator / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/tobari.md)
* [⁠bManga](https://bmanga.dedyn.io/) - Multi-Site Manga Aggregator
* [⁠YumeZone](https://yumezone.live/manga/) - Multi-Site Manga Aggregator
* [Cubari Proxy](https://proxy.cubari.moe/) - Multi-Site Manga Aggregator / [Discord](https://discord.com/invite/SavdUC45MS)
* [MangaKatana](https://mangakatana.com/)
* [MangaK](https://mangak.io/)
* [MangaBall](https://mangaball.net/)
* [Mangapill](https://mangapill.com/) / [GitHub](https://github.com/real-zephex/MangaThingy) (proxy)
* [⁠MangaTaro](https://mangataro.org/) / [Discord](https://discord.gg/FKd8XVneCw)
* [MangaHere](https://www.mangahere.cc/) or [MangaFox](https://fanfox.net/)
* [⁠Mangastash](https://mangastash.org/)
* [⁠JustManga](https://justmanga.cc/) / [Mirrors](https://projectjust.xyz/) / [Subreddit](https://www.reddit.com/r/ProjectJust) / [Discord](https://discord.gg/P3yqksmGun)
* [Rive Manga](https://www.rivestream.app/manga), [2](https://rivestream.ru/manga) / [Status](https://rentry.co/rivestream) / [Discord](https://discord.gg/6xJmJja8fV)
* [MangaTown](https://www.mangatown.com/)
* [All Manga](https://allmanga.to/) or [MKissa](https://mkissa.to/) / [Discord](https://discord.com/invite/6nce6cyJyM)
* [The Manga Library](https://rentry.co/FMHYB64#the-manga-library)
* [MangaHub](https://mangahub.io/)
* [Mgread](https://mgread.io/)
* [Scans.gg](https://scans.gg/changelog) / [Discord](https://discord.gg/cYFgYu66rx)
* [MangaBerri](https://mangaberri.com/) - Use [Adblock](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_adblocking)
* [⁠Mgeko](https://www.mgeko.cc/) - Manhwa / Manhua
* [Webtoon](https://www.webtoons.com/) - Manhwa / [Discord](https://discord.com/invite/webtoonofficial)
* [⁠FreeManhwa](https://freemanhwa.net/) - Manhwa
* [Toonily](https://toonily.com/) - Manhwa
* [LilyManga](https://lilymanga.net/) - Yuri
* [Great Discord Links](https://discord.gg/xAsyVb52a9) or [MangaDex Groups](https://mangadex.org/groups) - Manga Scanlation Groups
* [Madokami](https://wotaku.wiki/guides/manga/madokami) - Madokami Download Guide / [Archive](https://rentry.co/FMHYB64#madokami)
* [MediaBang](https://medibang.com/mpc/) or [⁠NamiComi](https://namicomi.com/en) - User-Created Manga
* [MP4DIRECTS](https://mp4directs.com/) or [⁠jnovels](https://jnovels.com/) - Manga Downloads
* [MangaUpdates](https://www.mangaupdates.com/) - Manga Database / Releases Updates
* [Manga CSE](https://cse.google.com/cse?cx=006516753008110874046:4im0fkhej3z) / [CSE 2](https://cse.google.com/cse?cx=006516753008110874046:a5mavctjnsc#gsc.tab=0) - Multi-Site Manga Search

***

## ▷ Manga Readers / Tools

* ↪️ **[Android Readers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_android_manga)** / **[iOS Readers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25BA_ios_reading)**
* ⭐ **[Suwayomi](https://github.com/Suwayomi)** - Manga Reader / [Extensions](https://keiyoushi.github.io/), [2](https://discord.gg/3FbCpdKbdY) / [Desktop](https://github.com/Suwayomi/Suwayomi-Server)
* [AllMangasReader](https://allmangasreader.com/) - Manga Reader
* [Houdoku](https://houdoku.org/) - Manga Reader / [GitHub](https://github.com/xgi/houdoku)
* [Adolla](https://github.com/AdollaApp/Adolla) - Manga Reader
* [OpenComic](https://github.com/ollm/OpenComic) - Manga Reader
* [Manga-Organizer](https://gitgud.io/Nagru/Manga-Organizer) - Manga Reader
* [PlayTorrio](https://playtorrio.xyz/), [2](https://playtorrio.pages.dev/) - Manga Reader / [Subreddit](https://www.reddit.com/r/PlayTorrio/) / [Discord](https://discord.gg/bbkVHRHnRk)
* [MangaOnlineViewer](https://github.com/TagoDR/MangaOnlineViewer) - Manga Reader
* [LANraragi](https://github.com/Difegue/LANraragi) - Manga Reader
* [Unyo](https://github.com/K3vinb5/Unyo) - Manga Reader
* [Manga-Manager](https://github.com/MangaManagerORG/Manga-Manager) - Manga Manager
* [Comics Downloader](https://github.com/Girbons/comics-downloader), [work_crawler](https://github.com/kanasimi/work_crawler/blob/master/document/README.en-US.md), [HDoujinDownloader](https://github.com/HDoujinDownloader/HDoujinDownloader), [FMD2](https://github.com/dazedcat19/FMD2) or [anime-dl](https://github.com/vrienstudios/anime-dl) - Manga Download Tools
* [BallonsTranslator](https://github.com/dmMaze/BallonsTranslator/blob/master/README_EN.md), [Koharu](https://koharu.rs/) / [GitHub](https://github.com/koharu-rs/koharu), [Cotrans](https://cotrans.touhou.ai/) or [Scanlate](https://scanlate.io/) - Manga Translators
* [Seanime](https://seanime.app/) / [Discord](https://discord.com/invite/3AuhRGqUqh), [KavitaReader](https://www.kavitareader.com/), [Komga](https://komga.org/) / [GitHub](https://github.com/gotson/komga) / [Discord](https://discord.gg/TdRpkDu) or [atsumeru](https://atsumeru.xyz/) - Self-Hosted Manga Readers
* [Webcomic Reader](https://openuserjs.org/scripts/anka-213/Webcomic_Reader) - Preloads Images, Remembers Progress and Keyboard Support

***

## ▷ Magazines

* ⭐ **[Mobilism Magazines](https://forum.mobilism.org/viewforum.php?f=123)** - Multi-Host / [User Ranks](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/mobilism-ranks.md)
* ⭐ **[PDFMagazines](https://pdfmagazines.club/news/)** - Novafile / Some NSFW
* ⭐ **[DownMagaz](https://downmagaz.net/)** - Novafile
* ⭐ **[MagazineLib](https://magazinelib.com/)** - VK
* [Calameo](https://calameo.com/) - Online Reading
* [Magzter](https://www.magzter.com/top-free-magazines) - Online Reading
* [FlipHTML5](https://fliphtml5.com/exploring) - Online Reading / [Downloader](https://fliphtml5.aivaded.com/)
* [Magazine Rack](https://archive.org/details/magazine_rack) - Archive.org
* [Computer Magazines](https://archive.org/details/computermagazines) - Archive.org
* [freemagazines](https://freemagazines.top/) - VK
* [FreeMagazinePDF](https://freemagazinespdf.com/) - VK
* [⁠EBooksYard](https://ebooksyard.com/) - VK
* [4kw Magazines](https://4kw.in/) - VK
* [ENMagazine](https://t.me/enmagazine) - Telegram
* [World Mags](https://www.worldmags.net/) - Nitroflare / Novafile
* [PDF Dude](https://pdfdude.com/) - Novafile
* [PDF Magazines Download](https://pdf-magazines-download.com/) - Novafile
* [PDF Magaz](https://www.pdfmagaz.in/) - Novafile / Some NSFW
* [PDF Magazines Archive](https://pdf-magazines-archive.com/) - Novafile
* [MagDownload](https://magdownload.com/) - Nitroflare
* [WholeEarth](https://wholeearth.info/) - Whole Earth Science Magazines
* [Retromags](https://www.retromags.com/), [⁠Out-of-Print Archive](https://www.outofprintarchive.com/) or [VGHF](https://archive.gamehistory.org/folder/9a193e8c-67e0-45ff-98d2-a33e85721cc4) - Retro Gaming Magazines
* [PC Zone](https://pixsoriginadventures.co.uk/PCZone/) - PC Zone Magazines
* [CGW Museum](https://www.cgwmuseum.org/) - Computer Gaming World Magazines
* [Atari Magazines](https://www.atarimagazines.com/) - Classic Computer Magazine Archive
* [RadioShack Catalogs](https://www.radioshackcatalogs.com/) - RadioShack Catalog Archive
* [HomePower](https://www.homepower.com/archive-browse) - Home Power Magazines
* [Archive Fashion for the World](https://www.archivepdf.net/) - Fashion Magazines

***

# ► Educational Books

* ↪️ **[Language Learning Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu/#wiki_.25BA_language_learning)**
* ↪️ **[Dictionaries / Thesaurus'](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7_dictionaries_.2F_thesaurus)**
* ↪️ **[Encyclopedias](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7_encyclopedias)**
* ⭐ **[OpenStax](https://openstax.org/)**
* ⭐ **[AcademicTorrents](https://academictorrents.com/)**
* [Institutional Access](https://www.facebook.com/groups/850609558335839) - Request Institutional Access PDFs
* [Online Books Page](https://onlinebooks.library.upenn.edu/)
* [Springer](https://link.springer.com/search?showAll=false&query=&facet-content-type=%22Book%22)
* [Taleem360](https://www.taleem360.com/)
* [LibreTexts](https://commons.libretexts.org), [2](https://libretexts.org/libreverse), [3](https://libretexts.org/)
* [PDFBooksWorld](https://www.pdfbooksworld.com/)
* [Monoskop](https://monoskop.org/log/)
* [LibertyFund](https://oll.libertyfund.org/)
* [ACM](https://dl.acm.org/)
* [HathiTrust](https://www.hathitrust.org/)
* [FreeBookCentre](https://freebookcentre.net/)
* [OAPEN](https://oapen.org/)
* [VDOC.PUB](https://vdoc.pub/)
* [Sciarium](https://sciarium.com/)
* [OpenED](https://open.bccampus.ca/)
* [De Gruyter Brill](https://www.degruyterbrill.com/?submittedFilterId=by-type&access_4=open&pageSize=10&sort=datedescending&type_5=book)
* [Learn Anything / Books](https://github.com/learn-anything/books)
* [Tradepub](https://knowfree.tradepub.com/)
* [eBookRoom](https://t.me/eBookRoom)
* [BookGoldMine](https://www.bookgoldmine.com/)
* [SuperKuh](http://erewhon.superkuh.com/library/)
* [⁠InfoBooks](https://www.infobooks.org/)
* [Non-Fiction](https://vk.com/non_fic)
* [FreePLRDownloads](https://freeplrdownloads.com/)
* [E-Books Directory](https://www.e-booksdirectory.com/)
* [Free eBooks](https://t.me/free_ebooks_pdfs)
* [Wikiversity](https://www.wikiversity.org/) - Learning Resources, Guides, Quizzes, Tools & More
* [OpenEdition](https://www.openedition.org/) - Books / Journals
* [JSTOR](https://www.jstor.org/) - Books / Journals
* [UCL Press](https://www.uclpress.co.uk/) - Books / Journals
* [Dummies Store](https://t.me/dummiesbook) - Books for Dummies Collection
* [2012 Book Archive](https://2012books.lardbucket.org/) - Creative Commons Books
* [CK-12](https://www.ck12.org/browse/) - Interactive Textbooks
* [Bookishfrenzy](https://t.me/premium_ebooks) - Books / Exam Books
* [Digital Libraries / Archives](https://oedb.org/ilibrarian/250-plus-killer-digital-libraries-and-archives/) - Online University Libraries
* [OpenDOAR](https://v2.sherpa.ac.uk/opendoar/) - Academic Repository Search
* [EveryCulture](https://www.everyculture.com/index.html) - World Culture Encyclopedia
* [⁠Japanese Wiki Corpus](https://www.japanesewiki.com/) - Japanese Culture / History Encyclopedia
* [Encyclopaedia Iranica](https://www.iranicaonline.org/) - Iranian Culture Encyclopedia
* [Brill](https://brill.com/) - International Law Books / Free for Students Only

***

## ▷ Textbooks

* 🌐 **[IvyPanda](https://ivypanda.com/blog/1000-open-textbooks-and-learning-resources-for-all-subjects/)** - Open-Source Textbooks
* ↪️ **[JEE / NEET Textbooks](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7_jee_.2F_neet)**
* [Textbook Search Engine](https://cse.google.com/cse/publicurl?cx=011394183039475424659:5bfyqg89ers), [2](https://cse.google.com/cse?cx=001639227550064093264:dznewka3cca) - Search for Textbooks
* [Open Textbook Library](https://open.umn.edu/opentextbooks/) - Textbooks
* [OpenStax College Textbooks](https://philschatz.com/books/) - Textbooks
* [⁠ReadYourFlow](https://readyourflow.com/) - Textbooks
* [TextBookGo](https://textbookgo.com/) - Textbooks
* [Wikibooks](https://wikibooks.org/) - Open-Content Textbooks
* [CLP](https://personal.math.ubc.ca/~CLP/) - Calculus Textbooks
* [Pearson](https://redd.it/smm6ib) - Pearson Textbook Download Guide
* [⁠CORE Econ](https://www.core-econ.org/) - Economics Textbooks

***

## ▷ STEM Resources

* 🌐 **[Awesome AI](https://github.com/owainlewis/awesome-artificial-intelligence#free-content)** - Artificial Intelligence Books
* [IntechOpen](https://www.intechopen.com/) - Science
* [Naked Scientists](https://www.thenakedscientists.com/) - Podcasts / Shows / Science
* [Free Astronomy Resources](https://er-cryptid.tumblr.com/post/176809097526/free-astronomy-resources) - Books / Notes / Astronomy / Physics
* [GoodTheorist](https://www.goodtheorist.science/) - Theoretical Physics
* [Chemistry.com.pk](https://chemistry.com.pk/) - Chemistry / Books
* [Biology.com.pk](https://biology.com.pk/) - Biology / Books
* [Institute of Mathematics](https://textbooks.aimath.org/) - Math / Books
* [HBPMS](https://hbpms.blogspot.com/) - Math / Books
* [All About Circuits](https://www.allaboutcircuits.com/education/) - Electronics
* [Ultimate Electronics Book](https://ultimateelectronicsbook.com/) - Electronics Schematics / Simulations
* [SemiWiki](https://semiwiki.com/) - Semiconductor Wiki
* [PDFiles](https://www.pdfiles.net/) - IT Books
* [Explanations](https://magcius.github.io/xplain/article/) - Advanced Computer Explanations

***

## ▷ History Books

* 🌐 **[r/AskHistorians Recommended](https://www.reddit.com/r/AskHistorians/wiki/books)** - Recommended History Books
* ⭐ **[Early Modern Texts](https://www.earlymoderntexts.com)** - Early Modern Philosophy
* ⭐ **[World History](https://www.worldhistory.org/)** or [Livius](https://www.livius.org/) - History Encyclopedias
* [Duke University Library](https://repository.duke.edu/catalog?utf8=%E2%9C%93&search_scope=https%3A%2F%2Frepository.duke.edu%2Fcatalog&q=&search_field=all_fields) - Historical Books
* [Early English Books](https://quod.lib.umich.edu/e/eebogroup/), [⁠Brown Digital Repository](https://repository.library.brown.edu/studio/collections/library/), [NYPL](https://digitalcollections.nypl.org/) or [Amherst](https://acdc.amherst.edu/) - Historical Texts / Books
* [Making of America](https://quod.lib.umich.edu/m/moa/) - American History
* [Classical Libraries](https://docs.google.com/spreadsheets/d/e/2PACX-1vRkUFBfVVqv5Tr2aZS4apFNpTJ-ys6VqeQxgsAI1v7cH5putIgchYWJAVGHuu0lWGmdD2DU7Vb1o7XH/pubhtml) - Classical Literature Collection / [Full List](https://docs.google.com/spreadsheets/d/1OGFA-vSmu7yTZutb9f7uVZGT2mWkKYP1sWO2-I3huQQ/)
* [Perseus Digital Library](https://www.perseus.tufts.edu/hopper/) - Classic / Greek / Roman / Arabic / Germanic
* [⁠The Internet Classics Archive](https://classics.mit.edu/) - Classic Philosophy / Literature
* [In Parenthesis](https://www.yorku.ca/inpar/) - Historic Tales
* [CELT](https://celt.ucc.ie/) - Irish / History / Literature / Politics
* [textfiles.com](http://textfiles.com/) - 1980s Text File Index
* [Smithsonian Institution Archives](https://siarchives.si.edu/) - Historical Text / Documents
* [IntraText Digital Library](https://www.intratext.com/) - Historical Text / Documents
* [MSU Digital Repository](https://d.lib.msu.edu/) - Historical Documents, Books, Recording & more
* [Archives.gov](https://archives.gov/) - US Historical Documents
* [Europeana](https://www.europeana.eu/) - European Historical Documents
* [The National Archives](https://nationalarchives.gov.uk/) - UK Historical Documents / [X](https://x.com/UKNatArchives)
* [ToposText](https://topostext.org/) - Greek Historical Documents
* [Panjab Digital Library](http://www.panjabdigilib.org/) - Panjab Historical Documents
* [Jewish Virtual Library](https://www.jewishvirtuallibrary.org/) - Encyclopedia of Jewish / Israeli History
* [The Library](https://philological.cal.bham.ac.uk/library.html), [⁠SCTA](https://scta.lombardpress.org/), [⁠CAMENA](https://mateo.uni-mannheim.de/camenahtdocs/camena_e.html) or [⁠Corpus Corporum](https://mlat.uzh.ch/) - Historical Latin Texts
* [World Radio History](https://worldradiohistory.com/) - Radio History Archive
* [The Morgan Library Museum](https://www.themorgan.org/music) or [DIAMM](https://www.diamm.ac.uk/) - Musical Manuscripts
* [Wiktenauer](https://wiktenauer.com/) - Historical European Martial Arts Wiki
* [Radical Scatters](https://radicalscatters.unl.edu/indices.html) - Emily Dickinson Fragments / Texts
* [The History of Maritime Piracy](http://www.cindyvallar.com/pirates.html) - Piracy History Blog
* [Van Gogh Letters](https://vangoghletters.org/vg/) - Vincent van Gogh Letters
* [DigitalTransgenderArchive](https://www.digitaltransgenderarchive.net/) - Transgender History Archive

***

## ▷ Quotes / Poetry

* ⭐ **[Wikiquote](https://wikiquote.org)**
* ⭐ **[Poetry Foundation](https://www.poetryfoundation.org/)**
* [⁠Eudaimonia](https://www.eudaimonia.wiki/) - Collaborative Book of Wisdom / Quotes
* [Brainy Quote](https://www.brainyquote.com/)
* [AZquote](https://www.azquotes.com/)
* [The Quote Garden](https://www.quotegarden.com/)
* [Quotations Home Page](https://theotherpages.org/quote.html)
* [Quote Collections](https://rentry.co/zeoemsh9)
* [Poetry In Translation](https://www.poetryintranslation.com/)
* [Poem Hunter](https://www.poemhunter.com/)
* [Discover Poetry](https://discoverpoetry.com/)
* [RuVerses](https://ruverses.com/)
* [Poetry.com](https://www.poetry.com/)
* [Poets.org](https://poets.org/)
* [Poetry Archive](https://poetryarchive.org/)
* [Scottish Poetry Library](https://www.scottishpoetrylibrary.org.uk/)

***

## ▷ Programming Books

* 🌐 **[Free-Programming-Books](https://ebookfoundation.github.io/free-programming-books-search/)** - Programming Book Index / [GitHub](https://github.com/EbookFoundation/free-programming-books)
* ⭐ **[O'Reilly](https://www.oreilly.com/)** - Tech / Programming / Infinite trial by clearing cookies & making a new account
* ⭐ **[ScanLibs](https://scanlibs.com/)**, [2](https://forcoder.net/), [3](https://coderprog.com/)
* [IT eBooks](https://it-ebooks.info/)
* [FreeComputerEbooks](https://freecomputerbooks.com/)
* [eBooks-IT](https://ebooks-it.org)
* [Flavio Copes](https://flaviocopes.com/)
* [WOW! eBook](https://www.wowebook.org/)
* [Free Ebooks Download List](https://free-ebook-download-links.blogspot.com/)
* [⁠Software Foundations](https://softwarefoundations.cis.upenn.edu/) - Programming Foundation + Formal Verification Books
* [GoalKicker](https://goalkicker.com/), [2](https://books.goalkicker.com/) - Programming Books Compiled from Stack Overflow Docs
* [Python Data Science Handbook](https://jakevdp.github.io/PythonDataScienceHandbook/) - Python Data Science / [GitHub](https://github.com/jakevdp/PythonDataScienceHandbook)
* [Go Books](https://github.com/dariubs/GoBooks) - GoLang Books
* [JSBooks](https://jsbooks.revolunet.com/) - Javascript Books
* [ChessProgramming](https://www.chessprogramming.org/) - Chess Programming Wiki

***

## ▷ Academic Papers

* ↪️ **[Study / Research Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu/#wiki_.25B7_research_tools)**
* ↪️ **[Research Paper Chatbots](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/ai#wiki_.25B7_specialized_chatbots)**
* ⭐ **[Sci-Hub](https://sci-hub.ru/)** - Science Articles / Research Papers / [Mirrors](https://vertsluisants.fr/index.php?article4/where-scihub-libgen-server-down) / [VK](https://vk.com/sci_hub) / [Subreddit](https://reddit.com/r/scihub)
* ⭐ **Sci-Hub Tools** - [Official TG Bot](https://t.me/scihubot), [2](https://t.me/freescience) / [Extension](https://addons.mozilla.org/en-US/firefox/addon/sci-hub-scholar/) / [DL Button](https://greasyfork.org/en/scripts/370246-sci-hub-button), [2](https://github.com/gchenfc/sci-hub-now) / [PDF Download](https://gagarine.medium.com/use-sci-hub-with-zotero-as-a-fall-back-pdf-resolver-cf139eb2cea7) / [Dumps](https://redd.it/edwi9b) / [DOI Redirect](https://greasyfork.org/en/scripts/412498)
* ⭐ **[arXiv](https://arxiv.org/)** or [ChinaRxiv](https://chinarxiv.org/) - Research Papers
* ⭐ **arXiv Tools** - [Chatbot](https://www.alphaxiv.org/) / [Search Engine](https://arxivxplorer.com/), [2](https://searchthearxiv.com/) / [3D Viewer](https://soarxiv.org/) / [Mobile](https://github.com/dagmawibabi/ScholArxiv)
* ⭐ **[Google Scholar](https://scholar.google.com/)** - Academic Papers Search Engine
* ⭐ **[Citrus Search](https://citrus-search.com/)** - Find Similar Research Papers
* ⭐ **[ResearchGate](https://www.researchgate.net/)** - Research Papers / Publications
* ⭐ **[SciLit](https://www.scilit.com/)** - Research Papers / Publications
* [ScholarKey](https://addons.mozilla.org/firefox/addon/scholarkey/) / [Script](https://greasyfork.org/scripts/582149) / [GitHub](https://github.com/ezraiiiiiiiiiiii/ScholarKey/) or [Scientific Doc Bypass](https://greasyfork.org/en/scripts/35521) - Add Open-Access Links to Academic Paper Sites
* [Chunkr](https://www.chunkr.ai/) or [Sophon](https://sophon.at/papers) - AI Research Paper Search
* [BulletPapers](https://www.bulletpapers.ai/) - Paper Summaries
* [Springer](https://link.springer.com/) - Research Papers / Publications
* [ScienceDirect](https://www.sciencedirect.com/) - Research Papers
* [Neliti](https://www.neliti.com/) - Academic Papers Search Engine
* [Share OSF](https://share.osf.io/) - Academic Papers Search Engine
* [Scinapse](https://scinapse.io/) - Academic Papers Search Engine / [Pro Script](https://rentry.co/scinapsebypass)
* [Semantic Scholar](https://www.semanticscholar.org/) - Academic Papers Search Engine
* [Consensus](https://consensus.app/) - Academic Papers Search Engine
* [Crossref](https://search.crossref.org/) - Articles Papers Search Engine
* [Lens](https://www.lens.org/) - Research Papers / Patents Database
* [Dimensions](https://app.dimensions.ai/discover/publication) - Research Papers / Patents Database
* [Academia](https://www.academia.edu/) - Academic Papers / [Downloader](https://github.com/ryanfb/academia-dl)
* [FreeFullPDF](https://freefullpdf.com/) - Academic Papers
* [⁠Open Alex](https://openalex.org/) - Academic Papers
* [Zooniverse](https://www.zooniverse.org/) - Crowdsourced Research
* [Clarivate](https://mjl.clarivate.com/) - Research Papers / Publications
* [Science Hub](https://www.pidantuan.com/) - Research Papers
* [Caltech Library](https://authors.library.caltech.edu/) - Research Papers
* [SciAlert](https://scialert.net/) - Research Papers
* [Springer](https://www.springer.com/) - Research Papers
* [Biomed Central](https://link.springer.com/brands/bmc) - Research Papers
* [Zenodo](https://zenodo.org/) - Research Papers
* [OA.mg](https://oa.mg/) - Research Papers
* [re3data](https://www.re3data.org/) - Research Data
* [Retraction Watch](https://retractionwatch.com/) - Retracted Research Papers
* [Ai2 Asta](https://asta.allen.ai/) - AI Scientific Paper Search
* [HAL](https://hal.science/) - Scientific Paper Search
* [Science.gov](https://www.science.gov/) - Scientific Paper Search
* [⁠Pidantuan](https://www.pidantuan.com/) - Scientific Paper Sharing Community / Requires Sign-Up
* [IDEAS](https://ideas.repec.org/) or [RePEc](http://repec.org/) - Economic Research Papers
* [PsyArXiv](https://osf.io/preprints/psyarxiv) - Psychology Research Papers
* [SocArXiv](https://osf.io/preprints/socarxiv) - Social Science Research Papers
* [Open Knowledge Maps](https://openknowledgemaps.org/) - Research Papers
* [Internet Archive Scholar](https://scholar.archive.org/) - Research Papers
* [Alexandria](https://digital.library.ucsb.edu/) - Research Papers
* [Paper Panda](https://paperpanda.app/) - Research Papers
* [Open Access Library](https://www.oalib.com/) - Research Papers
* [OpenAire](https://explore.openaire.eu/) - Research Papers
* [Association for learning Technology](https://repository.alt.ac.uk/view/subjects/) - Research Papers
* [Local Models Papers](https://rentry.org/LocalModelsPapers) - LLM Related Research Papers
* [⁠Aftergleam](https://aftergleam.app/) - Research Paper Reader / Android / [GitHub](https://github.com/jakobkreft/Aftergleam)
* [Legal Core](https://core.ac.uk/) - Papers / Academic
* [Dataone](https://www.dataone.org/) - Datasets
* [Kaggle](https://www.kaggle.com/datasets) - Datasets
* [Data Catalog](https://datacatalog.worldbank.org/) - Datasets
* [DBpedia](https://www.dbpedia.org/) - Datasets
* [GBIF](https://www.gbif.org/) - Biodiversity Datasets
* [RPubs](https://rpubs.com/) - R Markdown Data Publishing
* [PubMed](https://pubmed.ncbi.nlm.nih.gov/) - Medical Journals / [Search](https://www.pubmedisearch.com/)
* [OpenMD](https://openmd.com/) - Medical Journals
* [Free Medical Journals](http://www.freemedicaljournals.com/) - Medical Journals
* [⁠JMIR Publications](https://jmirpublications.com/) - Health / Medicine Journals
* [⁠PubMed Central](https://pmc.ncbi.nlm.nih.gov/) - Biomedical / Life Science Journals
* [medRxiv](https://www.medrxiv.org/) - Medicine Preprints
* [bioRxiv](https://www.biorxiv.org/) - Biology Preprints
* [Bioline](https://www.bioline.org.br/) - Bioscience Journals
* [SSRN](https://www.ssrn.com/) - Early Stage Research Papers
* [⁠PubPeer](https://pubpeer.com/) - View Scientific Research Criticism / Comments
* [Catalyzex](https://www.catalyzex.com/), [AI Reading List](https://docs.google.com/document/d/1bEQM1W-1fzSVWNbS4ne5PopB2b7j8zD4Jc3nm4rbK-U/) or [Daily Papers](https://huggingface.co/papers) - AI Research Papers
* [CensorBib](https://censorbib.nymity.ch/) or [Censored Planet](https://censoredplanet.org/) - Internet Censorship Research Papers
* [Connected Papers](https://www.connectedpapers.com/) or [LitMaps](https://app.litmaps.com/) - Find Connected Academic Papers

***

## ▷ Manuals

* 🌐 **[Manuals & Schematics](https://redd.it/nlw3er)**, [SafeManuals](https://safe-manuals.com/), [Manuzoid](https://manuzoid.com/), [manualzz](https://manualzz.com/), [ManualsNet](https://manualsnet.com/), [manua.ls](https://www.manua.ls/) or [ManualsLib](https://www.manualslib.com/) - Manual Directories
* ↪️ **[Vehicles Manuals](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25BA_vehicle)** - Vehicle Repair & Owner Manuals
* ⭐ **[RepairWiki](https://repair.wiki/)** - Repair Articles
* [ManualLib](https://www.manuallib.com/) or [Manuals+](https://manuals.plus/) - Manual Search
* [iFixIt](https://www.ifixit.com/) - Repair Manuals
* [Restarters](https://wiki.restarters.net/) - Device Repair Wiki / Guides
* [WonderHowTo](https://www.wonderhowto.com/) - Tech How-Tos
* [Manned.org](https://manned.org/) - Operating System Manuals
* [RetroSix](https://www.retrosix.wiki/) - Retro Console Repair Guides + Info / [Discord](https://discord.gg/D4Envqc5jr)
* [AntiqueRadio](https://antiqueradio.org/) - Vintage Radio + TV Restoration Guides
* [Exploitee.rs](https://www.exploitee.rs/) - Device Exploitation Wiki
* [David Kleinfeld Laboratory](https://neurophysics.ucsd.edu/Manuals/) - Lab Manuals

***

# ► Documents / Articles

* ↪️ **[Bypass Article Paywalls](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools#wiki_.25B7_paywall_bypass)**
* ⭐ **[TheFreeLibrary](https://www.thefreelibrary.com/)** - Articles
* ⭐ **[Nexus Search](https://t.me/nexus_search/214)**, [2](https://t.me/libgen_scihub_science_nexus_bot) - Science / Articles
* [Heystacks](https://heystacks.com/) - Public Google Docs
* [IDoc](https://idoc.pub/) - Document Search
* [Higher Intellect](https://preterhuman.net/) - Document Search
* [qDoc](https://idoc.tips/) - Document Search
* [PDFHost](https://pdfhost.io/) - Document Search
* [DOKU.PUB](https://doku.pub/) - Science / Articles
* [Academic Journals](https://academicjournals.org/) - Science / Articles
* [DOAJ](https://doaj.org/) - Journals / Articles
* [Proquest](https://www.proquest.com/) - Journals / Articles
* [MDPI](https://www.mdpi.com/) - Articles
* [Typewriter](https://tetw.org/) - Educational Articles & Essays
* [E-International Relations](https://www.e-ir.org/) - International Relations Articles
* [SkillCommons](https://www.skillscommons.org/) - Work Training Documents
* [Institute of Education Sciences](https://eric.ed.gov/) - Documents / Texts / Papers
* [SecretCanada](https://www.secretcanada.com/) - Canadian Document Archive
* [Pandora](https://pandora.nla.gov.au/) - Australian Document Archive
* [OATD](https://oatd.org/) or [⁠Brown Digital Repository](https://repository.library.brown.edu/studio/collections/dissertation/) - Theses / Dissertations
* [lol my thesis](https://lolmythesis.com/) - Summarized Theses
* [NSA Archive](https://nsarchive.gwu.edu/) - Reports
* [NAP](https://www.nationalacademies.org/publications/all) - Reports
* [WorldBank](https://www.worldbank.org/en/home) - Poverty Solution Research Data
* [Einstein Papers](https://einsteinpapers.press.princeton.edu/) - Albert Einstein's Collected Papers Archive
* [Aesthetics Archive](https://contempaesthetics.org/) - Aesthetics Articles / Notes Contemporary
* [CIA Publications](https://www.cia.gov/resources/publications/) - History / Reports
* [Constitute Project](https://www.constituteproject.org/) - World Constitutions Database
* [The American Presidency Project](https://www.presidency.ucsb.edu/) - Presidential Documents
* [Marine Corps Pubs](https://www.marines.mil/News/Publications/MCPEL/), [Air Force Pubs](https://www.e-publishing.af.mil/product-index/), [Army Pubs](https://armypubs.army.mil/), [⁠NZDF Documents](https://www.nzdf.mil.nz/media-centre/search-our-libraries/documents/) or [LiberatedManuals](https://www.liberatedmanuals.com/) - Military Documents / Manuals
* [NASA NTRS](https://ntrs.nasa.gov/collections/pubspace) or [STI](https://sti.nasa.gov/) - NASA Documents
* [CourtListener](https://www.courtlistener.com/) / [Unlock Docs](https://free.law/recap/), [USA Courts](https://pacer.uscourts.gov/) or [Case.law](https://case.law/) - Court Documents
* [Oyez](https://www.oyez.org/) - Supreme Court Case Summaries / Transcripts
* [Parliament Archives](https://www.parliament.uk/business/publications/archives/) - UK Parliamentary Documents
* [PapalEncyclicals](https://www.papalencyclicals.net/) - Catholic Church Documents
* [Open Payments](https://openpaymentsdata.cms.gov/) - Medical Device Company Payment Reports
* [Dataset Search](https://datasetsearch.research.google.com/) - Dataset Search Google
* [PDF / Doc Search Engine](https://cse.google.com/cse?cx=000013508089310229747:qf70z1tyrs0)

***

## ▷ Declassified / Leaked Documents

* 🌐 **[Epstein Research Resources](https://redd.it/1rc3gaz)** - Epstein Research Sites / Tools / Viewer Discretion Advised / Contains Censored NSFW Images
* ⭐ **[Epstein Exposed](https://www.epsteinexposed.com/)** / [GitHub](https://github.com/stonesalltheway1/Epstein-Pipeline), **[JMail](https://jmail.world/)** / [Wiki](https://jmail.world/wiki), [Epstein Secrets](https://epsteinsecrets.com/), [ExposingEpstein](https://exposingepstein.com/), [Epstein Library](https://www.justice.gov/epstein) or [Epstein Visualizer](https://epsteinvisualizer.com/) - Declassified Epstein Files / Viewer Discretion Advised / Contains Censored NSFW Images
* [WikiLeaks](https://wikileaks.org/) - Leaked Documents / [Index](https://file.wikileaks.org/)
* [The Uncensored Library](https://www.uncensoredlibrary.com/en) - Uncensored / Declassified Documents
* [FBI Vault](https://vault.fbi.gov/) - Declassified Documents
* [The Black Vault](https://www.theblackvault.com/) - Declassified Documents
* [Archives.gov](https://www.archives.gov/) - Declassified Documents
* [Distributed Denial of Secrets](https://ddosecrets.org/) - Transparency Collective
* [Library of Leaks](https://search.libraryofleaks.org/) - Leaked Documents
* [Cryptome](https://cryptome.org/) - Leaked Documents
* [⁠ICIJ](https://www.icij.org/investigations/) - Investigative Journalists Organization / Panama + Pandora Financial Leaks
* [Snowden Archive](https://github.com/iamcryptoki/snowden-archive) - Leaked Snowden Documents
* [⁠Climate Files](https://www.climatefiles.com/) - Climate Change Document Database / Exposes Climate Change Denying Companies
* [Google Leaks](https://www.zachvorhies.com/google_leaks/) - Leaked Google Documents

***

# ► Esoteric / Cultural

* ⭐ **[Sacred Text Archive](https://sacred-texts.com/)** - Esoterica / Mythology / Folklore / [Classic View](https://archive.sacred-texts.com/)
* ⭐ **[Libris Adepti](https://librisadepti.com/)** - Esoterica / Occult
* [Grimoar.cz](http://english.grimoar.cz/?Loc=key&Lng=2), [Darkbooks](https://darkbooks.org/collection/top250.html) or [Astrum Argenteum](https://www.astrumargenteum.org/library/) - Occult Books
* [Hermetic International](https://www.hermetics.net/) - Occult / Gnosticism / Hermetic / Philosophy
* [Hermetics](https://www.hermetics.org/library.html) - Ancient Texts / Mythology / Occult
* [EatTheFruit](https://www.eatthefruit.com/media-library/pdf-library/) - Ancient Texts / Mythology
* [Awakening-Intuition](https://www.awakening-intuition.com/ebooks.html) - Esoterica / Occult
* [Biblioteca Pleyades](https://www.bibliotecapleyades.net/esp_tema.htm) - Mythology / Conspiracy / Esoterica
* [Gnostic Society Library](http://www.gnosis.org/library.html) - Gnosticism
* [Logoi Library](https://logoilibrary.com/) - Gnosticism / Hermeticism
* [The Library of Consciousness](https://www.organism.earth/library/) - Esoterica
* [Esoteric Archive](https://esotericarchives.com/) - Esoterica
* [magZtore](https://t.me/magZtore) - Esoterica / Telegram
* [WonderlandLibraryOfMagicBooks](https://t.me/WonderlandLibraryOfMagicBooks) - Esoterica / Telegram
* [Synchroncity1111](https://t.me/synchroncity1111) - Esoterica / Telegram
* [SpiritualBooks](https://t.me/spiritualbooks) - Esoterica / Telegram
* [Masonic Library](https://masonicshop.com/masonic-library/) - Esoterica / Freemasonry
* [Rosicrucian Esotericism Lecture](https://rsarchive.org/) - Rosicrucian Esotericism
* [Dao](https://t.me/Dao_Qigong_Taiji_TCM_ebooks) - Spiritual Eastern Literature
* [IAPSOP](http://iapsop.com/) - Spiritualist / Occult Periodicals
* [Dhushara Research](https://www.dhushara.com/index.htm) - Metaphysics / Conspiracy / Psychedelics
* [The Theosophical Society](https://www.theosociety.org/) or [Theosophy World](https://www.theosophy.world/portfolio/term/ebooks) - Theosophy
* [Great Library of Eris](https://libraryoferis.org/) - Discordianism

***

## ▷ Abrahamic

* [Halakhah](https://www.halakhah.com/) - Talmud Translation
* [Targum](http://targum.info/targumic-texts/) - Targum Translation
* [Sefaria](https://www.sefaria.org/) - Jewish Texts Translations
* [The Dead Sea Scrolls](https://www.deadseascrolls.org.il/) - Dead Sea Scrolls Archive
* [Hidden Bible](http://www.hiddenbible.com/enoch/online.html) - Enoch Translation
* [DigiVatLib](https://digi.vatlib.it/) - Digital Vatican Library
* [BibleGateway](https://www.biblegateway.com/), [Armorer](https://armorer.io/), [Bible Hub](https://biblehub.com/) or [Bible.com](https://www.bible.com/) - Christian Bible
* [eSword](https://e-sword.net/) - Christian Bible Desktop App
* [Classics Ethereal Library](https://www.ccel.org/) - Christianity Literature
* [Bibliothek der Kirchenväter](https://bkv.unifr.ch/en/works?versionLanguage=eng) - Ancient Christian Literature
* [Early Christian Writings](https://www.earlychristianwritings.com/index.html) - Ancient Christian Literature
* [Quran.com](https://quran.com/) / [Android](https://github.com/quran/quran_android) / [iOS](https://github.com/quran/quran-ios), [Tanzil](https://tanzil.net/) or [AbcQuran](https://github.com/jomtek/AbcQuran) - Quran Translations
* [Sunnah.com](https://sunnah.com/) - Hadith Translation
* [Awesome Islam](https://github.com/AhmedKamal/awesome-Islam) - Islam Related Projects / Apps
* [Sirah](https://www.sirah.xyz/) - AI-Powered Hadith Translation / Collections
* [OpenMaktaba](https://openmaktaba.com/) - Islamic Books
* [TheIslam360](https://theislam360.com/) - Islamic Research App
* [Muslim Scholars](https://muslimscholars.info/) - Muslim Scholar Database

***

## ▷ Dharmic

* [Wisdom Library](https://www.wisdomlib.org/) - Dharmic Texts Archive
* [Vedanta Shastras](https://www.shastras.com/) - Hinduism
* [Encyclopedia Of Hinduism](https://archive.org/details/ConstanceA.JonesJamesD.RyanEncyclopediaOfHinduism/) - Hinduism Encyclopedia
* [BhagavadGitaApp](https://github.com/WirelessAlien/BhagavadGitaApp) or [Dharmik](https://github.com/shub39/Dharmik) - Bhagavad Gita Apps
* [Vedabase](https://vedabase.io/en/) - Bhaktivedanta Swami / Books / Transcripts / Letters
* [84000](https://84000.co/) - Buddhism
* [Encyclopedia Of Buddhism](https://archive.org/details/EdwardA.IronsEncyclopediaOfBuddhismEncyclopediaOfWorldReligions/) - Buddhist Encyclopedia
* [Buddhism Dictionary](http://www.buddhism-dict.net/ddb/) - Buddhist Dictionary
* [Sutta Central](https://suttacentral.net/) - Esoterica / Buddhism
* [Dhamma Talks](https://www.dhammatalks.org/) - Esoterica / Buddhism
* [Sri Granth](https://www.srigranth.org/) - Guru Granth Sahib Translation
* [SikhBookClub](https://sikhbookclub.com/) - Sikhism Book / Sign-Up
* [Jainism Library of Jain Literature](https://www.atmadharma.com/index.html) - Esoterica / Jainism

***

# ► Book Tracking / Databases

* ⭐ **[StoryGraph](https://www.thestorygraph.com/)** - Reading Tracker / Detailed Statistics / Mood-Based Recommendations
* ⭐ **[Hardcover](https://hardcover.app/)** - Book Tracking / Reviews / Recommendations / [KOReader Plugin](https://github.com/billiam/hardcoverapp.koplugin) / [Discord](https://discord.com/invite/hardcover)
* ⭐ **[Goodreads](https://www.goodreads.com/)** - Book Tracking / Reviews / Reading Lists / Recommendations / [Frontend](https://biblioreads.eu.org/)
* ⭐ **[LibraryThing](https://www.librarything.com/)** - Personal Library Cataloguing / Reviews / Recommendations / [Talpa Search](https://www.talpasearch.com/)
* ⭐ **[Open Library](https://openlibrary.org/)** - Open Bibliographic Database / Editions / Reading Lists / [API](https://openlibrary.org/developers/api)
* [WorldCat](https://search.worldcat.org/) - Global Library Catalogue / Book Editions / Library Holdings
* [BookBrainz](https://bookbrainz.org/) - Open Book Metadata Database / [API](https://api.bookbrainz.org/1/docs/)
* [Book Notification](https://www.booknotification.com/) - Author & Series Tracking / New Release Alerts / Reading Orders
* [Bookfeed.io](https://bookfeed.io/) - RSS Feeds for New Releases by Favourite Authors
* [ISFDB](https://www.isfdb.org/) - Science Fiction / Fantasy / Horror Bibliographic Database / Awards / Publication Histories
* [Fantastic Fiction](https://www.fantasticfiction.com/) - Author Bibliographies / Book Series / New Releases
* [Book Series in Order](https://www.bookseriesinorder.com/) - Author Bibliographies / Publication & Chronological Reading Orders
* [BookHype](https://bookhype.com/) - Reading Tracker / Book Release Calendar / Series Tracking
* [BookWyrm](https://joinbookwyrm.com/) - Open-Source Federated Reading Tracker / [Official Instance](https://bookwyrm.social/) / [GitHub](https://github.com/bookwyrm-social/bookwyrm)
* [Literal](https://literal.club/) - Social Reading Tracker / Reviews / Reading Lists
* [Oku](https://oku.club/) - Book Tracking / Reading Goals / Collections / Statistics
* [Candl](https://www.candlapp.com/) - Private Reading Tracker / Notes / Statistics / Spaced Repetition
* [⁠Bookplate](https://bookplate.eu/) - Private Reading Tracker / Notes
* [Libib](https://www.libib.com/) - Personal Library Cataloguing / ISBN Scanning / Web & Mobile
* [All My Books](https://www.bolidesoft.com/allmybooks.html) - Desktop Book Collection Manager / Windows
* [Anobii](https://www.anobii.com/) - Book Cataloguing / Reviews / Reading Community
* [Litsy](https://www.litsy.com/) - Social Reading / Reviews / Book Community
* [EntertainMe](https://www.entertainme.fun/) - Multi-Media Tracking / Books / Films / Games
* [rate.house](https://rate.house/) - Multi-Media Ratings / Reviews / Tracking
* [Yamtrack](https://github.com/FuzzyGrim/Yamtrack) - Self-Hosted Media Tracker / Books / Films / TV / Games
* [⁠BookOrbit](https://bookorbit.app/) / [GitHub](https://github.com/bookorbit/bookorbit) or [⁠Grimmory](https://grimmory.org/) / [GitHub](https://github.com/grimmory-tools/grimmory) - Ebook Managers / Self-Hosted
* [Listal](https://www.listal.com/) - Media Collection Tracking / Reviews / Lists
* [Ratings Filter](https://www.book-filter.com/) - Filter Books by Goodreads & StoryGraph Ratings
* [Books Search](https://books-search.typesense.org/) - Fast Open Library Book Database Search
* [Romance.io](https://www.romance.io/) - Romance Book Database / Tropes / Content Warnings / Ratings
* [nooSFere](https://www.noosfere.org/) - French-Language Science Fiction Bibliographic Database
* [Uchronia](https://www.uchronia.net/) - Alternate History Fiction Bibliography / Series / Divergence Points
* [⁠Banned Book List](https://docs.google.com/spreadsheets/u/0/d/10NwV38Rp6EF8X8p7Qa2iXpSFn9m46v717DQtJkLictI) - List of Books Banned by Schools

***

## ▷ Comic Tracking / Databases

* ⭐ **[LeagueOfComicGeeks](https://leagueofcomicgeeks.com/)** - Comic Tracking / Database / Releases
* [Omnibus Tracker](https://omnibusreaders.com/) - Comic Tracking / Database / Releases / Sales Tracking / [Discord](https://discord.gg/8N3sgZbV5H)
* [⁠VerseDb](https://versedb.com/) - Comic Tracking / Database / Releases / [Discord](https://discord.gg/mbtqVH8R9n)
* [⁠Comic Vine](https://comicvine.gamespot.com/) - Comic Database / Forum
* [⁠Grand Comics Database](https://www.comics.org/) - Comic Database
* [The Webcomic List](https://www.thewebcomiclist.com/) - Webcomic Database / Release Tracker
* [piperka](https://piperka.net/) - Webcomic Database / Release Tracker
* [Mad Cover Site](https://madcoversite.com/) - MAD Magazine History Archive

***

## ▷ Manga Tracking / Databases

* ⭐ **[MAL](https://myanimelist.net/)** - Manga / Light Novels / Tracking / Database / Reviews / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_myanimelist_tools)
* ⭐ **[Anilist](https://anilist.co/)** - Manga / Light Novels / Manhwa / Manhua / Tracking / Database / Reviews / [Extras](https://greasyfork.org/en/scripts/370473-automail)
* ⭐ **[MangaBaka](https://mangabaka.org/)** - Multi-Site Aggregator for Manga / Manhwa / Manhua / OEL / Light Novels w/ Tracking & Database / [Discord](https://mangabaka.org/discord)
* ⭐ **[Novel Updates](https://www.novelupdates.com/)** or [⁠RanobeDB](https://ranobedb.org/) - Light Novel Tracking / Databases
* [MangaUpdates](https://www.mangaupdates.com/) - Manga Tracking

***

# ► Curated Recommendations

## ▷ Book Recommendations

* 🌐 **[Book Awards](https://rentry.co/bookawards/)** - Index of Literary Awards
* ⭐ **[Five Books](https://fivebooks.com/)** - Expert Recommendations / Interviews / Reading Lists by Subject
* ⭐ **[The Greatest Books](https://www.thegreatestbooks.org/)** - Aggregated Greatest Books Rankings / Custom Lists
* ⭐ **[NPR's Books We Love](https://apps.npr.org/best-books/)** - Curated Recommendations / Genre & Theme Filters
* ⭐ **[StoryGraph](https://www.thestorygraph.com/)** - Personalized Recommendations / Mood & Genre Filters
* ⭐ **[Book Marks](https://bookmarks.reviews/)** - Aggregated Professional Reviews / Critics' Consensus
* ⭐ **[Whichbook](https://www.whichbook.net/)** - Mood-Based Discovery / Reader-Curated Recommendations
* ⭐ **[The Book Prize Index](https://book-prize-index.vercel.app/)** - Nonfiction Awards / Searchable Prize Database / [API](https://book-prize-index.vercel.app/data)
* [LibraryThing Awards](https://www.librarything.com/award) - Literary Awards / Winners & Nominees
* [Book DNA](https://bookdna.com/) - Author-Curated Recommendations / Themed Reading Lists
* [GoodBooks](https://www.goodbooks.io/) or [Read This Twice](https://readthistwice.com/) - Recommendations from Notable People
* [Most Recommended Books](https://www.mostrecommendedbooks.com/) - Recommendations from Influential People
* [r/suggestmeabook](https://www.reddit.com/r/suggestmeabook/) - Community Recommendations
* [The Book Rex](https://thebookrex.com/) - Fiction Discovery by Genre / Tropes / Content Warnings
* [Dan's Library](https://rentry.co/danslibrary/) - Curated Recommendations
* [r/TrueLit Top 100 Lists](https://www.reddit.com/r/TrueLit/wiki/top100lists) - Community-Ranked Literary Fiction
* [The Greatest Literature](https://editoreric.com/) - Classic Literature Rankings / Literary Canon
* [Greater Books](http://www.greaterbooks.com/) - Recommendations / Reading Lists
* [5000 Best](http://5000best.com/books/) - Top 5000 Books / Rankings
* [RecommendMeABook](https://recommendmeabook.com/) or [Uncovered](https://uncovered.ink/) - Discover by Reading The Opening Pages
* [Gnooks](https://www.gnooks.com/) or [Literature-Map](https://www.literature-map.com/) - Similar Author Discovery
* [Break the Bubble!](https://abooklike.foo/escape) - Discover Books Outside Your Usual Reading Tastes
* [TasteDive](https://tastedive.com/books) - Similar Book Recommendations
* [Readow](https://readow.ai/) - AI-Based Recommendations
* [Hacker Recommended Books](https://hacker-recommended-books.vercel.app/) - Recommendations from Hacker News
* [Mind Expanding Books](https://mindexpandingbooks.com/) - Curated Recommendations / [GitHub](https://github.com/hackerkid/Mind-Expanding-Books)
* [Reddit Reads](https://www.redditreads.com/) - Historical Most-Mentioned Books on Reddit / Data Through March 2023

***

## ▷ Comic Recommendations

* ⭐ **[ComicBookRoundup](https://comicbookroundup.com/)** - Comic Rating Aggregator ⁠
* ⭐ **[Comic Book Reading Orders](https://comicbookreadingorders.com/)** - Comic Book Reading Orders
* [r/Marvel Recommended](https://www.reddit.com/r/Marvel/wiki/faq) - Marvel Comic Recommendations
* [ComicBookCanon](https://www.comicbookcanon.com/) - Comics Top Lists
* [r/DCcomics Recommended](https://www.reddit.com/r/DCcomics/wiki/recommended) - DC Comic Recommendations
* [DC Media List](https://docs.google.com/spreadsheets/d/1znGm7MswCG0yuRHSvyHDUuIdeNSS7DP-yWOEqKYTAIY/) - Full DC Media List (1935-2024)

***

## ▷ Manga Recommendations

* ⭐ **[MangaBaka](https://mangabaka.org/)** - Multi-Site Aggregator for Manga / Manhwa / Manhua / OEL / Light Novels Recommendations / [Discord](https://mangabaka.org/discord)
* ⭐ **[MangaUpdates](https://www.mangaupdates.com/)** - Manga Database / Releases Updates
* [Kitsu](https://kitsu.io/) - Manga
* [Mangaki](https://mangaki.fr/) - Manga Recommendations
* [Manga Codex](https://mangacodex.com/) - Manga Infographics & Sales Stats
* [Anime-Planet](https://anime-planet.com/) - Manga
* [Nevix](https://nevix.com/) - Manga / Social Media
* [Kenmei](https://www.kenmei.co/) - Manga / [Discord](https://discord.gg/XeTFtYW)
* [Spin.moe](https://spin.moe/) - Find Random Manga

***

# ► Helpful Sites / Apps

* 🌐 **[Ebook Converters Wiki](https://wiki.mobileread.com/wiki/E-book_conversion)** or [Ebook-Converter](https://ebook-converter.com/) - Ebook Converter Software Indexes
* ↪️ **[Summary Generators](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools#wiki_.25B7_text_rephrasing)**
* ↪️ **[PDF File Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/file-tools/#wiki_.25B7_pdf_tools)**
* ⭐ **[Kindle Comic Converter](https://github.com/ciromattia/kcc)** - Multi-Format Converter / App
* ⭐ **[Papeer](https://papeer.tech/)** / [GitHub](https://github.com/lapwat/papeer), [dotepub](https://dotepub.com/) or [epub-creator](https://github.com/NiklasGollenstede/epub-creator) - Webpage to EPUB Converter
* [boko](https://zacharydenton.github.io/boko/) / [GitHub](https://github.com/zacharydenton/boko) or [Ebook-Online-Convert](https://ebook.online-convert.com/) - Multi-Format Converters / Web
* [⁠Manga & Comic Converter](https://www.mangaconverter.com/) - Comic / Manga to Book Converter / Web / [GitHub](https://github.com/NilsLeo/kcc-cloud)
* [eBook Converter Bot](https://t.me/ebook_converter_bot) - Telegram Ebook Converter / [GitHub](https://github.com/yshalsager/ebook-converter-bot)
* [CrowBook](https://github.com/crowdagger/crowbook) - Markdown to EPUB Converter
* [WorldCat](https://www.worldcat.org/), [Hoopla](https://www.hoopladigital.com/), [Libby](https://libbyapp.com/) / [Downloader](https://github.com/PsychedelicPalimpsest/LibbyRip), [LibrarySearch](https://librarysearch.gre.ac.uk/) or [TRL](https://www.trl.org/) - Search Local Libraries / [Extension](https://www.libraryextension.com/)
* [⁠Library Technology](https://librarytechnology.org/libraries/) - Global Library Database
* [How to Get Library Card Online](https://rentry.co/9b3vdo)
* [⁠⁠ReciproCard](https://reciprocard.com/) - Find Library Cards for Reciprocal Borrowing
* [⁠Books Unbanned](https://booksunbanned.com/) - Free Digital US Library Cards / Ages 13-26 Only
* [Scribd PDF](https://scribd.pdfdownloaders.com/) or [ScribdVPDF](https://scribdvpdf.blogspot.com/) / [2](https://docdownloader.com/) / [3](https://scribd.vpdfs.com/) / [4](https://scribd.downloader.tips/) / [5](https://scribd.vdownloaders.com/) - Scribd Downloaders
* [BookInfo](https://lordgnomembe.github.io/BookInfo/) - Get Book Info via ISBN
* [DeDRM_tools](https://github.com/Satsuoni/DeDRM_tools) - Ebook DRM Removal
* [FiveFilters](https://www.fivefilters.org/) - Multiple Article Accessibility Tools
* [LazyLibrarian](https://gitlab.com/LazyLibrarian/LazyLibrarian) - Book Torrent Autodownload / Manager
* [FicHub](https://fichub.net/), [FicDownloader](https://ficdownloader.com/) or [FanFictionDownloader](https://fanfictiondownloader.net/) - Fanfiction Downloaders
* [Sigil Ebook](https://sigil-ebook.com/) - EPUB Editor
* [epub-translator](https://github.com/sharplab/epub-translator) - EPUB Translators
* [SmartStitch](https://github.com/MechTechnology/SmartStitch) - Stitch Together Webtoons
* [FanFicFare](https://github.com/JimmXinu/FanFicFare) - Generate Ebooks from Stories / Fanfiction
* [HowLongToRead](https://howlongtoread.com/) or [ReadingLength](https://www.readinglength.com/) - Find Book Lengths / Reading Times
* [BTW](https://booktriggerwarnings.com/) - Book Trigger Warnings
* [DIY Book Scanner](https://diybookscanner.org/) - How to Scan Books
* [The Submission Grinder](https://thegrinder.diabolicalplots.com/) - Find a Publisher