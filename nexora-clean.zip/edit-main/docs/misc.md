***
***
**[◄◄ Back to Wiki Index](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/index)**
***
***

# ► Indexes

* 🌐 **[Awesome List Index](https://github.com/sindresorhus/awesome), [GitHub Topics](https://github.com/topics/awesome)** / [2](https://github.com/topics/awesome-list) - All Awesome Lists
* 🌐 **[Lists](https://github.com/jnv/lists)** - List of Lists Index
* ↪️ **[AI Indexes](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/ai#wiki_.25BA_ai_indexes)**
* ↪️ **[Privacy Indexes](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25B7_privacy_guides_.2F_indexes)**
* ⭐ **[r/PiratedGames Megathread](https://rentry.org/pgames)** - Game Site Index / [Discord](https://discord.gg/dZWwhUy)
* ⭐ **[CS.RIN Mega](https://cs.rin.ru/forum/viewtopic.php?f=10&t=95461)** - Game Site Index
* ⭐ **[Dan's Guides](https://rentry.co/danxyz7)** - List of Guides by Dan
* ⭐ **[privateersclub](https://privateers.wiki/)** - Game Site Index / [Discord](https://discord.gg/jz8dUnnD6Q)
* ⭐ **[Wotaku](https://wotaku.wiki/)** - Otaku Index / [Discord](https://discord.gg/vShRGx8ZBC)
* ⭐ **[EverythingMoe](https://everythingmoe.com/)** - Otaku Media Index / [Subreddit](https://www.reddit.com/r/everythingmoe/) / [Discord](https://discord.gg/GuueaDgKdS)
* ⭐ **[The Index](https://theindex.moe)** - Japanese Site Index / Bookmarking Site / [Wiki](https://thewiki.moe/) / [Discord](https://discord.gg/Snackbox)
* ⭐ **[Awesome Search](https://awesomelists.calvinjeng.io/)** - Awesome List Search
* ⭐ **[Couleur Tweak Tips](https://ctt.cx/)** - Comprehensive Hub of Resources and Tools / [Discord](https://discord.gg/CTT)
* ⭐ **[r/InternetIsBeautiful](https://reddit.com/r/InternetIsBeautiful)** - Helpful / Fun Sites
* ⭐ **[FMHY Search](https://fmhy.net/posts/search)** - Search the Wiki
* [Wispy Docs](https://wispydocs.pages.dev/) - List of Guides by Wispy
* [FMHY Android](https://github.com/omeg4-dev/fmhy-android) - FMHY Android App
* [Track Awesome List](https://www.trackawesomelist.com/) - Daily Awesome List Updates
* [⁠ForumDirectory](https://www.forumdirectory.com/) - Forum Directory
* [theindex.fyi](https://theindex.fyi/), [ooh.directory](https://ooh.directory/), [IndieBlogs](https://indieblog.page/), or [⁠Kagi Small Web](https://kagi.com/smallweb/) - Find Random Small / Indie Sites
* [xRanks](https://xranks.com/), [Start.me Stats](https://start.me/pages), [StatCrop](https://www.statscrop.com/websites/top-sites/), [HypeStat](https://hypestat.com/), [10 Million Sites](https://openpagerank.keywordseverywhere.com/top-10-million-domains) or [CuteStat](https://www.cutestat.com/) - Site Rankings
* [Store.app](https://store.app/), [NoSignups](https://nosignups.net/) / [GitHub](https://github.com/BraveOPotato/FckSignups), [SaaS Discovery](https://saasdiscovery.com/) or [Electron](https://www.electronjs.org/apps) - Web App Indexes
* [⁠JustIndex](https://justindex.cc/) - Otaku Index / [Mirrors](https://projectjust.xyz/) / [Subreddit](https://www.reddit.com/r/ProjectJust) / [Discord](https://discord.gg/P3yqksmGun)
* [ibiblio](https://www.ibiblio.org/) - Site / Tool Index
* [Ripped](https://ripped.guide/) - Site Index / [Discord](https://discord.com/invite/6qVr2aR)
* [unapothecary's terminal](https://unapothecary.neocities.org/websites) - Site / Tool Index
* [mw.rat.bz](https://mw.rat.bz/index.html) - Site / Tool Index
* [OneMillionScreenshots](https://onemillionscreenshots.com/) - Website Snapshot Map
* [Archive-It](https://archive-it.org/) - Archive.org Collections
* [Single Serving Sites](https://singleservingsites.cool/) - Single-Purpose Sites
* [Clone Wars](https://gourav.io/clone-wars) - Site Clone Index / [GitHub](https://github.com/GorvGoyl/Clone-Wars)
* [Open Sustainable Technology](https://opensustain.tech/) - Sustainable Tech Project Index
* [DeletedCity](https://deletedcity.net/) or [Restorativland](https://geocities.restorativland.org/) - Geocities Site Indexes
* [The National Archives](https://www.nationalarchives.gov.uk/webarchive/) - UK Government Site Archive / [X](https://x.com/UKNatArchives)
* [Gazetteer of Wikis](https://meta.miraheze.org/wiki/Gazetteer_of_wikis), [Wiki Stats](https://wikistats.wmcloud.org/display.php?t=mh) or [WikiDiscover](https://meta.miraheze.org/wiki/Special:WikiDiscover) - Miraheze Wiki Indexes
* [Creative Commons](https://github.com/fmhy/FMHYedit/issues/1386#issuecomment-1906854653) - Creative Commons Content Sites
* [OldSchoolSitesCatalogue](https://github.com/rarelygoeshere/OldSchoolSitesCatalogue), [404PageFound](https://www.404pagefound.com/) or [href.cool](https://href.cool/) - Oldschool Site Indexes
* [Funny / Useless](https://rentry.org/aksry2vc) - Funny / Useless Websites
* [Websites From Hell](https://websitesfromhell.net/) - Sites with Questionable Designs

***

## ▷ Git Project Indexes

* [Active GitHub Forks](https://techgaun.github.io/active-forks/) - Active Fork Index
* [Lovely Forks](https://github.com/musically-ut/lovely-forks) - Fork Repo Index
* [OSS Insight](https://ossinsight.io/) - Project Index
* [sourcehut](https://sr.ht/) - Project Index
* [Awesome Made by Brazilians](https://github.com/felipefialho/awesome-made-by-brazilians) - Project Index
* [Awesome Opensource Apps](https://github.com/unicodeveloper/awesome-opensource-apps) - Project Index
* [LibHunt](https://www.libhunt.com/) - Project Index
* [bestofjs](https://bestofjs.org/) - Project Index
* [git.news](https://git.news/) - Project Index
* [GitHub Rankings](https://evanli.github.io/Github-Ranking/) - Git Project Rankings / [GitHub](https://github.com/EvanLi/Github-Ranking)

***

## ▷ Random Sites / Discovery

* ⭐ **[Vijay's Virtual Vibes](https://vijaysvibes.uk/)** - Find Random Sites / [iFrame Version](https://vijaysvibes.uk/iframe-version.html)
* [Chance](https://chanceapp.io/?c=CHANCE-FMHY-DOOR) - Find Random Sites
* [BoredButton](https://www.boredbutton.com/) - Find Random Sites
* [Mx Tynehorne’s Cabinet](https://satyrs.eu/linkroll) - Find Random Sites
* [The Useless Web](https://theuselessweb.com/), [2](https://theuselessweb.site/) - Find Random Sites
* [JumpStick](https://jumpstick.app/) - Find Random Sites
* [Trilzo](https://www.trilzo.com/) - Find Random Sites
* [ViralWalk](https://www.viralwalk.com/) - Find Random Sites
* [The Forest](https://theforest.link/) - Find Random Sites
* [PortalPioneer](https://www.portalpioneer.com/) - Find Random Sites
* [Random-Website](https://random-website.com/) - Find Random Sites
* [Wilderness Land](https://wilderness.land/) - Find Random Sites
* [CloudHiker](https://cloudhiker.net/) - Find Random Sites
* [⁠OpenWeird](https://openweird.com/) or [⁠r/WeirdWebsites](https://www.reddit.com/r/WeirdWebsites/) - Find Random Weird Sites
* [WebRelic](https://www.webrelics.org/) - Find Random Retro Sites
* [Wiby](https://www.wiby.me/) - Find Random Retro Sites
* [HyperText](https://hypertext.tv/) - Random Sites / TV Channel Style / [GitHub](https://github.com/evadecker/hypertext.tv)

***

# ► Free Stuff

* [AppAgg](https://appagg.com/) - Multi-Platform / Apps / [Discord](https://discord.gg/XUhs6fcFqQ) / [GitHub](https://github.com/AppsAgg/AppAgg)
* [FreeCycle](https://www.freecycle.org/), [TrashNothing](https://trashnothing.com/) or [Freegle](https://www.ilovefreegle.org/) - Free Stuff Exchange / Gifting Communities
* [r/GooglePlayDeals](https://reddit.com/r/googleplaydeals) - Free / Cheap Apps / Games / [Reddit Bot](https://github.com/a-ton/gpd-bot)
* [App Sales](https://www.app-sales.net/nowfree/) - Free / Cheap Apps / Games
* [r/AppHookup](https://www.reddit.com/r/AppHookup/) - Free / Cheap Software & Apps / Games
* [AppRaven](https://appraven.net/activity/pricedrops?ratingCount=0&price=FREE) - Apple Platform Apps / Games / [Subreddit](https://www.reddit.com/r/AppRaven/) / [Telegram](https://t.me/AppRavenOfficial) / [Discord](https://discord.com/invite/q8nPsNAypC)
* [BAEN](https://www.baen.com/catalog/category/view/s/free-library/id/2012) - Books
* [FreeForStudent](https://freeforstudents.org/) or [⁠Student Offers](https://www.studentoffers.co/) - Free Student Deals / Discounts
* [FreeReadFeed](https://www.freereadfeed.com/) or [eReaderIQ](https://www.ereaderiq.com/freebies) - Free Kindle Releases
* [r/FREE](https://reddit.com/r/FREE/)
* [⁠r/freebies](https://www.reddit.com/r/freebies/)
* [r/eFreebies](https://reddit.com/r/eFreebies)
* [r/udemyfreebies](https://reddit.com/r/udemyfreebies)
* [r/FreeEBOOKS](https://reddit.com/r/FreeEBOOKS)

***

## ▷ Free Games

* ⭐ **[IsThereAnyDeal](https://isthereanydeal.com/giveaways/)** - Games / [Extension](https://augmentedsteam.com/) / [Discord](https://discord.com/invite/C3K4bBh)
* [FreeToGame](https://www.freetogame.com/games) or [Acid Play](https://acid-play.com/) - F2P Games / [Trackers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25BA_free_stuff)
* [Free Games Claimer](https://github.com/vogler/free-games-claimer) - Auto-Claim Free Epic, Amazon, and GOG Games
* [epicgames-freegames-node](https://github.com/claabs/epicgames-freegames-node) - Auto-Claim Free Epic Games
* [Free250](https://steam250.com/price/free), [r/FreeGamesOnSteam](https://reddit.com/r/FreeGamesOnSteam) or [SteamDB](https://steamdb.info/upcoming/free/) - Steam Games
* [SteamGifts](https://www.steamgifts.com/), [SteamDrops](https://steamdrops.net/) or [Key Hub](https://key-hub.eu/) - Steam Key Giveaways / [Discord](https://discord.gg/RbWahNY)
* [IndieGala](https://freebies.indiegala.com/) - Games
* [FreeGameCodes](https://freegames.codes/) - Games / [Discord](https://discord.gg/ZmUbRcp)
* [r/freegames](https://www.reddit.com/r/freegames/) - Games
* [FreeToKeep](https://freetokeep.gg/) - Games / [Discord](https://discord.gg/t3Yh5Pfw6Y)
* [r/RandomActsOfGaming](https://www.reddit.com/r/RandomActsOfGaming/) - Games
* [TemporarilyFreeGames](https://t.me/temporarilyfreegames) - Games
* [GG.deals Free](https://gg.deals/news/?availability=1&type=6) - Games / [Extension](https://gg.deals/extension/) / [Discord](https://discord.com/invite/NhsTFvdHXG)
* [GamerPower](https://www.gamerpower.com/) - Games
* [GrabFreeGames](https://grabfreegames.com/notifications) - Games / [Steam Group](https://steamcommunity.com/groups/GrabFreeGames) / [Discord](https://discord.gg/CjQSS4z)
* [Epic Games Free](https://www.epicgames.com/store/en-US/free-games) or [Epic Free Games](https://t.me/epicfreegames) - Free Epic Games
* [EpicFreeGamesList](https://josephmate.github.io/EpicFreeGamesList/) - Epic Free Games List
* [Steam Mods](https://store.steampowered.com/search/?maxprice=free&category1=997) - Steam Mods
* [Freetchio](https://shaigrorb.github.io/freetchio/) - itch.io Games
* [⁠VRDB](https://vrdb.app/games?min_price=0&max_price=0) or [QuestStoreDB](https://queststoredb.com/free_apps/) - VR Games
* [NobsGames](https://nobsgames.stavros.io/android/?name=&genre=&rating__gt=&price=free) - Game APKs
* [MiniReview](https://minireview.io/browse?sort=last-added-reviews&monetization=free&monetization-android=free&monetization-ios=free) - Mobile Game Recommendations / [Discord](https://discord.gg/TJq6EXfm7f)
* [Games Radar](https://play.google.com/store/apps/details?id=com.arioch.efgr) - Games / Android App
* [r/FreeGameFindings](https://reddit.com/r/FreeGameFindings) / [Socials](https://freegamefindings.ca/)
* [r/Freegamestuff](https://reddit.com/r/Freegamestuff)
* [Free Packages](https://steamdb.info/freepackages/) - Mass Activate All Free Steam Games / $5 Account Min / [Guide](https://youtu.be/svbdw-pYNT8)

***

## ▷ Assistance / Charity

* 🌐 **[Global Crisis Support Resources](https://fluffle.cc/provide)**
* ⭐ **[GiveWell](https://www.givewell.org/)**, [CharityNavigator](https://www.charitynavigator.org/), [Effective Altruism Funds](https://funds.effectivealtruism.org/), [Arab.org](https://arab.org/), [CharityWatch](https://www.charitywatch.org/) or [ProPublica](https://projects.propublica.org/nonprofits/) - Charity Ratings / Resources
* ⭐ **[⁠FindHelp](https://www.findhelp.org/)** - Find Free or Reduced-Cost Resources / US Only
* [⁠Single Mother Guide](https://singlemotherguide.com/) - Single Mother Government Benefits Guide / US Only
* [Be My Eyes](https://www.bemyeyes.com/) - Assist the Visually Impaired
* [r/Assistance](https://www.reddit.com/r/Assistance/) or [r/borrow](https://www.reddit.com/r/borrow/) - Assistance / Donation Subreddits
* [r/Homeless](https://www.reddit.com/r/homeless/) - Homeless Assistance Subreddit
* [r/Random_Acts_Of_Pizza](https://www.reddit.com/r/Random_Acts_Of_Pizza/) - Pizza Donation Subreddit
* [TinyKitten](https://tinykittens.com/) - Kitten Rescue / Donation
* [Free Rice](https://freerice.com/) - Earn Rice for the World Food Programme / Trivia
* [⁠Folding@home](https://foldingathome.org/) - Donate Idle PC to Disease Research
* [⁠e-NABLE](https://enablingthefuture.org/) - Volunteer Own 3D Printer for use in Prosthetic Limb Printing

***

# ► Food

* 🌐 **[/m/food](https://www.reddit.com/user/Siryonkee/m/food/)** - Food Multireddit
* 🌐 **[Dolici](https://dolici.com/)** - Top Restaurant List
* ⭐ **[Baking Calculators](https://bakingcalculators.com/)** - Measurement System Conversion Calculators
* ⭐ **[Grocy](https://grocy.info/)** / [Android](https://patrickzedler.com/grocy/) / [Subreddit](https://www.reddit.com/r/grocy) / [GitHub](https://github.com/grocy/grocy) or [Listonic](https://new.app.listonic.com/en) - Grocery / Pantry Managers
* ⭐ **[Too Good To Go](https://www.toogoodtogo.com/)** - Surplus Food Marketplace / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/TGTG.md)
* ⭐ **[Sporked](https://sporked.com/)** or [⁠Taquitos](https://www.taquitos.net/) - Packaged Food & Snack Reviews / Databases
* ⭐ **[Still Tasty](https://www.stilltasty.com/)** or [EatByDate](https://www.eatbydate.com/) - Shelf Life Guides
* ⭐ **[OpenTable](https://www.opentable.com/)** - Restaurant Reservation Search
* [⁠LocalHarvest](https://www.localharvest.org/), [⁠Local Picks](https://localpicks.org/) or [⁠USDA Local Food Portal](https://www.usdalocalfoodportal.com/) - Find Local Farms / Farmers' Markets / US Only
* [⁠CheapFoodMap](https://cheapfoodmap.com/) - Find Cheap (Under $10 Meals) / US Only
* [⁠Produce Converter](https://www.howmuchisin.com/produce_converters) - Produce Converter / Calculator
* [DoesItGoBad.com](https://www.doesitgobad.com/) - Food Storage Tips
* [⁠Save The Food](https://savethefood.com/) - Food Waste Prevention Tips / Tools
* [FoodExpirationDates](https://github.com/lorenzovngl/FoodExpirationDates) or [Fridgey](https://f-droid.org/packages/lying.fengfeng.foodrecords/) - Food Expiration Trackers
* [⁠Lowtein](https://lowtein.com/) - Meat / Dairy Grocery Deal Comparisons
* [⁠Cook Well](https://www.cookwell.com/) - Cooking Lessons / Science
* [Parsnip](https://www.parsnip.ai/) - Cooking Lessons / Skill Tracking App
* [r/Cooking](https://reddit.com/r/Cooking) - Cooking Discussion / Tips
* [r/AskCulinary](https://reddit.com/r/AskCulinary) - Get Cooking Advice
* [⁠Apple Rankings](https://applerankings.com/) - ⁠Apple Rankings / Reviews
* [Crispy Creations](https://clarasguide.valeena.workers.dev/Guides/crispycreations/) - Potato Chip Info / Guides
* [FermenThings](https://wiki.fermenthings.be/) - Fermentation Wiki
* [⁠SaltYourMeat](https://www.saltyourmeat.com/) - Dry Brining Calculator
* [HackTheMenu](https://hackthemenu.com/) - Fast Food Secret Menu Items
* [Boycott Buddy](https://www.boycottbuddy.app/) - Identify Brands with Unethical Practices (child labor, slave labor, etc.)
* [⁠Slave Free Chocolate](https://www.slavefreechocolate.org/) - Chocolatiers that use Ethically Sourced (child slavery free) Cocoa
* [⁠The Food Historian](https://www.thefoodhistorian.com/) - Food History Blog

***

## ▷ Recipes

* 🌐 **[TheGreatestCookbooks](https://thegreatestbooks.org/v/grid/the-greatest/cookbooks/books)** - Expert Recommended Cookbooks
* ⭐ **[Tandoor Recipes](https://docs.tandoor.dev/)**, [Mealie](https://mealie.io/) / [Discord](https://discord.com/invite/QuStdQGSGK), [⁠RecipeSage](https://recipesage.com/) / [GitHub](https://github.com/julianpoy/recipesage), [Cooked](https://cooked.wiki/), [⁠GrubPick](https://grubpick.com/) or [ManageMeals](https://managemeals.com/) - Recipe Managers
* ⭐ **[Noods.io](https://noods.io/)**, [⁠Gobsmacked](https://gobsmacked.io/), [Just the Recipe](https://www.justtherecipe.com/), [WheresTheDish](https://www.wheresthedish.com/), [⁠Forkestrate](https://app.forkestrate.com/), [Copy Me That](https://www.copymethat.com/), [drizzlelemons](https://www.drizzlelemons.com/) or [PlainOldRecipe](https://www.plainoldrecipe.com/) - Extract Recipes from Sites / [Firefox](https://addons.mozilla.org/en-US/firefox/addon/recipe-filter/) / [Chrome](https://chromewebstore.google.com/detail/ahlcdjbkdaegmljnnncfnhiioiadakae)
* ⭐ **[SuperCook](https://www.supercook.com/)** - Recipe Search
* [MyFridgeFood](https://myfridgefood.com/), [RecipeRadar](https://www.reciperadar.com/) or [WhiskIt](https://whiskit.ai/) - Find Recipes Based on Ingredients
* [Food Mood](https://artsandculture.google.com/experiment/food-mood/HwHnGalZ3up0EA?hl=en) - Blend Two Cuisines for Recipes
* [⁠RecipeTables](https://recipetables.com/) - Convert Recipes to Prep Tables
* [Fit Men Cook](https://fitmencook.com/) or [PunchFork](https://www.punchfork.com/) - Recipes
* [Search-22](https://search-22.com/recipe-search-tools) - Multi-Site Recipe Search
* [Wikibook Recipes](https://wikibooks.org/wiki/Category:Cookbook) - Recipe Wiki
* [Epicurious](https://www.epicurious.com/) - Recipe Search / Index
* [PublicDomainRecipes](https://publicdomainrecipes.com/) - Recipe Search / [GitHub](https://github.com/ronaldl29/public-domain-recipes)
* [Recipe Search](https://recipe-search.typesense.org/) - Recipe Search
* [Hari Recipes](https://hari.recipes/) - Recipe Search
* [⁠Delicious Recipes](https://www.gzrecipes.com/en/) - Recipe Search
* [KitchenAid](https://www.kitchenaid.com/recipes.html) - Recipe Search
* [⁠Budget Bytes](https://www.budgetbytes.com/) - Budget Recipes
* [Recipeeper](https://www.recipeeper.com/) - Dietary-Based Recipes
* [⁠DAREBEETS](https://darebeets.com/) - Plant-Based Recipes
* [TasteAtlas](https://www.tasteatlas.com/) - Recipe Map
* [AmazingRibs](https://amazingribs.com/) - Rib Recipes
* [The Bread Code Manifesto](https://github.com/hendricius/the-sourdough-framework) - Bread Baking Recipes
* [Historical Recipes](https://l-lists.com/en/lists/55cbww.html) or [Tasting History](https://www.tastinghistory.com/) - Historical Recipes
* [⁠Gode Cookery](http://www.godecookery.com/godeboke/godeboke.htm) - Authentic Medieval Recipes & Historical Info
* [r/GifRecipes](https://reddit.com/r/GifRecipes) - Recipes in GIF Format
* [r/recipes](https://reddit.com/r/recipes) - Share Recipes

***

## ▷ Drinks

* ⭐ **[/coffee/](https://rentry.co/coffeeguide)** or [Coffee Time General](https://pastebin.com/UEzwuyLz) - Coffee Brewing Masterlists / Guides
* ⭐ **[Beanconqueror](https://beanconqueror.com/)** / [GitHub](https://github.com/graphefruit/Beanconqueror) or **[Timer.Coffee](https://www.timer.coffee)** / [GitHub](https://github.com/antonkarliner/timer-coffee) - Coffee Tracking Apps / Timers
* [Cofi](https://github.com/rozPierog/Cofi) - Coffee Brew Timer / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/cofi-note.md)
* [Brew Great Coffee](https://www.brewgreat.coffee/) - Espresso / Pour-Over Brewing Tools + Tips
* [The Minimal Pour](https://theminimalpour.com/) - Pour-Over Coffee Calculator
* [Notbadcoffee](https://notbadcoffee.com/flavor-wheel-en/) - Interactive Coffee Flavor Wheel
* [Nahbucks!](https://nahbucks.com/) - Find Local Non-Starbucks Coffee Shops (US)
* [⁠Aeromatic](https://aeromatic.app/) - AeroPress Recipe App
* [/tea/](https://clarasguide.valeena.workers.dev/Guides/teageneral/) - Tea Brewing Masterlist / Guide
* [⁠Difford's Guide](https://www.diffordsguide.com/) - Cocktail Recipe Guide
* [Drinkable](https://github.com/MOIMOB/drinkable) - Create Cocktails from Home Ingredients
* [Make Me a Cocktail](https://makemeacocktail.com/mybar/) - Cocktail Builders

***

# ► Fashion / Clothing

* 🌐 **[Sewing Pattern Sites](https://purrfect-experience-8f2.notion.site/1e5ee5eeea7a80d9b703e7954cb63c35?v=1e5ee5eeea7a802aa2ec000c9ae6e046)** - Sewing Pattern Site Index
* [⁠firstVIEW](https://firstview.com/) - Archive of Fashion Runway Show Images + Videos
* [Archive Fashion for the World](https://www.archivepdf.net/) - Fashion Magazines
* [⁠Fashion History Timeline](https://fashionhistory.fitnyc.edu/) or [Historical Fashion](https://docs.google.com/document/d/1R8eulTsb9Zlc7h2H917dNJZS9s0rIq9OAu7LpSS9F2k/) - Historical Fashion Resources / History
* [r/MaleFashionAdvice Spreadsheet](https://docs.google.com/spreadsheets/d/1mhOIpjUUibBf3QueJs8iRJy5gBKCILq82ekJkiC5uqQ/) - Male Clothing Brand / Price Spreadsheet
* [r/FashionReps](https://www.reddit.com/r/FashionReps/) - Replica Clothing Community / [Discord](https://discord.com/invite/fashionreps)
* [⁠Doppel](https://doppel.fit/) - Replica Clothing Quality Control Platform 
* [⁠Gem](https://gem.app/) - Secondhand Clothing Multi-Store Search
* [GoodOnYou](https://directory.goodonyou.eco/) - Clothing Brand Sustainability Ratings
* [⁠Run Repeat](https://runrepeat.com/) - Shoe Shopping Guide / Reviews
* [A Bra That Fits](https://www.abrathatfits.org/calculator) or [BraMetric](https://brametric.com/) - Bra Size Calculators
* [Choly Knight](https://cholyknight.com/), [DRCOS](https://dr-cos.info/) or [FreeSewing](https://freesewing.eu/) / [Forum](https://forum.freesewing.eu/) / [Discord](https://discord.gg/freesewing-698854858052075530) - Free Clothing Sewing Patterns
* [PinDIY](https://www.pindiy.com/) - Free Crochet / Knitting Patterns and Magazines
* [⁠Craft Yarn Council](https://www.craftyarncouncil.com/instructions_kn.php3) - Knitting + Crochet Learning
* [Antique Pattern Library](https://www.antiquepatternlibrary.org/) - Antique Pattern Library / Knitting + Crochet
* [⁠RSN Stitch Bank](https://rsnstitchbank.org/) - Embroidery Stitches / Lessons
* [PEmbroider](https://github.com/CreativeInquiry/PEmbroider) - Embroidery Generator
* [⁠BraceletBook](https://www.braceletbook.com/) - DIY Bracelet Pattern Database
* [Ravelry](https://ravelry.com) - Fiber Artist Tools
* [TMHunt](http://www.tmhunt.com/) - Clothing Trademark Search

***

# ► Household

* ↪️ **[Raspberry Pi Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_raspberry_pi)**
* ⭐ **[Home Assistant](https://www.home-assistant.io/)** - Home Assistant / IoT / [Tracker](https://github.com/djdevil/person-tracker-card/) / [Appliances](https://github.com/mmalolepszy/hon-revived) / [GUI](https://github.com/LAB02-Research/HASS.Agent) / [Mobile Apps](https://companion.home-assistant.io/)
* ⭐ **[Grocy](https://grocy.info/)** - Grocery / Household Management Tool / [Android](https://patrickzedler.com/grocy/) / [Subreddit](https://www.reddit.com/r/grocy) / [GitHub](https://github.com/grocy/grocy)
* [OpenHab](https://www.openhab.org/) - Home Assistant / IoT / [Setup](https://github.com/openhab/openhabian) / [Mobile](https://github.com/openhab/openhab-android)
* [Esphome](https://esphome.io/) - Home Assistant / IoT / [Discord](https://discord.com/invite/KhAMKrd) / [GitHub](https://github.com/esphome/esphome)
* [ioBroker](https://www.iobroker.com/) - Home Assistant / IoT / [Discord](https://discord.com/invite/HwUCwsH) / [GitHub](https://github.com/ioBroker/ioBroker)
* [⁠Tasmota](https://github.com/arendst/Tasmota) - Local Smart Home Firmware
* [OpenIPC](https://openipc.org/) - Open-Source Firmware for Closed-Source IP Cameras
* [BudgetDuo](https://budgetduo.com/) - Split Household Expenses / [GitHub](https://github.com/hursey013/budget-duo)
* [OpenVoiceOS](https://www.openvoiceos.org/) - Custom Voice-Controlled Interfaces / [GitHub](https://github.com/OpenVoiceOS/)
* [Sweet Home 3D](https://www.sweethome3d.com/), [⁠Planner5D](https://planner5d.com/), [⁠3D Room Maker](https://3droommaker.com/) or [Homestyler](https://www.homestyler.com/) - Interior Design Tools
* [BlockLayer](https://www.blocklayer.com/) - Construction / Remodeling Calculators
* [PlanYourRoom](https://www.planyourroom.com/) - Visualize PC Setups

***

# ► Gardening / Agriculture

* 🌐 **[Awesome Agriculture](https://github.com/brycejohnston/awesome-agriculture)** - Agriculture Resources
* 🌐 **[Agriculture / Gardening Subreddits](https://clarasguide.valeena.workers.dev/Guides/touchgrasss/)**
* 🌐 **[Cannabis Growing Subreddits](https://www.reddit.com/r/trees/wiki/entreddits_social#wiki_growing)** or [Marijuana Subs](https://www.reddit.com/r/trees/wiki/entreddits_social) - Marijuana Subreddits
* ⭐ **[EarthEasy](https://eartheasy.com/blogs/yard-garden)**, [How To Garden](https://www.bhg.com/gardening/how-to-garden/), [HappySprout](https://www.happysprout.com), [Growing Guide](https://planter.garden/blog/), [GrowStuff](https://www.growstuff.org/) or [GrowVeg](https://www.growveg.com/) - Gardening Guides
* ⭐ **[r/Gardening](https://reddit.com/r/gardening)** - Gardening Community
* ⭐ **[r/Whatsthisplant](https://www.reddit.com/r/whatsthisplant/)** - Plant Identification Community
* [PictureThis](https://www.picturethisai.com/) or [Pl@ntNet](https://identify.plantnet.org/) - Plant Identification Tools / [Android](https://play.google.com/store/apps/details?id=cn.danatech.xingseus) / [iOS](https://apps.apple.com/us/app/picturethis-plant-identifier/id1252497129)
* [WildFlowerSearch](https://wildflowersearch.org/) - Flower Identifier
* [Permapeople](https://permapeople.org/) - Garden Plant Info
* [How Many Plants](https://howmanyplants.com/) - House Plant Information
* [Florae](https://github.com/aeri/Florae) or [Plant-it](https://github.com/MDeLuise/plant-it) - Plant Care Reminders
* [WorldOfSucculents](https://worldofsucculents.com/) - Succulent Database
* [MyGarden](https://gitlab.com/m9712/mygarden) - Garden Management App
* [Gardenia](https://www.gardenia.net/) or [Garden Design](https://www.gardendesign.com/) - Garden Design Resources
* [r/UrbanGardening](https://www.reddit.com/r/UrbanGardening/) - Urban Gardening Community
* [r/Farming](https://reddit.com/r/farming/) - Farming Community
* [Backyard Chickens](https://www.backyardchickens.com/) - Chicken Raising Forum
* [Composting](https://eartheasy.com/blogs/grow/composting) - Composting Guides
* [Modern Farmer](https://modernfarmer.com/) - Agricultural News
* [Chip Drop](https://getchipdrop.com/) - Free Mulch
* [World Hardiness Zones](https://upload.wikimedia.org/wikipedia/commons/a/a7/World_Hardiness_Zones.png) or [Plantmaps](https://www.plantmaps.com/) - Global Map of Hardiness Zones
* [r/Microgrowery](https://reddit.com/r/microgrowery/) or [GrassCity](https://forum.grasscity.com/) - Cannabis Growing Communities
* [SeedFinder](https://seedfinder.eu/en) - 35500+ Strain Database

***

# ► Vehicle

* 🌐 **[Awesome Vehicle Security](https://github.com/jaredthecoder/awesome-vehicle-security)** - Vehicle Security Resources
* [LEMON Manuals](https://lemon-manuals.la/), [JDMFSM](https://jdmfsm.info/Auto/), [CarPDFManual](https://www.carpdfmanual.com/), [iFitIt Vehicle](https://www.ifixit.com/Device/Car_and_Truck) or [ProCarManuals](https://procarmanuals.com/) - Auto Repair Manuals
* [StartMyCar](https://www.startmycar.com), [CarCareKiosk](https://www.carcarekiosk.com/) or [CarComplaints](https://www.carcomplaints.com/) - Car Repair Sites
* [Ownersman.com](https://ownersman.com/) - Car Owner Manuals
* [PremierProduct](https://www.premierproducts-uk.co.uk/) or [Auto Manual](https://www.auto-manual.com/) - Vehicle Manuals
* [⁠Auto Catalog Archive](https://autocatalogarchive.com/) - Vehicle Brochures
* [Cars.com](https://www.cars.com/research/compare/) - Vehicle Reviews / Comparisons
* [WebAutoCats](https://webautocats.com/) - Vehicle Parts Database
* [⁠CarSized](https://www.carsized.com/) - Vehicle Size Comparisons
* [How a Car Works](https://www.howacarworks.com/) - Car Mechanics / Automotive Engineering Guides
* [Internet Movie Cars Database](https://www.imcdb.org/) - Movie Vehicle Database
* [Internet Game Cars Database](https://igcd.net/) - Game Vehicle Database
* [PlateRecognizer](https://platerecognizer.com/) - License Plate Recognition
* [GasPrices](https://gasprices.aaa.com/) - Gas Price Tracker
* [Fuel.io](https://fuel.io/) - Vehicle Fuel Tracking
* [LubeLogger](https://lubelogger.com/) - Self-Hosted Maintenance + Fuel Mileage Tracker / [GitHub](https://github.com/hargata/lubelog)
* [Headunit Revived](https://github.com/andreknieriem/headunit-revived) - Turns Android into an Android Auto Head Unit / Display / [Wireless Helper](https://github.com/andreknieriem/wireless-helper)
* [DiPlay](https://shihabal3amri.github.io/DiPlay/) - CarPlay Receiver for Android Head Units / [GitHub](https://github.com/shihabal3amri/DiPlay)
* [EV-Map](https://ev-map.app/) - Electronic Vehicle Charging Map
* [Alibi](https://github.com/Myzel394/Alibi) or [DroidDashcam](https://play.google.com/store/apps/details?id=com.helge.droiddashcam) - Mobile Dashcams

***

# ► Sports

* 🌐 **[Sports Stat Sites](https://rentry.co/7awch4b9)** - Stat Sites Index
* 🌐 **[/sport calendars/](https://rentry.co/sportcalendars)** - Sports Schedules for Digital Calendars
* 🌐 **[Sports Games](https://rentry.co/c7zwkv9t)** - Mock Sports Draft Game Index
* ↪️ **[Live Sports](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25B7_live_sports)** / **[Replays](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25B7_sports_replays)**
* ⭐ **[The Athletic](https://www.nytimes.com/athletic/)** - Sports News / [Bypass Paywall](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools/#wiki_.25B7_paywall_bypass) / [Mobile](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_modded_apks) (search)
* [Slated](https://bandzz.slatedtv.workers.dev/) or [⁠EntertainMe](https://www.entertainme.fun/) - Sports Calendars / Schedules
* [Sofascore](https://www.sofascore.com/) or [⁠FlashScore](https://www.flashscore.com/) - Sport Scores, Standing & Schedules
* [⁠Sports Reference](https://www.sports-reference.com/) or [Opta Analyst](https://theanalyst.com/) - Sports Stats / Analytics
* [⁠spotrac](https://www.spotrac.com/) - Sports Financial Database / Contracts
* [The Number Wall](https://thenumberwall.com/) - Jersey Number Database
* [⁠PROGRID](https://www.progrid.org/) - NFL Calendar / Schedule Chart
* [⁠CFB.guide](https://cfb.guide/) - College Football Schedule / Scores
* [Tapology](https://www.tapology.com/) - Combat Sports Predictions
* [dropkickd](https://dropkickd.com/) - Rate / Track Wrestling Events
* [CageMatch](https://www.cagematch.net/) - Wrestling Promotion Database
* [⁠FotMob](https://www.fotmob.com/) - Football Stats Platform
* [⁠MatchSimulator](https://matchsimulator.com/) - Football League Simulator
* [HatTrick](https://www.hattrick.org/) - Multiplayer Football League Manager
* [⁠Futez](https://www.futez.com.br/) - Rate / Review Football Matches
* [⁠raceweek.io](https://raceweek.io/) - Motorsports Calendar
* [Formula Timer](https://formula-timer.com/livetiming) or [Nitrous](https://nitrous.software) / [GitHub](https://github.com/slowlydev/f1-dash) - F1 Live Stats Dashboards
* [Calendario Ciclismo](https://calendariociclismo.app/en/) - Cycling TV Schedule / Calendar

***

# ► Travel

* ↪️ **[Concerts / Live Shows](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/audio/#wiki_.25B7_concerts_.2F_live_shows)**
* ⭐ **[Atlas Obscura](https://www.atlasobscura.com/)** / [Mobile](https://app.atlasobscura.com/), [Wikivoyage](https://www.wikivoyage.org) or [WikiTravel](https://wikitravel.org/) - Travel Guides / Roadside Attraction Lists
* [⁠CozyCozy](https://www.cozycozy.com/) - Compares 100+ Travel Accommodation Sites
* [⁠Cultural Atlas](https://theculturalatlas.org/) - World Culture / Religion Guides
* [UNESCO World Heritage](https://whc.unesco.org/en/list/) - World Heritage Location Index
* [⁠Ikuyo](https://ikuyo.kenrick95.org/) - Trip / Travel Planning
* [Roadside America](https://www.roadsideamerica.com/) - Roadside Attraction Guides
* [RCDB](https://rcdb.com/) - Roller Coaster Database
* [DRdb](https://darkridedatabase.com/) - Dark Ride Database / [X](https://x.com/Team_DRDB)
* [⁠IMAX Guide](https://143190.xyz/) - Database of IMAX Theatres / [GitHub](https://github.com/r-imax/imaxguide)
* [FindFright](https://frightfind.com/) - Spooky Attractions / Walkthroughs
* [⁠dark-tourism](https://dark-tourism.com/) - Respectful / Non-Sensationalist Guide to Historical, Memorial & Dark Tourism Sites
* [Bike Sharing](https://bikesharingworldmap.com/) - Bike Rental Map
* [Seat61](https://www.seat61.com/) - Train Travel Guide
* [⁠Trustroots](https://www.trustroots.org/) - Traveler Hospitality Community
* [SitInShade](https://sitinshade.com/) - Avoid the Sun While Traveling
* [⁠EntryConditions](https://entryconditions.com/) - Passport Requirements Database
* [eSIMDB](https://esimdb.com/) - Compare eSIM Prices
* [⁠StationView](https://stationview.app/) - Live UK Train Schedule / Tracker

***

## ▷ Flights

* **Note** - Remember it's always good to cross-check flight prices across multiple providers + the airline's site itself to be sure you're getting the best deal.

***

* ⭐ **[ADS-B Exchange](https://globe.adsbexchange.com/)**, [Airplanes.live](https://globe.airplanes.live/) / [Mobile](https://github.com/d4rken-org/airplanes-live-app), [⁠Flight Viz](https://flight-viz.com/), [FlightAware](https://www.flightaware.com/), [FlightRadar24](https://www.flightradar24.com/), [PlaneFinder](https://planefinder.net/) or [Radarbox](https://www.airnavradar.com/) - Live Flight Trackers
* [VisaIndex](https://visaindex.com/) - Worldwide Travel Visa Guides
* [Google Flights](https://www.google.com/travel/flights) or [⁠SkyScanner](https://skyscanner.net/) - Compare / Book Flights
* [⁠AeroLOPA](https://www.aerolopa.com/) or [⁠SeatMaps](https://seatmaps.com/) - Flight Seat Maps / Features / Reviews
* [Matrix](https://matrix.itasoftware.com/) - Airfare Search
* [SkyVector](https://skyvector.com/) - Flight Planner
* [⁠OpenAirportMap](https://openairportmap.org/) - Airport Maps
* [⁠METAR-TAF](https://metar-taf.com/) - Airport Weather Tracking Tool
* [Delay Compensation](https://www.shenouda.nl/airline/) - Flight Delay & Refund Compensation Calculator
* [⁠ADSB.im](https://adsb.im/) - ADSB Tracking for Single Board Computers

***

# ► Maps

* 🌐 **[Awesome Maps](https://github.com/simsieg/awesome-maps)** - Online Map Resources
* 🌐 **[Soar](https://soaratlas.com/)**, [ArcGIS Living Atlas](https://livingatlas.arcgis.com/), [⁠WorldAtlas](https://www.worldatlas.com/) or [Cool Maps](https://coolmaps.esri.com/) - Atlases
* 🌐 **[Maps and Geospatial Products](https://www.ncei.noaa.gov/maps-and-geospatial-products)** - All NCEI Maps
* ⭐ **[nakarte](https://nakarte.me/)** - Multi-Map Aggregator
* ⭐ **[⁠Institute for the Study of War](https://understandingwar.org/)**, **[CrisisWatch](https://www.crisisgroup.org/crisiswatch)**, [ACLED](https://acleddata.com/conflict-data), [Global Conflict Tracker](https://www.cfr.org/global-conflict-tracker), [LiveUAMap](https://liveuamap.com/), [⁠World-Monitor](https://world-monitor.com/), [⁠SitDeck](https://sitdeck.com/), [⁠Iran War Map](https://iranwarmap.com/), [⁠Conflictly](https://www.conflictly.app/) or [Israeli-Palestine Conflict](https://israelpalestine.liveuamap.com/) - Global Conflict Maps
* [Maps.com](https://www.maps.com/) - Interesting / Educational Maps
* [Terraink](https://terraink.app/) / [GitHub](https://github.com/yousifamanuel/terraink), [⁠CartoArt](https://carto-art.vercel.app/) or [Map to Poster](https://github.com/originalankur/maptoposter) - Map Poster / Art Generators
* [FreeMapTools](https://www.freemaptools.com/) - Map Tools
* [Kiwix Maps](https://browse.library.kiwix.org/#lang=eng&category=&q=map) - Offline Downloadable Maps
* [The Cartographers' Guild](https://www.cartographersguild.com/) - Cartography Forum
* [TextToMap](https://www.textomap.com/) - Text-Based Map Search
* [Local Map](https://www.matthewsiu.com/local-map) - Explore a Map with Wikipedia
* [Flickr Map](https://www.flickr.com/map/) - Flickr Map
* [r/MapPorn](https://reddit.com/r/MapPorn) - Reddit Map Community
* [⁠WikiMapped](https://wikimapped.nikamma.in/), [NearbyWiki](https://en.nearbywiki.org/), [⁠Local Wikipedia](https://edjefferson.com/localwiki/), [Wiki-Map](https://wiki-map.com/) or [⁠Wikimap](https://wikimap.wiki/) / [GitLab](https://gitlab.com/nocylah/wikimap/) - Wikipedia Articles Geolocated on Maps
* [Urbex](https://urbexology.com/), [⁠Zuniz](https://zuniz.com/) / [Discord](https://discord.com/invite/7HaHj6ahx5), [⁠TrespassersHQ](https://trespassershq.com/) / [Discord](https://discord.gg/trespassers) or [UER](https://www.uer.ca/locations/gmaps/) / [Forum](https://www.uer.ca/forum_showcats.asp) - Urban Exploration / Abandoned Place Maps
* [⁠Arcade Database](https://zenius-i-vanisher.com/v5.2/arcades.php) - Arcade Game Map + Database
* [Wikimapia](https://wikimapia.org/) - Online Editable Map
* [Orhyginals Map](http://map.orhyginal.fr/) - Online Editable Map
* [MapChart](https://mapchart.net/) or [Qgis](https://qgis.org/) - Create Custom Maps
* [⁠d-maps](https://www.d-maps.com/) - Free Blank Maps / Outlines / Printable
* [There to Where](https://theretowhere.com/) - Find Apartments Near Important Things
* [Scribble Maps](https://www.scribblemaps.com/create/) - Custom Location Map
* [Dawarich](https://dawarich.app/) - Self-Hosted Google Maps Timeline Alternative / [Discord](https://discord.gg/pHsBjpt5J8)
* [gpx.studio](https://gpx.studio/) - GPX File Editor
* [Mobac](https://mobac.sourceforge.io/) - Mobile Atlas Creator
* [⁠Opportunity Atlas](https://www.opportunityatlas.org/) - Interactive Future Success Impact Map
* [Linguistic Maps](https://muturzikin.com/countries.htm) - World Linguistic Maps
* [Freedom House](https://freedomhouse.org/explore-the-map) or [Civicus Monitor](https://monitor.civicus.org/) - Freedom Maps
* [⁠FireMap](https://www.firemap.live/) - Wildfire Map / Tracker / [X](https://x.com/disaster_db)
* [Fires Near Me Australia](https://play.google.com/store/apps/details?id=au.gov.nsw.rfs.firesnearme.national) - Australian Bush Fires Map / Tracker / Android
* [⁠CrashAtlas](https://crashatlas.com/) - Aviation Accident Database / Map
* [Skimap.org](https://skimap.org/) - Detailed Ski Maps
* [LGA World Database](https://database.ilga.org/) - LGBT Legal Rights Map / Policy Tracking
* [Trans Rights Map](https://transrightsmap.tgeu.org/) - Trans Legal Rights Map / Policy Tracking
* [Erin's Informed Consent HRT Map](https://redd.it/d6p05q) - Gender Identity Clinics / Maps
* [BlueW](https://bluew.org/) - Free Water Refill Map
* [Notable People](https://tjukanovt.github.io/notable-people) or [People Map](https://pudding.cool/2019/05/people-map/) - Notable People Maps
* [NUKEMAP](https://nuclearsecrecy.com/nukemap/), [NukeSim](https://www.nukesim.com/), [Bomb Blast](https://outrider.org/nuclear-weapons/interactive/bomb-blast) or [MISSILEMAP](https://nuclearsecrecy.com/missilemap/) - Interactive Damage Effect Maps

***

## ▷ Navigation / Transport

* ⭐ **[Google Maps](https://www.google.com/maps/)**, [Apple Maps](https://maps.apple.com/), [Bing Maps](https://www.bing.com/maps), [Vela](https://github.com/PimpinPumpkin/Vela/), [OsmAnd](https://f-droid.org/packages/net.osmand.plus/), [FacilMap](https://facilmap.org/), [OsmAPP](https://osmapp.org/) or [Mapy](https://mapy.com) - Online / Offline Maps
* ⭐ **[CoMaps](https://www.comaps.app/)** / [Source Code](https://codeberg.org/comaps/comaps) or [Organic Maps](https://organicmaps.app/) / [Subreddit](https://www.reddit.com/r/organicmaps/) / [Telegram](https://t.me/OrganicMaps) / [GitHub](https://github.com/organicmaps/organicmaps) - Offline Maps
* ⭐ **[OpenStreetMap](https://www.openstreetmap.org/)** or [MapComplete](https://mapcomplete.org/) / [Source Code](https://source.mapcomplete.org/MapComplete/MapComplete/) - Open Community Maps
* ⭐ **[StreetComplete](https://streetcomplete.app/)** - OpenStreetMap Surveyor App / Quests / [GitHub](https://github.com/streetcomplete/streetcomplete)
* ⭐ **OpenStreetMap Tools** - [Resources](https://github.com/osmlab/awesome-openstreetmap) / [Features](https://github.com/deevroman/better-osm-org) / [Advanced Search](https://nominatim.openstreetmap.org/ui/search.html) / [Advanced Editor](https://level0.osmz.ru/) / [AI Editor](https://rapideditor.org/) / [⁠Opening Hours Validation](https://opening-hours.pages.dev/) / [Overpass API GUI](https://overpass-turbo.eu/)
* [Waze](https://www.waze.com/) - Driving / Navigation Focused Map / [Editor](https://www.waze.com/en-US/editor)
* [GMaps WV](https://f-droid.org/packages/us.spotco.maps/) - Restricted Google Maps WebView Wrapper / [GitHub](https://github.com/woheller69/maps)
* [CubeTrek](https://cubetrek.com/) - GPS Track Manager
* [⁠GPS Visualizer](https://www.gpsvisualizer.com/) - Create Maps + Profiles from GPS Data
* [Wikiroutes](https://wikiroutes.info/), [⁠Travic](https://travic.app/) or [CityMapper](https://citymapper.com/) - Public Transport Maps
* [AnyTrip](https://anytrip.com.au/) - Australia & New Zealand Public Transport Maps
* [⁠London Live](https://london.pengrubin.com/) or [SmartLDN](https://labs.palapple.com/smartldn) - London Public Transport Maps
* [Mini Tokyo 3D](https://minitokyo3d.com/) - Tokyo Public Transport Map / [GitHub](https://github.com/nagix/mini-tokyo-3d)
* [⁠HK Traffic Intelligence](https://hktraffic.keith-li.workers.dev/) / [GitHub](https://github.com/keithligh/hk-traffic-intelligence) or [⁠Hong Kong Transit 3D](https://hktransit3d.pages.dev/) - Hong Kong Public Transport Maps
* [Mini Map Macau](https://mini-map-macau.app/) - Macau Public Transport Map / [GitHub](https://github.com/asdfghj1237890/mini-macau)
* [rasp.yandex](https://rasp.yandex.ru/map/trains/) - Russia Public Transport Map
* [kakaomap](https://map.kakao.com/) - South Korea Public Transport Map
* [⁠Metroskop](https://metroskop.cz/) - Prague Public Transport Map
* [ALPR Watch](https://alprwatch.org/), [⁠FlockHopper](https://dontgetflocked.com/), [⁠Flock Surveillance Map](https://uncensored.ai/flocksurveillance), [DeFlock](https://deflock.org/) / [Discord](https://discord.gg/aV7v4R3sKT) / [GitHub](https://github.com/FoggedLens/deflock) or [Panopti](https://panopti.ca/) / [GitHub](https://github.com/resistanceisliberty/panopti.ca) (Canada) - AI Automated License Plate Reader Cameras / ALPR Maps
* [⁠Atlas of Surveillance](https://www.atlasofsurveillance.org/) - Police / Surveillance Tech Map
* [⁠Sparrow Map](https://map.sparrowmap.com/) - Police Vehicle Map / Community Camera Network
* [People Over Papers](https://iceout.org/en/) or [ICE Map](https://www.icemap.dev/) - ICE Activity Information / Maps
* [⁠Geo Share](https://github.com/jakubvalenta/geoshare) - Open Map Links in Alt Map Apps / Copy Coordinates

***

## ▷ Railway Maps

* [OpenRailwayMap](https://openrailwaymap.app/), [2](https://www.openrailwaymap.org/) - World's Railway Infrastructure
* [trains.fyi](https://trains.fyi/) - Real-Time North America Train Tracker
* [amtrak explorer](https://amtrakexplorer.com/) - North America Railway Map
* [⁠UrbanRail.Net](https://www.urbanrail.net/) - Railway Maps
* [Vanshnookenraggen Track Maps](https://www.vanshnookenraggen.com/_index/category/maps/track-maps/) - Detailed Subway Maps / History
* [AP Transit](https://aptransit.co/) - NYC Live Subway Map
* [Swiss Railways Network](https://maps.vasile.ch/transit-sbb/) - Switzerland Railway Map
* [vr.fi](https://www.vr.fi/en/live-train-tracker-map) - Finland Train Tracker Map
* [⁠Tokyo in Cross-Section](https://maps.chizutodesign.com/tokyo-danmenzu/) - Tokyo Railway Map
* [⁠MTR Map](https://hkmtrmap.com/) - Hong Kong Railway Map
* [SignalBox](https://www.map.signalbox.io/) or [Live Tube Map](https://www.londonunderground.live/) - UK Live Train Maps
* [carto.tchoo](https://carto.tchoo.net/) - France Live Train Map
* [RailRadar](https://railradar.in/railradar), [2](https://www.railjournal.in/) - India Live Train Map
* [⁠Rail Island](https://railisland.tw/) - Taiwan Live Train Map
* [⁠MiniLondon3D](https://www.minilondon3d.xyz/) - Real-time 3D map of the London Underground
* [Train positions](https://treinposities.nl/) - Netherlands Train Info Map
* [Chronotrains](https://www.chronotrains.com/) - European Train Distances
* [Abandoned Rails](https://www.abandonedrails.com/) - Abandoned US Railroad Routes

***

## ▷ Climate / Weather

* ⭐ **[Windy](https://www.windy.com/)**, **[Ventusky](https://www.ventusky.com/)**, [Xweather](https://live.xweather.com/), [⁠WXCharts](https://wxcharts.com/), [Earth Observatory](https://science.nasa.gov/earth/earth-observatory/global-maps/), [Zoom Earth](https://zoom.earth/), [⁠WunderMap](https://www.wunderground.com/wundermap), [Weatherwise](https://web.weatherwise.app/), [Earth Now](https://science.nasa.gov/climate-change/) or [Earth](https://earth.nullschool.net/) - General Weather / Climate Maps
* [⁠CyclonicWx](https://cyclonicwx.com/) - Tropical Weather Tracking Tools / Plotting
* [Netweather](https://www.netweather.tv/charts-and-data/global-jetstream) - Global Jetstream Forecast Map
* [Cyclocane](https://www.cyclocane.com/) - Cyclone and Hurricane Tracker Map
* [Supercell Wx](https://supercellwx.net/) - Visualize / Archive NEXRAD Data + Weather Alerts / [GitHub](https://github.com/dpaulat/supercell-wx)
* [tornado.live](https://tornado.live/) - Real-Time US Severe Weather Alerts Map
* [Weather Lab](https://deepmind.google.com/science/weatherlab) - AI Weather Model Map / Visualization
* [Tropical Tidbits](https://www.tropicaltidbits.com/) - Hurricane Forecast Models
* [FloodMap](https://www.floodmap.net/) - Sea Level / Flood Map
* [Snow Forecast](https://www.snow-forecast.com/maps) - Snow Forecast Maps
* [AtticRadar](https://atticradar.steepatticstairs.net/) - Advanced Weather Radar / NOAA Stations
* [Tornado Archive](https://tornadoarchive.com/) - Tornado Archive Data Explorer
* [Find Your Tornado Shelter](https://findyourtornadoshelter.com/) - Tornado Shelter Map
* [Blitzortung.org](https://www.blitzortung.org/en/live_lightning_maps.php) or [Lightning Maps](https://www.lightningmaps.org/) - Lightning / Thunderstorms Maps
* [ClearOutside](https://clearoutside.com/) - Weather Visibility Tracker
* [aqicn.org](https://aqicn.org/map/world) - Air Quality Map
* [CPRE](https://www.cpre.org.uk/light-pollution-dark-skies-map/) - England Light Pollution and Dark Skies
* [Electricity Maps](https://app.electricitymaps.com/map) - Electricity CO₂ Emissions Map
* [SaveEcoBot](https://www.saveecobot.com/en/radiation-maps) - Radioactivity / Air Quality in Ukraine

***

## ▷ Geography Maps

* [⁠Ecoregions](https://ecoregions.appspot.com/) - World Biomes Map
* [Falling Fruit](https://fallingfruit.org/) - Urban Harvesting Map
* [⁠Tangram Heightmapper](https://tangrams.github.io/heightmapper) or [Oilslick](https://mrgris.com/projects/oilslick/) - World Terrain Height / Elevation Maps
* [Global Fishing Watch](https://globalfishingwatch.org/map) - Fishing Activity Map
* [OCEARCH](https://www.ocearch.org/tracker/) - Shark Tracker
* [MarineTraffic](https://www.marinetraffic.com/), [CruiseMapper](https://www.cruisemapper.com/) or [MyShipTracking](https://www.myshiptracking.com/) - Live Ship Trackers
* [EuroBirdPortal](https://www.eurobirdportal.org/) - European Bird Distribution Map
* [Global Forest Watch](https://globalnaturewatch.org/map/) - Interactive Forest & Tree Cover Map
* [Sounds of the Forest](https://timberfestival.org.uk/soundsoftheforest-soundmap/) - Forest Sounds Map
* [Aporee](https://aporee.org/maps/) - World Map of Sounds
* [ExoRoad](https://www.exoroad.com/) - Find Places to Live via Description
* [Beacon](https://beacon.schneidercorp.com/) - Property Info / Map Search
* [World Population Density](https://luminocity3d.org/WorldPopDen/) - Population Density Map
* [Language Map](https://languagemap.vercel.app/) - Language Locations Map
* [FIRMS](https://firms.modaps.eosdis.nasa.gov/map/) - Fire / Thermal Anomalies Map
* [Native Land](https://native-land.ca/) - Indigenous Territory Map
* [⁠NYC Tree Map](https://www.nycgovparks.org/tree-map) or [London Tree Map](https://apps.london.gov.uk/public-realm-trees/) - City Tree Maps
* [kepler.gl](https://kepler.gl/) - Geospatial Analysis Tool / [GitHub](https://github.com/keplergl/kepler.gl)

***

## ▷ Geology Maps

* 🌐 **[⁠NGMDB](https://ngmdb.usgs.gov/)** - Geologic Map Database
* [USGS Maps](https://www.usgs.gov/products/maps) - Geologic Maps / 3-D Geologic Frameworks
* [Macrostrat](https://macrostrat.org/) - Geological Data Map
* [Fishermap](https://usa.fishermap.org/depth-map/) - Water Depth Maps
* [River Runner](https://river-runner.samlearner.com/) / [3D Map](https://river-runner-global.samlearner.com/) - Raindrop Tracking Map
* [Global Wetlands](https://www2.cifor.org/global-wetlands/) - Wetlands Map
* [Mindat](https://www.mindat.org/countrylist.php) - Mineral Deposits Map
* [PeakFinder](https://www.peakfinder.com/) - Mountain Names Map
* [topographic-map](https://en-gb.topographic-map.com/), [⁠Caltopo](https://caltopo.com/map.html/) or [OpenTopoMap](https://opentopomap.org/) - Topographic Map
* [KCG2](https://prop.kc2g.com/) - Ionospheric Conditions Map
* [VolcanoDiscovery](https://www.volcanodiscovery.com/erupting_volcanoes.html) - Volcano Activity Map
* [USGS](https://earthquake.usgs.gov/earthquakes/map/), [EMSC](https://www.emsc.eu/) or [Seismic Explorer](https://seismic-explorer.concord.org/) - Earthquake Activity Maps
* [GPlates](https://www.gplates.org/) - Plate Tectonics Simulator

***

## ▷ Historical Maps

* 🌐 **[David Rumsey Map Collection](https://www.davidrumsey.com/)** - Historical Map Indexes
* ⭐ **[Running Reality](https://www.runningreality.org/)**, [World History Maps](https://www.worldhistory.org/mapselect/), [⁠Globe of History](https://www.globeofhistory.com/) (desktop), [Chronas](https://www.chronas.org/) or [OldMapsOnline](https://www.oldmapsonline.org/) - Interactive Historical Maps
* [HMDB](https://www.hmdb.org/) - Historical Marker Database / Map
* [⁠London Remembers](https://www.londonremembers.com/) - London Historical Marker Database
* [⁠Castle Map](https://thecastlemap.com/) - World Map of Castles & Fortresses
* [Harvard WorldMap](https://worldmap.maps.arcgis.com/home/index.html) - ArcGIS Map Archive
* [Cronobook](https://cronobook.com/) - Historic Street View
* [EuraAtlas](https://euratlas.com/) - Historical Atlas of Europe
* [r/oldmaps](https://www.reddit.com/r/oldmaps/) or [r/papertowns](https://www.reddit.com/r/papertowns/) - Historical Maps Community
* [Historical City Maps](https://redd.it/61fdp6) - Collection of Historical City Maps
* [Library of Congress](https://www.loc.gov/collections/?fa=partof:geography+and+map+division) - LOC Historic Maps Archive
* [⁠Maptism](https://maptism.org/) - Archaeological Culture Maps
* [American Panorama](https://dsl.richmond.edu/panorama/) - Interactive US History Maps
* [⁠Historic Aerials](https://www.historicaerials.com/) - US Historical Aerial Imagery / Maps
* [Mused](https://mused.com/) - Text to 3D Historical Simulation Map
* [NLS Maps](https://maps.nls.uk/) - Historical Maps of Scotland
* [Imperium](https://imperium.ahlfeldt.se/) - Digital Atlas of the Roman Empire
* [ORBIS](https://orbis.stanford.edu/) - Interactive Simulation of Roman Trade & Travel Logistics
* [⁠Battles of the Romans](https://iosiflazaridis.github.io/battles-of-the-romans/) - Interactive Historical Roman Battle Map
* [Where the Greeks Fought](https://iosiflazaridis.github.io/ancient-greek-battles/) / [Modern](https://iosiflazaridis.github.io/modern-greek-battles/) - Interactive Historical Greek Battle Map
* [Ancient Earth](https://dinosaurpictures.org/ancient-earth) - Globe of Ancient Earth
* [⁠Theban Mapping Project](https://thebanmappingproject.com/) - Theban Necropolis / Valley of the Kings Mapping Project
* [1940s NYC](https://1940s.nyc/) - Explore 1940's New York
* [ORBAT Mapper](https://orbat-mapper.app/) - Recreate Historical Battle Maps / [X](https://x.com/orbatmapper) / [GitHub](https://github.com/orbat-mapper/orbat-mapper)
* [⁠Project ’44](https://www.project44.ca/) - World War II Historical Map / [X](https://x.com/project4_4) / [Discord](https://discord.gg/bzWEuc6JJv)
* [Project Athena](https://www.projectathena.ca/) - War in Afghanistan Historical Map / [X](https://x.com/TFProjectAthena) / [Discord](https://discord.gg/jMmxWZpUKs)
* [HK Battle 1941](https://digital.lib.hkbu.edu.hk/1941hkbattle/en/index.php) - The Battle of Hong Kong 1941 Interactive Map
* [Japanese Occupation of HK](https://digital.lib.hkbu.edu.hk/1941hkbattle/en/index.php) - Japanese Occupation of Hong Kong Interactive Map
* [⁠Maritime Stepping Stones](https://mass.cultureelerfgoed.nl/) or [⁠Wrecksite](https://www.wrecksite.eu/) - Historical Maritime Wreck Maps / Info
* [Medieval Murder Maps](https://medievalmurdermap.co.uk/) - Interactive Medieval Murder / Death Maps
* [⁠Map Myths](https://mapmyths.com/) - Historical Map Myths

***

## ▷ Infrastructure Maps

* [Open Infrastructure Map](https://openinframap.org/) - Global Infrastructure Map / [GitHub](https://github.com/openinframap/openinframap/)
* [⁠IODA](https://ioda.inetintel.cc.gatech.edu/) - Internet Infrastructure Outage Map
* [⁠Open Grid Work](https://opengridworks.com/) - Global Electricity Infrastructure Map
* [PowerOutage.us](https://poweroutage.us/) - US Power Outage Map
* [CoverageMap](https://coveragemap.com/) - Cell Coverage Map
* [CellMapper](https://www.cellmapper.net/) or [OpenCelliD](https://opencellid.org/) - Cell Tower Maps
* [Spectrum Ownership Map](https://specmap.sequence-omega.net/) - Cell Carrier FCC Spectrum Map
* [WiGLE](https://wigle.net/) - Wireless Networks Map
* [⁠Community Network Map](https://communitynetworks.org/content/community-network-map) - Municipal Networks Map
* [broadbandmap.fcc.gov](https://broadbandmap.fcc.gov/) - FCC National Broadband Map
* [Submarine Cable Map](https://www.submarinecablemap.com/) - Undersea Internet Cable Map
* [Fossil Fuel Map](https://www.fossilfuelmap.com/) - Fossil Fuel Map Dependency Map

***

## ▷ Satellite / Earth Data

* ⭐ **[Google Earth](https://www.google.com/earth/about/versions/)** - Earth Viewer
* [Huge Earth Maps](https://maps.drsys.eu/) - High Res Earth Maps
* [GeoHack](https://geohack.toolforge.org/) - Uncensored Google Satellite View / Coordinates Info / [GitHub](https://github.com/magnusmanske/geohack)
* [⁠GeoWhisperer](https://www.geowhisperer.org/) - Compare Satellite Images from Different Times
* [OpenMapTiles](https://openmaptiles.org/) - Self-Hosted Map Tools
* [NASA Earthdata](https://search.earthdata.nasa.gov/search) - Earth Data Archive
* [⁠Watched](https://www.watched.earth/) - Satellite Location Image History
* [Copernicus Browser](https://browser.dataspace.copernicus.eu/) - Copernicus Satellite Image Map / Database
* [glifwc](https://maps.glifwc.org/) - Map with Data
* [Mapillary](https://www.mapillary.com/) or [Mapcarta](https://mapcarta.com/) - Open Street View Data
* [Instant Street View](https://www.instantstreetview.com/) - Instantly Load Street View
* [MapCrunch](https://www.mapcrunch.com/) or [Random Street View](https://randomstreetview.com/) - Random Street View
* [city roads](https://anvaka.github.io/city-roads/) - City Roads Map
* [Land Lines](https://lines.chromeexperiments.com/) - Explore Google Earth via Gestures

***

# ► News

* 🌐 **[AllYouCanRead](https://www.allyoucanread.com/)** - Worldwide News Sites Index
* ↪️ **[Newspaper Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/reading#wiki_.25B7_newspapers)**
* ↪️ **[Bypass Article Paywalls](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools#wiki_.25B7_paywall_bypass)**
* ⭐ **[TorrentFreak](https://torrentfreak.com/)** - Piracy News / [Telegram](https://t.me/torrentfreaks)
* ⭐ **[Current Events Wiki](https://wikipedia.org/wiki/Portal:Current_events)** or [News as Facts](https://newsasfacts.com/) - Breaking News
* ⭐ **[Good News Network](https://www.goodnewsnetwork.org/)** or [Happy Daze](https://happydaze.io/) - Uplifting News
* [TV.Jest](https://tv.jest.one/) or [WorldNews24](https://worldnews24.tv/) - Live TV / News
* [Google Alerts](https://www.google.com/alerts) - News Alerts by Topics
* [CBM](https://comicbookmovie.com/) - Comic / Movie / TV News
* [Anime News Network](https://www.animenewsnetwork.com/) - Anime News
* [Anime Corner](https://animecorner.me/) - Anime / Manga News
* [ArtDaily](https://artdaily.com) - Art News
* [Codrops](https://tympanus.net/codrops/) - Design News
* [The Athletic](https://www.nytimes.com/athletic/) - Sports News / [Bypass Paywall](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools/#wiki_.25B7_paywall_bypass) / [Mobile](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_modded_apks) (search)
* [EventMap](https://rsoe-edis.org/eventMap) - Emergency and Disaster Maps
* [Interactive News Map](https://usa.liveuamap.com/) - Geolocated News Alerts / Headlines U.S.
* [⁠WTFJHT](https://whatthefuckjusthappenedtoday.com/) - Daily US Political News Summaries
* [⁠Bellingcat](https://www.bellingcat.com/) - Open-Source Investigative Journalism / [Discord](https://discord.gg/bellingcat) / [GitHub](https://github.com/bellingcat)
* [MedicineNet](https://www.medicinenet.com/), [MedPageToday](https://www.medpagetoday.com/), [EverydayHealth](https://www.everydayhealth.com/), [Medscape](https://www.medscape.com/), [Healthline](https://www.healthline.com/), [Medicalxpress](https://medicalxpress.com/) or [WebMD](https://www.webmd.com/) - Health News
* [MathURLs](https://mathurls.com/) - Math News
* [Dailynous](https://dailynous.com/) - Philosophy News
* [Medievalists](https://www.medievalists.net/category/news/) - Medieval History News
* [FinURLs](https://finurls.com/) - Finance & Business News
* [⁠election.run](https://election.run/) - Multi-Stream Election Streams / News 
* [⁠NCS](https://www.newscaststudio.com/) - Television Broadcast Network News
* [⁠Podnews](https://podnews.net/) - Podcast News
* [Web3 Is Going Great](https://www.web3isgoinggreat.com/) - Web3 Disaster News
* [CivicTracker](https://civictracker.us/) or [GovData](https://www.govactionlist.com/) - Government Executive Orders, Location & more
* [Aviation Safety Network](https://aviation-safety.net/) / [X](https://x.com/flightsafety), [PlaneCrashInfo](https://www.planecrashinfo.com/) or [AVHerald](https://avherald.com/) - Aviation Accidents / News
* [Read Something Wonderful](https://readsomethingwonderful.com/), [Read Something Great](https://www.readsomethinggreat.com/) or [BoredReading](https://boredreading.com/) - Random Articles / Blog Posts
* [Media Bias Fact Check](https://drmikecrowe.github.io/mbfcext/) or [HonestyMeter](https://www.honestymeter.com/) - Media Bias Checkers
* [Scribe](https://sr.ht/~edwardloveall/Scribe/) or [LibMedium](https://libmedium.batsense.net/) - Medium Frontends
* [Firefox Reader](https://support.mozilla.org/en-US/kb/firefox-reader-view-clutter-free-web-pages), [Tranquility](https://addons.mozilla.org/en-GB/firefox/addon/tranquility-1/), [txtdot](https://txt.dc09.xyz/) / [Instances](https://github.com/TempoWorks/instances) / [GitHub](https://github.com/TempoWorks/txtdot) or [Reader Mode](https://readermode.io/) - Browser Read-Mode / Text-Only Tools

***

## ▷ Aggregators

* ↪️ **[RSS Readers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools#wiki_.25B7_rss_readers)**
* [QotNews](https://news.t0.vc/) - Hacker News / Reddit / Lobsters / Tildes
* [Kagi News](https://news.kagi.com/) - Aggregator / Summaries / [GitHub](https://github.com/kagisearch/kite-public)
* [NewsMinimalist](https://www.newsminimalist.com/) - Aggregator / Summaries
* [⁠Particle](https://particle.news/) - Aggregator / Summaries
* [Spike News](https://readspike.com/), [2](https://spike.news/)
* [Upstract](https://upstract.com/) - Single Page News Aggregator
* [newstel](https://newstel.vercel.app/) - Telegram Channel News Aggregator
* [AllSides](https://www.allsides.com/) - Political News Aggregators
* [AlDaily](https://www.aldaily.com/) - Art / Philosophy / Literature News
* [Ground.news](https://ground.news/) - Requires Sign-Up
* [World Monitor](https://worldmonitor.app/) / [Tech Version](https://tech.worldmonitor.app/) / [GitHub](https://github.com/koala73/worldmonitor), [OSIRIS](https://osirisai.live/), [⁠Conflictly](https://www.conflictly.app/) or [⁠World-Monitor](https://world-monitor.com/) - Real-Time News Aggregators / Monitors / Maps
* [SPIDR](https://spidr.today/)
* [NewsNow](https://www.newsnow.co.uk/)
* [SkimFeed](https://skimfeed.com/)
* [Google News](https://news.google.com/)
* [sumi.news](https://sumi.news/)
* [AllTop](https://alltop.com/)

***

## ▷ Tech News

* ↪️ **[Dev / Cybersecurity News](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/dev-tools#wiki_.25BA_dev_news)**
* ⭐ **[⁠GamersNexus](https://gamersnexus.net/)** - PC Gaming News
* ⭐ **[Hacker News](https://news.ycombinator.com/)** - Tech News / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_hacker_news_tools)
* [World Monitor](https://tech.worldmonitor.app/) - Real-Time Tech News Aggregator / Monitor / Map / [GitHub](https://github.com/koala73/worldmonitor)
* [AlternativeTo Aggregator](https://alternativeto.net/news/all/) - Tech News Aggregator
* [⁠DeadStack](https://deadstack.net/) - Tech / AI News Aggregator
* [TechURLs](https://techurls.com/) - Tech News
* [Techmeme](https://www.techmeme.com/) - Tech News
* [The Brutalist Report](https://brutalist.report/) - Tech News
* [Techxplore](https://techxplore.com/) - Tech News
* [⁠ThisWeekInVideoGames](https://thisweekinvideogames.com/news/) - Gaming News
* [⁠GamingOnLinux](https://www.gamingonlinux.com/) - Linux Gaming News
* [TuxURLs](https://tuxurls.com/), [phoronix](https://www.phoronix.com/) or [⁠LWN](https://lwn.net/Archives/) - Linux News
* [Liliputing](https://liliputing.com/) - Hardware / Linux Mobile News
* [Geeks3D](https://www.geeks3d.com/), [Toms Hardware](https://www.tomshardware.com/) or [Overclock3D](https://overclock3d.net/) - Hardware News / Reviews
* [⁠IEEE Spectrum](https://spectrum.ieee.org/) - Engineering Magazine / News
* [EmergentMind](https://www.emergentmind.com/), [⁠TestingCatalog](https://www.testingcatalog.com/), [Singularity Hub](https://singularityhub.com/) or [Dupple](https://www.dupple.com/techpresso) - AI News
* [GamesRecap](https://gamesrecap.io/) - Game Announcements / Trailers
* [Internet Society](https://pulse.internetsociety.org/blog) - Internet Infrastructure News
* [⁠FilterWatch](https://filter.watch/english/) - Censorship News / Articles
* [RestorePrivacy](https://cyberinsider.com/news/) or [Privacy International](https://www.privacyinternational.org/) - Privacy / Security News

***

## ▷ Hacker News Tools

* 🌐 **[Awesome Hacker News](https://github.com/cheeaun/awesome-hacker-news)** - HN Apps & Resources Index
* ⭐ **[Newsit](https://newsit.benwinding.com/)** - Webpage Comments Widget / [GitHub](https://github.com/benwinding/newsit)
* ⭐ **[Modern HN](https://greasyfork.org/scripts/578540)** / [2](https://www.modernhn.com/) - Modern UI Extension
* [Orange Juice](https://oj-hn.com/) - Hacker News Features / Extension / [GitHub](https://github.com/OrangeJuiceExtension/OrangeJuice)
* [Hacki](https://github.com/Livinglist/Hacki) or [Harmoni](https://play.google.com/store/apps/details?id=com.simon.harmonichackernews) / [GitHub](https://github.com/SimonHalvdansson/Harmonic-HN) - Android Hacker News Apps
* [ZCombinator](https://github.com/Livinglist/ZCombinator), [HACK](https://apps.apple.com/app/id1464477788), [Octal](https://apps.apple.com/app/id1308885491), [Hackers](https://apps.apple.com/app/id603503901) or [Hacki](https://apps.apple.com/app/id1602043763) - iOS Hacker News Apps
* [The Hacker Herald](https://hackerherald.com/), [⁠Brutalist HN](https://brutalisthackernews.com/), [unslop.news](https://www.unslop.news/) or [hckrnws](https://www.hckrnws.com/) - HN Frontends
* [HNRankings](https://hnrankings.com/) - Best of / Top Posts Aggregator
* [⁠Hacker Smacker](https://hackersmacker.org/) - Filter / Mark HackerNews Posters
* [⁠Hacker Book](https://hackerbook.dosaygo.com/) - Hacker News Posts + Comment Archive
* [Hacker News RSS](https://hnrss.github.io/) - HN RSS Feeds

***

## ▷ Science News

* ⭐ **[Phys](https://phys.org/)** - Physics News / Articles
* [SciURLs](https://sciurls.com/)
* [NewScientist](https://www.newscientist.com/)
* [PopSci](https://www.popsci.com/)
* [ScienceDaily](https://www.sciencedaily.com/)
* [EurekAlert](https://www.eurekalert.org/)
* [LiveScience](https://livescience.com/)
* [ScienceNews](https://www.sciencenews.org/)
* [IFLScience](https://www.iflscience.com/)
* [⁠Nature This Week](https://naturethisweek.com/) - View Nature / Biology News from any Location

***

# ► Health

## ▷ Mental Health

* 🌐 **[Awesome Mental Health](https://dreamingechoes.github.io/awesome-mental-health)** or [mentalillnessmouse](https://mentalillnessmouse.wordpress.com/helpfulresources/) - Mental Health Resources
* ↪️ **[Relaxation / Ambient](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/audio/#wiki_.25B7_ambient_.2F_relaxation)**
* ⭐ **[Medito](https://meditofoundation.org/medito-app/)** / [GitHub](https://github.com/meditohq/medito-app) or [⁠Plum Village](https://plumvillage.app/) - Meditation Apps
* ⭐ **[Breath Ball](https://breathball.com/)** or [Breathly](https://breathly.app/) - Guided Breathing Practice Apps / Android, iOS
* ⭐ **[/mental health/](https://rentry.co/mentalhealthy)** - Mental Help Tips
* [Health Assessment Tools](https://www.nhs.uk/mental-health/) - General Health Tools
* [How We Feel](https://play.google.com/store/apps/details?id=org.howwefeel.moodmeter&hl=en-US) / [iOS](https://apps.apple.com/app/id1562706384), [Nomie](https://v5.nomie.app/), [Koduko](https://github.com/Mazahir26/koduko) - Wellbeing Apps / Journals
* [You feel like shit.](https://philome.la/jace_harr/you-feel-like-shit-an-interactive-self-care-guide/play/index.html), [2](https://youfeellikeshit.com/) - Interactive Self-Care Guide
* [deskspace](https://npckc.itch.io/deskspace) - Self-Care App
* [Mindfulness Coach](https://mobile.va.gov/app/mindfulness-coach) - Mindfulness / Stress Reduction App
* [Coping Skills Masterlist](https://docs.google.com/document/d/1KI1kzj6Bjx_O3ggYXfgEuTtOsLiCW0V-JeWpTyX5OOU/) - Mental Health Coping Skills
* [The FM Project](https://www.freemindfulness.org/download) - Guided Mindfulness Exercises
* [Waking Up](https://app.wakingup.com/scholarship) - Sam Harris' Mindfulness Platform
* [IIB Mindfulness](https://informationisbeautiful.net/visualizations/what-is-meditation-mindfulness-good-for/) - Meditation Techniques / Infographic
* [⁠Pause Point](https://greasyfork.org/scripts/578391) - Add Breathing / Activity Pause Before Site Entrances
* [Conversations](https://conversations.movember.com/en/conversations/) - Mental Health Conversation Practice
* [TripSit](https://tripsit.me/) / [Discord](https://discord.gg/tripsit), [Drugs.com](https://www.drugs.com/) or [DrugBank](https://go.drugbank.com/) - Drug Information / Side Effects

***

## ▷ Physical Health

* ⭐ **[The Fitness Wiki](https://thefitness.wiki/)** - Fitness Information Wiki
* ⭐ **[Sleeping Guide](https://rentry.co/sleepguide)** or **[Insomnia Guide](https://clarasguide.valeena.workers.dev/Guides/insomnia-guide/)** - Sleep Hygiene Guides / Tips
* ⭐ **[Simple Science Fitness](https://ss.fitness/calculators)** - Fitness Calculators
* ⭐ **[Standard BMI Calculator](https://www.nhlbi.nih.gov/calculate-your-bmi)**, [CDC Adult](https://www.cdc.gov/bmi/adult-calculator/index.html) or [CDC Teen](https://www.cdc.gov/bmi/child-teen-calculator/index.html) - BMI Calculator
* [openScale](https://github.com/oliexdev/openscale) or [trale](https://github.com/QuantumPhysique/trale) - Weight & Body Metrics Trackers
* [AMMFitness](https://www.ammfitness.co.uk/) - Fitness / Nutrition Info
* [FitoTrack](https://codeberg.org/jannis/FitoTrack), [Flexify](https://github.com/brandonp2412/Flexify) or [MyFitnessPal](https://www.myfitnesspal.com/) - Fitness Apps
* [NOOP](https://rentry.co/FMHYB64#noop) - Offline WHOOP Companion App
* [⁠Bevel](https://www.bevel.health/) or [Pulse](https://pulse.portlabs.in/) / [GitHub](https://github.com/adityaongit/pulse) - Wearable Watch Health Data Apps
* [SailRabbit](https://www.sailrabbit.com/bmr/) - BMR / TDEE Calculator
* [BMI Chart](https://upload.wikimedia.org/wikipedia/commons/c/cc/BMI_chart.png) - BMI Range Graph
* [Bodyweight Fitness Progressions](https://docs.google.com/spreadsheets/d/1a8tlZ-zbF695HA3Lmm20OIYeYYxo1lmUOczUXKLoL4s/)
* [r/LoseIt](https://www.reddit.com/r/loseit/) - Weight Loss Subreddit
* [MOVE! Coach](https://mobile.va.gov/app/move-coach) - Weight Loss Program
* [Weight Loss Side Effects](https://weight-loss-side-effects.netlify.app/) - Weight Loss Side Effect Mitigation
* [r/GainIt](https://www.reddit.com/r/gainit/) - Healthy Weight Gain Subreddit
* [r/Flexibility](https://www.reddit.com/r/flexibility/) - Flexibility Subreddit
* [Healthdirect](https://www.healthdirect.gov.au/), [epocrates](https://www.epocrates.com/), [MedlinePlus](https://medlineplus.gov/), [Merck Manuals](https://www.merckmanuals.com/), [Mayo Clinic](https://www.mayoclinic.org/), [RxList](https://www.rxlist.com/), [NEJM](https://www.nejm.org/), [PubMed Central](https://pmc.ncbi.nlm.nih.gov/), [HHS](https://www.hhs.gov/), [NIH](https://www.nih.gov/) or [CDC](https://www.cdc.gov/) - Government Health Resources
* [oshaction](https://www.oshaction.org/resources/) - Occupational Health and Safety Resources
* [⁠OpenPrescribing](https://openprescribing.net/) - Track NHS Prescription Trends & Spending
* [CancerFactFinder](https://cancerfactfinder.org/) - Cancer Fact Search
* [⁠INCIDecoder](https://inkeedecoder.com/) - Skincare Cosmetics Ingredients Databases / Search
* [Kids Health](https://www.kidshealth.org/) - Kids Health Information

***

## ▷ Workout / Exercise

* 🌐 **[ExRx.net](https://exrx.net/)** - Exercise Resources
* ⭐ **[DAREBEE](https://darebee.com/)** - Workout Plans
* ⭐ **[r/BodyweightFitness Wiki](https://www.reddit.com/r/bodyweightfitness/wiki/index/)** - Bodyweight Fitness Routines / [Android](https://play.google.com/store/apps/details?id=com.eightxthree.app)
* ⭐ **[/u/KNightNox Diagram](https://i.ibb.co/b5TpBHqm/g-Efyf0q.jpg)**, [2](https://i.ibb.co/b5TpBHqm/g-Efyf0q.jpg), [3](https://i.imgur.com/gEfyf0q.jpeg) - Zoomable Exercise Diagram
* ⭐ **[Boostcamp](https://www.boostcamp.app/)**, [Hevy](https://www.hevyapp.com/), [⁠Tracked](https://www.tracked.gg/), [⁠Hybrid Calisthenics](https://www.hybridcalisthenics.com/app), [FitNotes](https://www.fitnotesapp.com/), [⁠Strong App](https://www.strong.app/), [openGym](https://opengym.ch/) / [GitHub](https://github.com/DuarteSantos8/openGym) or [FitHero](https://fithero.app/) - Workout Trackers
* [Fitness Blender](https://www.fitnessblender.com/videos?exclusive%5B%5D=0) or [⁠Muscle & Strength](https://www.muscleandstrength.com/exercises) - Workout Videos
* [Calistree](https://calistree.app/) - Exercise Search / Workout Tracker
* [FitnessProgramer](https://fitnessprogramer.com/) - Workout Plans
* [Workout.cool](https://workout.cool/) or [Workout.lol](https://workout.lol/) - Custom Workout Plans
* [MuscleWiki](https://musclewiki.com/) or [The Casual Gym](https://gym.naya.com.np/) - Muscle / Exercise Information Tool
* [Liftosaur](https://www.liftosaur.com/), [LiftLog](https://github.com/LiamMorrow/LiftLog) or [StrongLifts](https://stronglifts.com/) - Weightlifting Trackers
* [BuffBook](https://buffbook.org/) - Strength Training Booklet / [GitHub](https://github.com/classy-giraffe/BuffBook)
* [Liftvault](https://liftvault.com/) - Weightlifting Programs / Spreadsheets
* [Google Fit](https://www.google.com/fit/) - Activity Coach
* [Impakt](https://www.impakt.com/) - AI Fitness Coach / Social Platform
* [OpenTracks](https://opentracksapp.com/) - Sports Tracking App
* [ACTIVE](https://www.active.com/) - Find Local Races & Events
* [Runlytics](https://www.runlytics.app/) - Running Analytics
* [RunnerUp](https://github.com/jonasoreland/runnerup) or [Strava](https://www.strava.com/) - Run Trackers
* [MapMyWalk](https://www.mapmywalk.com/) - Walking Tracker
* [GoldenCheetah](https://www.goldencheetah.org/), [AAT](https://bailu.ch/aat/) - Cycling / Biking Trackers
* [AllTrails](https://www.alltrails.com/), [Wikiloc](https://www.wikiloc.com/) or [TrailRouter](https://trailrouter.com/) - Hiking / Trail Routes
* [Wanderer](https://github.com/Flomp/wanderer) - Self-Hosted Trail Database
* [⁠OpenClimbing](https://openclimbing.org/) - Editable Climbing Map / [GitHub](https://github.com/zbycz/osmapp)
* [fastnfitness](https://github.com/brodeurlv/fastnfitness) or [PFCTE](https://github.com/SecUSo/privacy-friendly-circuit-training-exercises) - Exercise & Activity Trackers
* [wger](https://wger.de/) - Self-Hosted Workout, Nutrition / Weight App / [Fitness](https://github.com/wger-project/flutter) / [GitHub](https://github.com/wger-project/wger)
* [Feeel](https://gitlab.com/enjoyingfoss/feeel) - Home Workout App

***

## ▷ Nutritional Health

* ⭐ **[r/Nutrition](https://www.reddit.com/r/nutrition/)** - Nutrition Subreddit
* ⭐ **[OpenFoodFacts](https://world.openfoodfacts.org/)** - Food Database & Health Information / [Scanner](https://play.google.com/store/apps/details?id=org.openfoodfacts.scanner)
* [Waistline](https://github.com/davidhealey/waistline), [Energize](https://codeberg.org/epinez/Energize/), [Cronometer](https://cronometer.com/) or [Nutritionix](https://www.nutritionix.com/) - Nutrition, Diet, and Calorie Tracking Apps
* [NutritionFacts.org](https://nutritionfacts.org/) - Video Library for Latest Health-Based Research / Vegan-Focused
* [The Nutrition Source](https://nutritionsource.hsph.harvard.edu/) - Harvard University Health Website
* [Liquid Drink](https://play.google.com/store/apps/details?id=com.xpp.drink) - Liquid Intake Tracker
* [Daily Dozen](https://github.com/nutritionfactsorg/daily-dozen-android) - Daily Diet Recommendations / Android
* [Eat This Much](https://www.eatthismuch.com/), [Mealime](https://www.mealime.com/) or [MealPrepPro](https://mealpreppro.com/) / [Android](https://play.google.com/store/apps/details?id=com.nibbleapps.meal_prep_pro) - Meal Prep & Planning Apps / Android, iOS
* [Calories-In](https://calories-in.com/) - Meal Prep & Planning / Web
* [Nosh](https://nosh.tech/) - Food Management App
* [Edamam](https://www.edamam.com/) - Food-Related APIs
* [Caffeine Calculator](https://www.caffeineinformer.com/death-by-caffeine) - Caffeine Intake Calculator
* [⁠CaffeineHealth](https://github.com/ohuc/CaffeineHealth) - Caffeine Intake Calculator / Android
* [Examine.com](https://examine.com/) - Supplement & Nutrition Analysis
* [MyFoodData](https://www.myfooddata.com) - Food Nutrition Info
* [Nutrient Sorter](https://michaelf314.github.io/nutrient-sorter/) - Vegan Food Nutrient Sorter
* [FoodStruct](https://foodstruct.com/) - Food Encyclopedia & Comparison

***

## ▷ Sexual Health

* ⭐ **[PlannedParenthood](https://www.plannedparenthood.org/)**, [Abortion Resources](https://redd.it/phrcrn) / [2](https://redd.it/vm56bs) or [Safe2Choose](https://safe2choose.org/) - Abortion Resources
* ⭐ **[WomenOnWeb](https://www.womenonweb.org/en/women-on-web/)** - Free Abortion Pills
* [babycenter](https://www.babycenter.com/) - Pregnancy and Parenting Resources
* [Pregnancy Calculator](https://americanpregnancy.org/resources/pregnancy-calculator/) - Due Date Calculator
* [Scarleteen](https://www.scarleteen.com/) - Sex Education Resources
* [Euki](https://eukiapp.org/) - Sexual / Reproductive Health App
* [Tubal Sterilization](https://docs.google.com/spreadsheets/d/1Djia_WkrVO3S4jKn6odNwQk7pOcpcL4x00FMNekrb7Q/) - Tubal Sterilization Gynecologists

***

## ▷ HRT / Trans Health

* 🌐 **[Trans Healthcare Resources](https://transharmreduction.org/healthcare-resources)** or **[TFS Tools](https://transfemscience.org/misc/)**
* ⭐ **[Trans Papers](https://docs.google.com/spreadsheets/d/1d9KKqP9IHa5ZxU84a_Jf0vIoAh7e8nj_lCW27KbYBh0/)** - Academic Papers on Transgender Health & Sociology
* ⭐ **[Gender Dysphoria Bible](https://genderdysphoria.fyi/)** - Gender Dysphoria Learning / Guidance / [GitHub](https://github.com/GenderDysphoria/GenderDysphoria.fyi)
* [Trans Harm Reduction](https://transharmreduction.org/), [PGHRT](https://pghrt.diy) or [DIY HRT Directory 2.0](https://diyhrt.info/) - HRT Safety Guides / [Testing](https://transharmreduction.org/hrt-testing)
* [Erin's Informed Consent HRT Map](https://redd.it/d6p05q) or [⁠Trans Clinic Index](https://transclinicindex.org.uk/) (UK) - Gender Identity Clinics / Map
* [FTM Resource Guide](https://www.ftmguide.org/) - FTM Resources / Guidance
* [⁠Trans Voice Party](https://transvoice.party/) - Trans Voice Therapy Resources / [Discord](https://discord.gg/8weEXE7RzU)
* [Acoustic Gender](https://acousticgender.space/) or [Voice Tools](https://devextras.com/voicetools/) - Voice Therapy
* [Trans Rights Map](https://transrightsmap.tgeu.org/) - Trans Legal Rights Map / Policy Tracking

***

## ▷ Detoxing / Sobriety

* ⭐ **[r/NoSurf](https://www.reddit.com/r/nosurf/wiki/index)** - Digital Detox Community / [Discord](https://discord.com/invite/QFhXt2F)
* [Farhan](https://github.com/tahaak67/Farhan), [LockMeOut](https://play.google.com/store/apps/details?id=vikesh.dass.lockmeout), [DetoxDroid](https://github.com/flxapps/DetoxDroid) or [StopScroll](https://play.google.com/store/apps/details?id=com.noscroll.antiscroll) - Control Phone Addiction
* [Sobriety](https://github.com/KiARC/Sobriety) - Sobriety Tracker
* [I Am Sober](https://iamsober.com/en/site/home) - Sobriety Tracker / Community
* [Petals](https://github.com/LeoColman/Petals) - Quit / Reduce Marijuana Usage
* [DrugFree](https://drugfree.org/) - Drug Abuse Prevention & Recovery Help

***

## ▷ Porn Quitting

* 🌐 **[Porn Addiction Recovery Resources](https://xliwt.github.io/Recovery-resources/)**
* ↪️ **[Site Blocking](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_productivity_.2F_time_tracking)**
* [EasyPeasy](https://easypeasymethod.org/), [2](https://gitlab.com/snuggy/easypeasy) / [Audiobook](https://youtu.be/ZktxO6adTnI) or [QuitPornEasily](https://quitporneasily.com/) - Painlessly Quit Pornography
* [⁠FreeLife](https://rentry.org/FreeLife) - Porn Blocking Guide
* [Plucky](https://pluckyfilter.com/) - Content Filter
* [CleanBrowsing](https://cleanbrowsing.org/filters/) - Family DNS Filters
* [cringeMDb](https://cringemdb.com/), [Age Rating JuJu](https://www.ageratingjuju.com/), [Common Sense Media](https://www.commonsensemedia.org/) or [Unconsenting Media](https://www.unconsentingmedia.org) - Find SFW Movies
* [Movie Parser](https://raskie.com/post/practical-ai-autodetecting-nsfw) - Detect NSFW Scenes in Movies
* [Wingman](https://github.com/wingman-jr-addon/wingman_jr) or [HaramBlur](https://haramblur.com/) / [2](https://linktr.ee/haramblur) - Block NSFW Images
* [SAA Recovery](https://saa-recovery.org/), [Cosa Recovery](https://cosa-recovery.org/) or [Smart Recovery](https://www.smartrecovery.org/) - Find Sex Addiction Meetings

***

# ► Career

* 🌐 **[Common Q&As](https://www.indeed.com/career-advice/interviewing/top-interview-questions-and-answers)** - Interview Questions Index
* ⭐ **[Comparably](https://www.comparably.com/)** or [GoodFirms](https://www.goodfirms.co/) - Compare Companies / Salaries
* ⭐ **[Reverse Interview](https://github.com/viraptor/reverse-interview)** - Questions to Ask Potential Employers
* ⭐ **[Kimai](https://www.kimai.org/)** / [GitHub](https://github.com/kimai/kimai) or [Clockify](https://clockify.me/) - Work Hour Trackers
* [80,000 Hours](https://80000hours.org/), [O*NET](https://www.onetonline.org/), [Career Dreamer](https://grow.google/career-dreamer/) or [MyNextMove](https://www.mynextmove.org/) - Explore Career Options
* [r/careerguidance](https://www.reddit.com/r/careerguidance/) - Career Guidance Subreddit
* [UseThis](https://usesthis.com/) - Career Interviews
* [Science Career General](https://sciencecareergeneral.neocities.org/) - PhD / STEM Career Study Guides
* [LibreTexts Business](https://biz.libretexts.org/) - Business Learning / Guides
* [Space Crew](https://spacecrew.com/) - Find Space Related Jobs
* [US Job Market Visualizer](https://karpathy.ai/jobs/) - US Job Market Statistics + Visualization / [GitHub](https://github.com/karpathy/jobs)
* [BLS](https://www.bls.gov/) - U.S. Bureau of Labor Statistics
* [MedusaJS](https://medusajs.com/) - Open Source Commerce Store
* [Contact Card](https://contact-card.murtuzaalisurti.com/) - Contact Card Generator
* [MS Word Cover Page Templates](https://www.mswordcoverpages.com/) - Cover Page Templates
* [Linkedin Preview](https://www.alarapp.com/en/linkedin-preview) - Preview Linkedin Posts
* [WhoPaysWriters](http://whopayswriters.com/) - Freelance Writing Publications
* [Creator Monetization Platforms](https://docs.google.com/spreadsheets/d/1ii59-tKBwsol4jGwVehXy-oaJfVLKUciwXtB2tuKqQg/edit#gid=0) - Monetization Platforms Comparisons
* [Gale Presents: Udemy](https://www.gale.com/elearning/udemy) - Business Courses / Requires Library Card
* [Pimp My Money](https://pimpmymoney.net/) (Torrent) or [HubSpot Academy](https://academy.hubspot.com/) - Digital Marketing Courses
* [Statista](https://statista.com/) - Market Statistic Search
* [Systeme](https://systeme.io/) or [SendPulse](https://sendpulse.com/) - Marketing Tools
* [Marmof](https://marmof.com/) - Creator / Marketing AI
* [MMAGlobal](https://www.mmaglobal.com/) - View Past Marketing Reports
* [Annual Reports](https://www.annualreports.com/) - Annual Company Reports
* [LeanTime](https://leantime.io/) - Project / Delivery Manager
* [Twain](https://www.twain.ai/), [WriteCream](https://www.writecream.com/) or [Textcortext](https://textcortex.com/) - AI Communication Outreach Assistants
* [Cody](https://meetcody.ai/) - Company Management AI
* [PHPCRM](https://www.phpcrm.com/), [Monday](https://monday.com/) or [Twenty](https://github.com/twentyhq/twenty) - Company Management Tools
* [⁠Invoify](https://invoify.vercel.app/) / [GitHub](https://github.com/al1abb/invoify), [EasyInvoicePDF](https://easyinvoicepdf.com) / [GitHub](https://github.com/VladSez/easy-invoice-pdf), [Invoicely](https://invoiceto.me/), [InvoiceNinja](https://invoiceninja.com/) or [Akaunting](https://akaunting.com/) - Invoice Generators
* [Google Patents](https://patents.google.com/) - Searchable Patents Database
* [Layoffs.fyi](https://layoffs.fyi/) or [⁠WarnTracker](https://www.warntracker.com/) - Live Layoffs Trackers
* [GoodJobsFirst](https://goodjobsfirst.org/) - Subsidy Tracker
* [QR Menu Creator](https://qrmenucreator.com/) - Convert Menu to QR Codes
* [CandidateChecker](https://candidatechecker.io/) - User Backgrounds for Hiring

***

## ▷ Job Search / Application

* 🌐 **[⁠CareerPanels](https://www.careerpanels.com/)** - Index of Job Boards
* ⭐ **[4-Day Week](https://4dayweek.io/)** - Find Jobs with 4-Day Weeks
* [OnSites](https://www.onsites.fyi/) - View / Share Interview Experiences
* [50WaysToGetAJob](https://50waystogetajob.com/) - Interactive Job Search Guide
* [⁠Welcome To The Jungle](https://www.welcometothejungle.com/), [JobBoardSearch](https://jobboardsearch.com/), [⁠HiringCafe](https://hiringcafe.com/), [JobsFromSpace](https://www.jobsfromspace.com/), [CyberCoders](https://www.cybercoders.com/), [whoishiring](https://whoishiring.io/), [⁠freehire](https://freehire.me/) / [GitHub](https://github.com/strelov1/freehire), [Toby Tools](https://rentry.co/qnu6x), [The Muse](https://www.themuse.com/search/), [Indeed](https://www.indeed.com/) or [EuroJobs](https://eurojobs.com/) - Job Search
* [Hiring Without Whiteboards](https://github.com/poteto/hiring-without-whiteboards) - Find Straightforward Hiring Processes
* [RolePad](https://rolepad.com/) or [JobSync](https://github.com/Gsync/jobsync) - Job Search Managers
* [DoorsOpen](https://www.doorsopen.co/) - Music Industry Jobs
* [Job Shell](https://github.com/angelplusultra/job-shell) - Scrape Job Postings
* [SpeedyApply](https://www.speedyapply.com/) or [AIHawk](https://github.com/feder-cr/Jobs_Applier_AI_Agent_AIHawk) - Job Application Autofill Tools

***

## ▷ Resume / Portfolio

* 🌐 **[⁠r/Resumes Wiki](https://www.reddit.com/r/resumes/wiki/index/)** - Resume Resources / Guides
* ⭐ **[RX Resume](https://rxresu.me/)** / [GitHub](https://github.com/amruthpillai/reactive-resume), [Resume Matcher](https://resumematcher.fyi/) / [GitHub](https://github.com/srbhr/Resume-Matcher), [FlowCV](https://flowcv.com/), [HeyCV](https://heycv.app/), [EZCV](https://www.ezcv.pro/) or [Sheets](https://sheetsresume.com/) - Resume / CV Builders
* ⭐ **[KickResume Samples](https://www.kickresume.com/en/help-center/resume-samples/)** - Resume Samples
* [ResumGO](https://www.resumgo.com/) - Resume Templates
* [⁠YAMLResume](https://yamlresume.dev/) / [GitHub](https://github.com/yamlresume/yamlresume) or [RenderCV](https://rendercv.com/) / [GitHub](https://github.com/rendercv/rendercv) - YAML Based Resume Builders
* [IntelligentCV](https://www.intelligentcv.app/) - Resume Builder Mobile App
* [ChatProfolio](https://chatprofolio.vercel.app/) or [PeerList](https://peerlist.io/) - Portfolio Builders
* [CoFolios](https://cofolios.com/) or [⁠perfolios](https://directoryyy.com/) - Portfolio Samples

***

## ▷ Remote Jobs

* 🌐 **[Awesome Remote Jobs](https://github.com/lukasz-madon/awesome-remote-job)** or [Established Remote](https://github.com/yanirs/established-remote) - Remote Job Resources
* 🌐 **[⁠remote-jobs](https://remoteintech.company/)** - Remote Friendly Company Index / [GitHub](https://github.com/remoteintech/remote-jobs)
* ⭐ **[Real Work From Anywhere](https://www.realworkfromanywhere.com/)** - Global "Work-From-Anywhere" Job Board / Avoid Ads
* [Overemployed](https://overemployed.com/) - Discuss Working 2+ Remote Jobs / [Subreddit](https://www.reddit.com/r/overemployed) / [Discord](https://discord.com/invite/a8VGhbZyek)
* [r/RemoteJobs](https://www.reddit.com/r/RemoteJobs/) - Remote Jobs Subreddit / Check "Job Posts" Flag
* [⁠Volunteers Base](https://volunteersbase.com/) - Volunteer Work Exchange / Work for Stay Network
* [NoCommute](https://www.nocommutejob.com/) - Remote Job Notifications
* [WeNomad](https://wenomad.so/) or [Nomad List](https://nomads.com/) - Remote Work Ratings
* [Jobspresso](https://jobspresso.co/) - Remote Jobs
* [Remote First Jobs](https://remotefirstjobs.com/) - Remote Jobs
* [Remote Jobs](https://remotejobs.com/) - Remote Jobs
* [himalayas](https://himalayas.app/) - Remote Jobs
* [We Work Remotely](https://weworkremotely.com/) - Remote Jobs
* [TangerineFeed](https://tangerinefeed.net/) - Remote Jobs
* [RemoteYeah](https://remoteyeah.com/) - Remote Jobs / [Telegram](https://t.me/remoteyeah) / [Discord](https://discord.gg/69s55S7DjB)
* [CareerVault](https://careervault.io/) - Remote Jobs
* [NoDesk](https://nodesk.co/) - Remote Jobs
* [Remote OK](https://remoteok.com/) - Remote Jobs
* [Dynamite Jobs](https://dynamitejobs.com/) - Remote Jobs
* [Working Nomads](https://www.workingnomads.com/jobs) - Remote Jobs
* [Remotive](https://remotive.com/) - Remote Jobs
* [DailyRemote](https://dailyremote.com/) - Remote Jobs
* [HireBasis](https://www.hirebasis.com/) - Remote Jobs

***

## ▷ Tech Jobs

* 🌐 **[30-sec](https://30secondsofinterviews.org/)** - Tech Interview Questions Indexes
* 🌐 **[Summer 2026 Internships](https://github.com/SimplifyJobs/Summer2026-Internships)** - Tech Internships List / [Notifications](https://swelist.com/)
* 🌐 **[TheRemoteFreelancer](https://github.com/engineerapart/TheRemoteFreelancer)** - Remote Tech Jobs Index
* ↪️ **[Learn Programming](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu/#wiki_.25BA_developer_learning)**
* ↪️ **[Learn Computer Science](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu/#wiki_.25B7_computer_science)**
* ⭐ **[Tech Interview Handbook](https://www.techinterviewhandbook.org/software-engineering-interview-guide/)** or [Frontend Interview Handbook](https://www.frontendinterviewhandbook.com/) - Interview Handbooks / [GitHub](https://github.com/yangshun/)
* [⁠2026-SWE-College-Jobs](https://github.com/speedyapply/2026-SWE-College-Jobs) - Software Engineering Internship & New Grad Positions
* [MoAiJobs](https://www.moaijobs.com/) - Find Jobs in AI Companies
* [FOSS Jobs](https://www.fossjobs.net/) - FOSS Project Jobs
* [⁠Hiresail](https://hire.welhan.dev/calibrate) - Freelance Work / Swipe Style Search / Resume Generator
* [⁠Remote Frontend Jobs](https://remotefrontendjobs.com/), [Remote Backend Jobs](https://remotebackendjobs.com/) or [Remote Java jobs](https://remotejavajobs.com) - Find Developer Jobs
* [Authentic Jobs](https://authenticjobs.com/) - Find Developer / Designer Jobs
* [Dribbble](https://dribbble.com/) - Designer Jobs
* [r/DesignJobs](https://www.reddit.com/r/DesignJobs/) - Designer Jobs Subreddit
* [Best PM Jobs](https://www.bestpmjobs.com/) - Tech Firm Night Jobs
* [JS Remotely](https://javascript.jobs/) - Find Remote JavaScript Jobs
* [larajobs](https://larajobs.com/) - Find Laravel Jobs
* [Python Job Board](https://www.python.org/jobs/) - Find Python Jobs
* [Levels.fyi](https://www.levels.fyi/) - Tech Career Salaries
* [Interviews.school](https://interviews.school/) - Interview Preparation Guides
* [Interview Warmup](https://grow.google/grow-your-career/articles/interview-tips/) - Interview Practice
* [Cyberseek](https://www.cyberseek.org/index.html) - Cybersecurity US Job Market Info
* [NIST](https://www.nist.gov/nice/apprenticeship-finder) - Find NICE Cybersecurity Apprenticeship Programs
* [Data.gov Resources](https://resources.data.gov/) - Data Management Tools / Training
* [AWS re/Start](https://aws.amazon.com/training/restart/) or [AWS Training](https://www.aws.training/) - Cloud Career Training
* [9Tut](https://www.9tut.com/) - CCNA Certification Training
* [CompTIA](https://www.comptia.org/) / [Practice](https://www.examcompass.com/), [Cisco Training](https://www.cisco.com/c/en/us/training-events/training-certifications/certifications.html) or [UI.com](https://www.ui.com/training/) - Training / Certifications
* [web3.career](https://web3.career/) or [FindWeb3](https://findweb3.com/) - Find Web3 Jobs

***

## ▷ Startup

* 🌐 **[Awesome Startup](https://github.com/Ibexoft/awesome-startup-tools-list)**, [Awesome Launching Platforms](https://github.com/DirectorySurf/awesome-launch-platforms), [Awesome Launch](https://github.com/soGeneri/awesome-launch) or [Tools for Startups](https://docs.google.com/spreadsheets/d/1s6-hGBh0_tqa-jd23fsdYuwbmS8UPmElPqaH-Rnoa_A/htmlview) - Startup Resources Indexes
* 🌐 **[moreThanFAANGM](https://kaustubh-natuskar.github.io/moreThanFAANGM/)** - Good Companies / Startups Index
* [Best Pitch Deck](https://bestpitchdeck.com/) or [Pitch Deck Hunt](https://www.pitchdeckhunt.com/) - Successful Pitch Deck Examples
* [⁠Awesome OSS Monetization](https://github.com/PayDevs/awesome-oss-monetization/) - Monetization Approaches for OSS Projects
* [⁠Startups RIP](https://startups.rip/) or [Failory](https://www.failory.com/graveyard) - Learn Why Startups Failed
* [280+ Websites to Submit Your Startup](https://airtable.com/shrwqaak73gy83w9A/tblu5RcUft9fYp9Ju/viwFHmIyMniXzlpK4?blocks=show) or [PlacesToPostYourStartup](https://www.placestopostyourstartup.com/) - Startup Submission Sites
* [WellFound](https://wellfound.com/) - Find Employees for Startups
* [Business Card Generator](https://business-card-generator.vercel.app/) or [Haystack](https://thehaystackapp.com/) - Business Cards

***

## ▷ Collaboration Platforms

* ⭐ **[NextCloud](https://nextcloud.com/)** - Collaboration Platform / File Sharing / [GitHub](https://github.com/nextcloud)
* [Teams for Linux](https://github.com/IsmaelMartinez/teams-for-linux) - Unofficial Teams Client / Windows, macOS, Linux
* [Atlassian](https://www.atlassian.com/) - Collaboration Platform
* [Twake](https://twake.app/) - Collaboration Platform / [GitHub](https://github.com/linagora/twake-drive)
* [ScreenRec](https://screenrec.com/) - Screen Recording for Collaboration
* [Zulip](https://zulip.com/) - Team Chat / [GitHub](https://github.com/zulip/zulip/)
* [Freedcamp](https://freedcamp.com/) - Project / Task Organization
* [Asana](https://asana.com/) - Project / Task Organization
* [Linear](https://linear.app/) - Project / Task Organization
* [Factsplat](https://factsplat.com/) - Project Manager
* [Mural](https://www.mural.co/) - Project Manager
* [Nino](https://nino.app/) - Task Manager
* [Trello](https://trello.com/) - Task Manager
* [WeKan](https://github.com/wekan/wekan), [Kanboard](https://kanboard.org/) or [Planka](https://planka.app/) - Kanban Boards / Task Managers
* [Airtable](https://www.airtable.com/) - Spreadsheet-Database Hybrid for Team Workflows

***

## ▷ Personal Finance / Budgeting

* 🌐 **[r/PersonalFinance Wiki](https://www.reddit.com/r/personalfinance/wiki/index/)** or [UK Personal Finance](https://ukpersonal.finance/) - Personal Finance Advice / Resources
* ⭐ **[Paisa](https://paisa.fyi/)**, **[HomeBank](https://www.gethomebank.org/)**, **[Bagels](https://github.com/EnhancedJax/Bagels)**, **[GnuCash](https://gnucash.org/)**, **[Firefly III](https://firefly-iii.org/)**, **[Money Manager EX](https://moneymanagerex.org/)** or **[Actual](https://actualbudget.org/)** - Finance / Expense Managers
* [Cashew](https://play.google.com/store/apps/details?id=com.budget.tracker_app), [Money Manager Ex](https://github.com/moneymanagerex/android-money-manager-ex), [Buckwheat](https://buckwheat.app/) or [My Expenses](https://www.myexpenses.mobi/) - Mobile Expense Managers
* [GreenStash](https://github.com/Pool-Of-Tears/GreenStash) - Savings Goal Tracker
* [Denaro](https://github.com/NickvisionApps/Denaro) - Linux Finance Manager
* [Ledger](https://ledger-cli.org/) or [hledger](https://hledger.org/) - Plain-Text Accounting Tools
* [FreeTaxUSA](https://www.freetaxusa.com/), [IRS Free File](https://apps.irs.gov/app/freeFile/) or [US Taxes](https://ustaxes.org/) - Free US Tax Filing
* [r/povertyfinance Wiki](https://www.reddit.com/r/povertyfinance/wiki/index/) - Financial Advice / Resources
* [r/BeerMoney](https://www.reddit.com/r/beermoney/) - Online Earning Opportunities / Community
* [YieldFinder](https://yieldfinder.app/) - Savings Account / Treasury Yield Comparisons

***

## ▷ Investing / Market Research

* ⭐ **[TradingView](https://www.tradingview.com/)** / [Alert Forwarder](https://github.com/fabston/TradingView-Webhook-Bot), **[GoCharting](https://gocharting.com/)**, **[ticker](https://github.com/achannarasappa/ticker)** or **[finviz](https://finviz.com/)** - Market Charting / Analysis
* ⭐ **[StockTicker](https://github.com/premnirmal/StockTicker)** or **[Candle](https://gitlab.com/cosmosapps/candle)** - Mobile Market Tracking
* [Wealthfolio](https://wealthfolio.app/) / [X](https://x.com/WealthfolioApp) / [Discord](https://discord.gg/WDMCY6aPWK) / [GitHub](https://github.com/wealthfolio/wealthfolio), [Ghostfolio](https://ghostfol.io/) / [GitHub](https://github.com/ghostfolio/ghostfolio) / [Export To](https://github.com/dickwolff/Export-To-Ghostfolio) or [Portfolio Performance](https://www.portfolio-performance.info/en/) / [GitHub](https://github.com/portfolio-performance/portfolio) - Investment Portfolio Trackers / Management
* [OpenBB](https://openbb.co/), [GamestonkTerminal](https://github.com/GamestonkTerminal/GamestonkTerminal) or [Koyfin](https://www.koyfin.com/) - Investment Research Platforms
* [PortfolioVisualizer](https://www.portfoliovisualizer.com/) - Portfolio Analysis / Backtesting
* [Bogleheads](https://www.bogleheads.org/) - Long-Term Investing Resources
* [ETFDB](https://etfdb.com/) (US) or [justETF](https://www.justetf.com/) (EU / UCITS) - ETF Research and Screening Platforms 
* [Quiver Quantitative](https://www.quiverquant.com/) - Alternative Investment Data / Research
* [Infolib](https://infolib.org/) - Financial News / Market Dashboard
* [Weekly Market Recap](https://am.jpmorgan.com/) - Stock Market Recaps
* [Simul8or](https://simul8or.com/) - Trading Simulator
* [Compound Interest Calculator](https://www.investor.gov/financial-tools-calculators/calculators/compound-interest-calculator) - Investment Growth Calculator
* [Financials Extension](https://github.com/cmallwitz/Financials-Extension) - Stock Market Data for LibreOffice
* [Kitco](https://www.kitco.com/) - Precious Metals Prices / Calculators

***

## ▷ Crypto

* **Note** - It's recommended to store cryptocurrency offline in cold wallets, rather than exchanges like Binance or others. This increases security and gives you full control of your assets.

***

* 🌐 **[ChainList](https://chainlist.org/)** - EVM RPC List / [GitHub](https://github.com/DefiLlama/chainlist)
* 🌐 **[WalletExplorer](https://www.walletexplorer.com/)** - Bitcoin Block Explorer / Wallet Index
* 🌐 **[KYCNOT.ME](https://kycnot.me/)** / [i2p](http://nti3rj4j4disjcm2kvp4eno7otcejbbxv3ggxwr5tpfk4jucah7q.b32.i2p/) / [.onion](http://kycnotmezdiftahfmc34pqbpicxlnx3jbf5p7jypge7gdvduu7i6qjqd.onion/) / [Source Code](https://codeberg.org/pluja/kycnotme) or **[NotKYC](https://notkyc.com/)** - Non-KYC Exchanges / Services
* ⭐ **[WalletScrutiny](https://walletscrutiny.com/)** - Verify Crypto Wallets are Open-Source / Secure / [Subreddit](https://www.reddit.com/r/WalletScrutiny) / [Discord](https://discord.gg/yCNdcSJw9k) / [GitLab](https://gitlab.com/walletscrutiny/walletScrutinyCom)
* ⭐ **[Rotki](https://rotki.com/)** - Portfolio Manager / [Discord](https://discord.rotki.com/) / [GitHub](https://github.com/rotki)
* [BitcoinTalk](https://bitcointalk.org/) - Bitcoin Forum
* [BTCPay](https://btcpayserver.org/) - FOSS Bitcoin Payment Processor
* [BitcoinWhosWho](https://www.bitcoinwhoswho.com/) - Bitcoin Address Scanner
* [BlockChain](https://www.blockchain.com/explorer), [Velo](https://velo.xyz/), [CoinWatch](https://github.com/shorthouse/CoinWatch), [Hivexplorer](https://hivexplorer.com/), [BlockChair](https://blockchair.com/), [Mempool](https://mempool.space/), [L2BEAT](https://l2beat.com/), [HiveblockExplorer](https://hiveblockexplorer.com/) or [LiveCoinWatch](https://www.livecoinwatch.com/) - Live Crypto Prices / Blockchain Explorers
* [Privacy Watch](https://privacy.watch/) - Privacy Crypto Price Tracker
* [CoinGlass](https://www.coinglass.com) - Crypto Derivatives Data
* [DefiLlama](https://defillama.com/) - TVL Aggregator
* [Cryptopedia](https://www.gemini.com/cryptopedia) or [Crypto Canon](https://a16zcrypto.com/posts/article/crypto-readings-resources/) - Crypto Learning Resources
* [IQ.Wiki](https://iq.wiki/) - Crypto Encyclopedia
* [Traders Video Library](https://t.me/TradersVideo_Library) - Crypto Trading Courses
* [HiveRSS](https://www.hiverss.com/) - Create Hive RSS Feeds

***

# ► Shopping


* **Note** - Make sure to install a [adblocker](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_adblocking) when using these sites.

***

* 🌐 **[⁠Monerica](https://app.monerica.com/filter?Statuses=Verified)** - Monero-Friendly Site Index
* ⭐ **[Consumer Rights Wiki](https://consumerrights.wiki/)** - Documents Practices That Impact Consumer Rights / [Extension](https://github.com/FULU-Foundation/CRW-Extension) / [Discord](https://discord.gg/8w5rSNAXRf)
* ⭐ **[Dark Patterns Tip Line](https://darkpatternstipline.org/)** or [Dark Patterns](https://hallofshame.design/collection/) - Deceptive Services to Avoid
* ⭐ **[Parfumo](https://www.parfumo.com/)** - Fragrance Database / Reviews / Discovery / Collection Tracker
* [⁠Worse on Purpose](https://www.worseonpurpose.com/) - Brand Product Quality Tracking / Investigations
* [Dark Patterns Detective](https://games.productartistry.com/games/dark-patterns) - Learn to Avoid Deceptive Services
* [Boycott Buddy](https://www.boycottbuddy.app/) - Identify Brands with Unethical Practices (child labor, slave labor, etc.)
* [⁠Slave Free Chocolate](https://www.slavefreechocolate.org/) - Chocolatiers that use Ethically Sourced (child slavery free) Cocoa
* [ProductHunt](https://producthunt.com/) - Product / Service Reviews
* [RTINGS](https://www.rtings.com/) - Product Comparisons / Reviews
* [Pepper](https://www.pepperdeals.com/) or [SlickDeals](https://slickdeals.net/) - Shopping Deal Communities
* [⁠BangYourBuck](https://bangyourbuck.com/) - Unit Shopping Calculator / Comparisons for Amazon
* [Hagglezon](https://www.hagglezon.com/) - Price Comparisons for Amazon Stores Across Europe
* [Knockoff](https://knockoff.co/) - Remove Trademark-Squat Brands from Amazon Results / [GitHub](https://github.com/Shpigford/knockoff)
* [⁠RedRecs](https://www.redrecs.com/) - Reddit Product Rankings, Summaries, and Comments
* [ThisIsWhyImBroke](https://www.thisiswhyimbroke.com/) - Find Interesting Things to Buy
* [⁠BuyItForLife](https://buyitforlife.com/) - Durable Product Shopping Guide / [Subreddit](https://www.reddit.com/r/BuyItForLife/)
* [PicClick](https://picclick.com/) - ebay Visual Search Engine
* [⁠NoBids](https://nobids.net/), [⁠BuyMap](https://buymap.app/) or [WatchCount](https://www.watchcount.com/) - eBay Advanced Search
* [Typo Hound](https://typohound.com/) or [FatFingers](https://fatfingers.com/) - eBay Typo Search
* [⁠a view from my seat](https://aviewfrommyseat.com/) / [UK](https://aviewfrommyseat.co.uk/) - See Event Views Before Buying Tickets
* [Desenmascara](https://desenmascara.me/) - Spot Counterfeit Sites
* [⁠Gem](https://gem.app/) - Secondhand Clothing Multi-Store Search
* [r/MaleFashionAdvice Spreadsheet](https://docs.google.com/spreadsheets/d/1mhOIpjUUibBf3QueJs8iRJy5gBKCILq82ekJkiC5uqQ/) - Male Clothing Brand / Price Spreadsheet
* [r/FashionReps](https://www.reddit.com/r/FashionReps/) - Replica Clothing Community / [Discord](https://discord.com/invite/fashionreps)
* [⁠Doppel](https://doppel.fit/) - Replica Clothing Quality Control Platform
* [⁠Carryology](https://www.carryology.com/) - Baggage, Luggage and Everyday Carry Reviews
* [Best Damn EDC](https://www.youtube.com/channel/UCK5R1BsMtGd4DtI5uGQRHIg) - Everyday Carry Reviews / [Blog](https://bestdamnedc.com/)
* [⁠PackHacker](https://www.packhacker.com/) - Everyday Carry and Travel Gear Reviews / [YouTube](https://www.youtube.com/channel/UC_rI3y1DzDULTr-UIvshiwg)
* [⁠OutdoorGearLab](https://www.outdoorgearlab.com/) - Outdoor Gear Comparisons / Reviews
* [⁠Everyday Commentary](https://www.everydaycommentary.com/best-of) - Flashlight and Knife Reviews / [YouTube](https://www.youtube.com/@EverydayCommentary)
* [⁠Run Repeat](https://runrepeat.com/) - Shoe Shopping Guide / Reviews
* [⁠Lowtein](https://lowtein.com/) - Meat / Dairy Grocery Deal Comparisons
* [⁠The Gentleman Stationer](https://www.gentlemanstationer.com/resources) - Writing Instrument and Stationery Reviews
* [Unsharpen](https://www.youtube.com/@unsharpen) - Mechanical Pencil Reviews / [Blog](https://unsharpen.com/)
* [JetPens Blog](https://www.jetpens.com/blog) - Mechanical Pen / Pencil Guides / Shopping / [YouTube](https://www.youtube.com/@JetPens)
* [⁠Knockology](https://forum.knockology.com/) or [r/mechanicalpencils](https://www.reddit.com/r/mechanicalpencils/) / [Wiki](https://www.reddit.com/r/mechanicalpencils/wiki/index/) / [Discord](https://discord.com/invite/2zZfsax) - Mechanical Pencil Communities
* [⁠Pen Addict](https://www.penaddict.com/) - Mechanical Pencil and Stationery Reviews
* [⁠UK Fountain Pens](https://ukfountainpens.com/) - Fountain Pen Reviews
* [WornOnTV](https://wornontv.net/) or [ShopYourTV](https://shopyourtv.com/) - Find Outfits from TV Shows
* [GoodOnYou](https://directory.goodonyou.eco/) - Clothing Brand Sustainability Ratings
* [BabyGearLab](https://www.babygearlab.com/) - Baby Product Comparisons / Reviews
* [Cars.com](https://www.cars.com/research/compare/) - Vehicle Reviews / Comparisons
* [⁠CarSized](https://www.carsized.com/) - Vehicle Size Comparisons
* [Fragrantica](https://www.fragrantica.com/) or [Basenotes](https://basenotes.com/) - Fragrance Databases / Reviews / Communities
* [⁠INCIDecoder](https://inkeedecoder.com/) - Skincare Cosmetics Ingredients Databases / Search
* [Models.dev](https://models.dev/) - AI Model Database / Pricing / [GitHub](https://github.com/anomalyco/models.dev)
* [Build List](https://buildlist.org/) or [USA Parts Made Fast](https://partsmadefast.com/) / [X](https://x.com/mattfreed) - On-Demand Online Manufacturers

***

## ▷ Electronics / Tech

* ⭐ **[NanoReview](https://nanoreview.net/)** - Tech / Hardware Comparisons
* ⭐ **[TechPowerup](https://www.techpowerup.com/)** - Tech / Hardware Comparisons
* [RTINGS](https://www.rtings.com/) - Tech / Hardware Comparisons
* [⁠LTT Labs](https://www.lttlabs.com/) - In-Depth Hardware / Tech Reviews
* [TechGearLab](https://www.techgearlab.com/) - Tech / Hardware Comparisons
* [ProductChart](https://www.productchart.com/) - Tech / Hardware Comparisons
* [Octoparts](https://octopart.com/) - Tech / Hardware Comparisons
* [Technical City](https://technical.city/) - Tech / Hardware Comparisons
* [Techspecs](https://techspecs.io/) - Tech / Hardware Comparisons
* [ComparisonTabl.es](https://comparisontabl.es/) - Compare E-Readers, Phones, Speakers, etc.
* [VRcompare](https://vr-compare.com/) - VR & AR Headset Comparisons
* [⁠The Great MicroSD Card Survey](https://www.bahjeez.com/the-great-microsd-card-survey/) - MicroSD Tests / Comparisons
* [DrawTab](https://docs.sevenpens.com/drawtab) - Drawing Tablet Info / Wiki
* [⁠OscarLiang.com](https://oscarliang.com/) - FPV Drone Equipment Reviews
* [3D Printer Recs](https://redd.it/1bh9jud) - Hobbyist 3D Printer Recommendations
* [⁠SpoolScout](https://www.spoolscout.com/) - Search / Compare 3D Printing Filament Prices
* [⁠RackRat](https://rackrat.net/) - eBay Rackmount Server Prices / Comparisons

***

## ▷ Mobile / Phones

* ⭐ **[GSMArena](https://www.gsmarena.com/)** / [Guide](https://www.gsmarena.com/reviews.php3?sTag=Buyers+guide), [PhoneDB](https://phonedb.net/), [GSMChoice](https://www.gsmchoice.com/en/), [⁠Antutu](https://www.antutu.com/web/ranking) or [Kimovil](https://www.kimovil.com/en/) - Compare Phones / Prices
* [Dumbphone Finder](https://joyful-bienenstitch-cb6242.netlify.app/) - Compare Dumbphones (Non-Smartphones) / Prices / [Quiz](https://joyful-bienenstitch-cb6242.netlify.app/quiz)
* [Prepaid Compare](https://prepaidcompare.net/) - Compare Prepaid Phones / Prices
* [PhoneSized](https://phonesized.com/) or [HotSpot3D](https://www.hotspot3d.com/) - Phone Size Comparisons
* [Don’t kill my app!](https://dontkillmyapp.com/) - Manufacturer Battery Life vs. App Functionality

***

## ▷ Cameras

* [Camera Decision](https://cameradecision.com/), [⁠DPReview](https://www.dpreview.com/products/compare/cameras) or [Digicamfinder](https://digicamfinder.com/) - Compare Cameras
* [⁠Camera Size](https://camerasize.com/compare/) - Camera Size Comparison Tool
* [⁠PentaxForums Reviews](https://www.pentaxforums.com/reviews/all/) - Camera Gear Reviews

***

## ▷ PC Hardware / Building

* ⭐ **[PCPartPicker](https://pcpartpicker.com/)**, [BuildCores](https://www.buildcores.com/) / [Subreddit](https://reddit.com/r/buildcores) / [Discord](https://discord.gg/gxHtZx3Uxe) or [CGDirector](https://www.cgdirector.com/pc-builder/) - PC Building Sites
* ⭐ **[r/PCMasterrace Builds](https://pcmasterrace.org/builds)**, [r/BuildaPC Wiki](https://www.reddit.com/r/buildapc/wiki/index) or [PC Tiers](https://pctiers.com/) - PC Building Guides / **[Video](https://youtu.be/s1fxZ-VWs2U)**
* ⭐ **[Open Benchmarking](https://openbenchmarking.org/)** - Hardware Benchmarks
* ⭐ **[CPUBenchmark](https://www.cpubenchmark.net/)**, [Toms GPU Hierarchy](https://www.tomshardware.com/reviews/gpu-hierarchy) or [NoteBenchcheck](https://www.notebookcheck.net/Benchmarks-Tech.123.0.html) - GPU / CPU Benchmarks
* [⁠PerUnitPrice](https://perunitprice.com/) - Hardware Price Comparisons
* [SuggestALaptop Guide](https://docs.google.com/document/d/1_Oh9M4zrBB1hx3B0Yw32-evH4bqTmwNM5DJ12lWvA0w/) - Laptop Suggestions / [Subreddit](https://www.reddit.com/r/SuggestALaptop/) / [Discord](https://discord.gg/pes68JM)
* [r/buildapc](https://reddit.com/r/buildapc) - PC Building Community / [Discord](https://discord.com/invite/buildapc)
* [r/BuildAPCForMe](https://reddit.com/r/BuildAPCForMe) - PC Building Community
* [⁠MiniPCs.zip](https://minipcs.zip/) or [⁠Mini PC Doc](https://docs.google.com/spreadsheets/d/1MSVzjTK5bubSo7_pltKbWausKWoVUYynNdouj4GlIdE) - Mini PC Price Comparisons
* [⁠MoboMaps](https://mobomaps.com/) - Motherboard Visualizations / Info
* [⁠Cybenetics PSU Benchmarks](https://www.cybenetics.com/index.php?option=psu-performance-database) or [PSU Tier List](https://psutierlist.org/) / [Document](https://docs.google.com/spreadsheets/d/1akCHL7Vhzk_EhrpIGkz8zTEvYfLDcaSpZRB6Xt6JWkc/) / [Discord](https://discord.gg/qkrJy3hDa8) - PSU Buying Guides / Benchmarks
* [CPU Scout](https://www.cpuscout.com/) - eBay CPU Price Tracker
* [⁠WhereIsMyRam](https://whereismyram.com/) - DDR5 RAM Price Tracker
* [NewMaxx's SSD Site](https://borecraft.com/) / [Doc](https://docs.google.com/spreadsheets/d/1ExFofRZOk9BP2-gp0jtMHPmnStkHlkG_3KmqQNgwyBc/), [SSD Tester](https://ssd-tester.com/) or [JohnnyLucky](https://www.johnnylucky.org/data-storage/ssd-database.html) - SSD Buying Comparisons
* [Disk Prices](https://diskprices.com/), [⁠PricePerGig](https://pricepergig.com/), [List of Disks](https://www.listofdisks.com/) or [⁠TerabyteDeals](https://terabytedeals.com/) - Disk Price Trackers
* [EveryMac](https://everymac.com/) - Mac Info Database

***

## ▷ TV / Monitors

* [DisplaySpecifications](https://www.displayspecifications.com/), [PC Monitors](https://pcmonitors.info/), [TFTCentral](https://tftcentral.co.uk/), [Monitor Hunter](https://docs.google.com/document/d/1illeNLsUfZ4KuJ9cIWKwTDUEXUVpplhUYHAiom-FaDo/), [Monitor Spreadsheet](https://docs.google.com/spreadsheets/d/1wBV0U3a1XuP1yFLvs_Ald3FE1y45bVxtS2zBXixsGLs/edit) or [DisplayNinja](https://www.displayninja.com/) - Monitor Buying Guides
* [sven dpi](https://www.sven.de/dpi/) - Screen / Monitor Size Comparisons
* [4K TV Guide](https://www.reddit.com/r/4kTV/comments/1scq3vi/20262027_buying_guides_faq/) - 4K TV Buying Guide
* [⁠r/HTBuyingGuides](https://www.reddit.com/r/HTBuyingGuides/) - Home Theater Buying Guides
* [Dolby Vision Stuff](https://docs.google.com/spreadsheets/d/15i0a84uiBtWiHZ5CXZZ7wygLFXwYOd84) - Dolby Vision (HDR) Playback Guide

***

## ▷ Audio Equipment

* [AudioScienceReview](https://www.audiosciencereview.com/forum/index.php) or [⁠HiFiGuides Forum](https://forum.hifiguides.com/) - Audio Equipment Discussion
* [Scarbir](https://www.scarbir.com/), [Squiglink](https://squig.link/), [DIY-Audio-Heaven](https://diyaudioheaven.wordpress.com/), [Crinacle Graphs](https://graph.hangout.audio/) or [Crinacle](https://list.hangout.audio/iem) - Headset / Headphone / Earphone Comparisons
* [Consoomer_Guide](https://consoomer-guide.pages.dev/) / [2](https://rentry.org/consoomer_guide) - Earphone Shopping Guide
* [SpeakerRanking](https://www.speakerranking.com/) - Speaker Comparisons / Reviews
* [Erin's Audio Corner](https://www.erinsaudiocorner.com/) or [Equipboard](https://equipboard.com/) - Audio Equipment Comparisons
* [⁠Audio Test Kitchen](https://www.audiotestkitchen.com/) - Compare Microphone Sounds

***

## ▷ Keyboards / Mice

* ⭐ **[r/MechanicalKeyboards Wiki](https://www.reddit.com/r/MechanicalKeyboards/wiki/index)**, [KeebFinder](https://keeb-finder.com/) or [Alexotos](https://www.alexotos.com/keyboard-vendor-list/) / [Discord](https://discord.com/invite/xMQArAaGRB) - Mechanical Keyboard Recommendations
* ⭐ **[⁠MouseCTRL](https://mousectrl.com/)**, [Viscose's Friction Sheet](https://docs.google.com/spreadsheets/d/1Ix0RN4WDgRIn9uSUMy2smG_vWR3FTnZHgNpumChfHM0/) or [Mousepad Mastersheet](https://docs.google.com/spreadsheets/d/1RAnmZxDNduaGV8kB-GCvZ0MO6d9-0j9jmrU2f8dp0Ww/) - Mousepad Comparison Chart
* [EloShapes](https://www.eloshapes.com/), [Sensor.fyi](https://sensor.fyi/info/), [RocketJumpNinja](https://www.rocketjumpninja.com/) or [r/MouseReview](https://www.reddit.com/r/MouseReview/) / [Discord](https://discord.gg/mousereview) - Mouse Buying Guides
* [Shwamper's Skate Tierlist](https://docs.google.com/spreadsheets/d/1EUffzKOidRJ1W3-I1ocRd7yE_QDqXL58rUTOyC5ZBj4) - Mouse Dot Skate Recommendations / [X](https://x.com/shwamper5)

***

## ▷ Gaming Equipment

* [⁠RetroSizer](https://retrosizer.com/) - Compare Sizes of Handhelds
* [Gamepadla](https://gamepadla.com/) - Gamepad / Controller Latency Tests
* [RetroCatalog](https://retrocatalog.com/) or [Handheld Emulation Compatibility](https://docs.google.com/spreadsheets/d/1irg60f9qsZOkhp0cwOU7Cy4rJQeyusEUzTNQzhoTYTU/) - Handheld Game Emulation Compatibility / Info
* [⁠EmuReady](https://www.emuready.com/) - Mobile Game Emulation Compatibility / Info / [Discord](https://discord.gg/CYhCzApXav) / [GitHub](https://github.com/Producdevity/EmuReady)
* [⁠Archcord](https://www.flashcarts.net/) - DS + GBA Flashcart Comparisons / YSMenu Compatibility
* [Consolevariations](https://consolevariations.com/) - Game Console Rarity / Shopping

***

## ▷ Games

* ↪️ **[Steam Store Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools#wiki_.25B7_store_tools)**
* ⭐ **[GG.deals](https://gg.deals/)** - Multi-Store / Multi-Platform / [Extension](https://gg.deals/extension/) / [Discord](https://discord.com/invite/NhsTFvdHXG)
* ⭐ **[IsThereAnyDeal](https://isthereanydeal.com/)** - Multi-Store / [Extension](https://augmentedsteam.com/) / [Discord](https://discord.com/invite/C3K4bBh)
* ⭐ **[SteamDB](https://steamdb.info/sales/)** - Steam Sales / [Extension](https://steamdb.info/extension/) / [Discord](https://discord.com/invite/steamdb)
* [⁠Dark Pattern Games](https://www.darkpattern.games/) - Addictive Mobile Game Mechanic Avoidance Database
* [⁠EGData](https://egdata.app/) - Epic Store Sales / [GitHub](https://github.com/nachoaldamav/egdata)
* [r/SteamDeals](https://www.reddit.com/r/steamdeals/) - Steam Sales
* [CheapShark](https://www.cheapshark.com/) - Multi-Store / [Discord](https://discord.com/invite/cheapshark)
* [PSPrices](https://psprices.com/) - Multi-Store / Multi-Platform / [Discord](https://discord.com/invite/hN57zh8Ey2)
* [DekuDeals](https://www.dekudeals.com/) - Console Game Price Tracker
* [AppAgg](https://appagg.com/) - Multi-Store / Multi-Platform / [Discord](https://discord.gg/XUhs6fcFqQ) / [GitHub](https://github.com/AppsAgg/AppAgg)
* [CheapCharts](https://games.cheapcharts.com/) - Switch, Xbox and Playstation Price Tracker
* [r/GameDeals](https://www.reddit.com/r/gamedeals) - Game Deal Subreddit
* [PriceCharting](https://www.pricecharting.com/) - Game, Comic & Trading Card Price Tracker
* [⁠VRDB](https://vrdb.app/) or [QuestStoreDB](https://queststoredb.com/) - VR Game / App Price Tracker

***

## ▷ Physical Media / Streaming

* [Blu-ray.com](https://www.blu-ray.com/) - Blu-ray Release Calendar / Database / Reviews / [Deals](https://www.blu-ray.com/deals/)
* [⁠DVDBeaver](https://www.dvdbeaver.com/) - Blu-ray & DVD Release Calendar / Database / Reviews
* [High Def Digest](https://www.highdefdigest.com/) - Blu-ray Release Calendar / Database / Reviews
* [Releases](https://www.releases.com/) - Blu-Ray / DVD Release Calendar
* [DVDs Release Dates](https://www.dvdsreleasedates.com/) - DVD Release Calendar
* [Caps-A-Holic](https://caps-a-holic.com/) - Compare Movie Release Quality / Details
* [⁠Best Blurays](https://www.bestblurays.com/) - Find Best Quality Blu-ray Release
* [JustWatch Deals](https://www.justwatch.com/us/on-sale) - Digital Movie + Show Deals
* [⁠IPTV Surf](https://iptv.surf/) - IPTV Service Guide / Toolkit
* [⁠StreamCheck](https://search.streamcheck.pro/) - IPTV Provider Channel Checker
* [⁠Suppose](https://www.suppose.tv/) - Compare TV Providers (US Only)

***

## ▷ Apps

* [AppRaven](https://appraven.net/activity/pricedrops?ratingCount=0&price=FREE) - Apple Platform Apps / Games / [Subreddit](https://www.reddit.com/r/AppRaven/) / [Telegram](https://t.me/AppRavenOfficial) / [Discord](https://discord.com/invite/q8nPsNAypC)
* [App Sales](https://www.app-sales.net/nowfree/) - Android Apps
* [r/GooglePlayDeals](https://reddit.com/r/googleplaydeals) - Android Apps
* [r/AppHookup](https://www.reddit.com/r/AppHookup/) - Multi-Store / Multi Platform
* [⁠r/MacAppStoreDeals](https://www.reddit.com/r/MacAppStoreDeals/) - Apple Apps

***

## ▷ Books / Audiobooks

* [BookFinder](https://bookfinder.com/) - Online Book Price Comparisons
* [⁠r/ebookdeals](https://www.reddit.com/r/ebookdeals/) - Book Deal Tracking Subreddit
* [⁠Kobo Price Tracker](https://bookpricetracker.com/) - Book Price Tracker
* [CheapCharts Books](https://www.cheapcharts.com/us/itunes/ebooks/on-sale) - Apple Books Deal Tracking
* [CheapCharts Audiobooks](https://www.cheapcharts.com/us/itunes/audiobooks/on-sale) - Apple Books Audiobook Deal Tracking
* [eReaderIQ](https://www.ereaderiq.com/) - Kindle Book Price Comparisons
* [Omnibus Tracker](https://omnibusreaders.com/sales) - Comic Sales Tracking

***

## ▷ Toys / Collectibles

* [MyFigureCollection](https://myfigurecollection.net/) - Japanese Pop-Culture Merch Database
* [Misprint](https://www.misprint.com/) - Buy / Sell Pokémon Cards
* [⁠ThePriceDex](https://www.thepricedex.com/) - Pokémon Card Price Tracking
* [PkmnCards](https://pkmncards.com/), [Pokéllector](https://www.pokellector.com/) or [Limitless](https://limitlesstcg.com/) - Pokémon Card Databases / Resources
* [Dinosaur Toy Blog](https://dinotoyblog.com/) or [Animal Toy Blog](https://animaltoyforum.com/blog/) - Animal Toy Reviews
* [Ty Collector](https://tycollector.com/) or [Beaniepedia](https://beaniepedia.com/) - Ty Collectibles Databases
* [BreyerHorseRef](https://www.breyerhorseref.com/) - Breyer Horse Database
* [The Toy Pool](https://thetoypool.com/) - Multi-Brand Toy & Doll Database
* [Brickset](https://brickset.com/), [⁠BrickEconomy](https://www.brickeconomy.com/) or [Bricklink](https://www.bricklink.com/) - LEGO Set Database / Reviews / Marketplaces
* [⁠Brickfact](https://brickfact.com/) - LEGO Set Database / Price Tracker
* [⁠MinifigScan](https://pacolabs.com/MinifigScan/) - LEGO Minifigure Blind Box Identification Tool
* [⁠Brick Hound](https://brickhound.com/) - LEGO Deal Alerts
* [FigureRealm](https://www.figurerealm.com/) - Track Action Figure Collection

***

## ▷ Price Tracking

* ⭐ **[Dupe](https://dupe.com/)** or [wtf.deals](https://wtf.deals/) - Furniture Duplicate Deals Search
* ⭐ **[Keepa](https://keepa.com/)**, [PriceHistory](https://pricehistoryapp.com/) or [CamelCamelCamel](https://camelcamelcamel.com/) - Amazon Price Trackers / [App](https://play.google.com/store/apps/details?id=com.offertadelgiorno.offertadelgiorno)
* [⁠TrackaLacker](https://www.trackalacker.com/) - Price Tracker
* [Vetted](https://vetted.ai/) or [FlipsHope](https://flipshope.com/) - Price Tracking Extensions
* [r/WhatsThisWorth](https://www.reddit.com/r/whatsthisworth/) - Online Appraisals
* [Music Software Deals](https://musicsoftwaredeals.com/) - Track Music Software Prices
* [Valuta EX](https://valuta.exchange/) or [Currency World](https://currency.world/) - Currency Converters

***

# ► Useful Sites

* ↪️ **[Skills / Hobbies / DIY](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu/#wiki_.25BA_skills_.2F_hobbies_.2F_diy)**
* ↪️ **[Manual Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/reading#wiki_.25B7_manuals)** - Repair Articles / Manuals
* ↪️ **[Mind Mapping](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools#wiki_.25B7_mind_mapping)**
* ↪️ **[Presentation / Slideshare Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_presentation_tools)**
* ↪️ **[Data Visualization](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_data_visualization_tools)**
* ↪️ **[Polling Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_poll_sites)**
* ⭐ **[endoflife.date](https://endoflife.date/)** - Tool / Tech End of Life Index
* [Don't Call The Police](https://dontcallthepolice.com/) - Alternative Crisis Response / Police Alternatives
* [RANDOM](https://www.random.org/), [The One Generator](https://theonegenerator.com/) or [getrandomgenerator](https://getrandomgenerator.com/) - Random Generators
* [Versus](https://versus.com/), [SocialCompare](https://socialcompare.com/en) or [Diffen](https://www.diffen.com/) - Compare Anything
* [Compare Sizes](https://comparesizes.com/) or [⁠SizeR.jp](https://sizer.jp/) - Compare Sizes of Anything
* [The Measure Of Things](https://www.themeasureofthings.com) - Comparative / Relative Quantity Measurements
* [⁠anruler](https://anruler.com/) - Online Ruler
* [Paper Sizes](https://papersizes.io/) - Common Paper Sizes
* [wttr](https://wttr.in/) - Simple / Minimal Weather / [GitHub](https://github.com/chubin/wttr.in)
* [⁠RetroCast Now](https://weather.com/retro/), [WeatherStar 4000+](https://weatherstar.netbymatt.com/) / [2](https://weatherstar.dev/) / [International](https://mwood77.github.io/ws4kp-international/), [WeatherStar 80's](https://weatherstar3000.netbymatt.com/) or [WeatherScan](https://weatherscan.net/) - Retro Style Weather / [GitHub](https://github.com/MistWeatherMedia/)
* [Wheel Decide](https://wheeldecide.com/), [SpinWheelPlus](https://spinwheelplus.com/), [Ultimate Wheel](https://ultimatewheelspin.com/), [PickerWheel](https://pickerwheel.com/), [SpinWheelify](https://spinwheelify.com/), [SpinTheWheel](https://spinthewheel.io/), [HeySpinner](https://heyspinner.com/), [SpinTheWheel](https://spinthewheel.net/), [TheSpinnerWheel](https://thespinnerwheel.com/) or [Wheel of Names](https://wheelofnames.com/) - Wheel Randomizers / Spinners
* [⁠Date Night Questions](https://www.datenightquestions.com/) - Friend / Date Q&A Cards
* [SurveyHeart](https://surveyheart.com/) - Survey Creators
* [Label Studio](https://labelstud.io/) or [Cvat](https://www.cvat.ai/) - Data Organizing Tools
* [colnect](https://colnect.com/en) - Manage Personal Collections
* [Acoustic Gender](https://acousticgender.space/) - Measure Voice Pitch
* [Timeline Cascade](https://markwhen.com/) / [GitHub](https://github.com/mark-when/markwhen), [Timeline JS](https://timeline.knightlab.com/) or [Time.Graphics](https://time.graphics/) - Create Timelines
* [Timeliner](https://timelinize.com/) - Create Personal Digital Timeline
* [Familypedia](https://familypedia.fandom.com/), [Gramps](https://gramps-project.org/blog/), [FamilySearch](https://www.familysearch.org/) or [WikiTree](https://wikitree.com/) - Find Family Trees
* [⁠Family Chart](https://github.com/donatso/family-chart), [Family Tree Builder](https://family-tree-builder.com/) or [FamilyEcho](https://www.familyecho.com/) - Create Custom Family Tree
* [ThistoThat](https://www.thistothat.com/) - How to Glue Anything to Anything
* [r/CurlyHair Guide](https://docs.google.com/document/d/e/2PACX-1vSvGm-p4tvrstjT-XEo6pTHZSYeEON7xF5lPSnNv-3Kc2lCrdnkjXhFbdHt4pF3HUetWZ1j9dgfBBkS/pub) - Curly Hair Haircare Guide
* [WhyDoCatsAndDogs...?](https://whydocatsanddogs.visualcinnamon.com/) - Pet Q&A Site
* [Stolen Drone](https://stolendrone.info/) - Stolen Drone Info
* [CacheSleuth](https://www.cachesleuth.com/) - Geocaching Tools
* [17Track](https://www.17track.net/en), [Informed Delivery](https://informeddelivery.usps.com/) or [Parcelsapp](https://parcelsapp.com/en/) - Mail Package Tracking
* [TemplateMaker](https://www.templatemaker.nl/) - Package / Box Templates
* [⁠FULU Bounties](https://bounties.fulu.org/) - Console DRM Removal Bounties
* [Hots&Cots](https://www.hotscots.app/) - Military Reviews of Barracks / DFAC / [X](https://x.com/hotscots_app)

***

## ▷ Multi Tool Sites

* ⭐ **[TinyWow](https://tinywow.com/)** - Text / Image / PDF / File
* ⭐ **[⁠HeyTools](https://heytools.app/)** - Text / PDF / Image / Code
* ⭐ **[PineTools](https://pinetools.com/)** - Text / Multimedia / Colors / Code
* [⁠Ou0.cc](https://ou0.cc/) - Text / Social Media / Code / Multimedia
* [GoOnlineTools](https://goonlinetools.com/) - Text / Encode-Decode / Code / Random / Image
* [⁠99Tools](https://99tools.net/) - Text / Encode-Decode / Code / Random / Image
* [⁠Edge Tools](https://edgetools.io/) - Image / Text / PDF / Code
* [Framasoft](https://degooglisons-internet.org/en/) - Text / Collaboration
* [10015.io](https://10015.io/) - Text / Image / Code / Colors
* [⁠ClipZeal](https://clipzeal.com/) - Video / Audio / Image / GIF
* [⁠VidhyaGen](https://vidhyagen.com/) - Image / PDF / Text
* [ToolBox](https://footrue.com/) - Image / Text / Code / PDF
* [Private.coffee](https://private.coffee/services.html) - Text / Code
* [RandomTools](https://randomtools.io/) - Social Media / Text / Image / Code
* [delphitools](https://delphi.tools/) - Social Media / Text / Image
* [MajorGeeks Tools](https://tools.majorgeeks.com/) - Social Media / Text / Image / Code
* [OmniTools](https://omnitools.app/) - Social Media / Text / Image / Code
* [⁠ToolKnit](https://toolknit.com/) - Image / Video / PDF / Audio / File
* [⁠WebBrowserTools](https://webbrowsertools.com/) - Code / Text / Image
* [IPVoid](https://www.ipvoid.com/) - Text / IP
* [AppsCyborg](https://appscyborg.com/) - File Conversion / Media
* [Online Tools](https://onlinetools.com/) - File-Specific Tools
* [a.tools](https://www.a.tools/) - Text / Image / Code / Cryptography
* [RakkoTools](https://rakko.tools/en) - Text / Code / Image
* [123Apps](https://123apps.com/) - Multimedia / File Conversion / PDF
* [Webacus](https://webacus.dev/) - Data / Text / Design / Cryptography / Unit Conversion
* [Media.io](https://www.media.io/online-tools.html) - Multimedia
* [BfoTool](https://bfotool.com/) - Text / Image / Code / File Conversion
* [Ian Coleman](https://iancoleman.io/) - Cryptography and Encoding Tools
* [URL Decode](https://url-decode.com/all-tools) - Dev Tools / Web Tools / File Conversion

***

## ▷ Productivity / Time Tracking

* 🌐 **[ProductivePrivacy](https://priductive.com/)** - Privacy-Focused Productivity Apps
* 🌐 **[Time and Date](https://www.timeanddate.com/)** - Multiple Time Tracking Tools
* ↪️ **[To-Do Lists](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools#wiki_.25B7_to_do_lists)**
* ↪️ **[Android Productivity / App Blocking](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_productivity_.2F_app_blockers)**
* ⭐ **[Super Productivity](https://super-productivity.com/)** - Time Tracker / Productivity App / To-Do List / [GitHub](https://github.com/super-productivity/super-productivity)
* ⭐ **[Habitica](https://habitica.com/)** - Achievement Style Productivity App / [GitHub](https://github.com/HabitRPG/habitica)
* ⭐ **[LeechBlock](https://www.proginosko.com/leechblock/)**, [Plucky](https://pluckyfilter.com/), [⁠one sec](https://one-sec.app/), [Block Site](https://webextension.org/listing/block-site.html) or [Forest](https://addons.mozilla.org/en-US/firefox/addon/forest-stay-focused-be-present/) / [Chrome](https://chrome.google.com/webstore/detail/forest-stay-focused-be-pr/kjacjjdnoddnpbbcjilcajfhhbdhkpgk) - Site Blocking Extensions
* [Zoneless](https://zoneless.tools/), [WorldTimeBuddy](https://www.worldtimebuddy.com/) or [EveryTimeZone](https://everytimezone.com/) - Time Zone Visualizers / Comparisons
* [⁠FocusTube](https://github.com/malekwael229/FocusTube), [UnDistracted](https://www.undistracted.app/) or [Focus-ToDo](https://chromewebstore.google.com/detail/ngceodoilcgpmkijopinlkmohnfifjfb) - Distraction / Doomscroll Blocking Extensions
* [r/GetMotivated](https://www.reddit.com/r/GetMotivated/) - Motivational Community
* [Project Karma](https://projectkarma.me/) - Productivity RPG 
* [Untools](https://untools.co/) - Better Thinking Tools
* [Freeter](https://freeter.io) - Work Organizer / [GitHub](https://github.com/FreeterApp/Freeter)
* [VisualizeHabit](https://visualizehabit.com/) - Habit Tracking
* [Cold Turkey](https://getcoldturkey.com/) - Site Blocker / Productivity App
* [⁠WHPH](https://whph.ahmetcetinkaya.me/) - Productivity Tracker / [GitHub](https://github.com/ahmet-cetinkaya/whph)
* [⁠ScreenZen](https://screenzen.co/) - Site / App Blocker
* [SelfControlApp](https://selfcontrolapp.com/) - Mac Site Blocker
* [ActivityWatch](https://activitywatch.net/) - Device / App Time Tracker / [Extensions](https://github.com/ActivityWatch/aw-watcher-web)
* [ProcrastiTracker](https://strlen.com/procrastitracker/) - Device / App Time Tracker
* [Focumon](https://www.focumon.com/) - Pokémon Style Productivity App
* [Timer](https://klaster1.github.io/timer-5) - Time Tracker
* [wnr](https://getwnr.com/) - Time Tracker / Break Reminders
* [Pomatez](https://zidoro.github.io/pomatez/) - Time Tracker / Break Reminders
* [BreakTimer](https://breaktimer.app/) - Break Reminders
* [Stretchly](https://hovancik.net/stretchly) - Break Reminders
* [skāl.es](https://www.skal.es/) - Work Life Balance Tracking
* [BreakMessage](https://breakmessage.com/) - Online Break Reminders
* [Time Tracker](https://www.wfhg.cc/) - Browser Time Tracking Extension / [GitHub](https://github.com/sheepzh/time-tracker-4-browser)
* [Comicsflow](https://comicsflow.com/) - Comic / Manga Project Manager

***

## ▷ Calendars / Events

* ↪️ **[To-Do Apps](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android/#wiki_.25B7_to-do_apps)**
* ⭐ **[Cal.com](https://cal.com/)** - Business / Work Schedule Calendar / [GitHub](https://github.com/calcom/cal.com)
* ⭐ **[LettuceMeet](https://lettucemeet.com)**, [Star Fit](https://starbestfit.com/), [Samay](https://samay.app/), [Pick Time](https://pick-time.io/), [Event Rallly](https://rallly.co/) / [GitHub](https://github.com/lukevella/Rallly), [Groop](https://joingroop.com/), [Cally](https://cally.com/), [Mobilizon](https://joinmobilizon.org/) or [Gancio](https://gancio.org/) - Event Planning / Schedule Voting
* [Luma](https://luma.com/), [⁠Heylo](https://www.heylo.com/), [⁠Eventbrite](https://www.eventbrite.com/) or [Meetup](https://www.meetup.com/) - Search or Post Local Events
* [GanttProject](https://www.ganttproject.biz/) - Project Scheduling App
* [⁠zcal](https://zcal.co/) - Scheduling / Meeting Tool
* [Proton Calendar](https://proton.me/calendar) - Calendar / [Discord](https://discord.com/invite/proton)
* [Tuta Calendar](https://tuta.com/calendar) - Calendar
* [Tweek](https://tweek.so/) - Calendar
* [Gantt](https://github.com/neuronetio/gantt-schedule-timeline-calendar) - Calendar
* [time.fyi](https://time.fyi/) - Calendar / Time Tools
* [Office Holidays](https://www.officeholidays.com/) - World Event Calendars
* [Countdowns](https://www.countdowns.live/) - Create Custom Countdowns
* [StageTimer](https://stagetimer.io/) - Event Timer
* [Table Plan](https://table-plan.com/) - Seating Chart Maker ⁠
* [WhoBrings](https://whobrings.com/) - Party Item Management Tool
* [Spliit](https://spliit.app/) or [KittySplit](https://www.kittysplit.com/en/) - Group Expense Splitting Calculator

***

# ► Fun Sites

## ▷ Chat / Forums

* 🌐 **[r/ListOfSubreddits](https://www.reddit.com/r/ListOfSubreddits/wiki/listofsubreddits/)** - List of Subreddits
* 🌐 **[Piracy Subs](https://www.reddit.com/r/Piracy/wiki/megathread/related_subreddits)** - Piracy Subreddits
* 🌐 **[The Hive Index](https://thehiveindex.com/)** - Online Communities Index
* ↪️ **[Multireddit Index](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_multireddits)**
* ↪️ **[AI Chatbots](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/ai#wiki_.25BA_ai_chatbots)**
* ⭐ **[Knockout](https://knockout.chat/)** / [Discord](https://discord.com/invite/tqUtPA43Hy), [comfy box](https://comfybox.floofey.dog/), [SheepishPatio](https://sheepishpatio.net/) or [Macintosh Cafe](https://forum.agoraroad.com/) - General Forums
* ⭐ **[SufficientVelocity](https://forums.sufficientvelocity.com/)**, [Myth Weavers](https://www.myth-weavers.com/), [⁠AltHistory](https://althistory.com/), [RolePlayer](https://www.roleplayer.me/) or [SpaceBattles](https://forums.spacebattles.com/) - Fanfiction / Roleplaying Communities
* [Frantic Fanfic](https://franticfanfic.com/) - Fanfiction Chat Game
* [bugs](https://nobodyhere.com/bugs/) or [Posting.Cool](https://posting.cool/) - Random Topic Forums
* [⁠Perfectly Imperfect](https://www.pi.fyi/) or [⁠Bliish](https://bliish.com/) - Oldschool Internet Style Social Media Sites
* [⁠CozyTalk](https://cozy.talk/) - Minimalist Retro-Style Chat / Forum
* [Earth Reviews](https://neal.fun/earth-reviews/) - Help Improve the Simulation
* [Virtual World List](https://virtualworldslist.neocities.org/) - Virtual World List
* [⁠late.sh](https://late.sh/) - Command-Line Style Clubhouse / [GitHub](https://github.com/mpiorowski/late-sh)
* [Monkey](https://www.monkey.app/) - Random Chat Rooms
* [Wireclub](https://www.wireclub.com/) - Topic Chat Rooms
* [Spirits and Such](https://spiritsandsuch.org/en) - Arataka Reigen Homepage / Text Board, Image Board, Games & more
* [MyCast](https://www.mycast.io/) - Dream Casting Discussions
* [Alchemy Forums](https://alchemyforums.com/index.php) - Alchemy Forum
* [AnimeSuki](https://forums.animesuki.com/), [AnimeUKNews](https://forums.animeuknews.net/) or [Fanverse](https://www.fanverse.org/) - Anime Discussion
* [Fora](https://fora.com/communities/) or [Discourse](https://discover.discourse.com/) - Specialty Forums
* [Resetera](https://www.resetera.com/), [RetroGameTalk](https://retrogametalk.com/) / [Subreddit](https://www.reddit.com/r/RetroGameTalk/) or [RacketBoy](https://racketboy.com/forum/) - Gaming Forums
* [TheRPF](https://www.therpf.com/forums/) - Movie Costume / Prop Forum
* [Airsoft International](https://discord.gg/airsoft) - Airsoft Guides / Community
* [Photonlexicon](https://www.photonlexicon.com/forums/) - Lasers Forum
* [Status.Cafe](https://status.cafe/) - Share Current Status
* [TwoCansAndAString](https://twocansandstring.com/) or [TellOnMe](https://tellonym.me/) - Anonymous Q&A
* [A Collection of Unsaid Things](https://somethingsarebetterleftunsaid.vercel.app/) - Anonymous Unsent Message Archive
* [PostSecret](https://postsecret.com/) - Share Secrets via Postcard
* [Earth 2050](https://2050.earth/) - Future Predictions
* [MessageToTheFuture](https://messagetothefutu.re/) or [FutureMe](https://www.futureme.org/) - Send Messages to Future Self
* [PenPal World](https://www.penpalworld.com/) or [GlobalPenFriends](https://www.globalpenfriends.com/) - Pen Pal Community
* [WriteAPrisoner](https://writeaprisoner.com/) - Pen Pals for Inmates

***

## ▷ Image / Video

* ↪️ **[YouTube Search / Archives](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/social-media#wiki_.25B7_youtube_search)**
* ↪️ **[Digital Art Collections](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7_art_galleries_.2F_collections)**
* ↪️ **[Image Creation](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25BA_image_creation)**
* ↪️ **[ASCII Art](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools#wiki_.25B7_ascii_art)**
* ↪️ **[Art / Illustrations](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25B7_art_.2F_illustrations)**
* ↪️ **[GIF Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25B7_gif_tools)**
* ↪️ **[Meme Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools/#wiki_.25B7_meme_tools)**
* ↪️ **[4chan Archives](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/social-media#wiki_.25B7_4chan_archives)**
* ⭐ **[SakugaBooru](https://www.sakugabooru.com/)** - Anime Animation Booru / [Enhancements](https://chromewebstore.google.com/detail/sakuga-extended/khmnmdaghmhkcbooicndamlhkcmpklmc)
* ⭐ **[Floor796](https://floor796.com/)** - Ever-Expanding Animated Scene
* [loc.alize](https://loc.alize.us/) - Explore Earth via Images
* [Newgrounds Auditorium](https://bluemaxima.org/auditorium/) - Newgrounds Flash Animation Archive
* [⁠SWF Rodeo](https://swf.rodeo/) or [TheBest404](https://thebest404pageeverredux.com/) - Random SWFs
* [MSPFA](https://mspfa.com/) - MS Paint Fan Adventures
* [GigaMacro](https://viewer.gigamacro.com/) - Panoramic Photography
* [⁠The Hong Kong Phantasm](https://www.hkphantasm.com/) - Hong Kong Slide Photography Archive
* [Retro TV Simulator](https://www.myretrotvs.com/) - Simulate Oldschool TV Channels
* [TheOfficeStareMachine](http://theofficestaremachine.com/) - The Office Video Emotion Search
* [BumpWorthy](https://www.bumpworthy.com/) - Adult Swim Bumps
* [YouTune](https://youtune.elan.place/) - Random Low View Songs
* [⁠Flipnote Studio Scratch](https://turbowarp.org/382497241) - Web-based Flipnote Studio
* [Sudomemo](https://www.sudomemo.net/), [Flipnote Archive](https://archive.sudomemo.net/) or [Kaeru Gallery](https://gallery.kaeru.world/) - DS Flipnote Studio Galleries
* [⁠Amiga Graphics Archive](https://amiga.lychesis.net/) - Commodore Amiga Graphics Archive
* [Toonami Remastered](https://www.toonamiremastered.com/) - Remastered Toonami Content
* [ThisXDoesNotExist](https://thisxdoesnotexist.com/) - Realistic-Looking Fake Versions of Things
* [ThisPersonNotExist](https://thispersonnotexist.org/), [ThisPersonDoesNotExist](https://www.thispersondoesnotexist.com/) or [this-person-does-not-exist](https://this-person-does-not-exist.com/) - People That Don't Exist
* [The Slideshow](https://theslideshow.net/) - Google Image Slideshow
* [⁠The Gallery of Babel](https://babel.alfaoz.dev/) or [babel image archives](https://babelia.libraryofbabel.info/) - Image Version of Library of Babel
* [Different Strokes](https://scottts.itch.io/different-strokes) - Online User-Made Art Gallery
* [Creative Uncut](https://www.creativeuncut.com/) - Video Game Art
* [IndieGameBooru](https://indiegame.booru.org/) - Indie Game Image Booru
* [ASCII Theatre](https://ascii.theater/) - ASCII Based Movies
* [Random Screenshot](https://randomscreenshot.com/) or [Random Prnt.sc](https://chrishannah.me/prntsc/) - Random Screenshots
* [Random Comic Generator 3.0](https://explosm.net/rcg) - Explosm Random Comic Generator
* [Pulp-O-Mizer](https://thrilling-tales.webomator.com/derange-o-lab/pulp-o-mizer/pulp-o-mizer.html) - Vintage Magazine Cover Generator
* [Chris Shier](https://www.csh.bz/) - Canvas Animations / GIFs
* [r/Place Atlas](https://place-atlas.stefanocoding.me/) - r/Place Info
* [LameBook](https://www.lamebook.com/) - Funny Facebook Statuses
* [Kittenwar!](https://www.kittenwar.com/) - Rate Kittens
* [Cataas](https://cataas.com/cat) - Random Cat Images
* [procatinator](https://procatinator.com/) - Cat GIFs & Music
* [Open Puppies](https://openpuppies.com/) - Random Dog GIFs
* [EveryoneDraw](https://everyonedraw.com/), [pixels.land](https://pixel.land/) or [World of Pixels](https://ourworldofpixels.com/) - Infinite Online Pixel Art
* [⁠3place](https://3place.world/) - Infinite Online 3D Pixel Art Globe
* [Triviart](https://triviart.live/) - Infinite Painting Canvas with Trivia
* [bomomo](https://bomomo.com/) - Multi-Brush Painting
* [Monsterland](https://monsterland.net/) - Collaborative Monster Drawing
* [JS Kid Pix](https://kidpix.app/) - Browser JS KidPix
* [Paint with Music](https://artsandculture.google.com/experiment/paint-with-music/YAGuJyDB-XbbWg) - Paint with Sound
* [JacksonPollock](https://www.jacksonpollock.org/) - Blob-Style Painting
* [No Paint](https://nopaint.art/) - Press "Paint" if you like what you see, "No" if you don't
* [paint.wtf](https://paint.wtf/) - Have an AI Judge Your Art
* [⁠MagnifiedSand](https://magnifiedsand.com/) - Microscopic Sand Magnification Database
* [Magic Sketchpad](https://meowni.ca/glitch/magic-sketchpad/) - Magical Sketchpad
* [Webchemy](https://webchemy.org/) - Drawing / Sketching
* [World Draw](https://world-draw.appspot.com/draw) - Draw World Together
* [Eschersket](https://eschersket.ch/) - Symmetry Drawing Tool
* [MakeCoatOfArms](https://www.allfamilycrests.com/makecoatofarms.htm) - Coat of Arms Generator
* [Where Is The Google Car](https://www.whereisthegooglecar.com/) - Google Car Images / Locations
* [Web Neko](https://webneko.net/) - Nekos on the Web
* [Uji](https://ghpages.noahdoersing.com/uji/) or [Turtletoy](https://turtletoy.net/) - Minimalist Art Generators
* [Random Art](https://www.random-art.org/) - Random Art Generator
* [Paper Quilling Art](https://pissang.github.io/paper-quilling-art/) - Paper Quilling Art Generator
* [Periodicity](https://williamhoza.com/periodicity/) - Harmonic Motion Patterns
* [Synaptic Spiral](https://synapticspiral.nz/), [Mandelnaut](https://techmatt.github.io/fractals/explorer/) or [Mandelbrot Explorer](https://math.hws.edu/eck/js/mandelbrot/MB.html) / [WebGPU](https://math.hws.edu/eck/js/mandelbrot/MBgpu.html) - Fractal Visualizers / Creators
* [Silk](http://weavesilk.com/) - Create Geometric Silk Art
* [MandalaGaba](https://www.mandalagaba.com/) / [Pro Version](https://pro.mandalagaba.com/), [Mandala App](https://mandala-app.com/) or [DigitalDoily](https://codymoose.github.io/web-applications/DigitalDoily/index.html) - Zen Geometry Tools
* [Inspirograph](https://inspiral-web.nathanfriend.com/) or [SpirographN](http://seedcode.com/SpirographN/sgn.html) - Spirograph Tool
* [myMrLx](https://codepen.io/davidpanik/full/myMrLx/) - Spiral Art Generators
* [Remoji](https://remoji.com/) - Emoji Painting
* [EmojiMix](https://tikolu.net/emojimix) or [Emoji Kitchen](https://emojikitchen.dev/) - Combine Emojis
* [EmoteStud](https://emotestud.io/), [Emoji Factory](https://codepen.io/oliviale/full/qLYNbE) or [Ccclaymoji](https://fffuel.co/ccclaymoji/) - Emoji Creators
* [pokemon-colorscripts](https://gitlab.com/phoneybadger/pokemon-colorscripts) - Terminal Pokémon Sprites
* [Pokémon Fusion](https://pokemon.alexonsager.net/) - Fuse Pokémon
* [Poke Palettes](https://pokepalettes.com/) - Pokémon Color Palettes
* [Star Wars Intro Creator](https://starwarsintrocreator.kassellabs.io/) - Create Star Wars Intros
* [Mirage Gallery](https://www.miragegallery.ai/) - AI Art Gallery
* [Gondola List](https://gondola.nabein.me/list) - Gondola Meme Archive
* [Matchbox Dan](https://matchbox-dan.com/) - Matchbox Car Picture Archive
* [Zoomquilt](https://www.zoomquilt.org/) / [2](https://zoomquilt2.com/), [Infinite Zoom](https://infinitezoom.net/) or [Arkadia](https://arkadia.xyz/) - Infinite Zooming Paintings
* [Blue Ball Machine 2](https://blueballmachine2.ytmnd.com/) - Full Page Chain Reaction Image
* [YourNameInLandsat](https://science.nasa.gov/specials/your-name-in-landsat/) - Spell Anything via Satellite Images
* [Useless Certifications](https://uselesscertifications.com/) - Useless Certifications
* [Anime Girls Holding Programming Books](https://cat-milk.github.io/Anime-Girls-Holding-Programming-Books/)
* [webgbcam](https://maple.pet/webgbcam/) - Game Boy Camera in Browser
* [Terminal Video Player](https://github.com/TheRealOrange/terminalvideoplayer) - Cursed Terminal Video Player

***

## ▷ Interactive

* 🌐 **[David.li](https://david.li/)** - Physics Games
* ↪️ **[Browser Games](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/games#wiki_.25BA_browser_games)**
* ⭐ **[The Life Engine](https://thelifeengine.net/)** - Artificial Life Simulation / [Video](https://youtu.be/iSAKEnRfles) / [Discord](https://discord.gg/ZsrAAByEnr)
* ⭐ **[Sandboxels](https://neal.fun/sandboxels/)**, [Powder Game 2](https://dan-ball.jp/en/javagame/dust2/), [Powder Toy](https://powdertoy.co.uk/), [sandspiel.club](https://sandspiel.club/) - Falling Sand Physics Sandbox
* ⭐ **[Genetic Cars 2](https://rednuht.org/genetic_cars_2/)** or [geneticars](https://geneticars.vercel.app/) - Random 2D Car Generator
* ⭐ **[Human Benchmark](https://humanbenchmark.com/)** - Brain Games & Cognitive Tests
* [⁠your ai slop bores me](https://youraislopbores.me/) - Interactive Human AI Roleplaying / [Discord](https://discord.gg/aislop)
* [DJ3D](https://dj3d.io/) - Watch YouTube in Virtual World
* [⁠Page Rage](https://page-rage.com/) - Destroy Any Web Page
* [⁠weball](https://www.funwithcomputervision.com/weball/) - Web Page Katamari Damacy
* [The ⁠Museum of All Things](https://may.as/moat/) / [GitHub](https://github.com/m4ym4y/museum-of-all-things) or [⁠The Endless Museum](https://theendlessmuseum.com/)- 3D Virtual Wikipedia Museums
* [VentScape](https://www.ventscape.life/rage) or [PostSecretVoicemail](https://www.postsecretvoicemail.com/) - Speak into a Void
* [AfterTheBeep](https://afterthebeep.tel/) - Public Voicemail
* [1000 Seconds](https://mattround.com/usvsth3m/1000-seconds/) - Test of Patience
* [Notpron](http://www.notpron.com/) - Worlds Hardest Internet Riddle
* [Frequency2156](https://frequency2156.com/) - Listen to / Record Survival Messages
* [Oracle](https://roadtolarissa.com/oracle/) - Try to Trick an AI
* [Moral Machine](https://www.moralmachine.net/) - Decision-Making AIs
* [Cookie Consent Speed.Run](https://cookieconsentspeed.run/) - Cookie Disabling Game
* [Are You You?](https://www.areyouyou.eu/) - Try to Fool Face Recognition Software
* [Word Blanks](https://www.wordblanks.com/) or [Plot Generator](https://www.plot-generator.org.uk/) - Online Mad Libs
* [MagicKeyboard](http://magickeyboard.io/) - Try "feross", "hexbin", "rain", or "semi"
* [Just Type Stuff](https://justtypestuff.com/) - Type Things into Existence
* [⁠HammyHome](https://hammyhome.com/) - Interactive Virtual Pet Hamsters
* [Nicky Case](https://ncase.me/) - Interactive Social Simulations / Puzzles
* [Cafe and Diner](https://www.cafeanddiner.com/) - Browser Mystery Game
* [Pokémon Fossil Museum](https://my.matterport.com/show/?m=P9WCbyCBGBM) - Explore Pokémon Fossil Museum
* [New Campaign Trail](https://www.newcampaigntrail.com/) - Presidential Campaign Game
* [2020 Game](https://2020game.io/) - Play Through 2020
* [Terminal 00](https://angusnicneven.com/), [corru.observer](https://corru.observer/), [lomando](https://lomando.com/main.html) or [angelangelangel](https://angelangelangelangelangel.com/) - Cursed Sites / Horror Games
* [Windows93](https://www.windows93.net/) - Windows 93 Emulator
* [larsberg](https://www.larsberg.net/#/), [substack](https://substack.net/) or [mrdoob](https://mrdoob.neocities.org/) - Trippy 3D Experiments
* [Hypertranslate](https://www.ravbug.com/hypertranslate/) - Google Translate Telephone Game
* [Google Doodles](https://doodles.google/), [2](https://sites.google.com/site/populardoodlegames) - Interactive Google Doodles
* [elgooG](https://elgoog.im/) - Google Easter Eggs
* [Quick, Draw](https://quickdraw.withgoogle.com/) - Doodle Game
* [Doodle Dash](https://xenova-doodle-dash.static.hf.space/index.html) - Let AI Guess Doodles
* [Genetic Walkers](https://rednuht.org/genetic_walkers/) - Genetic Algorithm Walkers
* [A Better World](https://abw.blue/index_en.php) - Interactive History Changing Game
* [OpenGeofiction](https://opengeofiction.net/) - User-Made Fictional Map
* [⁠The Cursed Library](https://cursed.epic.net/) - Interactive 3D Short Stories
* [MyGrandmothersLingo](https://www.sbs.com.au/mygrandmotherslingo/) - Interactive Story
* [⁠The HTML Review](https://thehtml.review/archive) - Interactive Stories / Poetry Written in Code
* [⁠Ted the Caver](https://teds-caving-page.netlify.app/) - Interactive Horror Story / Webs First Creepypasta (2001)
* [⁠Git City](https://www.thegitcity.com/) - 3D GitHub City / [GitHub](https://github.com/srizzon/git-city)
* [tiny.london](https://tiny.london/), [Isometric NYC](https://isometric.nyc/) or [Isometric Istanbul](https://isometricistanbul.com/) - Isometric Pixel-Art Maps
* [⁠Web Rewind](https://web-rewind.com/) - Interactive Web History Journey
* [What Football Will Look Like](https://www.sbnation.com/a/17776-football/chapter-1) - Interactive Future Football Story
* [DrivingSimulator](https://framesynthesis.com/drivingsimulator/maps/) - 3D Driving Simulator
* [Traffic Simulation](https://traffic-simulation.de/) - Traffic Flow Simulation
* [⁠Stowaway](https://stowaway.live/) - Live 3D Flight Window Seat Simulator
* [OpenScope](https://www.openscope.io/) or [⁠Vectors](https://vectorsatc.com/) - Air Traffic Control Simulators
* [cnnix-steership](https://edition.cnn.com/interactive/2021/03/cnnix-steership/) - Steer through the Suez Canal
* [Jellify](https://sc420.github.io/jellify-ur-website/) - Turn Websites to Jelly / [GitHub](https://github.com/sc420/jellify-ur-website)
* [Ballooning](https://alexanderperrin.com.au/triangles/ballooning/) - Procedurally Generated Balloon Simulator
* [Tamajoji](https://aericode.itch.io/tamajoji) - Browser Tamagotchi
* [Our World of Text](https://ourworldoftext.com/), [TextWall](https://tw.2s4.me/) or [OurWorldOfText](https://www.yourworldoftext.com/) - Infinite Community Text Grid
* [This Is Sand](https://thisissand.com/) - Make Sand Art
* [Orb.Farm](https://orb.farm/) - Virtual Aquatic Ecosystem
* [3DTuning](https://www.3dtuning.com/) - Build 3D Cars
* [Generativeplanets](https://zehfernandes.com/generativeplanets/builder) or [Planet](https://oskarstalberg.com/game/planet/planet.html) - Planet Generators
* [Townscaper](https://oskarstalberg.com/Townscaper/) - Town Building Sandbox
* [Gravity Points](https://codepen.io/akm2/full/rHIsa), [Hermann](https://www.hermann.is/gravity/) or [dmilin1](https://dmilin1.github.io/PrincipiaJS/build/index.html) - Gravity Simulators
* [Google Gravity](https://mrdoob.com/projects/chromeexperiments/google-gravity/) - Falling Google
* [Origami Simulator](https://origamisimulator.org/) - Origami Simulation
* [Super Snowflake Maker](https://supersnowflakemaker.com/) or [Fold & Cut](https://www.onemotion.com/fold-cut-paper/) - Make Digital Paper Snowflakes
* [Iceberger](https://joshdata.me/iceberger.html) - Draw an Iceberg, See how it Floats
* [Pointer Pointer](https://pointerpointer.com/) or [PointerPointerClone](https://pointerpointerclone.shiprzq.workers.dev/) - Have Your Pointer Pointed At
* [BubblesPop](https://bubblespop.netlify.app/), [2](https://brainteaser.top/bubblespop.html) - Pop Bubble Wrap
* [Checkbox Life](https://huth.me/checkbox-life/) or [Checkbox Olympics](https://checkbox.toys/) - Checkbox Games
* [⁠infiniDomino](https://infinidomino.io/) - Endless Dominoes 
* [Keep calm and poke me.](https://calm.ovh/) - Poke & Pull
* [Elastic Man](https://www.adultswim.com/etcetera/elastic-man/) - Elastic Morty
* [Screentoys](https://www.screentoys.com/) - Photo Morphing Toy
* [Smash The Walls](https://smashthewalls.com/) - Smash Walls
* [Koalas to the Max](https://www.koalastothemax.com/) - Make Smaller & Smaller Dots
* [Popcat](https://popcat.click/) - Worldwide Popcat Clicking Competition
* [Spherical Trochoids](https://claytonmain.github.io/spherical-trochoids/) - Experiment with Spherical Trochoids
* [⁠DrawAFish](https://drawafish.com/) - Global Fish Drawing Tank
* [gradient.horse](https://gradient.horse/) - Global Horse Drawing
* [DrawAurora](https://www.drawaurora.com/) - Draw Auroras
* [Neonflames](https://29a.ch/sandbox/2011/neonflames/) - Draw Nebulas
* [Leapy Grid](https://codepen.io/Godje/full/mOzpEY/) - Play with Rainbow Grid
* [⁠Beat Battle](https://beat-battle.net/) - Browser Beat Battle Game
* [Pianos.pub](https://pianos.pub/) - Find Public Pianos
* [danielx](https://danielx.net/composer/) or [AMS](https://flyx.org/ams/) - Mario Paint Composer Ports / [Archive](https://archive.org/details/mariopaintcomposer_201609)
* [⁠Gesture Synth](https://gesturesynth.com/) - Interactive Gesture-Based Audio Synth
* [Typatone](https://www.typatone.com/) - Play Music by Typing
* [Blossom](https://blossom.alexbainter.com/) - Create Sounds via Clicks
* [Drawing Garden](https://drawing.garden/) - Create Sounds via Mouse Movement
* [Fractal Sound Explorer](https://codeparade.itch.io/fractal-sound-explorer) - Create Sounds via Fractals
* [Corruption Loops](https://corruptionloops.alexbainter.com/) - Generative Unique Ambient Music
* [Abundant Music](https://pernyblom.github.io/abundant-music/) - Procedural Music Editor
* [typedrummer](http://typedrummer.com/) - Drum by Typing
* [Soundscape](https://soundscape.world/) - Builder / Visualizer
* [MikuTap](https://aidn.jp/mikutap/) - Click to Make Sounds / Graphics
* [Patatap](https://www.patatap.com/) - Type to Create Melodies / Moving Shapes
* [Touch Pianist](http://touchpianist.com/) - Magical Piano App
* [A.I. DUET](https://experiments.withgoogle.com/ai/ai-duet/view/) - AI Piano Duet
* [Pianoverse](https://pianoverse.net/) or [MultiplayerPiano](https://multiplayerpiano.com/) - Multiplayer Piano
* [DJ Phonetic](https://djphonetic.brianfoo.com/) - Historical Speech Beatboxing
* [Viola the Bird](https://artsandculture.google.com/experiment/viola-the-bird/nAEJVwNkp-FnrQ?cp) - Browser Cello
* [bongo.cat](https://bongo.cat/) - Become Bongo Cat
* [ambient.garden](https://ambient.garden/) - 3D Audio Landscape
* [audio visual generator](https://fredericbriolet.com/avg/) - Visual Audio Generator
* [Short Trip](https://alexanderperrin.com.au/paper/shorttrip/) - Relaxing Cat Game
* [Draw a Stickman](https://drawastickman.com/) - Stickman Adventure / [Discord](https://discord.com/invite/DFvejdC)
* [Wonder of Wonder Art](https://aidn.jp/wowa/) - Create a Dancing Character
* [Emotiguy](https://testing.duckwithsunglasses.com/emotiweb/) - Edit Emotiguy
* [Cursor Car](https://papercookies.itch.io/cursor-car) - Play with Car Cursor

***

## ▷ Interesting

* ↪️ **[Learning Sites & Virtual Tours](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25BA_learning_sites)**
* ⭐ **[The Pudding](https://pudding.cool/)** - Explains Ideas w/ Visual Essays
* ⭐ **[Ranker](https://www.ranker.com/)**, [Rank Engine](https://www.pubmeeple.com/ranking-engine), [Topsters](https://topsters.org/), [Listography](https://listography.com/), [TheTopsTens](https://www.thetoptens.com/) or [ListVerse](https://listverse.com/) - Create / Explore Ranked Lists
* ⭐ **[TierMaker](https://tiermaker.com/)**, [GOATY](https://goaty.gg/) or [OpenTierBoy](https://www.opentierboy.com/) / [GitHub](https://github.com/infinia-yzl/opentierboy) - Create / Explore Tier Lists
* [Wiki List of Lists of Lists](https://en.wikipedia.org/wiki/List_of_lists_of_lists) - Index of Wiki Lists
* [Iceberg Charts](https://www.reddit.com/r/IcebergCharts/) or [⁠Iceberg Threads](https://icebergthreads.com/) - Explore Obscure Topics
* [DamnInteresting](https://www.damninteresting.com/) - Interesting Stories
* [⁠MythBusters Results](https://mythresults.com/) - Tested MythBusters Myth Repository
* [Unusual Articles](https://wikipedia.org/wiki/Wikipedia:Unusual_articles) - Unusual Wiki Articles
* [HeyFromTheFuture](https://heyfromthefuture.com/) - What People Wish They Knew at Your Age
* [spurious correlations](https://tylervigen.com/spurious-correlations) - Random Correlations
* [FirstVersions](https://www.firstversions.com/) - Find First Versions of Anything
* [ConWorld](https://wiki.conworld.org/) - Constructed Worlds Wiki
* [Think Labyrinth](https://www.astrolog.org/labyrnth.htm) - Encyclopedia of Maze Algorithms and Resources
* [Aesthetics Wiki](https://aesthetics.fandom.com/wiki/Aesthetics_Wiki) / [Subreddit](https://www.reddit.com/r/aesthetic/) or [List of Aesthetics](https://aesthetics.fandom.com/wiki/List_of_Aesthetics) - Aesthetics Wikis / Lists
* [⁠Internet Checkpoint](https://internetcheckpoint.page/) - Archive of taia777 "Internet OST Checkpoints" / Life Stories / [Discord](https://discord.gg/Qwt7m8CFVn) / [GitHub](https://github.com/geauser/internetcheckpoint)
* [⁠moltbook](https://www.moltbook.com/) - A Social Network for AI Agents
* [Chirper](https://chirper.ai/) - AI Generated X.com
* [InfiniteConversation](https://infiniteconversation.com/) - Never-Ending AI Conversations
* [The Dictionary of Obscure Sorrows](https://www.thedictionaryofobscuresorrows.com/) - Made Up Words for Sorrows
* [⁠Museum of Failure](https://museumoffailure.com/) - Failed Products / Services History
* [⁠Detective Board](https://www.detectiveboard.io/) - Make / Explore Community Detective Boards
* [Game a-b-street](https://a-b-street.github.io/docs/) - Traffic Simulation
* [John Conway’s Game of Life](https://playgameoflife.com/) - Cellular Automaton Game / [Patterns](https://conwaylife.appspot.com/library/) / [Video](https://youtu.be/CgOcEZinQ2I), [2](https://youtu.be/R9Plq-D1gEk)
* [Judge My Music](https://pudding.cool/2021/10/judge-my-music/) - Have an AI Judge Your Taste in Music
* [Michaelbach](https://michaelbach.de/ot/) or [Optical Toys](https://optical.toys/) - Optical Illusions
* [Strobe Illusion](https://strobe.cool/) - Hallucination Illusion
* [PoliticalTests](https://politicaltests.github.io/) - Political Alignment Tests
* [Emoji to Scale](https://javier.xyz/emoji-to-scale/) - Emoji Size Scale
* [⁠Read QR By Hand](https://noel-friedrich.github.io/read-qr-by-hand) - Learn How-To Read QR by Hand
* [The GIF Pronunciation Page](https://www.olsenhome.com/gif/) - How to Pronounce "GIF"
* [Where's George?](https://www.wheresgeorge.com/) or [TrackDollar](https://trackdollar.com/) - Dollar Tracking
* [WordCount](https://www.vidarholen.net/contents/wordcount/) - Most Common Linux Kernel Source Code Words

***

## ▷ Media / Lore

* ⭐ **[The Lost Media Wiki](https://lostmediawiki.com/)** / [Forum](https://forums.lostmediawiki.com/) / [Subreddit](https://www.reddit.com/r/lostmedia/) / [Discord](https://discord.gg/NFsM8YbBYH)
* [⁠Fanlore](https://fanlore.org/) - Fan Community Wiki
* [The Cutting Room Floor](https://tcrf.net/The_Cutting_Room_Floor) - Unused Video Game Content Research
* [⁠Confic Wiki](https://www.containmentfiction.net/) - Containment Fiction Wiki
* [⁠Tolkien Gateway](https://tolkiengateway.net/) - J.R.R. Tolkien Content Encyclopedia / Wiki
* [Middle-Earth Map](https://middle-earth-interactive-map.web.app/) - Tolkien's Middle-Earth Map
* [QuarterMaester](https://quartermaester.info/) - Game of Thrones Map
* [⁠GomiTier](https://www.gomitier.tech/) - Create Custom Anime Tier Lists w/ AniList or Mal Account
* [Pushing Pixels](https://www.pushing-pixels.org/fui/) - Imaginary UI from Movies
* [⁠Celery Man](https://celeryman.fun/) - Tim & Eric Celery Man Desktop / Dance Sim / [GitHub](https://github.com/turtlesoupy/celeryman-os)
* [⁠The Courage Computer](https://the-courage-computer.vercel.app/) - Courage Style Computer
* [⁠Movie Mistakes](https://www.moviemistakes.com/) - Movie Mistakes Database w/ Community Voting
* [Nestflix](https://nestflix.fun/) - Fictional Media in Media Database
* [BogLeech](https://bogleech.com/) - Monster Design Reviews
* [Projectrho](https://www.projectrho.com/public_html/rocket/) - Fantasy Rocket Encyclopedia
* [BreezeWiki](https://breezewiki.com/) / [Mirrors](https://docs.breezewiki.com/Links.html#(part._.Mirrors)) or [Phantom](https://codeberg.org/phantom-org/phantom) - Fandom Frontends

***

## ▷ Mysteries / Paranormal

* ↪️ **[Mythology / Folklore](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7_mythology_.2F_folklore)**
* ⭐ **[MorbidKuriosity](https://morbidkuriosity.com/)** - Dark History, Conspiracies, Crime, Myths, etc.
* [Websleuths](https://www.websleuths.com/) - Crime Solving Forum
* [House Creep](https://www.housecreep.com/) - Homes with A Curious or Criminal History
* [EnigmaLabs](https://enigmalabs.io/), [⁠UFO Evidence](http://www.ufoevidence.org/) or [UFO Casebook](https://www.ufocasebook.com/) - UFO + UAP Sighting Lists / Tracking
* [⁠Fern Flower Project](https://www.fern-flower.org/) - Database of Anomalous / Paranormal Phenomenon
* [TheShadowlands](https://theshadowlands.net/) - Oldschool Paranormal Research Site
* [Demons of the Deep](https://seademons.weebly.com/) - Demon Encyclopedia
* [BFRO](https://bfro.net/) - Bigfoot Research Site
* [FutureTimeline](https://www.futuretimeline.net/) - Timeline of Future Predictions

***

## ▷ Live Cameras

* ⭐ **[WebcamTaxi](https://www.webcamtaxi.com/en/)**
* ⭐ **[Explore](https://explore.org/)**, [Mangolinkcam](https://www.mangolinkcam.com/), [Africam](https://africam.com/our-locations/) or [AnimalsLife](https://animalslife.net/category/shelters/) - Animal Cams
* ⭐ **[San Diego Zoo](https://zoo.sandiegozoo.org/live-cameras)** or [NationalZoo](https://nationalzoo.si.edu/webcams) - Zoo Webcams
* [WorldCams](https://worldcams.tv/)
* [OpenCCTV](https://opencctv.org/)
* [EarthCam](https://www.earthcam.com/)
* [WebcamExplore](https://www.webcamexplore.com/)
* [BalticLiveCam](https://balticlivecam.com/)
* [EarthCamTv](https://www.earthcamtv.com/)
* [Camscape](https://www.camscape.com/)
* [Worldviewstream](https://worldviewstream.com/)
* [CamStreamer](https://camstreamer.com/live)
* [SkylineWebcams](https://www.skylinewebcams.com/en.html)
* [Webcam Hopper](https://www.webcamhopper.com/)
* [WorldCam](https://worldcam.eu/)
* [⁠Tomarigi](https://tomarigi.me/world)
* [Mangolink World](https://www.mangolinkworld.com/)
* [Insecam](http://www.insecam.org/en/) - Public Surveillance Webcams
* [CameraFTP](https://www.cameraftp.com/cameraftp/publish/publishedcameras.aspx)
* [WebcamGalore](https://www.webcamgalore.com/)
* [Windy Webcams](https://www.windy.com/-Webcams/webcams)
* [LiveCam Croatia](https://www.livecamcroatia.com/en)
* [⁠TrafficVision](https://trafficvision.live/) - Live Traffic Cams
* [Project ⁠Alveus Sanctuary](https://www.alveussanctuary.org/) - 24/7 Educational Wildlife Live Streams / Conservation Project
* [Monterey Bay Aquarium](https://www.montereybayaquarium.org/cams-videos/live-cams) or [AquariumOfPacific](https://www.aquariumofpacific.org/exhibits/webcams) - Aquarium Webcams
* [⁠CCTV-World](https://www.cctv-world.kr/) - South Korea Live Cams
* [meow.camera](https://meow.camera/) - Chinese Cat Cams / [Android](https://play.google.com/store/apps/details?id=com.hello.purr) / [iOS](https://apps.apple.com/app/id6475722361) / [Discord](https://discord.com/invite/QmHWpZF9cP)
* [The Fish Doorbell](https://visdeurbel.nl/en/) - Help Fish Migrate
* [r/controllablewebcams](https://reddit.com/r/controllablewebcams) / [Discord](https://discord.gg/wdjtevG)
* [snoweye](https://www.snoweye.com/) - Ski Resorts
* [Airport Webcams](https://airportwebcams.net/) / [X](https://x.com/AirportWebcams)
* [FogCam](https://www.fogcam.org/) - The World's Oldest Webcam

***

## ▷ Random

* ↪️ **[Random Sites / Discovery](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_random_sites_.2F_discovery)**
* ⭐ **[TheOnion](https://theonion.com/)** - Satirical News Articles
* ⭐ **[Copypasta Text](https://copypastatext.com/)** - Copypasta Databases
* ⭐ **[CreepyPasta](https://www.creepypasta.com/)** - Creepypasta Database
* ⭐ **[⁠Trollpasta Wiki](https://trollpasta.com/wiki/Trollpasta_Wiki)** - Trollpasta Database / Wiki
* ⭐ **[Neal.fun](https://neal.fun/)** - Toys / Games
* ⭐ **[Uncyclopedia](https://en.uncyclopedia.co/)** - Wikipedia Parody
* ⭐ **[WhatBeatsRock](https://www.whatbeatsrock.com/)** - Guess What Beats What
* ⭐ **[Library of Babel](https://libraryofbabel.info/)** - Every Book of Past, Present, and Future
* [OpenChaos.dev](https://www.openchaos.dev/) - Evolving Open-Source Project Governed by Community Votes
* [Grant Kot](https://grantkot.com/) - Toys / Games
* [R74n](https://r74n.com/) - Toys / Games
* [Oimo](https://oimo.io/works) - Toys / Games
* [AIDN](https://aidn.jp/) - Toys / Games
* [Neave](https://codepen.io/neave) / [2](https://neave.com/) - Toys / Games
* [BoredHumans](https://boredhumans.com/) - Toys / Games
* [puissant](https://sandwichpuissant.net/) - Toys / Games
* [Mr.doob](https://mrdoob.com/) - Toys / Games
* [Bimble Space](https://in.bimble.space/toys) - Toys / Games
* [Creative Tech Guy](https://creativetechguy.com/) - Toys / Games
* [Just For Fun](https://justforfun.io/) - Toys / Games
* [Andrew Marsh](https://andrewmarsh.com/software) - Toys / Games
* [JenniferDewalt](https://jenniferdewalt.com/) - Toys / Games
* [Experiments with Google](https://experiments.withgoogle.com/collections) - Toys / Games
* [yezi](https://yezi.itch.io/) - Toys / Games
* [topster](https://topster.net/) - Toys / Games
* [p5aholic](https://experiments.p5aholic.me/) - Toys / Games
* [vole.wtf](https://vole.wtf/) - Toys / Games
* [WilliamHoza](https://williamhoza.com/misc/) - Toys / Games
* [Rinkworks](http://www.rinkworks.com/) - Toys / Games
* [Orteil](https://orteil.dashnet.org/) - Toys / Games
* [funwebsite](https://funwebsite.fun/) - Toys / Games
* [Toms.Toys](https://toms.toys/) - Toys / Games
* [Pointless Sites](https://www.pointlesssites.com/) - Toys / Games
* [The Scientific Place](https://scientific.place/) - Toys / Games
* [artistaiden](https://artistaiden.com/) - Toys / Games
* [ToyBox](https://toybox.toms.toys/) - Toys / Games
* [eieio.games](https://eieio.games/) - Experimental Games / Showcases
* [⁠IARadio](https://iaradio.eu/) - AI Generated Radio Stations
* [The Red Button](https://clicktheredbutton.com/) - Random Video / Song Generator
* [Things to Do](https://randomthingstodo.com/) or [TheZen](https://thezen.zone/) - Activity Suggestions
* [Scattergories](https://swellgarfo.com/scattergories) - Scattergories List Generator
* [⁠Jerma Sites](https://jerma.io/) or [Jerma](https://www.jerma.org/) - Jerma Resources / Content Sites
* [⁠Color Names](https://names.color.pizza/) - Interactive Human-Named Color Browser
* [colornames](https://colornames.org/) - Help Name Colors
* [Colorword](https://colorword.recu3125.com/) - Word Color Voting
* [Color Arena](https://color-arena.agpallav.com/) - Best Color Voting
* [Gizoogle](https://www.gizoogle.net/) - Google Shiznit
* [Presence](https://presence.mrarich.com/) - Unwrap Presents Remotely
* [Lots of Links](https://annierau.com/LOL-lots-of-links) - Random Funny Links
* [WindowSwap](https://www.window-swap.com/) or [VisualVacation](https://virtualvacation.us/window) - Open Random Windows
* [MoodLight](https://www.moodlight.org/) or [Defonic MoodLight](https://defonic.com/moodlight.html) - Turn Screen into Strobe / Mood Light
* [HYDRA](https://hydra.ojack.xyz/) - Live Coding Networked Visuals / [Discord](https://discord.gg/ZQjfHkNHXC)
* [The Editing Room](https://www.the-editing-room.com/) - Funny Abridged Movie Scripts
* [⁠Roastdit](https://roastdit.kadoa.com/) - Reddit Profile Roasting AI
* [ShindanMaker](https://en.shindanmaker.com/) - Diagnoses / Fortune AI
* [LMGTFY](https://lmgtfy2.com/), [LMDDGTFY](https://lmddgtfy.net/) or [LMSPTFY](https://lmsptfy.com/) - Remind People that Search Engines Exist
* [AfterTheTone](https://afterthetone.com/) - Random Answering Machine Messages
* [Pink Trombone](https://dood.al/pinktrombone/) - Human Pitch Generator
* [Purrli](https://purrli.com/) - Cat Purr Generator
* [WebCassette](https://webcassette.klevgrand.se/) - Add Cassette Effects to Songs
* [The Nicest Place](https://thenicestplace.net/) - Internet Hugs
* [InspiroBot](https://inspirobot.me/) - Inspirational Quote Generator
* [HORG](https://horg.com/) - Holotypic Occlupanid Research Group
* [Waifu Labs](https://waifulabs.com/) - Meet Your Waifu
* [Skynet](https://pierrepapierciseaux.net/.skynet/?lang=en) - View Websites like they're from the 90s
* [CameronsWorld](https://www.cameronsworld.net/) - 90s Themed Website
* [Classic GTA Sites](https://classicgtasites.com/) - Original GTA Site
* [The Death Generator](https://deathgenerator.com/) - Video Game Text Generator
* [IASIP App](https://iasip.app/) - It's Always Sunny Title Generator
* [JUST SCREAM!](https://justscream.baby/listen/) - Screams into the Universe / Archive
* [UpJoke](https://upjoke.com/) - Jokes for Any Topic
* [CSS Puns](https://saijogeorge.com/css-puns/) - CSS Puns
* [Peter Answers](https://www.peteranswers.com/) - Create Fake Questions & Answers
* [The Santa Tracker](https://www.thesantatracker.com/) - Track Santa during Christmas
* [April Fools Day On The Web](https://aprilfoolsdayontheweb.com/) - Find April Fools' Pranks Played by Websites
* [GeekPrank](https://geekprank.com/) or [Pranx](https://pranx.com/) - Windows Pranks
* [Update Faker](https://updatefaker.com/) or [Fake Update](https://fakeupdate.net/) - Fake System Update Pranks
* [DownloadHardware](https://downloadhardware.com/) - Download Computer Hardware
* [The Restart Page](http://www.therestartpage.com/) - Vintage Operating System Reboots
* [Windows XP Error Worm](https://ybenbihi.github.io/windows-error-worm/) - Click & Drag Windows Errors
* [HackTyper](https://hackertyper.net/), [HackerTyper](https://hackertyper.com/), [Hoacks](https://hoacks.com/) or [Geektyper](https://geektyper.com/) - Fake Hacking Screens