***
***
**[◄◄ Back to Wiki Index](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/tools-index)**
***
***

# ► Video Tools

* 🌐 **[Digital Video Intro](https://github.com/leandromoreira/digital_video_introduction)** - Digital Video Guides / Resources
* ↪️ **[TV / Monitor Comparisons](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_tv_.2F_monitors)**
* ↪️ **[YouTube Tools / Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/social-media#wiki_.25BA_youtube_tools)**
* ↪️ **[AI Video Generators](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/ai#wiki_.25BA_video_generation)**
* ⭐ **[Reincubate Camo](https://camo.com/studio)** - Use Any Camera as Webcam
* [⁠Broadcast Box](https://b.siobud.com/) / [GitHub](https://github.com/Glimesh/broadcast-box), [Screen Share Party](https://ba.net/screen/), [Screego](https://app.screego.net/) / [GitHub](https://github.com/screego/server/) or [Screen-Sharing](https://share-your-screen.vercel.app/) / [GitHub](https://github.com/tonghohin/screen-sharing) - Web-Based Screen Sharing
* [⁠uxplay-windows](https://github.com/leapbtw/uxplay-windows) - AirPlay Receiver / Windows
* [Deep-Live-Cam](https://github.com/hacksider/Deep-Live-Cam) - Video Face Swap / Windows, macOS, Linux
* [Rope](https://github.com/Hillobar/Rope) - Video Face Swap Tools / Windows / [Discord](https://discord.com/invite/EcdVAFJzqp)
* [VideoHelp Forum](https://forum.videohelp.com/) - All Things Media Discussion / Web
* [ICAT](https://www.nvidia.com/en-us/geforce/technologies/icat/) or [Video Compare](https://github.com/pixop/video-compare) - Video Quality Comparison & Analysis Tools / Windows
* [videoduplicatefinder](https://github.com/0x90d/videoduplicatefinder) - Duplicate Video Finder / Windows, macOS, Linux, Docker
* [MkvDefaultTrackChanger](https://mkvdefaulttrackchanger.pages.dev/) - Change Default MKV Subtitle / Audio Tracks / Windows, macOS, Linux / [GitHub](https://github.com/MikeMoolenaar/MkvDefaultTrackChanger)
* [untrunc](https://github.com/anthwlock/untrunc) or [⁠MP4Recover](https://github.com/ActiveTK/MP4Recover) - Recover Broken MP4 Files / Docker

***

## ▷ Physical Media Tools

* ↪️ **[Physical Media Shopping](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_physical_media_.2F_streaming)**
* [ImgBurn](https://www.majorgeeks.com/files/details/imgburn.html) - CD / DVD Burning / Windows
* [DVDStyler](https://sourceforge.net/projects/dvdstyler/) - CD / DVD Burning / Windows, macOS, Linux
* [VidCoder](https://vidcoder.net/) or [XReveal](https://www.xreveal.com/) / [Pro](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/download#wiki_.25BA_software_sites) - DVD / Blu-ray Ripping / Windows
* [MakeMKV](https://forum.makemkv.com/forum/viewtopic.php?f=5&t=1053), [2](https://cable.ayra.ch/makemkv/) - Create MKV from Blu-ray / DVD / Windows, macOS
* [DGDemux](https://www.rationalqm.us/dgdemux/dgdemux.html) - Blu-ray/UHD Disk Demuxer / Windows, Linux
* [PgcDemux](https://www.videohelp.com/software/PgcDemux) - DVD Disk Demuxer / Windows
* [BatchGuy](https://github.com/yaboy58/BatchGuy) - Blu-ray Ripping / Windows
* [UHD Drives Flashing Guide](https://forum.makemkv.com/forum/viewtopic.php?f=16&t=19634) / Web
* [Redump](https://redump.info/) - Disc Preservation Info Project / Web
* [VHS Decode](https://github.com/oyvindln/vhs-decode) - VHS Decoder / Windows, macOS, Linux

***

## ▷ Video File Hosts

* **Note** - Most file hosts remove files after inactivity, while some delete them regardless. Check each host if you're concerned about file expiry. Tags are: Account Space / Individual File Limit / File Retention.

***

* ↪️ **[Streaming Hosts](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25B7_video_streaming)** - Host Videos on YouTube Style Sites
* ⭐ **[DoodStream](https://doodstream.com/)** - 5GB / 60 Days / Requires Sign-Up / Use Adblock
* ⭐ **[Litterbox](https://litterbox.catbox.moe/)** - 1GB / 3 Days
* ⭐ **[Catbox](https://catbox.moe/)** - 200MB / Forever (w/ Account) / Allows Hotlinking
* ⭐ **[Gofile](https://gofile.io/)** - 1TB Monthly / 10 Days
* ⭐ **[Send.now](https://send.now/)** - Unlimited / 15 Days After Last View (w/ Account)
* [VOE](https://voe.sx/) - Unlimited / 60 Days / 720p / Requires Sign-Up
* [MixDrop](https://mixdrop.ag/) - Unlimited / 60 Days / 720p / Requires Sign-Up
* [FEX.NET](https://fex.net/) - 100GB / 10GB Guest / 7 Days / [Telegram](https://t.me/FEXNETWORK)
* [Byse](https://byse.sx/), [2](https://filemoon.sx/), [3](https://filemoon.to/) - 50GB / 40TB per account / Forever / Requires Sign-Up
* [Hexupload](https://hexload.com/) - 15GB / 30 Days
* [Vidoza](https://vidoza.net/) - 15GB / 15 Days / Requires Sign-Up
* [⁠Streamain](https://streamain.com/) - Unlimited / Forever
* [⁠CryptFiles](https://cryptfiles.cloud/) - Unlimited / Forever
* [Vidmoly](https://vidmoly.me/) - 15TB / 1 Year
* [⁠AnonMP4](https://anonmp4.to/) - 20GB / Forever
* [NetU](https://netu.tv/) - 7.5GB / 90 Days (after last view)
* [Streamplay](https://streamplay.to/) - 30TB / 20GB
* [UQLOAD](https://uqload.vc/) - 5GB / Forever
* [Luluvdoo](https://luluvdoo.com/), [2](https://lulustream.com/) - 15GB / 60 Days Since Last Download
* [Streamtape](https://streamtape.com/), [2](https://streamtape.to/) - 15GB / Requires Sign-Up
* [Dubz](https://dubz.co/) - 100MB / Forever
* [Streamable](https://streamable.com/) - 250MB / 2 Days (90 Days with Account)
* [uguu](https://uguu.se/) - 128MB / 3 Hours
* [webmshare](https://webmshare.com/) - WebM & GIF Hosting / 20MB / Forever
* [Videy](https://videy.co/) - 100MB / MP4 Only
* [⁠SpectrShare](https://spectrshare.com/) - P2P Video Streaming / Temp Files

***

## ▷ Screen Recording

* ⭐ **[OBS Studio](https://obsproject.com/)** / Windows, macOS, Linux / [Discord](https://discord.com/invite/obsproject) / [GitHub](https://github.com/obsproject/obs-studio)
* [Segra](https://segra.tv/) / [GitHub](https://github.com/Segergren/Segra), [SteelSeries Moments](https://steelseries.com/gg/moments), [⁠Ascent](https://www.tryascent.gg/), [Vice](https://github.com/eklonofficial/Vice) or [RePlays](https://github.com/lulzsun/RePlays) - Game Recording Tools
* [Shinobi](https://shinobi.video/) - Network Video Recorder / macOS, Linux / [Discord](https://discord.com/invite/mdhmvuH) / [GitLab](https://gitlab.com/Shinobi-Systems/Shinobi)
* [MythTV](https://www.mythtv.org/) - Digital Video Recorder (DVR) / Windows, macOS, Linux / [GitHub](https://github.com/MythTV/mythtv)
* [FFmpeg](https://ffmpeg.org/) / Windows, macOS, Linux / [GitHub](https://github.com/FFmpeg/FFmpeg) / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video-tools#wiki_.25B7_ffmpeg_tools)
* [Recordly](https://recordly.dev/) / Windows, macOS, Linux / [GitHub](https://github.com/webadderallorg/Recordly)
* [ShareX](https://getsharex.com/) / Windows / [Discord](https://discord.com/invite/ShareX) / [GitHub](https://github.com/ShareX/ShareX)
* [vokoscreenNG](https://linuxecke.volkoh.de/vokoscreen/vokoscreen.html) / Windows, Linux / [GitHub](https://github.com/vkohaupt/vokoscreenNG)
* [Cap](https://cap.so/) / Windows, macOS, Linux, Web / [X](https://x.com/cap) / [Discord](https://discord.gg/y8gdQ3WRN3) / [GitHub](https://github.com/CapSoftware/Cap)
* [Shar.ec](https://shar.ec/) / Web
* [ScreenREC](https://screen-rec.vercel.app/) / Web / [GitHub](https://github.com/heysagnik/screenREC)
* [RecordScreen](https://recordscreen.io/) / Web
* [Google Screen Recorder](https://toolbox.googleapps.com/apps/screen_recorder/) / Web
* [⁠Cursorful](https://cursorful.com/) / Web

***

## ▷ Processing / Encoding

* ⭐ **[⁠Codecs Wiki](https://codecs.wiki/)** / [Discord](https://discord.com/invite/bbQD5MjDr3), [⁠Video Noob Guide](https://gist.github.com/arch1t3cht/b5b9552633567fa7658deee5aec60453/), [archived-things](https://sometimes-archives-things.github.io/archived-things/), [JET Guide](https://jaded-encoding-thaumaturgy.github.io/JET-guide/master/), [The Encoding Guide](https://encoding-guide.neocities.org/) or [Silentaperture](https://silentaperture.gitlab.io/mdbook-guide/) - Video Encoding Guides
* ⭐ **[HandBrake](https://handbrake.fr/)** or [VidCoder](https://vidcoder.net/) - Video Encoding Software / Windows, macOS, Linux / [Guide](https://www.rapidseedbox.com/blog/guide-to-mastering-handbrake) / [GitHub](https://github.com/HandBrake/HandBrake)
* ⭐ **[FFmpeg](https://ffmpeg.org/)** - Multimedia Processors / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video-tools#wiki_.25B7_ffmpeg_tools) / Windows, macOS, Linux / [GitHub](https://github.com/FFmpeg/FFmpeg)
* ⭐ **[Shutter Encoder](https://www.shutterencoder.com/)** - Video Encoding Software / Windows, macOS, Linux / [GitHub](https://github.com/paulpacifico/shutter-encoder)
* ⭐ **[MKVToolNix](https://mkvtoolnix.download/)** - MKV Editing Tools / Windows, macOS, Linux / [Source Code](https://codeberg.org/mbunkus/mkvtoolnix)
* ⭐ **[Basics to the Art of Remuxing](https://clarasguide.valeena.workers.dev/Guides/remuxing/)** - Learn How to Remux Videos
* [DDVT](https://forum.doom9.org/showthread.php?t=183479) - Dolby Vision RPU Demuxing / Injecting / Editing
* [IFME](https://github.com/Anime4000/IFME) - Video Encoding / Windows, Linux
* [Av1an](https://github.com/rust-av/Av1an) - Video Encoding / Windows, macOS, Linux
* [FastFlix](https://fastflix.org/) - Video Conversion / Windows, macOS, Linux / [GitHub](https://github.com/cdgriffith/FastFlix)
* [Winnydows](https://winnydows.com/) - Video Conversion Software / Windows, macOS, Linux / [Telegram](https://t.me/xvid4psp81)
* [staxrip](https://github.com/staxrip/staxrip/) - Video Encoding / Contact Sheet + Thumbnails Creator / Windows
* [XMedia Recode](https://www.xmedia-recode.de/en/) - Video Conversion / Windows
* [NEAV1E](https://github.com/Alkl58/NotEnoughAV1Encodes) - AV1 Encoding / Windows
* [sickbeard_mp4_automator](https://github.com/mdhiggins/sickbeard_mp4_automator) - Automate Video Processing / Windows, macOS, Linux
* [selur](https://www.selur.de/) - Video Encoding / Windows, Linux
* [vvenc](https://github.com/fraunhoferhhi/vvenc), [vvdec](https://github.com/fraunhoferhhi/vvdec) or [VVCEasy](https://github.com/MartinEesmaa/VVCEasy) - VVC Encode / Decode

***

## ▷ Online Processing

* ⭐ **[Autocompressor](https://autocompressor.net/)** - Compress / 2GB / [BlueSky](https://bsky.app/profile/autocompressor.net) / [Discord](https://discord.com/invite/8afxgEpxH4)
* [Compress Video Online](https://compress-video-online.com/) - Compress / Unlimited
* [8mb.video](https://8mb.video/) - Compress / 2GB / [Discord](https://discord.com/invite/UzmzPfX)
* [Rotato](https://tools.rotato.app/) - Compress / 2GB
* [VideoSmaller](https://www.videosmaller.com/) - Compress / 500MB
* [YouCompress](https://www.youcompress.com/) - Compress / 500MB
* [MP4Compress](https://www.mp4compress.com/) - Compress / 500MB
* [VERT](https://vert.sh/) - Converter / [Discord](https://discord.gg/8XXZ7TFFrK) / [GitHub](https://github.com/VERT-sh/VERT)
* [Video Express Converter](https://vc.germanov.dev/)
* [VideoConverter](https://www.movavi.com/video-converter/) - Converter
* [Restream Tools](https://restream.io/tools) - Converter

***

## ▷ FFmpeg Tools

* [FFmpeg-Builds](https://github.com/BtbN/FFmpeg-Builds) or [media-autobuild_suite](https://github.com/m-ab-s/media-autobuild_suite) - Autobuild Tools
* [ffmpeg-web](https://ffmpeg-web.netlify.app/) / [GitHub](https://github.com/Dinoosauro/ffmpeg-web), [FFmpeg Online](https://ffmpeg.wide.video/), [⁠ffmpeg webCLI](https://tejaswigowda.com/ffmpeg-webCLI/) / [GitHub](https://github.com/tejaswigowda/ffmpeg-webCLI), [⁠CompressO](https://compresso.codeforreal.com/) / [GitHub](https://github.com/codeforreal1/compressO) or [ffmpegwasm](https://ffmpegwasm.netlify.app/) / [2](https://ffmpeg.gcc.ac.cn/) / [GitHub](https://github.com/ffmpegwasm/ffmpeg.wasm) - FFmpeg Web Apps
* [FFmpeg Libav](https://github.com/leandromoreira/ffmpeg-libav-tutorial) or [ffmprovisr](https://amiaopensource.github.io/ffmprovisr/) - FFmpeg Guides
* [ASM Lessons](https://github.com/FFmpeg/asm-lessons) - FFmpeg Assembly Language Lessons / Multiple Languages
* [FFmpeg Cheat Sheet](https://gist.github.com/steven2358/ba153c642fe2bb1e47485962df07c730), [FFmpeg Commander](https://ffmpeg-commander.com/) or [FFmpeg Buddy](https://evanhahn.github.io/ffmpeg-buddy/) - Command Lists
* [WebMConverter](https://argorar.github.io/WebMConverter/) - WebM Converter
* [PureMPV](https://github.com/4ndrs/PureMPV) - Info Copy Tool
* [FFmpeg Batch](https://ffmpeg-batch.sourceforge.io/) - Bulk Conversion Tools

***

## ▷ Live Streaming

* 🌐 **[Awesome Streaming](https://github.com/juancarlospaco/awesome-streaming-tools)** or [StreamerFreebies](https://streamerfreebies.com/) - Live Streaming Resources
* ⭐ **[OBS Studio](https://obsproject.com/)** - Live Stream Manager / Windows, macOS, Linux / [Discord](https://discord.com/invite/obsproject) / [GitHub](https://github.com/obsproject/obs-studio)
* ⭐ **OBS Tools** - [Tweaks](https://ctt.cx/video/obs/) / [Multi-Stream](https://sorayuki.github.io/obs-multi-rtmp/) / [Background Remover](https://github.com/locaal-ai/obs-backgroundremoval) / [Web App](https://github.com/Niek/obs-web) / [Phone Controller](https://github.com/Kounex/obs_blade) / [Smooth Zoom](https://github.com/JustAdumbPrsn/OBS-Smooth-Zoom) / [Plugin Updater](https://ko-fi.com/s/0b5bd4536d) / [Guide](https://www.nvidia.com/en-us/geforce/guides/broadcasting-guide/)
* ⭐ **[Streamer.bot](https://streamer.bot/)** - Live Stream Manager / [X](https://x.com/streamerdotbot) / [Subreddit](https://www.reddit.com/r/streamerbot) / [Discord](https://discord.com/invite/hYqQGG3puC) / [GitHub](https://github.com/Streamerbot)
* [⁠TikFinity](https://tikfinity.zerody.one/) - TikTok Live Toolkit / [Discord](https://discord.gg/uthtmVdpy8)
* [TikTok Chat Reader](https://tiktok-chat-reader.zerody.one/) - Live TikTok Chat Reader
* [⁠MeldStudio](https://meldstudio.co/) - Live Stream Manager / Windows, macOS
* [StreamLabs](https://streamlabs.com/) - Live Stream Manager / Windows, macOS / [GitHub](https://github.com/streamlabs/desktop)
* [Stream Elements](https://streamelements.com/) - Streaming Service Manager
* [Restream](https://restream.io/) - Multi-Platform Streams
* [TwitchChat](https://twitchat.fr/) - Live Stream Manager / [Discord](https://discord.com/invite/fmqD2xUYvP) / [GitHub](https://github.com/Durss/Twitchat)
* [VDO Ninja](https://vdo.ninja/) - Live Stream Collaboration Tool
* [LiveStreamDVR](https://github.com/MrBrax/LiveStreamDVR) or [⁠StreamRecorder](https://streamrecorder.io/) - Live Stream Recorder
* [NVIDIA Broadcast](https://www.nvidia.com/en-us/geforce/broadcasting/broadcast-app/) - Stream Audio / Video Enhancer / Windows
* [⁠Moblin](https://github.com/eerimoq/moblin) - IRL Live Streaming App / iOS
* [Owncast](https://owncast.online/) / [GitHub](https://github.com/owncast/owncast) or [Restreamer](https://github.com/datarhei/restreamer) - Self-Hosted Live Streaming
* [WDFlat](https://www.wdflat.com/) - Stream Elements
* [Strem](https://github.com/strem-app/strem) - Stream Automation
* [ppInk](https://github.com/PubPub-zz/ppInk/), [⁠AnnotateWeb](https://annotateweb.com/), [gInk](https://github.com/geovens/gInk), [Screenshot](https://jpgonline.com/screenshot) or [Live Draw](https://github.com/antfu/live-draw) - Screen Annotation
* [⁠Overlays](https://overlays.uno/) - Live Stream Overlays
* [Amuse](https://6klabs.com/amuse) or [Songify](https://songify.rocks/) - Now Playing Overlays
* [⁠Twitch Poll Overlay](https://poll.ma.pe/) - ⁠Twitch Poll Overlay
* [real-url](https://github.com/wbt5/real-url) - Copy Live Stream URLs
* [Chat-Downloader](https://github.com/xenova/chat-downloader) - Retrieve Chat Messages from Livestreams

***

## ▷ VTuber Tools

* 🌐 **[Runa's Archive](https://kekuwi.github.io/Runa-Archive)** - VTuber Resources / [Discord](https://discord.com/invite/GdfHVZ6Z33)
* [⁠VTuber Nook](https://vtuber-nook.com/) - VTuber Resources
* [Best VTuber](https://gist.github.com/emilianavt/cbf4d6de6f7fb01a42d4cce922795794) - VTuber Resources
* [VTResources](https://vtresources.carrd.co/) - VTuber Resources
* [VTuber Assets](https://discord.gg/acU3dFRtvC) - VTuber Resources
* [VTuber Kit](https://kyuppin.itch.io/vtuber-kit) or [VRoid](https://vroid.com/en/studio) - VTuber Character Creators / Tracking
* [VSeeFace](https://www.vseeface.icu/), [Kalidoface 3D](https://3d.kalidoface.com/), [⁠VNyan](https://suvidriel.itch.io/vnyan) or [Animaze](https://www.animaze.us/) - 3D Tracking & Puppeteering (VRM)
* [Vtube Studio](https://denchisoft.com/) or [Inochi2D](https://inochi2d.com/) / [Discord](https://discord.com/invite/abnxwN6r9v) - 2D / Live2D Tracking
* [veadotube](https://olmewe.itch.io/veadotube-mini) - PNGTuber & Reactive Software
* [avatarify-python](https://github.com/alievk/avatarify-python) - Real-Time Photo / Video Avatars
* [VTuberized Logos](https://vtuber-style-logos.vercel.app/) - VTuber Style Logos

***

## ▷ [Subtitle Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25BA_subtitle_tools)

***

## ▷ [Linux Video Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_linux_video)

***

## ▷ [Mac Video Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_mac_video)

***

# ► Video Players

* 🌐 **[Awesome Video](https://github.com/krzemienski/awesome-video)** - Video Streaming Resources
* 🌐 **[Video Help](https://www.videohelp.com/software/sections/video-players?orderby=Rating)** - Video Player Index
* 🌐 **[MPV Clients](https://mpv.rocks/)** - MPV Based Client Index
* ⭐ **[MPV](https://mpv.io/)** - Video Player / [Improved UI](https://github.com/tomasklaen/uosc) / [Custom Builder](https://mpv-easy.github.io/mpv-build/) / [Frontends](https://github.com/mpv-player/mpv/wiki/Applications-using-mpv) / [GitHub](https://github.com/mpv-player/mpv)
* ⭐ **[MPC-HC](https://github.com/clsid2/mpc-hc/)** or [MPC-BE](https://sourceforge.net/projects/mpcbe/) / [GitHub](https://github.com/Aleksoid1978/MPC-BE) - Video Player / [YT-DL Support](https://www.free-codecs.com/guides/how_to_stream_videos_with_mpc-hc.htm) / [OpenSubtitles Bypass](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/mp-opensubs.md)
* ⭐ **[MPC-QT](https://mpc-qt.github.io/)** - Video Player / MPC UI w/ MPV Internal Player / Easy Setup / [GitHub](https://github.com/mpc-qt/mpc-qt)
* ⭐ **[VLC](https://nightlies.videolan.org/)**, [2](https://www.videolan.org/) - Video Player / Use Nightly for Correct Colors / [GitHub](https://github.com/videolan/vlc)
* ⭐ **[FastStream](https://faststream.online/)** - Fragmentation Streaming Extension / [Firefox Note](https://github.com/Andrews54757/FastStream?tab=readme-ov-file#notice-for-firefox-extension-store-users) / [GitHub](https://github.com/Andrews54757/FastStream/)
* ⭐ **[OpenVideo](https://openvideofs.github.io)** or [Stream-Bypass](https://github.com/ByteDream/stream-bypass) - Use Streaming Sites in Ad-Free Player with Subs, Speed Control & More
* [Codec Guide](https://www.codecguide.com/), [ALF FreeWare VideoCODECs](https://codec.kyiv.ua/), or [Free-Codecs](https://www.free-codecs.com/) - Video Player Codec Collections
* [PotPlayer](https://potplayer.tv/) - Video Player / [Twitch Addon](https://github.com/TwitchPotPlayer/TwitchPotPlayer) / [YouTube Addon](https://chromewebstore.google.com/detail/potplayer-youtube-shortcu/cfdpeaefecdlkdlgdpjjllmhlnckcodp)
* [Screenbox](https://github.com/huynhsontung/Screenbox) - Video Player
* [GridPlayer](https://github.com/vzhd1701/gridplayer), [AVPlayer](http://www.awesomevideoplayer.com/) or [ICAT](https://www.nvidia.com/en-us/geforce/technologies/icat/) - Multi-Video Players
* [SPlayer](https://www.splayer.org/) - Video Player with Smart Translation
* [ImPlay](https://github.com/tsl0922/ImPlay) - Video Player
* [SMPlayer](https://www.smplayer.info/), [2](https://sourceforge.net/projects/smplayer/) - Video Player / [SMTube](https://www.smtube.org/) / [GitHub](https://github.com/smplayer-dev/smplayer)
* [uView](https://www.idruf.com/) - Video Player
* [Flyleaf](https://github.com/SuRGeoNix/Flyleaf) - Video Player
* [KikoPlay](https://kikoplay.fun/) - Video Player
* [h5player](https://h5player.anzz.top/) - Add Features to HTML5 Video Players / [GitHub](https://github.com/xxxily/h5player)
* [Plyr](https://plyr.io/) - Online HTML5, YouTube and Vimeo Player / [GitHub](https://github.com/sampotts/plyr)
* [⁠panoptic](https://panoptic.live/) - Watch Multiple Live Streams At Once
* [MotionMonkey](https://omega.gg/MotionMonkey/) - Stream Online Videos in Player
* [StreamLink](https://streamlink.github.io/) - Extract Videos from Sites to Players / [Twitch Adblock](https://github.com/2bc4/streamlink-ttvlol) / [GitHub](https://github.com/streamlink/streamlink)
* [polsy.org.uk](https://polsy.org.uk/) - Alt Players for Video Sites

***

## ▷ Stream Sync

* ⭐ **[Syncplay](https://syncplay.pl/)** - App / [GitHub](https://github.com/Syncplay/syncplay)
* ⭐ **[Watch2Gether](https://w2g.tv/)** - Online Player
* ⭐ **[SyncWatch](https://github.com/Semro/syncwatch)** - Online Extension
* ⭐ **[Kosmi](https://kosmi.io/)** - Online Player
* ⭐ **[WatchParty](https://www.watchparty.me/)** - Online / Virtual Browser / [Discord](https://discord.gg/3rYj5HV) / [GitHub](https://github.com/howardchung/watchparty)
* ⭐ **[neko](https://neko.m1k1o.net/)** - Docker Virtual Browser / [GitHub](https://github.com/m1k1o/neko)
* [HyperBeam](https://hyperbeam.com/) / [VIP](https://greasyfork.org/en/scripts/457795) - Virtual Computer Embed
* [OpenTogetherTube](https://opentogethertube.com/) or [TurtleTV](https://turtletv.app/) - Online Player
* [Metastream](https://getmetastream.com/) - Online Extension / [Discord](https://discord.com/invite/nfwPRb9) / [GitHub](https://github.com/samuelmaddock/metastream)
* [Caracal Club](https://caracal.club/) - Online Player
* [Mzelo](https://mzelo.com/) - Online Player
* [⁠SyncUp](https://syncup.tv/) - Online Player
* [CyTube](https://cytu.be/) - Online Player
* [⁠CinevoSync](https://sync.cinevo.us/) - Online Player
* [VideoTogether](https://videotogether.github.io/) - App
* [baked.live](https://baked.live/) - Online Player
* [MovieNight](https://github.com/zorchenhimer/MovieNight) - Docker / [Discord](https://discord.gg/F2VSgjJ)

***

## ▷ MPV Tools

* 🌐 **[⁠Awesome-MPV](https://github.com/stax76/awesome-mpv)** - MPV Tools / Resources
* [MPV Config Guide](https://thewiki.moe/tutorials/mpv/), [2](https://iamscum.wordpress.com/guides/videoplayback-guide/mpv-conf/), [3](https://hooke007-github-io.translate.goog/unofficial/index.html?_x_tr_sl=auto&_x_tr_tl=en&_x_tr_hl=en-US&_x_tr_pto=wapp)
* [Flower's MPV Config](https://github.com/flowerey/flower-mpv-config) - Automated MPV Configs
* [ModernZ](https://github.com/Samillion/ModernZ) or [uosc](https://github.com/tomasklaen/uosc) - Alt User Interfaces
* [Simple MPV WebUI](https://github.com/open-dynaMIX/simple-mpv-webui) - WebUI Controller
* [MPV Context Menu](https://gitlab.com/carmanaught/mpvcontextmenu)
* [MPV Scripts](https://github.com/mpv-player/mpv/wiki/User-Scripts) - Userscripts
* [VideoClip](https://github.com/Ajatt-Tools/videoclip), [2](https://github.com/f0e/mpv-lossless-cut) - Clip Tool
* [MPV WebM](https://github.com/ekisu/mpv-webm) - WebM Tool
* [Play With MPV](https://greasyfork.org/en/scripts/416271) or [ff2mpv](https://github.com/woodruffw/ff2mpv) - Open Videos with MPV
* [MPV WebTorrent Hook](https://github.com/noctuid/mpv-webtorrent-hook) - Torrent Streaming
* [⁠mpv-autosub](https://github.com/davidde/mpv-autosub) - Subtitle Auto Downloader
* [AutoSubSync MPV](https://github.com/joaquintorres/autosubsync-mpv) - Sub Sync
* [MPV SponsorBlock](https://github.com/po5/mpv_sponsorblock), [2](https://codeberg.org/jouni/mpv_sponsorblock_minimal) - SponsorBlock for MPV
* [⁠JumpSkip](https://github.com/ElectricArdvark/jumpskip) - Intro / Outro Skipping Script for MPV
* [ThumbFast](https://github.com/po5/thumbfast) - MPV Thumbnails
* [ArtCNN](https://github.com/Artoriuz/ArtCNN), [AniSD](https://github.com/Sirosky/Upscale-Hub/releases/tag/AniSD-ArtCNN) or [Ani4k](https://github.com/Sirosky/Upscale-Hub/releases/tag/Ani4k-v2-ArtCNN) - Anime Upscaling
* [FSR](https://gist.github.com/agyild/82219c545228d70c5604f865ce0b0ce5) or [CAS](https://gist.github.com/agyild/bbb4e58298b2f86aa24da3032a0d2ee6) - AMD FidelityFX port
* [MPV Prescalers](https://github.com/bjin/mpv-prescalers/) - NNEDI / RAVU Upscaling
* [GLSL CFL Prediction](https://github.com/Artoriuz/glsl-chroma-from-luma-prediction) - Chroma Upscaling

***

## ▷ VLC Tools

* 🌐 **[Awesome VLC](https://github.com/mfkl/awesome-vlc)** - VLC Resources
* [VLSub](https://github.com/exebetche/vlsub) - Sub Downloader
* [VLC Slow Seek Fix](https://redd.it/os6f1q)

***

# ► Media Servers

* ↪️ **[Torrent Automation](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25BA_torrent_apps)**
* ⭐ **[Jellyfin](https://jellyfin.org/)** - Media Server / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video-tools#wiki_.25B7_jellyfin_tools) / [Matrix](https://matrix.to/#/#jellyfinorg:matrix.org) / [Discord](https://discord.gg/zHBxVSXdBV) / [GitHub](https://github.com/jellyfin/jellyfin)
* ⭐ **[Kodi](https://kodi.tv/)** or [Xbox Kodi](https://apps.microsoft.com/detail/9nblggh4t892) - Media Server / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video-tools#wiki_.25B7_kodi_tools)
* [TRaSH Guides](https://trash-guides.info/) / [Discord](https://discord.com/invite/4K2kdvwzFh), [⁠Duck Guides](https://duckkota.gitlab.io/guides/) or [The Complete Guide](https://redd.it/pqsomd) - Server Setup Guides
* [Simkl](https://simkl.com/), [MDBList](https://mdblist.com/) or [Trakt](https://app.trakt.tv/) - Media Trackers / List Creators
* [Prowlarr](https://prowlarr.com/) / [GitHub](https://github.com/Prowlarr/Prowlarr), [FlexGet](https://flexget.com/) or [r/softwarr](https://reddit.com/r/softwarr) - Autodownload Tools
* [Reiverr](https://github.com/aleksilassila/reiverr) - Media Server Manager
* [HTPC Download Box](https://github.com/sebgl/htpc-download-box) - Media Server Automation
* [Seanime](https://seanime.app/) - Anime Server / [Discord](https://discord.com/invite/3AuhRGqUqh)
* [swizzin](https://swizzin.ltd/) or [⁠YAMS](https://yams.media/) / [Discord](https://discord.com/invite/Gwae3tNMST) - Media Server Install Script / Debain + Ubuntu
* [DMS](https://github.com/anacrolix/dms) - Media Server
* [Emby](https://emby.media/) - Media Server
* [Universal Media Server](https://www.universalmediaserver.com/) - Media Server
* [OSMC](https://osmc.tv/) - Media Server
* [Kawaii-Player](https://github.com/kanishka-linux/kawaii-player) - Media Server
* [Streama](https://github.com/streamaserver/streama) - Media Server
* [Gerbera](https://gerbera.io/) - Media Server
* [Homehost](https://github.com/ridhwaans/homehost) - Media Server
* [Kyoo](https://github.com/zoriya/Kyoo) - Media Server / [Discord](https://discord.com/invite/E6Apw3aFaA)
* [Chocolate](https://github.com/ChocolateApp/Chocolate) - Media Server
* [Plezy](https://plezy.app/) / [GitHub](https://github.com/edde746/plezy) or [Plex](https://www.plex.tv/media-server-downloads/) - Media Server / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video-tools#wiki_.25B7_plex_tools)
* [Media-Hoarder](https://github.com/theMK2k/Media-Hoarder) - Media Catalog Frontend
* [HTPC](https://r-htpc.github.io/wiki/) - Home Theater PC guides / [Subreddit](https://www.reddit.com/r/htpc/)
* [MSX](https://msx.benzac.de/info/) - Web App
* [TheIntroDB](https://theintrodb.org/) / [Discord](https://discord.gg/Qn6RhamxT5) / [Telegram](https://t.me/theintrodb) / [GitHub](https://github.com/TheIntroDB) or [SkipDB](https://skipdb.tv/) / [Status](https://status.skipdb.tv/) / [GitHub](https://github.com/SkipDB-TV/skipdb) - Intro / Credit Skipping
* [Tunarr](https://tunarr.com/) / [GitHub](https://github.com/chrisbenincasa/tunarr/), [ErsatzTV](https://ersatztv.org/) or [dizqueTV](https://github.com/vexorian/dizquetv) - Custom Live Channel Servers
* [ansible-hms-docker](https://github.com/ahembree/ansible-hms-docker) or [DockSTARTer](https://github.com/GhostWriters/DockSTARTer) - Automated Docker Media Server Setups
* [Seerr](https://github.com/seerr-team/seerr) / [Mobile](https://github.com/seerr-team/mobile-app) or [Ombi](https://github.com/Ombi-app/Ombi) - User Request Management
* [Dispatcharr](https://github.com/Dispatcharr/Dispatcharr) or [⁠tuliprox](https://github.com/euzu/tuliprox) - IPTV Playlist Managers for Servers
* [YTDL-Sub](https://ytdl-sub.readthedocs.io/en/) - Add YouTube Channels to Media Servers / [GitHub](https://github.com/jmbannon/ytdl-sub)
* [xTeVe](https://github.com/xteve-project/xTeVe) - Plex / Emby M3U Proxy

***

## ▷ Plex Tools

* [Reddit Guide](https://redd.it/ma1hlm) - Plex Setup Guides
* [Tautulli](https://tautulli.com/) - Server Monitor / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/tautulli-note.md)
* [Kitana](https://github.com/pannal/Kitana) - Plugin Frontend
* [Reaparr](https://www.reaparr.rocks/) - Merge Plex Libraries w/ Your Own / [Docs](https://github.com/Reaparr/Docs) / [Discord](https://discord.com/invite/k2KvDJbnNm) / [GitHub](https://github.com/Reaparr/Reaparr)
* [PlexDrive](https://github.com/plexdrive/plexdrive) - Mount Google Drive
* [SyncLounge](https://github.com/synclounge/synclounge) - Media Sync
* [PseudoTV](https://github.com/DEFENDORe/pseudotv) - Create TV Channels
* [Overseerr](https://seerr.dev/) - User Requests / [IMDb Extension](https://chromewebstore.google.com/detail/overseerr-assistant/hopnjiadheaagfhpipecoamoegijhnij)
* [Pasta Tool](https://www.pastatool.com/) - Audio / Sub Changer / [GitHub](https://github.com/cglatot/pasta)

***

## ▷ Jellyfin Tools

* 🌐 **[Awesome Jellyfin](https://github.com/awesome-jellyfin/awesome-jellyfin)** - Jellyfin Resources
* ⭐ **[Fladder](https://github.com/DonutWare/Fladder/)** - Desktop Client / Windows, macOS, Linux, Android, iOS
* [Blink](https://github.com/prayag17/Blink) - Desktop Client
* [jellyfin-desktop](https://github.com/jellyfin/jellyfin-desktop) - Desktop Client
* [Findroid](https://github.com/jarnedemeulemeester/findroid) or [Streamyfin](https://github.com/streamyfin/streamyfin) - JellyFin Android Clients
* [Jellyfin Forum](https://forum.jellyfin.org/) - Official Jellyfin Forum
* [Jellyfin Vue](https://github.com/jellyfin/jellyfin-vue) - Jellyfin Web Client
* [Jellyfin "arr" Setup Guide](https://www.fuzzygrim.com/posts/media-server)
* [Jellyfin Customization Guide](https://youtu.be/F85qMyBeiDI)
* [Jellyfin Themes](https://jellyfin.org/docs/general/clients/css-customization/#community-themes)
* [Jellyfin RPC](https://github.com/Radiicall/jellyfin-rpc) - Jellyfin Discord Rich Presence

***

## ▷ Kodi Tools

* ⭐ **[Elementum](https://elementum.surge.sh/)** - Torrent Streaming / Trakt Sync / Similar to Stremio + Torrentio
* [Kodi Builds Chart](https://kodiapps.com/builds-chart)
* [r/Addons4Kodi](https://www.reddit.com/r/Addons4Kodi/) / [Tracker](https://kinkeadtech.com/best-kodi-streaming-addons/) / [Trending](https://kodiapps.com/addons-chart) or [⁠TroyPoint](https://troypoint.com/) - Kodi Addons
* [Kodi Skins](https://kodi.tv/addons/omega/category/skins/) or [WIP Skins](https://forum.kodi.tv/forumdisplay.php?fid=160) - Kodi Skins
* [Synko](https://github.com/Skaytacium/synko) - Kodi Stream Sync
* [Plex Kodi Connect](https://github.com/croneter/PlexKodiConnect) or [plex-for-kodi](https://github.com/pannal/plex-for-kodi) - Plex for Kodi
* [quasar](https://quasar.surge.sh/) - Torrent Plugin
* [IPTV Client](https://kodi.wiki/view/Add-on:PVR_IPTV_Simple_Client)
* [tinyMediaManager](https://www.tinymediamanager.org/) or [MediaElch](https://www.kvibes.de/mediaelch/) - Media Collection Managers

***

# ► Video Download

* ↪️ **[YouTube Video Downloaders](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/social-media#wiki_.25B7_youtube_downloaders)**
* ↪️ **[Twitch Video Downloaders](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/social-media#wiki_.25B7_twitch_downloaders)**
* ↪️ **[Download Managers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/file-tools/#wiki_.25B7_download_managers)**
* ⭐ **[yt-dlp](https://github.com/yt-dlp/yt-dlp)** or [YTDL-PATCHED](https://github.com/ytdl-patched/ytdl-patched) - Multi-Site / [Commands](https://github.com/TheFrenchGhosty/TheFrenchGhostys-Ultimate-YouTube-DL-Scripts-Collection) / Windows, macOS, Linux / [Discord](https://discord.gg/H5MNcFW63r)
* ⭐ **[cobalt](https://cobalt.tools/)** - Multi-Site / Online / [Instances](https://cobalt.directory/) / [X](https://x.com/justusecobalt) / [Discord](https://discord.com/invite/pQPt8HBUPu) / [GitHub](https://github.com/imputnet/cobalt)
* ⭐ **[⁠lostnode](https://dl.lostnode.lol/)** - Multi-Site / Online
* ⭐ **[9xbuddy](https://9xbuddy.com/)**, [2](https://9xbuddy.site/), [3](https://9xbuddy.in/) - Multi-Site / Online
* [Video Download Helper](https://www.downloadhelper.net/) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/video-downloadhelper.md), [FetchV](https://fetchv.net/) or [MPMux](https://mpmux.com/) - Extensions
* [⁠VideoDL](https://github.com/CharlesPikachu/videodl) - Multi-Site / Windows, macOS, Linux
* [VRKA](https://github.com/MaverickRox/VRKA) - Multi-Site / Windows, macOS, Linux
* [NeoDLP](https://neodlp.neosubhamoy.com/) - Multi-Site / Windows, macOS, Linux / [GitHub](https://github.com/neosubhamoy/neodlp)
* [SCrawler](https://github.com/AAndyProgram/SCrawler) - Multi-Site / Windows, macOS, Linux / [Discord](https://discord.gg/uFNUXvFFmg)
* [you-get](https://you-get.org/) - Multi-Site / CLI / [GitHub](https://github.com/soimort/you-get)
* [Musvkrobot](https://t.me/musvkrobot) - Multi-Site / Telegram Bot
* [⁠Rip Anything From Anywhere](https://anything.rip/) - Multi-Site / Online
* [⁠CYBROX](https://cybrox.pro/) - Multi-Site / Online
* [vdwn.cloud](https://vdwn.cloud/), [2](https://imov.life/) - Multi-Site / Online
* [yoink.tools](https://yoink.tools/) - Multi-Site / Online
* [AMP4](https://amp4.cc/) - Multi-Site / Online
* [AudioFetcher (MP4)](https://audiofetcher.com/) - Multi-Site / Online / [Discord](https://discord.gg/DFZaejcJfg)
* [VideoFK](https://www.videofk.com/) - Multi-Site / Online
* [⁠OFA Downloader](https://oneforalldownloader.com/) - Multi-Site / Online
* [⁠YT-DLP Online](https://ytdlp.online/), [2](https://ytdlp.wiki/) - Multi-Site / Online
* [SSSTik](https://ssstik.io/), [myfaveTT](https://myfavett.com/) or [tiktok-to-ytdlp](https://github.com/Dinoosauro/tiktok-to-ytdlp) - TikTok
* [Threads Downloader](https://threadsdownloader.com/) - Threads
* [Piner](https://piner.io/) - Pinterest / Online
* [⁠ReelSave](https://reelsave.app/) - Instagram
* [iTeraPlay](https://iteraplay.com/), [Terabox Downloader](https://getindevice.com/terabox-downloader/), [⁠TeraBox Gen](https://terabox.hnn.workers.dev/), [TeraFetch](https://terafetch.com/) or [1024TeraDL](https://1024teradl.com/) - ⁠TeraBox Video Downloaders
* [hls-downloader](https://github.com/puemos/hls-downloader), [⁠cat-catch](https://github.com/xifangczy/cat-catch/blob/master/README_en.md), [hls extension](https://webextension.org/listing/hls-downloader.html) or [hlsloader](https://www.hlsloader.com/) - HLS Downloaders
* [GetWVKeys](https://getwvkeys.cc/) - Send Widevine Requests / [GitHub](https://github.com/GetWVKeys/)
* [DRM Bypass Toolkit](https://rentry.co/FMHYB64#dbt) - DRM Bypass Guide

***

# ► Video Editing

* ⭐ **[r/VideoEditing](https://www.reddit.com/r/VideoEditing/)** - Video Editing Subreddit / [Wiki](https://www.reddit.com/r/VideoEditing/wiki/index/)
* ⭐ **[Eyecandy](https://eyecannndy.com/)** - Visual Technique Examples / [Discord](https://discord.com/invite/WRyrPkWEzT)
* ⭐ **[Waifu2x GUI](https://github.com/AaronFeng753/Waifu2x-Extension-GUI)**, [⁠TheAnimeScripter](https://github.com/NevermindNilas/TheAnimeScripter), [Video2x](https://github.com/k4yt3x/video2x), [Warlock-Studio](https://github.com/Ivan-Ayub97/Warlock-Studio), [Lossless Scaling](https://fmhy.net/gaming#download-games) (search) or [Dandere2x](https://github.com/akai-katto/dandere2x) - Video Upscaling
* [Codecs and Containers](https://www.reddit.com/r/VideoEditing/wiki/codecsandcontainers) - Info on Codecs & Containers
* [VideoHelp Forum](https://forum.videohelp.com/forums/2-Video) - Video Editing Forums

***

## ▷ Video Editors

* ↪️ **[Editing Software](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent/#wiki_.25BA_torrent_sites)** / [2](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/download#wiki_.25BA_software_sites)
* ↪️ **[Linux Video Editors](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_linux_video)** / [macOS](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_mac_video)
* ⭐ **[DaVinci Resolve](https://www.blackmagicdesign.com/products/davinciresolve)** - Video Editor / Requires Sign-Up (Fake Info Works) / [Guides](https://www.blackmagicdesign.com/products/davinciresolve/training) / [Subtitle Generator](https://tom-moroney.com/auto-subs/) / [Green Screen Extract](https://github.com/alexandremendoncaalvaro/CorridorKey-Runtime) / Windows, macOS, Linux / [X](https://x.com/Blackmagic_News) / [Discord](https://discord.gg/davinci-resolve-community-714620142096482314)
* ⭐ **[Kdenlive](https://kdenlive.org/en/)** - Video Editor / Windows, macOS, Linux / [GitHub](https://github.com/KDE/kdenlive)
* ⭐ **[LosslessCut](https://github.com/mifi/lossless-cut)** - Video Editor / Windows, macOS, Linux
* ⭐ **[Shotcut](https://shotcut.org/)** - Video Editor / Windows, macOS, Linux / [GitHub](https://github.com/mltframework/shotcut)
* [OpenShot](https://www.openshot.org/) - Video Editor / Windows, macOS, Linux / [Source Code](https://code.launchpad.net/openshot)
* [Keyflame](https://rentry.co/FMHYB64#keyflame) - Video Editors / Plugins
* [VSDC](https://www.videosoftdev.com/) - Video Editor / Windows, macOS
* [Avidemux](http://fixounet.free.fr/avidemux/) - Video Editor / Windows, macOS, Linux
* [Blender](https://www.blender.org/) - Video Editor / Windows, macOS, Linux / [Forums](https://blenderartists.org/) / [Source Code](https://projects.blender.org/blender/blender)
* [Auto-Editor](https://auto-editor.com/) - CLI Editor
* [MoviePy](https://zulko.github.io/moviepy/) - Python Editor / [GitHub](https://github.com/Zulko/moviepy/)
* [Webm Generator](https://github.com/dfaker/WebmGenerator) - Webm Editor / Windows
* [avisynth](http://avisynth.nl/index.php/Main_Page) - Video Processor / Windows, macOS, Linux
* [VapourSynth](https://www.vapoursynth.com/) - Video Processor / Windows, Linux
* [Source Filmmaker](https://store.steampowered.com/app/1840/Source_Filmmaker/) - Steam Movie-Making Tool / [Resources](https://sfmlab.com/) / Windows
* [OpenRV](https://github.com/AcademySoftwareFoundation/OpenRV) - Image / Sequence Playback Review / Windows, macOS, Linux
* [suckless-cut](https://github.com/couleur-tweak-tips/suckless-cut) - Cut & Trim Videos / Windows, macOS, Linux
* [vidcutter](https://github.com/ozmartian/vidcutter) - Cut & Trim Videos / Script
* [FreeMoCap](https://freemocap.org/) - Motion Tracking / Windows, macOS, Linux / [GitHub](https://github.com/freemocap/freemocap)
* [Kurku](https://app.kurku.tech/) - Motion Tracking / Web

***

## ▷ Online Editors

* ⭐ **[Mastershot](https://mastershot.app/)**
* ⭐ **[wide.video](https://wide.video/)** / [Discord](https://discord.gg/Q54kW97yj5)
* ⭐ **[Pikimov](https://pikimov.com/)** - Use Chromium Browser / [Discord](https://discord.gg/DhNcC7GQn7)
* [Klippy](https://www.klippy.pro/) / [Discord](https://discord.gg/xJVXbQVPZP)
* [FreeCut](https://www.freecut.net/), [2](https://freecut-sandy.vercel.app/) / [GitHub](https://github.com/walterlow/freecut)
* [Panzoid](https://panzoid.com/)
* [⁠Tooscut](https://tooscut.app/) / [GitHub](https://github.com/mohebifar/tooscut)
* [vidmix](https://vidmix.app/)
* [Video Cutter](https://video-cutter-js.com/)
* [Omniclip](https://omniclip.app/) / [Discord](https://discord.com/invite/Nr8t9s5wSM) / [GitHub](https://github.com/omni-media/omniclip)
* [Cuttr](https://cuttr.in/) - Transcription Based Editor
* [Vididoo](https://vididoo.vercel.app/) - Multitool
* [VideoCandy](https://videocandy.com/) - Multitool
* [Video2Edit](https://www.video2edit.com/) - Multitool
* [Crop Video](https://crop-video.com/) - Crop Videos
* [LoopVid](https://loopvid.kastden.org/) - Loop Videos
* [Crossfade](https://crossfade.io/) - Video / Audio Crossfading
* [VidLouder](https://www.videolouder.com/) - Increase Video Volume
* [Convert2Video](https://convert2video.com/) - Image / Audio to Video

***

## ▷ Effects / Enhancements

* [⁠Grainrad](https://grainrad.com/) or [effect.app](https://effect.app/) - Online Video Effects
* [Topaz](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/download#wiki_.25BA_software_sites) / [2](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video-tools#wiki_.25B7_vfx_sites) or [UniFab](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/download#wiki_.25BA_software_sites) (search) - AI Video Enhancement Tools
* [Gyroflow](https://gyroflow.xyz/) / [Discord](https://discord.com/invite/YaUtNpWTUh) / [GitHub](https://github.com/gyroflow/gyroflow) or [ComfyUI-Video-Stabilizer](https://github.com/nomadoor/ComfyUI-Video-Stabilizer) - Video Stabilization
* [Flowframes](https://nmkd.itch.io/flowframes) or [SVP](https://www.svp-team.com/) / [Guide](https://www.svp-team.com/wiki/Manual:SVPcode) - Video Interpolation / Increase FPS
* [⁠ntsc-rs](https://ntsc.rs/) - TV + VHS Artifact Video Effect Editor / [Web Version](https://web.ntsc.rs/) / [GitHub](https://github.com/ntsc-rs/ntsc-rs)
* [VideoColorizerColab](https://colab.research.google.com/github/jantic/DeOldify/blob/master/VideoColorizerColab.ipynb) - Video Colorization Colab
* [⁠Dithering Studio](https://ditheringstudio.com/) - Video Dithering Tool
* [OpenColorIO](https://opencolorio.org/) - Video Color Manager
* [FreshLUTs](https://freshluts.com/) - Free LUTs (Color Filters)
* [blur](https://github.com/f0e/blur) or [Smoothie](https://github.com/couleur-tweak-tips/smoothie-rs) - Add Motion Blur to Videos / [Tutorial](https://youtu.be/16-KU4r3BcA)
* [ProPainter](https://github.com/sczhou/ProPainter) - Video Inpainting
* [CorridorKey](https://github.com/nikopueringer/CorridorKey2.0) - AI Green Screen Extraction Tool / Unmixing / High VRAM Requirements / [DaVinci Plugin](https://github.com/alexandremendoncaalvaro/CorridorKey-Runtime) / [GUI](https://github.com/edenaion/EZ-CorridorKey/) / [Discord](https://discord.gg/zvwUrdWXJm)

***

## ▷ VFX Sites

* [FootageCrate](https://footagecrate.com/)
* [FreeVideoEffect](https://freevideoeffect.com/)
* [VideoCoPilot](https://www.videocopilot.net/products/ae22/)
* [VFXmed](https://www.vfxmed.com/)
* [Team V.R Releases](https://rentry.co/FMHYB64#team-vr)
* [flex_cg_vfx](https://t.me/flex_cg_vfx)
* [Download Pirate](https://www.downloadpirate.com/) - **Use [Adblock](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_adblocking)** / [Discord](https://discord.gg/ucTvVtBz9Z)
* [Ae Blender](https://www.aeblender.com/)
* [HunterAE](https://hunterae.com/)
* [⁠ScenePacks](https://t.me/moviescenepack)
* [AETemp](https://t.me/AETemp)
* [Visual Effects Pack](https://t.me/visual_effects_pack)
* [AEDownloadPro](https://aedownloadpro.com/)
* [Intro HD](https://intro-hd.net/) / **[Warning](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/introhd-critical.md)**

***

## ▷ Animation Tools

* 🌐 **[Creator Resources](https://www.newgrounds.com/wiki/creator-resources/)** - Art & Animation Resource Index
* ⭐ **[Unreal Engine](https://www.unrealengine.com/)** / [Discord](https://discord.gg/9KPvQ4H), [MoonRay](https://openmoonray.org/), [cgsoftbox](https://t.me/cgsoftbox), [SketchUp](https://sketchup.trimble.com/en/plans-and-pricing/sketchup-free) / [Plugins](https://sucj.me/) or [Twinmotion](https://www.twinmotion.com/en-US) - 3D Creation Tools
* ⭐ **Unreal Engine Tools** - [Modding Guides](https://github.com/Dmgvol/UE_Modding) / [Megascans](https://quixel.com/megascans) / [Model Extractor](https://fmodel.app/) / [Model Viewer](https://www.gildor.org/en/projects/umodel) / [UPK Explorer](https://www.nexusmods.com/site/mods/587) / [Wiki](https://www.pcgamingwiki.com/wiki/UPK_Explorer)
* [⁠Autograph](https://www.maxon.net/en/autograph), [OpenToonz](https://opentoonz.github.io/e/) / [GitHub](https://github.com/opentoonz/opentoonz), [Friction](https://friction.graphics/) / [GitHub](https://github.com/friction2d/friction), [Blender](https://www.blender.org/) / [Forums](https://blenderartists.org/) / [Source Code](https://projects.blender.org/blender/blender), [Wick Editor](https://www.wickeditor.com/editor/), [Tixl](https://tixl.app/) / [Discord](https://discord.com/invite/tooll3-823853172619083816) / [GitHub](https://github.com/tixl3d/tixl), [Clipnote Studio](https://calcium-chan.itch.io/clipnote), [⁠Touch Designer](https://derivative.ca/) or [Pencil2D](https://www.pencil2d.org/) - Motion Graphics Editors / Animation Tools
* [Animaker](https://www.animaker.com/) - Animated Video Creator
* [3DThis](https://3dthis.com/) - 3D Animation Tools
* [⁠Su3yaki](https://kasuga.itch.io/su3yaki) - Create 3D Turntable Animations
* [Mega Scans](https://quixel.com/megascans) - 3D Scans
* [Mixer](https://quixel.com/mixer) - 3D Texture Creation Tool
* [PlanetSide](https://planetside.co.uk/) - CG Environment Generator
* [cgplugdump](https://t.me/cgplugdump) - CG Software Plugins
* [Physically Based](https://physicallybased.info/) - RGB Values of Elements
* [AnimeEffects](https://github.com/AnimeEffectsDevs/AnimeEffects), [enve](https://maurycyliebner.github.io/), [Cavalry](https://cavalry.studio/), [TupiTube](https://tupitube.com/) or [Synfig](https://www.synfig.org/) - 2D Animation Tools
* [MonsterMash](https://monstermash.zone/) - Sketch-Based Modeling & Animation Tool
* [Storyboarder](https://wonderunit.com/storyboarder/) - Quickly Visualize & Test Animations / [GitHub](https://github.com/wonderunit/storyboarder)
* [LuxCoreRender](https://luxcorerender.org/) - Rendering Engine
* [RenderChan](https://morevnaproject.org/renderchan/) - 2D Animation Render Manager
* [Mandelbulber](https://mandelbulber.com/) / [GitHub](https://github.com/buddhi1980/mandelbulber2) or [FragM](https://github.com/3Dickulus/FragM) - Fractal Rendering Software / [3D](https://mb3d.overwhale.com/)
* [JWildfire](https://jwildfire.overwhale.com/), [IFSRenderer](https://github.com/bezo97/IFSRenderer) or [Fractorium](http://fractorium.com/) - Flame Fractal Rendering Software
* [BestSnip](https://bestsnip.com/animation/), [Sketch Machine](https://sketchmachine.net/), [Plask](https://plask.ai/) or [Rive](https://rive.app/) - Online Animation Tools
* [Glaxnimate](https://glaxnimate.org/) or [Trangram](https://www.trangram.com/) - Vector Animation Tools
* [LibreSprite](https://libresprite.github.io/) / [GitHub](https://github.com/LibreSprite/LibreSprite), [GraphicsGale](https://graphicsgale.com/us/), [Poxil](https://poxil.vercel.app/) / [GitHub](https://github.com/F4tal1t/Poxil), [JPixel](https://pixelfromhell.itch.io/jpixel), [Aseprite](https://github.com/aseprite/aseprite) / [Guide](https://youtu.be/Z4Enx-Nb43E), [SpriteSheep](https://spritesheep.com/) / [Discord](https://discord.gg/cQBZV3FcEZ), [fizzy](https://fizzyed.it/) / [Web App](https://fizzyed.it/app/) / [GitHub](https://github.com/fizzyedit/fizzy), [KPix](https://github.com/krush62/KPix), [⁠Xprite](https://xprite.cc/) / [GitHub](https://github.com/rhinoc/xprite) or [SpookyGhost](https://encelo.itch.io/spookyghost) - Pixel Art Animation Tools
* [⁠Wigglypaint](https://internet-janitor.itch.io/wigglypaint) or [FizzPaint](https://fizzpaint.ameniwa.com/) - Browser Painting / Animated Brushes
* [Spritesheet Generator](https://spritesheetgenerator.online/) - Spritesheet Generator
* [Animated Drawings](https://sketch.metademolab.com/), [⁠FliiipBook](https://www.fliiipbook.com/), [Mutsuacen](https://mutsuacen.com/), [FAIR Animated Drawings](https://fairanimateddrawings.com/site/home) or [MotorPen](https://motorpen.com/) - Animate Drawings
* [FlipAnim](https://flipanim.com/) - Create Animated Flipbooks
* [Viggle](https://viggle.ai/) - Animated Character Creators / [Discord](https://discord.com/invite/viggle)
* [Mixamo](https://www.mixamo.com/), [Endorphin](https://archive.org/) (search) / [Subreddit](https://www.reddit.com/r/endorphin/) or [Cascadeur](https://cascadeur.com/) - 3D Character Animation Tools
* [MMHuman3D](https://github.com/open-mmlab/mmhuman3d) - 3D Human Model Creator
* [Blender Open Movies](https://youtube.com/playlist?list=PLav47HAVZMjnTFVZL-aImCQIC0uLZtNCz) - CGI Assets

***

## ▷ Stock Videos

* 🌐 **[Awesome Stock Resources](https://github.com/neutraltone/awesome-stock-resources#videos)** or **[CuteStockFootage](https://cutestockfootage.com/free/video)** - Stock Video Indexes
* [Historic Films](https://www.historicfilms.com/) or [National Film Preservation Foundation](https://www.filmpreservation.org/) - Historic Footage / Films
* [commons.wikimedia](https://commons.wikimedia.org/wiki/Category:Videos) or [Wikimore](https://git.private.coffee/privatecoffee/wikimore#instances) - Wiki Commons Video Files
* [⁠Destockd](https://www.destockd.com/) - Stock Videos
* [Moving Image Archive](https://www.movingimagearchive.com/) - Stock Videos
* [Pexels](https://www.pexels.com/) - Stock Videos
* [Dareful](https://dareful.com/) - 4K Stock Videos
* [Monzoom](https://www.monzoom.com/) - 4K Stock Videos
* [BeachFrontBroll](https://www.beachfrontbroll.com/) - Stock Videos
* [Magnific](https://www.magnific.com/videos) - Stock Videos
* [veed.io](https://www.veed.io/videos) - Stock Videos
* [VidsPlay](https://www.vidsplay.com/) - Stock Videos
* [MixKit](https://mixkit.co/) - Stock Videos
* [ineedfx](https://ineedfx.com/) - Stock Videos
* [MotionPlaces](https://www.motionplaces.com/) - Worldwide Stock Videos
* [DroneStock](https://dronestock.com/) - Drone Video Footage
* [MovieTools](https://movietools.info/) - Video Loops