/**
 *  Copyright (c) 2025 taskylizard. Apache License 2.0.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

import type { DefaultTheme } from 'vitepress'

// @unocss-include

export const meta = {
  name: 'Nexora',
  description: 'Discover useful digital resources, tools, and guides.',
  hostname: 'https://example.com', // Replace with Nexora's real domain before deployment.
  keywords: ['stream', 'movies', 'gaming', 'reading', 'anime'],
  build: {
    api: true,
    nsfw: true
  }
}

export const excluded = [
  'readme.md',
  'single-page',
  'single-page.md',
  'feedback.md',
  'index.md',
  'sandbox.md',
  'startpage.md'
]

// Strip the URL scheme and a leading "www." so "https://www.pi-hole.net/x" and
// "pi-hole.net/x" compare the same way. Shared by the build-time index
// (constants.ts) and the client search box so they normalize identically.
export const stripSchemeAndWww = (value: string) =>
  value.replace(/^[a-z][a-z0-9+.-]*:\/\//, '').replace(/^www\./, '')

const TRACKING_QUERY_PARAMS = new Set([
  'fbclid',
  'gclid',
  'gbraid',
  'mc_cid',
  'mc_eid',
  'wbraid'
])

export function normalizeSearchUrl(value: string) {
  const stripped = stripSchemeAndWww(value)
  const hashIndex = stripped.indexOf('#')
  const withoutHash = hashIndex === -1 ? stripped : stripped.slice(0, hashIndex)
  const hash = hashIndex === -1 ? '' : stripped.slice(hashIndex + 1)
  const queryIndex = withoutHash.indexOf('?')

  if (queryIndex === -1) return hash ? `${withoutHash}#${hash}` : withoutHash

  const hostPath = withoutHash.slice(0, queryIndex)
  const params = new URLSearchParams(withoutHash.slice(queryIndex + 1))
  for (const key of [...params.keys()]) {
    if (key.startsWith('utm_') || TRACKING_QUERY_PARAMS.has(key)) {
      params.delete(key)
    }
  }

  const query = params.toString()
  return `${hostPath}${query ? `?${query}` : ''}${hash ? `#${hash}` : ''}`
}

const safeEnv = (key: string) =>
  typeof process !== 'undefined' ? process.env?.[key] : undefined

// Treat the common falsy spellings as "off", not just the exact string 'false'.
const isFalsy = (val?: string) =>
  ['false', '0', 'no', 'off'].includes((val ?? '').trim().toLowerCase())

if (isFalsy(safeEnv('FMHY_BUILD_NSFW'))) {
  meta.build.nsfw = false
}
if (isFalsy(safeEnv('FMHY_BUILD_API'))) {
  meta.build.api = false
}

const formatCommitRef = (commitRef: string) =>
  commitRef.slice(0, 8)

const cfStart = safeEnv('CF_PAGES_COMMIT_SHA')
const commitStart = safeEnv('COMMIT_REF')

export const commitRef =
  safeEnv('CF_PAGES') && cfStart
    ? formatCommitRef(cfStart)
    : commitStart
      ? formatCommitRef(commitStart)
      : 'dev'

export const feedback = `<a href="/feedback" class="feedback-footer">Made with ❤</a>`


export const nav: DefaultTheme.NavItem[] = [
  { text: '📚 Beginners Guide', link: '/beginners-guide' },
  { text: '📑 Changelog', link: '/posts/changelog-sites' },
  {
    text: '🛠️ Tools',
    items: [
      { text: '🔎 Nexora Search', link: '/posts/search' },
      { text: '🚀 Startpage', link: '/startpage' },
      { text: '🇸 SearXNG', link: 'https://searx.fmhy.net/' },
      { text: '🛡️ SafeGuard', link: 'https://github.com/fmhy/FMHY-SafeGuard' },
      {
        text: '🔖 Bookmarks',
        link: 'https://github.com/mian196/fmhy-bookmarks-extension'
      },
      { text: '🖥️ Selfhosting', link: '/other/selfhosting' }
    ]
  },
  {
    text: '➕ More',
    items: [
      { text: '❓ FAQs', link: '/other/FAQ' },
      { text: '🤝 Contributing', link: '/other/contributing' },
      { text: '💬 Feedback', link: '/feedback' },
      { text: '💾 Backups', link: '/other/backups' },
      { text: '📖 Piracy Glossary', link: 'https://fluffle.cc/piracyglossary' },
      { text: '🎨 Wallpapers', link: '/other/wallpapers' },
    ]
  }
]

export const sidebar: DefaultTheme.Sidebar | DefaultTheme.NavItemWithLink[] = [
  {
    text: '<span class="i-twemoji:books"></span> Beginners Guide',
    link: '/beginners-guide'
  },
  {
    text: '<span class="i-twemoji:newspaper"></span> Posts',
    link: '/posts'
  },
  {
    text: '<span class="i-twemoji:light-bulb"></span> Contribute',
    link: '/other/contributing'
  },
  {
    text: 'Wiki',
    collapsed: false,
    items: [
      {
        text: '<span class="i-twemoji:name-badge"></span> Adblocking / Privacy',
        link: '/privacy'
      },
      {
        text: '<span class="i-twemoji:robot"></span> Artificial Intelligence',
        link: '/ai'
      },
      {
        text: '<span class="i-twemoji:television"></span> Movies / TV / Anime',
        link: '/video'
      },
      {
        text: '<span class="i-twemoji:musical-note"></span> Music / Podcasts / Radio',
        link: '/audio'
      },
      {
        text: '<span class="i-twemoji:video-game"></span> Gaming / Emulation',
        link: '/gaming'
      },
      {
        text: '<span class="i-twemoji:green-book"></span> Books / Comics / Manga',
        link: '/reading'
      },
      {
        text: '<span class="i-twemoji:floppy-disk"></span> Downloading',
        link: '/downloading'
      },
      {
        text: '<span class="i-twemoji:cyclone"></span> Torrenting',
        link: '/torrenting'
      },
      {
        text: '<span class="i-twemoji:brain"></span> Educational',
        link: '/educational'
      },
      {
        text: '<span class="i-twemoji:mobile-phone"></span> Android / iOS',
        link: '/mobile'
      },
      {
        text: '<span class="i-twemoji:penguin"></span> Linux / macOS',
        link: '/linux-macos'
      },
      {
        text: '<span class="i-twemoji:globe-showing-asia-australia"></span> Non-English',
        link: '/non-english'
      },
      {
        text: '<span class="i-twemoji:file-folder"></span> Miscellaneous',
        link: '/misc'
      }
    ]
  },
  {
    text: 'Tools',
    collapsed: false,
    items: [
      {
        text: '<span class="i-twemoji:laptop"></span> System Tools',
        link: '/system-tools'
      },
      {
        text: '<span class="i-twemoji:card-file-box"></span> File Tools',
        link: '/file-tools'
      },
      {
        text: '<span class="i-twemoji:paperclip"></span> Internet Tools',
        link: '/internet-tools'
      },
      {
        text: '<span class="i-twemoji:left-speech-bubble"></span> Social Media Tools',
        link: '/social-media-tools'
      },
      {
        text: '<span class="i-twemoji:memo"></span> Text Tools',
        link: '/text-tools'
      },
      {
        text: '<span class="i-twemoji:alien-monster"></span> Gaming Tools',
        link: '/gaming-tools'
      },
      {
        text: '<span class="i-twemoji:camera"></span> Image Tools',
        link: '/image-tools'
      },
      {
        text: '<span class="i-twemoji:videocassette"></span> Video Tools',
        link: '/video-tools'
      },
      {
        text: '<span class="i-twemoji:speaker-high-volume"></span> Audio Tools',
        link: '/audio#audio-tools'
      },
      {
        text: '<span class="i-twemoji:red-apple"></span> Educational Tools',
        link: '/educational#educational-tools'
      },
      {
        text: '<span class="i-twemoji:man-technologist"></span> Developer Tools',
        link: '/developer-tools'
      }
    ]
  },
  {
    text: 'More',
    collapsed: true,
    items: [
      meta.build.nsfw
        ? {
            text: '<span class="i-twemoji:no-one-under-eighteen"></span> NSFW',
            link: 'https://rentry.org/NSFW-Checkpoint'
          }
        : {},
      {
        text: '<span class="i-twemoji:warning"></span> Unsafe Sites',
        link: '/unsafe'
      },
      {
        text: '<span class="i-twemoji:wastebasket"></span> Recently Removed',
        link: '/recently-removed'
      },
      {
        text: '<span class="i-twemoji:package"></span> Storage',
        link: '/storage'
      }
    ]
  }
]
