#### Limit Bypass Note

Apple only allows you to sideload 3 apps (including SideStore) using a free Apple Account. To bypass this limit on SideStore, you can use [SparseBox](https://docs.sidestore.io/docs/advanced/alternative#sidestore-exploits) / [Guide](https://docs.sidestore.io/docs/advanced/alternative#sidestore-exploits) (iOS 17.0 - 18.1 Beta 4, not including 17.7.1, 17.7.2) or [LiveContainer](https://github.com/LiveContainer/LiveContainer) / [2](https://github.com/LiveContainerMirror/LiveContainer/) (iOS 16+).
