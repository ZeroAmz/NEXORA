***
***
**[◄◄ Back to Wiki Index](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/tools-index)**
***
***

# ► Social Media Tools

* 🌐 **[Disroot](https://disroot.org/en/services)**, [Hoffnung für die Zukunft](https://hoffnungfuerdiezukunft.net/) / [2](https://evilasswebsite.com/), [⁠Radical Servers](https://help.riseup.net/en/security/resources/radical-servers), [canine.tools](https://canine.tools/services), [4d2](https://4d2.org/), [bloat.cat](https://bloat.cat/), [⁠NerdVPN](https://nerdvpn.de/), [⁠Privacy Redirect](https://privacyredirect.com/), [⁠Nadeko](https://nadeko.net/), [⁠Meowing](https://meowing.de/) or [adminForge](https://adminforge.de/#services)- Frontend Indexes
* ↪️ **[Chat / Forum Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_chat_.2F_forums)**
* ↪️ **[Android](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android/#wiki_.25B7_social_media_apps)** / **[iOS](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android/#wiki_.25B7_social_media_apps2)** - Mobile Social Media Apps
* ⭐ **[GrayJay](https://grayjay.app/)** - YouTube, Twitch, Rumble, etc. / [Guide](https://youtu.be/EnZrv37u66c) / [Plugins](https://plugins.grayjay.app/) / [Add Platforms](https://grayjay-sources.github.io/), [2](https://github.com/grayjay-sources/grayjay-sources.github.io), [3](https://gitlab.futo.org/videostreaming/plugins) / [GitLab](https://gitlab.futo.org/videostreaming/grayjay)
* ⭐ **[SocialBlade](https://socialblade.com/)** - Social Media Stats
* ⭐ **[LiveCounts](https://livecounts.io/)** - Live Social Media Stats
* ⭐ **[LibRedirect](https://github.com/libredirect/browser_extension)**, [Predirect](https://github.com/libreom/predirect) or [Proxy Redirect](https://openuserjs.org/scripts/sjehuda/Proxy_Redirect) - Frontend Redirect Extensions
* [Numblr](https://github.com/heyLu/numblr) - Self-Hosted Frontend Redirect
* [Pinless](https://pinterest.bunk.im/), [2](https://pinterest.fsky.io/) / [Instances](https://instances.bunk.im/) / [.onion](http://pinvnrvjzyxdglrfcf75bhqyftmr3c4gvt6lwhe6khwv2zy2yo4htlqd.onion/) / [GitHub](https://github.com/bunk-im/pinless), [⁠PinLite](https://pinlite.app/) or [Binternet](https://github.com/Ahwxorg/Binternet) - Pinterest Frontends / Viewers
* [⁠Pinterest Power Menu](https://github.com/Angel2mp3/Pinterest-Power-Menu) - Pinterest Improvement Script
* [⁠grapper](https://grapper.gab.net.eu.org/) - Vine Video Archive / Username Required
* [Social-Searcher](https://www.social-searcher.com/) or [WeVerify](https://cse.google.com/cse?cx=006976128084956795641:ad1xj14zfap) - Social Media Search Engines
* [Social Media Hacker List](https://github.com/MobileFirstLLC/social-media-hacker-list) - Social Media Apps / Tools
* [ExportComments](https://exportcomments.com/) - Export Social Media Comments
* [socid_extractor](https://github.com/soxoj/socid-extractor) - Extract Social Media User Info from Pages
* [BlackTwist](https://www.blacktwist.app/) - Free Threads Analytics
* [Schedul](https://www.schedulethreads.com/) - Threads Content Publishing & Scheduling
* [PixelHunter](https://pixelhunter.io/) or [⁠Dropmatico](https://dropmatico.com/app) - Social Media Image Resizer
* [CleanSnap](https://www.cleansnap.co/) - Customize Social Media Screenshots

***

# ► Discord Tools

* **Warning** - Chat archivers, mass-deleters, mods, and third-party clients can potentially break Discord's terms of service. Misusing them can lead to account terminations, so use them at your own risk.

***

* ↪️ **[Chat Clients / Discord Alts](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools#wiki_.25B7_chat_tools)**
* ⭐ **[embedez](https://embedez.com/)** / [X](https://x.com/embedez) / [Discord](https://discord.gg/FmW9c8gtCp) or [FxEmbed](https://github.com/FxEmbed/FxEmbed) - Social Link Embedders
* ⭐ **[Disblock Origin](https://codeberg.org/AllPurposeMat/Disblock-Origin)** or [Discord Adblock](https://codeberg.org/ridge/Discord-AdBlock) - Hide Nitro + Boost Ads
* ⭐ **[OpenAsar](https://openasar.dev/)** - Better Performance with Improved `app.asar` / [Discord](https://discord.gg/YDMptE8u2b) / [GitHub](https://github.com/GooseMod/OpenAsar) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/openasar.md)
* [⁠Nelly](https://nelly.tools/) or [Discorder](https://discorder.tools/) - Discord Web Tools
* [Discord Markdown](https://discord-md.vercel.app/) - Discord Markdown / Formatting Guide / [GitHub](https://github.com/Hacksore/discord-md)
* [Discorch](https://discorch.org/) / [Source Code](https://codeberg.org/discorch/discorch), [CordWipe](https://github.com/avizmarlon/cordwipe) or [Discrub](https://github.com/prathercc/discrub) - Message Manipulation Tools / Always Delay 9+ Seconds
* [AnswersOverflow](https://www.answeroverflow.com/) - Discord Search Engine / [GitHub](https://github.com/AnswerOverflow/AnswerOverflow)
* [Discord Profile Viewer](https://addynrpfp.vercel.app/) - View / Download Discord User's Avatar or Banner
* [Discord Chat Exporter](https://github.com/Tyrrrz/DiscordChatExporter) / [Python](https://github.com/mahtoid/DiscordChatExporterPy) or [Discord History Tracker](https://dht.chylex.com/) / [GitHub](https://github.com/chylex/Discord-History-Tracker) - Archive / Export Discord Chats
* [Wumpus Central](https://discord.gg/zZ6szdKQu6) - Discord Experimental Server Hub
* [SimpleDiscordCrypt](https://gitlab.com/An0/SimpleDiscordCrypt) - Discord Message Encryption / [Discord](https://discord.gg/rSUyXeCHBE)
* [⁠ShrinkCord](https://github.com/isaac4096/shrink-cord) - Web Discord Video Compression Extension
* [dsc.gg](https://dsc.gg/) - Create Custom Discord Invites
* [instaparty](https://instaparty.gg/) - Temporary Discord Servers
* [Discord Templates](https://discordtemplates.me/) - Discord Server Templates
* [discord-badges](https://github.com/mezotv/discord-badges) - Discord Badge Info
* [Discord Previews](https://discordpreviews.com/) - Experimental Discord Features / [X](https://x.com/discordpreviews) / [Discord](https://discord.gg/discord-603970300668805120)
* [Discord-Api](https://discord.gg/discord-api) - Discord API Chat
* [Discord-Datamining](https://github.com/Discord-Datamining/Discord-Datamining) - Discord Datamining via JS Files
* [Discord TTS Bot](https://docs.moonstar-x.dev/discord-tts-bot/) - Text to Speech for Discord
* [⁠WebP-Conv](https://webp-conv.pages.dev/) - Video To WebP Converter
* [Embed Visualizer](https://embed.discord.website/) or [EB](https://eb.nadeko.bot/) - Preview Embeds
* [Useful Embed Index](https://gist.github.com/mohsreg/927bf8b2092515ee1a8ee88c3e4d2c14) - Social Media Embed Index
* [BetterTwitFix](https://github.com/dylanpdx/BetterTwitFix) - Fix X.com / Telegram Embeds
* [axinstagram](https://axinstagram.com/) / [GitHub](https://github.com/edideaur/axinstagram/) or [⁠OGInstagram](https://oginstagram.com/) / [GitHub](https://github.com/seirenkr/OGInstagram) - Fix Instagram Embeds
* [⁠fxTikTok](https://github.com/okdargy/fxTikTok) - Fix TikTok Embeds
* [Discord Packages](https://github.com/peterhanania/discord-package) - View Discord Packages / Set Account Language English / Self-Host for Privacy / [Discord](https://discordpackage.com/discord)
* [Hammertime](https://hammertime.cyou/), [Dank.tools](https://dank.tools/discord-timestamp), [⁠DiscTimestamps](https://disctimestamps.com/), [discordtimestampgenerator.net](https://discordtimestampgenerator.net/) or [discord-timestamps](https://r.3v.fi/discord-timestamps/) - Discord Timestamp Generators
* [TagMap](https://tagmap.io/) - Meet People with Similar Interests

***

## ▷ Discord Clients

* 🌐 **[Discord3rdParties](https://github.com/Discord-Client-Encyclopedia-Management/Discord3rdparties)** - Discord Clients Index
* ⭐ **[Vencord](https://vencord.dev/)** / [Custom Plugins](https://docs.vencord.dev/installing/custom-plugins/) / [Discord](https://discord.gg/D9uwnFnqmd) / [GitHub](https://github.com/Vendicated/Vencord) or [Vesktop](https://vesktop.dev/) / [GitHub](https://github.com/Vencord/Vesktop) - Discord Client Mod / [Plugins](https://vencord.dev/plugins)
* ⭐ **[Equicord](https://equicord.org)** / [Discord](https://discord.gg/5Xh2W87egW) / [GitHub](https://github.com/Equicord/Equicord) or [⁠Equibop](https://equibop.org/) / [GitHub](https://github.com/Equicord/Equibop) - Discord Client Mod / [Plugins](https://equicord.org/plugins)
* ⭐ **[WebCord](https://github.com/SpacingBat3/WebCord)** - Privacy-Hardened Client / [Discord](https://discord.gg/aw7WbDMua5)
* [Legcord](https://legcord.app/) - Discord Client / [Privacy-Fork](https://github.com/Milkshiift/GoofCord) / [Discord](https://discord.gg/TnhxcqynZ2) / [GitHub](https://github.com/Legcord/Legcord)
* [Replugged](https://replugged.dev/) - Discord Client Mod / [Discord](https://discord.gg/HnYFUhv4x4) / [GitHub](https://github.com/replugged-org/replugged)
* [BetterDiscord](https://betterdiscord.app/) - Discord Client Mod / [Plugins](https://betterdiscord.app/plugins) / [Banned Plugins](https://rentry.co/BDBannedPlugins) / [Discord](https://discord.gg/0Tmfo5ZbORCRqbAd) / [GitHub](https://github.com/BetterDiscord/BetterDiscord)
* [Discordo](https://github.com/ayn2op/discordo) - Discord Terminal Client
* [Dorion](https://spikehd.dev/projects/dorion/) - Discord Client Mod / [GitHub](https://github.com/SpikeHD/Dorion)
* [⁠Concord](https://github.com/chojs23/concord) - Discord TUI
* [Spacebar](https://github.com/spacebarchat/spacebarchat) - Self-Hosted / [Discord Compatible](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/spacebar.md)
* [Dissent](https://github.com/diamondburned/dissent) - GTK4 Discord Client
* [Discord Portable](https://portapps.io/app/discord-portable/) / [PTB PortApps](https://portapps.io/app/discord-ptb-portable/) - Portable Discord Stable

***

## ▷ Client Customization

* 🌐 **[Client Themes](https://betterdiscord.app/themes)** or [Discord Themes](https://github.com/topics/discord-theme) - Client Theme Index
* ⭐ **[Discohook](https://discohook.app/)**, [Embed Creator](https://embed.dan.onl/) or [Embed Generator](https://message.style/) - Embed Generators
* ⭐ **[CustomRP](https://www.customrp.xyz/)** / [GitHub](https://github.com/maximmax42/Discord-CustomRP) or [geetRPCS](https://geetrpcs.vercel.app/) / [GitHub](https://github.com/makcrtve/geetRPCS) - Customizable Rich Presence
* [BD Editor](https://bdeditor.dev/) - Client Theme Editor
* [Overlayed](https://overlayed.dev/) / [GitHub](https://github.com/overlayeddev/overlayed) or [⁠Orbolay](https://github.com/SpikeHD/Orbolay) - Alternative Discord Overlays
* [Coloured-Text-Generator](https://rebane2001.com/discord-colored-text-generator/) - Discord ANSI Text Generator
* [Auto Creavite](https://auto.creavite.co/icons) - Animated Icon / Banner Generator
* [Discord Avatar Maker](https://discord-avatar-maker.app/) - Discord Avatar Creator
* [Better Default Discord](https://better-default-discord.netlify.app/) - Improved Default Discord Avatars
* [Pfps.gg](https://pfps.gg/) - Find Discord Avatars
* [USRBG](https://git.is-hardly.online/USRBG/USRBG) - Custom Discord Profile Backgrounds / [Discord](https://discord.gg/r59DjpaDHD)
* [Emoji List](https://discords.com/emoji-list), [Discadia (Emojis)](https://discadia.com/emojis/) or [emoji.gg](https://emoji.gg/) - Discord Emojis / GIFs
* [Discord-Emoji-Downloader](https://thatiemsz.github.io/Discord-Emoji-Downloader/) - Emoji Downloader
* [ImageClipboard](https://imageclipboard.com/) - Free Discord Nitro Emojis
* [Snowsgiving Icons & Emotes](https://web.archive.org/web/20230729100139/https://cdn.discordapp.com/attachments/689605845058715801/862281806820278292/Snow.zip) - Snowsgiving Event Icons / Emojis
* [Discord Text to Emoji](https://jtprince.com/discord/) - Convert Text to Discord Emojis
* [Stickers.gg](https://stickers.gg) - Free Discord Stickers
* [PreMiD](https://premid.app/) - Display Web Activity in Discord Status / [Discord](https://discord.premid.app/) / [GitHub](https://github.com/PreMiD/PreMiD)
* [Music Presence](https://musicpresence.app/), [2](https://musicpresence.app/) - Audio Player Rich Presence / [Discord](https://discord.com/invite/musicpresence) / [GitHub](https://github.com/ungive/discord-music-presence)
* [Jellyfin RPC](https://github.com/Radiicall/jellyfin-rpc) - Jellyfin Rich Presence
* [⁠YouTubeDiscordPresence](https://github.com/XFG16/YouTubeDiscordPresence) - YouTube Rich Presence
* [Adobe Discord RPC](https://github.com/teeteeteeteetee/adobe-discord-rpc) - Adobe Rich Presence
* [PS3 Rich](https://github.com/zorua98741/PS3-Rich-Presence-for-Discord) - PS3 Rich Presence
* [discord-vscode](https://marketplace.visualstudio.com/items?itemName=icrawl.discord-vscode) - VSCode Rich Presence / [GitHub](https://github.com/iCrawl/discord-vscode)

***

## ▷ Discord Bots

* ⭐ **[FreeStuff Bot](https://freestuffbot.xyz/)** - Free Games Alert Bot / [Telegram](https://t.me/freestuff_hub) / [Discord](https://discord.com/invite/WrnKKF8)
* [⁠Embedded](https://embedded.gallery/) / [Discord](https://discord.com/invite/Be9yDnBPBw), [FixEmbed](https://fixembed.app/) / [GitHub](https://github.com/kenhendricks00/FixEmbed) or [⁠Embed Fixer](https://github.com/seriaati/embed-fixer) - Discord Embed Fix Bots
* [esmBot](https://github.com/esmBot/esmBot) - Multi-Tool Discord Bot
* [NotQuiteNitro](https://nqn.blue/) - Discord Nitro Alternative
* [Kenku FM](https://www.kenku.fm/) - Listen Together / Listening Parties / [GitHub](https://github.com/owlbear-rodeo/kenku-fm)
* [fmbot](https://fm.bot/) - Discord Voice Chat Scrobbling
* [Chuu](https://github.com/ishwi/Chuu) - Last.fm Discord Bot
* [Craig](https://craig.chat/) - Voice Channel Recorder Bot / [Backup](https://craig.chat/giarc/)
* [MonitoRSS](https://monitorss.xyz/) or [ReadyBot](https://readybot.io/) - RSS Discord Bots
* [⁠appeal.gg](https://dashboard.appeal.gg/) - Server Ban Appeal Management Dashboard
* [Steambase Bot](https://steambase.io/tools/steam-discord-bot) - Steam Insights Bot
* [⁠Wispbyte](https://wispbyte.com/) - Free Discord Bot Server Hosting / 512MB RAM / 1GB Disk / Unlimited Bandwidth
* [Red Discordbot](https://github.com/Cog-Creators/Red-DiscordBot) or [Discord-Bot](https://github.com/CorwinDev/Discord-Bot) - Self-Hostable Discord Moderation Bots
* [Wickbot](https://wickbot.com/) - Discord Security Bot
* [⁠Internet Archival Bot](https://internet-archival.xyz/) - Discord Internet Archival Bot / [Discord](https://discord.gg/gzdhhZSmhm) / [GitHub](https://github.com/Pendonym/Internet-Archival-Bot)
* [⁠HoneyBot](https://eas.lol/honeybot) - Security / Anti-Spam / Anti-Scam Discord Bot
* [⁠Honeypot](https://discord.com/discovery/applications/1450060292716494940) - Auto-Ban Spam Bots using Dedicated Channel
* [Automod Config](https://docs.google.com/spreadsheets/d/1pUGVAARMBadmNqQW6cPKhSaT-uYDgQlRBnlQ9TMDXTI/edit#gid=730346323) - Automod Bot Config
* [Modmail](https://github.com/modmail-dev/modmail) - Discord Modmail Bot
* [Discord-Linux](https://discord-linux.com/) - Linux Container Bot

***

## ▷ Server / Bot Indexes

* 🌐 **[Discord Servers](https://discord.com/servers)** - Server Index
* 🌐 **[Disdex](https://disdex.io/)** - Server Index / [Discord](https://discord.gg/C5M7ZGHDhH)
* 🌐 **[Alternatives to MEE6](https://alternativestomee6.com/)** - MEE6 Alternatives
* [GuildFinder](https://www.guildfinder.org/) - Server Index
* [DISBOARD](https://disboard.org/) - Server Index
* [Discords.com](https://discords.com/) - Server / Bot Index
* [Discord Me](https://discord.me/) - Server / Bot Index
* [DiscordServers.com](https://discordservers.com/) - Server / Bot Index
* [Disforge](https://discordservers.io/) - Server / Bot Index
* [Open Source Projects](https://discord.com/open-source) - Server / Bot Index
* [Top.gg](https://top.gg/) - Bot Index
* [Bots on Discord](https://bots.ondiscord.xyz/) - Bot Index
* [Discord Bots](https://discord.bots.gg/) - Bot Index
* [Discord Bot List](https://discordbotlist.com/) - Bot Index
* [Botlist.me](https://botlist.me/) - Bot Index
* [Void Bots](https://voidbots.net/) - Bot Index

***

# ► Reddit Tools

* 🌐 **[⁠B0tRank](https://www.botrank.net/)** - Reddit Bot Database
* ⭐ **[Reddit Stream](https://reddit-stream.com/)** - Live Thread Viewer
* ⭐ **[Reddit Enhancement Suite](https://redditenhancementsuite.com/)** / [GitHub](https://github.com/honestbleeps/Reddit-Enhancement-Suite), [Reddit++](https://greasyfork.org/en/scripts/490046), [Reddit Fix](https://greasyfork.org/en/scripts/404497-reddit-fix), [Reddit Extension](https://lindseysim.com/p/reddit-extension), [RedditEnhancer](https://github.com/joelacus/RedditEnhancer) or [RedditMod2](https://greasyfork.org/en/scripts/29724-redditmod2) - Reddit Enhancement Extensions / Scripts
* ⭐ **[Redlib](https://github.com/redlib-org/redlib-instances/blob/main/instances.md)** / [2](https://github.com/libreddit/libreddit-instances/blob/master/instances.md) - Reddit Frontends / Viewers
* ⭐ **[Old Reddit Redirect](https://github.com/tom-james-watson/old-reddit-redirect)** or [Teamdoko Old Reddit](https://teamdoko.com/products/old-reddit-for-safari) - Redirect New Reddit to Old
* ⭐ **[Newsit](https://newsit.benwinding.com/)** - Webpage Comments Widget / [GitHub](https://github.com/benwinding/newsit)
* [Redditp](https://redditp.com/) or [Reddit Viewer](https://reddit-viewer.com/) - Reddit TikTok Style Viewers
* [Beleave](https://beleave.virock.org/) or [SubCleaner](https://www.subcleaner.com/) - Subreddit Cleaners / Managers
* [Bookmarkeddit](https://bookmarkeddit.com/) - Saved Post Manager / Organizer / [GitHub](https://github.com/mateussilva98/bookmarkeddit) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/bookmarkeddit.md)
* [Reddit Sub Counter](https://greasyfork.org/en/scripts/567501) - Restore Subreddit Subscriber Counter
* [Reddit Comber](https://redditcomber.com/) or [Sub Notification](https://redd.it/5mz9z5) - Reddit Keyword Notifications
* [Reddit Preview](https://redditpreview.com/) - Preview Reddit Posts
* [RedditRaffler](https://www.redditraffler.com/) - Reddit Raffle System
* [⁠SubHarbor](https://subharbor.com/) - Subreddit Backup Pages
* [PowerDeleteSuite](https://github.com/j0be/PowerDeleteSuite) - Reddit Auto Post Delete
* [SnooSnoop](https://snoosnoop.com/) - Reddit Account Analyzer
* [⁠Reddit Migrate](https://github.com/nileshnk/reddit-migrate) - Reddit Account Migrator
* [Reddit Emojis](https://greasyfork.org/en/scripts/443011) - Emojis for Old Reddit
* [Subreddit Tabs](https://greasyfork.org/en/scripts/460086) - Subreddit Icon Tabs
* [⁠Sink It](https://gosinkit.com/) - Improved Reddit Comment Navigation
* [Reddit Comment Highlights](https://github.com/aesy/reddit-comment-highlights) - Highlight New Comments
* [infini.wtf](https://infini.wtf/) - Reddit Image Search
* [Load Reddit Images Directly](https://github.com/nopperl/load-reddit-images-directly) - Direct Image Viewer
* [UniversalScammerList](https://www.universalscammerlist.com/) - List of Reddit Scammers
* [⁠lurker](https://tangled.org/oppi.li/lurker) - Self-Hostable Read-Only Reddit Client

***

## ▷ Reddit Downloaders

* **Note** - You can also download Reddit videos by commenting: `/u/SaveVideo`.

***

* [gallery-dl](https://codeberg.org/mikf/gallery-dl) - Reddit Bulk Image Downloader / [Discord](https://discord.gg/rSzQwRvGnE)
* [⁠Redvid](https://redvid.io/) - Reddit Media Downloader
* [RipMe](https://github.com/RipMeApp/ripme) - Reddit Media Downloader
* [RapidSave](https://rapidsave.com/) - Reddit Video / GIF Downloader

***

## ▷ Reddit Alternatives

* ↪️ **[Lemmy Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/social-media#wiki_.25B7_lemmy_tools)**
* [Raddle](https://raddle.me/) - Minimalist / Privacy-Focused
* [r/RedditAlternatives](https://reddit.com/r/RedditAlternatives) - Find Reddit Alternatives
* [Tildes](https://tildes.net/) - Non-Profit / User-Driven Discussion
* [Ramble](https://ramble.pw/) - Privacy-Focused
* [Discuit](https://discuit.org/) - Centralized Reddit Alt with User Control

***

## ▷ Reddit Search

* [Reveddit](https://www.reveddit.com/), [rOSINT+](https://rosintplus.vercel.app/), [Undelete](https://undelete.pullpush.io/), [⁠Reddit Restore](https://greasyfork.org/scripts/585120) (Userscript), [redditOSINT](https://www.rosint.dev/) / [GitHub](https://github.com/zuxu4n/RedditOsint), [Ghostddit](https://ghostddit.aeddit.com/) or [Reddit Uncensored](https://github.com/Fubs/reddit-uncensored) - View Deleted / Hidden Reddit Posts + Comments
* [New PullPush](https://ihsoyct.github.io/), [PullPush Search](https://search.pullpush.io/) or [Better Reddit Search](https://betterredditsearch.web.app/) - Advanced Reddit Search
* [Arctic Shift](https://arctic-shift.photon-reddit.com/) - Reddit Archive Dump Search / [GitHub](https://github.com/ArthurHeitmann/arctic_shift)
* [Reddit Dump Files](https://academictorrents.com/browse.php?search=stuck_in_the_matrix%2C+Watchful1%2C+RaiderBDev&sort_field=added&sort_dir=DESC) - Reddit Comment Archives
* [redarcs](https://the-eye.eu/redarcs/) - Reddit Pushshift Archives
* [⁠Reddit Answers](https://www.reddit.com/answers/) - Reddit Search Engine
* [rComments](https://github.com/iampueroo/rComments) - Explore Comments / Replies without Clicking a Post
* [ScrollDrop](https://scrolldrop.com/) - Reddit Media Crawler
* [Wiki Downloader](https://github.com/michealespinola/reddit.wikidownloader) - Reddit Wiki Page Scraper
* [Find on Reddit](https://chromewebstore.google.com/detail/find-on-reddit/jbcdpeekakanklckgooknpbonojhjncm) - Find Discussions of the Current URL

***

## ▷ Subreddit Discovery

* 🌐 **[r/ListOfSubreddits](https://www.reddit.com/r/ListOfSubreddits/)** - Subreddits Index
* ↪️ **[Multireddit Indexes](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_multireddits)**
* ⭐ **[Vizit](https://redditstuff.github.io/sna/vizit/)**, [sayit](https://anvaka.github.io/sayit/) or [SubredditMentionsGraph](https://dmarx.github.io/SubredditMentionsGraph/network/) - Visualize Related Subreddits
* [r/findareddit](https://www.reddit.com/r/findareddit/) - Get Subreddit Suggestions
* [Subreddit Calculator](https://trevor.shinyapps.io/subalgebra/) or [redsim](https://anvaka.github.io/redsim/) - Find Similar Subreddits
* [Map of Reddit](https://anvaka.github.io/map-of-reddit) - Subreddit Map
* [subreddits](https://subreddits.org/) - Find Random Subreddits
* [Subreddit Stats](https://subredditstats.com/) or [SubRanking](https://subranking.com/) - Subreddits Stats / Ranking

***

# ► Telegram Tools

* 🌐 **[TDirectory](https://tdirectory.me/)**, [Awesome Telegram](https://github.com/ebertti/awesome-telegram) or [TelegramChannels](https://telegramchannels.me/) - Telegram Channel Indexes
* 🌐 **[ComBot Groups](https://combot.org/top/telegram/groups)** - Top Telegram Groups Index
* [Telegago](https://cse.google.com/cse?&cx=006368593537057042503:efxu7xprihg#gsc.tab=0), [2](https://cse.google.com/cse?cx=006249643689853114236:a3iibfpwexa), [Lyzem](https://lyzem.com/), [xTea](https://xtea.io/ts_en.html) or [TG-ME](https://www.tg-me.com/) - Telegram CSEs
* [SaveRestrictedContentBot](https://github.com/vasusen-code/SaveRestrictedContentBot) - Save Restricted Content
* [Telesco.pe](https://telesco.pe/) - Telegram Round Video Recorder
* [TGCF](https://github.com/aahnik/tgcf) - Telegram Message Forwarding
* [TheFeedReaderBot](https://thefeedreaderbot.com/) - RSS Reader
* [tg-channel-cloner-workers](https://gitlab.com/ParveenBhadooOfficial/tg-channel-cloner-workers) - Clone Telegram Channels
* [tasra](https://the-eye.eu/tasra/) - Telegram Channel Archive
* [CHPic](https://chpic.su/), [Stickers Cloud](https://stickers.cloud/en), [⁠fstik](https://fstik.app/) or [ComBot Stickers](https://combot.org/stickers) - Telegram Stickers / Emojis

***

## ▷ Telegram Clients

* ⭐ **[AyuGram](https://docs.ayugram.one/downloads/)** - Desktop Client / Portable / [Chat](https://t.me/ayugramchat) / [Telegram](https://t.me/ayugram) / [GitHub](https://github.com/AyuGram/AyuGramDesktop)
* ⭐ **[Materialgram](https://kukuruzka165.github.io/materialgram/)** - Desktop Client / Portable / [GitHub](https://github.com/kukuruzka165/materialgram)
* ⭐ **[Unigram](https://github.com/UnigramDev/Unigram)** - Desktop Client
* [Forkgram](https://github.com/Forkgram/tdesktop) - Desktop Client
* [64Gram](https://github.com/TDesktop-x64/tdesktop) - Desktop Client / [Telegram](https://t.me/tg_x64)
* [VidoGram](https://vidogram.org/) - Desktop Client
* [VanillaTG](https://t.me/VanillaTG) - Client Themes

***

## ▷ Telegram File Tools

* [tdl](https://docs.iyear.me/tdl/) - File Download / Upload Tool / [GitHub](https://github.com/iyear/tdl)
* [File-Sharing-Bot](https://github.com/CodeXBotz/File-Sharing-Bot) / [Telegram](https://t.me/CodeXBotz), [easy_share_bot](https://t.me/easy_share_bot) or [UploadBot](https://t.me/uploadbot) - Upload Files to Telegram
* [TG-FileStreamBot](https://github.com/EverythingSuckz/TG-FileStreamBot) - Telegram File Streaming
* [WZML-X](https://github.com/SilentDemonSD/WZML-X), [⁠Quicksbot](https://t.me/quicksbot), [Telegram Media Downloader](https://greasyfork.org/en/scripts/446342), [TopSaverBot](https://t.me/TopSaverBot), [CatdlBot](https://t.me/CatdlBot) or [DownloadsMasterBot](https://t.me/DownloadsMasterBot) - Media Downloaders
* [Musvkrobot](https://t.me/musvkrobot) - Video Downloader
* [GdriveXbot](https://t.me/TheGdriveXBot) or [google-drive-telegram-bot](https://github.com/viperadnan-git/) - Google Drive Upload Bots
* [MEGA Uploader X](https://t.me/MegaUploadXbot) or [Mega-Bot](https://github.com/Itz-fork/Mega.nz-Bot) - Remote Mega File Upload Bot
* [OneDrive X](https://t.me/onedrivexbot) - Remote OneDrive File Upload Bot
* [telegram-download-daemon](https://github.com/alfem/telegram-download-daemon/) - Download Large Telegram Files
* [convrt_bot](https://t.me/convrt_bot), [FileConvertBot](https://t.me/FileConvertBot), [newfileconverterbot](https://t.me/newfileconverterbot) or [pdfbot](https://t.me/pdfbot) - File Converters
* [ILovePDF](https://github.com/nabilanavab/ilovepdf) - Telegram File to PDF Converter

***

## ▷ Telegram Bots

* 🌐 **[BotsArchive](https://t.me/BotsArchive)**, [TelegramBotsList](https://danyspin97.github.io/TelegramBotsList/) or [borodutch.eth](https://borodutch.com/) - Telegram Bots Indexes
* [⁠Wispbyte](https://wispbyte.com/) - Free Telegram Bot Server Hosting / 512MB RAM / 1GB Disk / Unlimited Bandwidth
* [Searchee Bot](https://t.me/SearcheeBot) - Telegram Channel Search Bot
* [Rose](https://t.me/MissRose_bot) or [GroupHelpBot](https://t.me/GroupHelpBot) - Telegram Group Managers
* [TediCross](https://github.com/TediCross/TediCross) - Telegram to Discord Bridge
* [WatgBridge](https://github.com/akshettrj/watgbridge) - Telegram to WhatsApp Bridge
* [Mautrix](https://github.com/mautrix/telegram) - Telegram to Matrix Bridge
* [Callmebot](https://www.callmebot.com/) - Trigger Voice Calls or Chats
* [Skeddy](https://skeddy.me/) - Telegram Reminder Bot
* [Reddit2Telegram](https://github.com/Fillll/reddit2telegram) - Reddit Post Bot
* [rss2tg_bot](https://t.me/rss2tg_bot) or [TheFeedReaderBot](https://t.me/TheFeedReaderBot) - RSS Feed Bots
* [ShortUrlBot](https://t.me/ShortUrlBot) - Link Shortener Bots
* [AiImageBot](https://t.me/AiImageBot) - Text to Image
* [Shieldy Bot](https://t.me/shieldy_bot) - Spam Protection Bot / [GitHub](https://github.com/1inch/shieldy)

***

# ► YouTube Tools

* ↪️ **[YouTube Ad + Sponsorblock](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_adblocking)**
* ⭐ **[PocketTube](https://pockettube.io/)** or [Kadium](https://kadium.kasper.space/) - Subscription Managers
* ⭐ **[LocalTube Manager](https://localtubemanager.pages.dev/)** - Subscribe, Like Videos, Make Playlists Locally without Account / [GitHub](https://github.com/abhishekY495/localtube-manager)
* [Youtube-shorts block](https://github.com/doma-itachi/Youtube-shorts-block) or [Shorts Deflector](https://evenevan.github.io/shorts-deflector/) / [GitHub](https://github.com/evenevan/shorts-deflector) - Play Shorts In The Normal Desktop Interface
* [Remove YouTube Shorts](https://addons.mozilla.org/en-US/firefox/addon/remove-youtube-shorts/) or [Hide YT Shorts Filter List](https://github.com/gijsdev/ublock-hide-yt-shorts) - Hide YouTube Shorts
* [YouTube Wrapped](https://videorecap.viewodyssey.com/) - Personal YouTube Rewind
* [YouTube-Subscriptions-RSS](https://github.com/jeb5/YouTube-Subscriptions-RSS) - Export Subscriptions to RSS Feed
* [YouTube Subscription History](https://xxluke.de/subscription-history/) - Subscription History Tracker
* [MassYoutubeUnsubscriber](https://github.com/DomHeadroom/MassYoutubeUnsubscriber) - Bulk Remove YouTube Subscriptions
* [YouTube Spammer Purge](https://github.com/ThioJoe/YT-Spammer-Purge) - Delete All YouTube Spam Comments / [Domain List](https://github.com/ThioJoe/YT-Spam-Lists)
* [YT Data Tools](https://ytdt.digitalmethods.net/) - ⁠YouTube Data Tools
* [Playboard](https://playboard.co) - YouTube Channel Stats
* [vidIQ](https://vidiq.com/extension/) - YouTube Viewership Data
* [⁠Thumbs Up](https://thumbsup.tv/) - Preview YouTube Thumbnails / Titles
* [yt2pod](https://github.com/frou/yt2pod) - Create Podcasts from YouTube Channels
* [SpeechChat](https://speechchat.com/) - Text to Speech Client
* [songs-to-youtube](https://github.com/7x11x13/songs-to-youtube) - Convert Audio Files and Upload to YouTube
* [YTSubConverter](https://github.com/arcusmaximus/YTSubConverter) - Styled YouTube Subtitles
* [Amara](https://amara.org/) or [SubtitlesForYoutube](https://github.com/yashagarwal1411/SubtitlesForYoutube) - Import Local Subtitles to YouTube / [Edge](https://microsoftedge.microsoft.com/addons/detail/subtitles-for-youtube/gfjcoflghpdkddjnpegonjhnbngeocfi)
* [ChatReplay](https://chatreplay.stream/) - Livestream Chat Replay
* [LiveTL](https://kentonishi.com/LiveTL/) - Livestream Chat Translator
* [YT Boost Chat](https://greasyfork.org/en/scripts/520755) or [YT RM3](https://greasyfork.org/en/scripts/521342) - Reduce YouTube Chat Memory Usage
* [YT LiveChat Flusher](https://github.com/ys-j/YoutubeLiveChatFlusher) - Add Bullet Chatting (Danmaku) to Livestreams

***

## ▷ YouTube Customization

* ⭐ **[Return YouTube Dislike](https://returnyoutubedislike.com/)** - View YouTube Dislikes / [Web App](https://haeri.github.io/youtube-dislike-viewer/) / [Discord](https://discord.com/invite/mYnESY4Md5)
* ⭐ **[DeArrow](https://dearrow.ajay.app/)** - Reduce Sensationalism / Clickbait
* ⭐ **[VORAPIS](https://vorapis.pages.dev/)** - Classic YouTube Layout / Increased Performance / [Extra Themes](https://github.com/lightbeam24/StarTube) / [Error Fix](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/vorapis.md) / [Discord](https://discord.com/invite/tBBZQMscag)
* [ImprovedTube](https://improvedtube.com/), [YouTube Alchemy](https://greasyfork.org/en/scripts/521686), [Tweaks for YT](https://inzk.dev/tweaks-for-youtube/), [Magic Actions](https://www.chromeactions.com/), [⁠Control Panel for YouTube](https://soitis.dev/control-panel-for-youtube) / [GitHub](https://github.com/insin/control-panel-for-youtube), [YouTube Tweaks](https://addons.mozilla.org/en-US/firefox/addon/youtube-tweaks/) / [Chrome](https://chrome.google.com/webstore/detail/youtube-tweaks/oeakphpfoaeggagmgphfejmfjbhjfhhh) or [Enhancer for YT](https://www.mrfdev.com/enhancer-for-youtube) - YouTube Enhancement Extensions
* [YouTube Hide Watched](https://github.com/EvHaus/youtube-hide-watched) - Toggle Visibility of Watched Videos / Shorts
* [TubeMod](https://github.com/Pedro-Gregorio/TubeMod), [Unhook](https://unhook.app/) or [Less Addictive YouTube](https://github.com/AlexisDrain/Less-Addictive-YouTube) - Distraction-Free YouTube
* [Thumbnail Rating Bar](https://github.com/elliotwaite/thumbnail-rating-bar-for-youtube) - Display Like / Dislike Ratio on Thumbnails
* [YT Like-Dislike Shortcut](https://github.com/avi12/youtube-like-dislike-shortcut) - Add Like / Dislike Hotkeys
* [YT: Not Interested](https://greasyfork.org/en/scripts/396936-yt-not-interested-in-one-click) - Show "Not Interested" and "Don't Recommend" Buttons
* [YouTube Search Fixer](https://phoennix.gitlab.io/youtubesearchfix/) - Declutter Search Results / Homepage
* [BlockTube](https://github.com/amitbl/blocktube) or [YTBlock](https://chromewebstore.google.com/detail/ytblock-block-any-content/nedcanggplmbbgmlpcjiafgjcpdimpea) - YouTube Content Blocker
* [YouTube Fixes](https://greasyfork.org/en/scripts/405614) - YouTube Tweaks
* [Restore Handle to Custom](https://greasyfork.org/en/scripts/468740) - Shows Display Name Instead of Handle
* [Focused YouTube](https://github.com/makaroni4/focused_youtube) or [yt-neuter](https://github.com/mchangrh/yt-neuter) - Minimalist YouTube
* [Non-Rounded Design](https://greasyfork.org/en/scripts/453802) - Revert YouTube's New Rounded Design
* [Timestamped YouTube Comments](https://chromewebstore.google.com/detail/timestamped-youtube-comme/gnpppldhfbbagiaalkddddajadhlgofm) - View Timestamped Comments
* [Tabview YouTube](https://greasyfork.org/en/scripts/501249) - View Comments / Info in Tab View
* [⁠Ambient Light](https://github.com/WesselKroos/youtube-ambilight) - Add Ambient Light to YouTube

***

## ▷ Players / Frontends

* ↪️ **[Android](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_android_youtube_apps)** / **[iOS](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_ios_youtube_apps)** - Mobile YouTube Apps
* ⭐ **[FreeTube](https://freetubeapp.io/)** / [GitHub](https://github.com/FreeTubeApp/FreeTube), [⁠OpenTubeX](https://opentubex.org/) / [GitHub](https://github.com/OpenTubeX/OpenTubeX) or [Flow Desktop](https://github.com/Flow-Tube/Flow-Desktop) - Desktop YouTube Apps 
* ⭐ **[Invidious](https://invidious.io/)** or [Materialious](https://materialio.us/) - YouTube Frontend / [Instances](https://api.invidious.io/), [2](https://redirect.invidious.io/) / [TUI](https://github.com/darkhz/invidtui) / [GitHub](https://github.com/iv-org/invidious/)
* ⭐ **[GrayJay](https://grayjay.app/)** - YouTube, Twitch, Rumble, etc. / [Guide](https://youtu.be/EnZrv37u66c) / [Plugins](https://plugins.grayjay.app/) / [Add Platforms](https://grayjay-sources.github.io/), [2](https://github.com/grayjay-sources/grayjay-sources.github.io), [3](https://gitlab.futo.org/videostreaming/plugins) / [GitLab](https://gitlab.futo.org/videostreaming/grayjay)
* [YouT-ube](https://www.yout-ube.com/) or [MUI Tube](https://muitube.com/) - Use YouTube Full Window Player / Bypass uBO Delay
* [YTCH](https://ytch.tv/), [Channel Surfer](https://channelsurfer.tv/) or [FreeTVz](https://freetvz.com/) - Random TV Style YouTube / Custom Channels
* [YouTube Notes](https://instadeq.com/youtube-notes/) - YouTube Note-Taking Frontend
* [Walrus](https://joinwalrus.tv/), [Sync-Tube](https://sync-tube.de/), [YouTube Party](https://youtubeparty.netlify.app/) or [Hergetto](https://hergetto.live/) - YouTube Watch Parties
* [TwitchTheater](https://twitchtheater.tv/), [VidGrid](https://vidgrid.tk.gg/), [YouTube Multiplier](https://www.youtubemultiplier.com/) or [ViewSync](https://viewsync.net/) - Watch Multiple YouTube Videos
* [TypeType](https://watch.typetype.video/), [2](https://typetype.video/) - YouTube Frontend / [GitHub](https://github.com/TypeType-Video/TypeType)
* [⁠FocusTube](https://focustube.mathy.li/) - YouTube Frontend / [GitHub](https://github.com/helbetmathias/focustube)
* [Piped](https://piped.private.coffee/) - YouTube Frontend / Requires Sign-Up / [GitHub](https://github.com/TeamPiped/Piped)
* [youtube-local](https://github.com/user234683/youtube-local) or [yt-local](https://git.sr.ht/~heckyel/yt-local) - YouTube Frontend
* [PKGA](https://greasyfork.org/en/scripts/442089) or [YouTube WideScreen](https://greasyfork.org/en/scripts/409893) - Improved YouTube Theater Mode
* [YouTube Cinema](https://greasyfork.org/en/scripts/585902) - Expand YouTube Player to Fill Viewport
* [YewTube](https://github.com/mps-youtube/yewtube) - Terminal YouTube Players
* [VacuumTube](https://github.com/shy1132/VacuumTube) - TV Version of YouTube on PC

***

## ▷ Video Tools

* ↪️ **[Video Adblockers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_adblocking)**
* ↪️ **[Video Transcribers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video/#wiki_.25BA_subtitle_tools)**
* ⭐ **[polsy.org.uk](https://polsy.org.uk/stuff/ytrestrict.cgi)** - Video Region Restriction Checker
* [⁠YouTube No Translation](https://youtube-no-translation.vercel.app/) - Disable YouTube Auto Translations / [GitHub](https://github.com/YouG-o/YouTube_No_Translation)
* [Video Resumer](https://addons.mozilla.org/en-US/firefox/addon/video-resumer/) - Remembers Where You Left Off in Video
* [Jump Cutter](https://github.com/WofWca/jumpcutter) - Skip Silent Parts of Videos
* [Rotate YouTube Video](https://addons.mozilla.org/en-US/firefox/addon/rotate-youtube-video/) - Rotate, Zoom, & Mirror Videos
* [YouTube Upload Time](https://chromewebstore.google.com/detail/youtube-upload-time/nenoecmaibjcahoahnmeinahlapheblg) - Check Exact Upload Time/Date of Videos
* [Annotations Data Archive](https://archive.org/details/youtubeannotations) - Restore Video Annotations
* [YouTube Metadata](https://mattw.io/youtube-metadata/) - YouTube Video Metadata Viewer
* [YTCliply](https://ytcliply.com/) or [yt_clipper](https://github.com/exwm/yt_clipper) - Crop YouTube Videos / Create Clips
* [Looptube](https://www.looptube.xyz/) - Loop YouTube Videos / Segments
* [YourCodecs](https://github.com/undecV/YourCodecs) - Enable / Disable Player Codecs

***

## ▷ Playlist Tools

* ⭐ **[playlists.at](https://playlists.at/)** - Playlist Creators / [Chrome Extension](https://chromewebstore.google.com/detail/drag-drop-playlist-creato/aklnkkbopjjemjlkffhamaepagbmblbg)
* [TubeSync](https://github.com/meeb/tubesync) - Sync YouTube Channels / Playlists to a Media Server
* [ytcc](https://github.com/woefe/ytcc) - Keep Track of Your Playlists
* [Multiselect (Firefox)](https://addons.mozilla.org/en-US/firefox/addon/multiselect-for-youtube/) or [Multiselect (Chrome)](https://chromewebstore.google.com/detail/gpgbiinpmelaihndlegbgfkmnpofgfei) - Playlist Manager
* [Export YT Playlists](https://export-youtube-playlist.vercel.app/) or [⁠Export YouTube Playlist](https://exportyoutubeplaylist.com/) - Export Playlists to Excel, CSV, Text or Bookmark HTML ⁠
* [Playlist Randomizer](https://playlist-randomizer.com/) - YouTube Playlist Randomizer
* [playlist.tools](https://playlist.tools/) - Reverse YouTube Playlists
* [YT Playlist Length](https://ytplaylist-len.sharats.dev/) or [Length Checker](https://youtube-playlist-length-calculator.onrender.com/) - Playlist Length Checkers
* [YouTubePlaylistMerge](https://rentry.org/YouTubePlaylistMerge) - Playlist Merge Guide
* [⁠YouTube Auto-Pause Bypass](https://greasyfork.org/en/scripts/568818) - Prevents YouTube Playlist Auto-Pausing

***

## ▷ YouTube Downloaders

* 🌐 **[YT-DL GUI Index](https://www.reddit.com/r/youtubedl/wiki/info-guis)** - List of YouTube Downloader GUIs
* ↪️ **[Multi-Site Downloaders](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video-tools#wiki_.25BA_video_download)**
* ⭐ **[Parabolic](https://github.com/NickvisionApps/Parabolic)**, [Tartube](https://tartube.sourceforge.io/) / [GitHub](https://github.com/axcore/tartube/), [yt-dlp-gui](https://github.com/kannagi0303/yt-dlp-gui-v2), [ytdlp-interface](https://github.com/ErrorFlynn/ytdlp-interface) or [Vividl](https://github.com/Bluegrams/Vividl) - YT-DLP GUIs
* ⭐ **[JDownloader](https://jdownloader.org/)** - YouTube Downloader App
* ⭐ **[yt-dlp](https://github.com/yt-dlp/yt-dlp)** / [Commands](https://github.com/TheFrenchGhosty/TheFrenchGhostys-Ultimate-YouTube-DL-Scripts-Collection) / [Discord](https://discord.gg/H5MNcFW63r) or [YTDL-PATCHED](https://github.com/ytdl-patched/ytdl-patched) - YT-DL CLIs / TUIs
* ⭐ **[YoutubeDownloader](https://github.com/Tyrrrz/YoutubeDownloader)** - YouTube Downloader App
* [Stacher](https://stacher.io/), [Cube YouTube Downloader](https://github.com/database64128/youtube-dl-wpf) or [Open Video Downloader](https://github.com/jely2002/youtube-dl-gui) - YT-DL GUIs
* [⁠YT1s](https://yt1s.com.co/) or [CNVMP3](https://cnvmp3.com/) / [Subreddit](https://www.reddit.com/r/cnvmp3) - Online YT-DL Downloaders
* [⁠Wayback YouTube](https://www.waybackyt.download/) - Download Deleted YouTube Videos via Wayback Machine
* [Pinchflat](https://github.com/kieraneglin/pinchflat), [MeTube](https://github.com/alexta69/metube), [Downtify](https://github.com/henriquesebastiao/downtify), [YoutubeDL-Material](https://github.com/Tzahi12345/YoutubeDL-Material) or [yt-dlp Web UI](https://github.com/marcopiovanello/yt-dlp-web-ui) - Self-Hosted YT-DLP
* [ytarchive](https://github.com/Kethsar/ytarchive) - YouTube Livestream Downloader
* [Tube All Images](https://imageyoutube.com/) - Download YouTube Images
* [YTThumbnailHD](https://ytthumbnailhd.com/), [ThumbnailDownloader](https://www.thumbnaildownloader.art/) or [YT Thumbnail Grabber](https://youtube-thumbnail-grabber.com/) - Download Video Thumbnails
* [youtube-comment-downloader](https://github.com/egbertbouman/youtube-comment-downloader) - Download YouTube Comments
* [⁠ytsubdl](https://ytsubdl.com/) - Extract Subtitles/Transcript from YouTube Videos

***

## ▷ YouTube Search

* 🌐 **[YT Channel Spreadsheet](https://docs.google.com/spreadsheets/d/1xZm5BcQTYJx8sfSuqHExHtIOPtSfod8beHKtYzp8DxE/)** or **[YouTube_Channels](https://github.com/PrejudiceNeutrino/YouTube_Channels)** - YouTube Channel Indexes
* ⭐ **[Favoree](https://www.favoree.io/)** - Discover / Search YouTube Channels
* ⭐ **[YouTube Advanced Search](https://playlists.at/youtube/search/)** - Search Engine
* ⭐ **[Filmot](https://filmot.com/)** or [CTRL-F-VIDEO](https://github.com/Evan-Wildenhain/CTRL-F-VIDEO) - Search within YouTube Subs, Captions & Transcripts / [Firefox](https://addons.mozilla.org/en-US/firefox/addon/youtube-captions-search/) / [Chrome](https://chromewebstore.google.com/detail/youtube-captions-search/kimbeggjgnmckoikpckibeoaocafcpbg)
* [comb.io](https://comb.io/), [clip.cafe](https://clip.cafe/), [InPhrase](https://inphrase.com/) or [Yarn](https://yarn.co/) - Clip / Phrase Search Engines
* [YT Non Biased Searcher](https://kvnaust.github.io/YouTube-NonBiasedVideoSearcher) - Algorithm-Free YouTube Search / Improved Sorting
* [⁠YouTube Metadata Search](https://youtube.snivy.pl/) - ⁠YouTube Metadata Search
* [yt-fts](https://github.com/NotJoeMartinez/yt-fts) - Full-Text Search of Subtitles from Channels / Videos
* [Icono](https://www.icono-search.com/) - Description-Based Video Search / [Discord](https://discord.gg/RWv7bGKwHr)
* [⁠LikeSearch](https://likesearch.kaustlabs.com/) - Search Your Liked YouTube Videos
* [⁠HackerTube](https://hackertube.org/) - Educational YouTube Videos
* [MW Geofind](https://mattw.io/youtube-geofind/location) or [TubeTrotter](https://www.tubetrotter.live/) - Find Geotagged Videos
* [YT Comment Viewer](https://commentviewer.com/) / [GitHub](https://github.com/sameerdash2/comment-viewer), [CommentShark](https://www.commentshark.com/youtube-comment-searcher), [Hadzy](https://hadzy.com/) or [YCF](https://ytcomment.kmcat.uk/) - Comment Search / View Censored Comments
* [Tokin](https://tokin.tv/) - Find Trending / Hidden Gem Videos
* [IMG_0001](https://walzr.com/IMG_0001), [Gloria o Devoto](https://gloriaodevoto.vercel.app/) or [Random Video](https://random-video.com/) - Find Random / Obscure YouTube Videos
* [YouTube’s Recycle Bin](https://docs.google.com/document/d/1mV5PhumaIJ8mtH8XmohqXkk5fjK_HlqcineMccPQm5A/) / [X](https://x.com/MingKasterMK/), [Project Random](https://0xbeef.co.uk/random), [ObscureTube](https://obscuretube.com/) or [petittube](https://petittube.com/fullscreen.php) - Find Videos with <100 Views

***

## ▷ YouTube Archiving

* ⭐ **[YouTube Video Finder](https://findyoutubevideo.thetechrobo.ca/)** / [GitHub](https://github.com/TheTechRobo/youtubevideofinder/) or [⁠Archivarix](https://archivarix.net/) - Multi-Archive Search Engines
* [Tubeup](https://github.com/bibanon/tubeup) - YouTube Video to IA Uploader
* [Tube Archivist](https://www.tubearchivist.com/) - Self-Hosted YouTube Media Server / [GitHub](https://github.com/tubearchivist/tubearchivist)
* [yark](https://github.com/Owez/yark) - YouTube Channel Archiver
* [Filmot](https://filmot.com/unlistedSearch) or [Unlisted Videos](https://unlistedvideos.com/) - Search / Watch Unlisted YouTube Videos
* [PreserveTube](https://preservetube.com/), [2](https://preservetube.net/), [3](https://preservetube.org/) or [Hobune](https://hobune.stream/) - YouTube Video Archives
* [youtubecrawl](https://archive.org/details/youtubecrawl) - Captures of Pages from YouTube (IA)
* [Filmot Title Restorer](https://greasyfork.org/en/scripts/430202-filmot-title-restorer), [quite a playlist](https://quiteaplaylist.com/) or [RecoverMy.Video](https://www.recovermy.video/) - Restore Titles of Deleted / Private Videos
* [Decache](https://sindexmon.github.io/decache/) - Check Cache for Lost YouTube Videos / [Discord](https://discord.gg/6U8KwQEhyU) / [GitHub](https://github.com/SindexMon/decache/)

***

# ► Bilibili Tools

* [PiliPlus](https://github.com/bggRGjQaUbCoE/PiliPlus) - Desktop App
* [Bilibili-Evolved](https://github.com/the1812/Bilibili-Evolved) - Site Enhancement Script
* [BilibiliSponsorBlock](https://www.bsbsb.top/) - Skip Sponsored Bilibili Ads / [GitHub](https://github.com/hanydd/BilibiliSponsorBlock)
* [Quality Script](https://greasyfork.org/en/scripts/467511) - Change Quality without Account
* [Comments Script](https://greasyfork.org/en/scripts/473498) - View Comments without Account
* [Sign-Up Block](https://greasyfork.org/en/scripts/467474) - Sign-Up Block Script
* [wiliwili](http://www.xfangfang.cn/wiliwili/) - Gamepad Client

***

# ► Twitch Tools

* 🌐 **[Twitch Extensions](https://dashboard.twitch.tv/extensions/categories/43f48606-8b91-4149-94e6-02def012c79f)** - Twitch Extensions Index
* ⭐ **[FrankerFacez](https://www.frankerfacez.com/)**, [BetterTTV](https://betterttv.com/) or [7TV](https://7tv.app/) - Twitch Enhancement Extensions
* ⭐ **[TwitchNoSub](https://github.com/besuper/TwitchNoSub)** / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/twitchnosub.md), [Sub-Vod](https://www.sub-vod.fr/) or [twitchnosub](https://twitchnosub.com/) - Watch Sub Only Twitch Videos
* ⭐ **[Stream Scheme](https://www.streamscheme.com/)** - Livestreaming Guides / Resources
* [⁠Twitch Gearbox](https://gearbox.crunchprank.net/twitch/filter.php) - Twitch Advanced Search
* [Gumbo](https://github.com/seldszar/gumbo) or [Twitch-Live](https://github.com/yungsamd17/Twitch-Live) - Twitch Stream Trackers
* [HypeTrigger](https://hypetrigger.io/) - Automatically Create Clips
* [Twitch Clip Search](https://www.twitch-clip-search.com/) - Search for Clips
* [VODarchive](https://vodarchive.com/), [⁠VODs](https://vodvod.top/) or [TwitchArchive](https://twitcharchive.com/) - Twitch Video Archives
* [Twitch Previews](https://github.com/MarkM-dev/Previews-client) or [Previews](https://previews-app.com/) - Twitch Video Previews
* [Unwanted Twitch](https://github.com/kwaschny/unwanted-twitch) - Hide Twitch Categories / Channels
* [vTwitch](https://vtwitch.com/) - Show Chat Below Player
* [JChat](https://www.giambaj.it/twitch/jchat/) - Show Twitch Chat on Screen
* [TwitchChatDanmaku](https://github.com/wheatup/TwitchChatDanmaku), [Transparent-Twitch-Chat](https://github.com/chylex/Transparent-Twitch-Chat) or [Transparent Twitch Chat Overlay](https://github.com/baffler/Transparent-Twitch-Chat-Overlay) - Transparent Twitch Chat
* [⁠Twitch Logs](https://tv.supa.sh/logs) - Twitch Chat History / Logs
* [Screenshot Twitch](https://github.com/eramdam/userscripts/blob/main/Screenshot%20Twitch.user.js) - Add Screenshot Button to Twitch
* [⁠Stream Database](https://www.streamdatabase.com/) / [Discord](https://discord.com/invite/streamdatabase) or [⁠BadgeBase](https://badgebase.de/) - Twitch Badge + Emote Databases / Tracking
* [Twitch Drops Miner](https://github.com/DevilXD/TwitchDropsMiner) or [Twitch Drops Miner (Fork)](https://github.com/SimpliAj/twitchdropsminer) - Auto Claim Twitch Drops
* [TwitchRSS](https://twitchrss.appspot.com/) or [twitchrss](https://twitchrss.com/) - Twitch RSS Generators
* [Streamlink Twitch GUI](https://github.com/streamlink/streamlink-twitch-gui) - Twitch Browser for Streamlink
* [get stream](https://pwn.sh/tools/getstream.html) - Extract Twitch URLs
* [Lurker.tv](https://www.lurker.tv/) - Discord Server-Based Twitch Stream Recs
* [Twitch TV OBS Subtitles](https://github.com/stephenlb/twitch-tv-obs-subtitles/) - Add Subtitles to Twitch Stream
* [Twitch Scroll Wheel Volume](https://greasyfork.org/en/scripts/420862) - Add Scroll Wheel Volume to Stream
* [StreamLadder](https://streamladder.com/) - Social Media Templates for Twitch Clips
* [TwitchLeak](https://twitchleak.netlify.app/) - Twitch Top Earners Table
* [TwitchEmotes](https://twitchemotes.com/) - Global Twitch Emotes
* [ChatGuessr](https://chatguessr.com/) - GeoGuessr for Twitch
* [SullyGnome](https://sullygnome.com/), [TwitchInsights](https://twitchinsights.net/), [StreamCharts](https://streamscharts.com/) or [TwitchTracker](https://twitchtracker.com/) - Twitch Stats
* [Rumble](https://rumble.com/) or [Kick](https://kick.com/) - Twitch Alternative

***

## ▷ Twitch Players

* ⭐ **[Chatterino](https://chatterino.com/)** / [2](https://github.com/SevenTV/chatterino7), [Chatterino Homies](https://chatterinohomies.com/) or [Chatty](https://chatty.github.io/) - Twitch Chat Clients
* [Twitch App](https://gitlab.com/linuxbombay/twitch-application/application) or [Tress](https://gitlab.com/Ignamarte/tress) - Twitch Desktop Clients
* [⁠TwitchUnblock](https://test2-fawn-eta.vercel.app/) - Twitch Frontend / Web / [GitHub](https://github.com/MXFia19/TwitchUnblock-Web)
* [SpeechChat](https://speechchat.com/) - Twitch Text to Speech Client
* [Walrus](https://joinwalrus.tv/) - Make Twitch Watch Parties
* [MultiTwitch.tv](https://multitwitch.tv/), [MultiTwitch.co](https://multitwitch.co/), [⁠100 Multiview](https://www.100multiview.com/twitch), [Twitch3D](https://hjjg200.github.io/twitch3d/), [MultiStre.am](https://multistre.am/), [MultiStreamer](https://multistreamer.tv/), [⁠Viewington](https://viewington.com/watch) or [TwitchTheater](https://twitchtheater.tv/) - Twitch Multi-Stream
* [nobody.live](https://nobody.live/) or [Twitch Roulette](https://twitchroulette.net/) - Random Stream Roulette
* Alternate Player for Twitch.tv - [Firefox](https://addons.mozilla.org/en-US/firefox/addon/twitch_5/)
* [Twitch Lurker](https://github.com/mikeyaworski/Twitch-Lurker) - Twitch Stream Auto-Open

***

## ▷ Twitch Adblockers

* 🌐 **[TwitchAdSolutions](https://github.com/ryanbr/TwitchAdSolutions)** - Solutions / Scripts for Blocking Twitch Ads
* ⭐ **[AdGuard Extra](https://github.com/AdguardTeam/AdGuardExtra)** - Twitch Adblocker / Userscript Works Best
* ⭐ **[VAFT Script](https://github.com/ryanbr/TwitchAdSolutions#scripts)** - Twitch Adblocker
* [TTV LOL PRO](https://github.com/younesaassila/ttv-lol-pro) - Twitch Adblocker / [Proxies](https://wiki.cdn-perfprod.com/v1/must-read/proxies)
* [PurpleAdblock](https://github.com/arthurbolsoni/Purple-adblock) - Twitch Adblocker
* [luminous-ttv](https://github.com/AlyoshaVasilieva/luminous-ttv) - Twitch Adblocker
* [PurpleTV](https://purpletv.aeong.win/) - Mobile Ad-Free Twitch App / [Alpha](https://t.me/pubTwAlpha) / [Telegram](https://t.me/pubTw)

***

## ▷ Twitch Downloaders

* [ClipsGameLab](https://clipsgamelab.github.io/#/download) or [clipsey](https://clipsey.com/) - Video Downloaders
* [twitch-dl](https://github.com/ihabunek/twitch-dl) or [twitch-downloader](https://github.com/jybp/twitch-downloader) - CLI Video Downloaders
* [Twitch Downloader](https://github.com/lay295/TwitchDownloader) or [TwitchLink](https://twitchlink.github.io/) - Desktop Video Downloaders
* [TwitchRecover](https://github.com/TwitchRecover/TwitchRecover) - Recover / View / Download Twitch Videos
* [Twitch-Chat-Downloader](https://github.com/PetterKraabol/Twitch-Chat-Downloader) - Download Twitch Chat Messages

***

# ► Twitter/X Tools

* ⭐ **[Trends24](https://trends24.in/)** or [GetDayTrends](https://getdaytrends.com/) - Trending Hashtags Trackers
* ⭐ **[r/Twitter](https://reddit.com/r/Twitter)** - X.com Subreddit
* ⭐ **[Nitter](https://funkstelle.hoffnungfuerdiezukunft.net/)**, [2](https://nr.evilasswebsite.com/), [3](https://tw1tter.com/) / [Redirector](https://xxcancel.com/) / [Instances](https://codeberg.org/mv12star/shitter/wiki/Instances) / [2](https://status.d420.de/) / [.onion](http://zcbxmgileoovnup5k4yj4w6r3vicqpawqc6b33rnmmsqy6n4micpzoad.onion/), [⁠Twitee](https://twitee.co/), [⁠sotwe](https://www.sotwe.com/), [twstalker](https://twstalker.com/), [Twitter Viewer](https://twitterviewer.net/) or [x⁠TwitterViewer](https://xtwitterviewer.com/) - X.com Frontends / Viewers
* [Typefully](https://typefully.com/) - Schedule Tweets
* [Chirr App](https://getchirrapp.com/) - Turn Articles into X.com Threads / [Firefox](https://addons.mozilla.org/en-US/firefox/addon/chirr-app/) / [Chrome](https://chromewebstore.google.com/detail/chirr-app/cmbconaimdngicdnbpjnjocbpkdpmfkg)
* [FollowerWonk](https://followerwonk.com/) - Find / Analyze / Optimize Followers
* [Community Notes Leaderboard](https://community-notes-leaderboard.com/) - X.com Community Notes Leaderboard
* [Osomenet](https://osome.iu.edu/tools/osomenet/) - Twitter Info Spread Data
* [Twitter Mass Unfollow](https://github.com/luqmanoop/twitter-mass-unfollow) - X.com Unfollow Tool
* [Twitter Detector](https://github.com/stilliard/Twitter-detector) - Detect X.com Link on a Page
* [tweetXer](https://github.com/lucahammer/tweetXer) - Delete X.com Posts
* [X.com Direct](https://greasyfork.org/en/scripts/404632) - Removes t.co Tracking from X.com

***

## ▷ Twitter/X Archiving

* [Thread Safe](https://github.com/dkaslovsky/thread-safe) - Twitter Backup Tool
* [TwitterMediaHarvest](https://github.com/EltonChou/TwitterMediaHarvest) - Twitter Media Downloader
* [Twitsave](https://twitsave.com/) or [sssTwitter](https://ssstwitter.com/) - Download Twitter Videos
* [memory.lol](https://github.com/travisbrown/memory.lol/) - Twitter Account Archive
* [Ghost Archive](https://ghostarchive.org/) or [Megalodon](https://megalodon.jp/) - Twitter Archive Services
* [Twitter Archive Parser](https://github.com/timhutton/twitter-archive-parser), [⁠twitter.cat](https://twitter.cat/) or [twitter-web-exporter](https://github.com/prinsss/twitter-web-exporter) - Tweet / Post Archives
* [Twayback Machine](https://staringispolite.github.io/twayback-machine/) - View Users' Old Tweets
* [TweetedAt](https://oduwsdl.github.io/tweetedat/) - View Tweet Dates

***

## ▷ Twitter/X Customization

* ⭐ **[Control Panel for Twitter](https://soitis.dev/control-panel-for-twitter)** - Twitter Enhancement Extensions
* [Minimal Twitter](https://typefully.com/minimal-twitter) - Minimal Twitter Themes
* [OldTwitter](https://github.com/dimdenGD/OldTwitter) or [GoodTwitter2](https://github.com/Bl4Cc4t/GoodTwitter2) - Original Twitter Theme
* [OldTweetDeck](https://github.com/dimdenGD/OldTweetDeck) - Twitter Dashboard
* [Twitter Plus](https://greasyfork.org/en/scripts/387969) - View Twitter Images in Original Quality
* [Twitter Demetricator](https://bengrosser.com/projects/twitter-demetricator/) - Remove All Twitter Metrics
* [Thread Reader App](https://threadreaderapp.com/) - Unroll Twitter Threads / Search
* [Hide Content Warning](https://greasyfork.org/en/scripts/437359) or [Disable Blur](https://userstyles.world/style/15658/) - Remove Sensitive Content Blur

***

# ► Bluesky Tools

* 🌐 **[BlueskyDirectory](https://blueskydirectory.com/)** - Bluesky Resources
* 🌐 **[⁠ATStore](https://atstore.fyi/)** - AT Protocol Based Web Apps
* ⭐ **[Bluesky](https://bsky.app/)** - Federated Twitter Alternative
* [⁠WitchSky](https://witchsky.app/) - Bluesky Frontend
* [Follower Bridge](https://github.com/kawamataryo/sky-follower-bridge) - Import Following from Twitter/X
* [Twitter/X Import](https://tangled.org/marcomaroni.it/twitter-to-bluesky) - Import Tweets from Twitter/X
* [Tuisky](https://github.com/sugyan/tuisky) - TUI Client
* [deck.blue](https://deck.blue/) - Bluesky Dashboard
* [DarkSky](https://github.com/FireCubeStudios/DarkSky) - Bluesky Client / Windows

***

# ► Facebook Tools

* [FBPurity](https://www.fbpurity.com/) - Facebook Enhancement Extensions
* [⁠FB Login Wall Remover](https://greasyfork.org/en/scripts/548145) - Remove Facebook Login Wall
* [Charcoal Dark Mode](https://chromewebstore.google.com/detail/charcoal-dark-mode-for-me/aaekanoannlhnajolbijaoflfhikcgng) - Facebook Messenger Dark Mode
* [Facebook Matrix](https://plessas.net/facebookmatrix) - Facebook Search Formulas
* [WhoPostedWhat](https://whopostedwhat.com/) - Facebook Post Search
* [FB.Zone](https://fb.zone/) - Color Themes for Facebook
* [Remove FBclid](https://chromewebstore.google.com/detail/remove-fbclid-and-utm/ehkdoijaaigomfliimepliikhjkoipob) - Removes fbclid and utm_ Query Parameters in URLs
* [News Feed Eradicator](https://west.io/news-feed-eradicator/) - Hide Facebook News Feed
* [Unlike-Everything](https://github.com/tlorien/Unlike-Everything-on-Facebook) - Remove All Facebook Likes

***

# ► Instagram Tools

* [axinstagram](https://axinstagram.com/) / [GitHub](https://github.com/edideaur/axinstagram/) or [⁠OGInstagram](https://oginstagram.com/) / [GitHub](https://github.com/seirenkr/OGInstagram) - Fix Instagram Embeds
* [Find-User-ID](https://codeofaninja.com/tools/find-instagram-user-id/) - ID Finder
* [InstaAddict](https://github.com/Androz2091/instaddict) - Instagram Addiction Test
* [Unfollow-Everyone](https://github.com/tlorien/Unfollow-Everyone-on-Instagram) - Bulk Instagram Unfollow
* [InstagramUnfollowers](https://davidarroyo1234.github.io/InstagramUnfollowers/) - Check Who Follows Back / [GitHub](https://github.com/davidarroyo1234/InstagramUnfollowers)
* [Instagram Experiments Guide](https://github.com/daniiii5/Public-Guide)

***

## ▷ Viewers / Downloaders

* ⭐ **[Instaloader](https://instaloader.github.io/)** - CLI Downloader / [GitHub](https://github.com/instaloader/instaloader)
* [KittyGram](https://kittygram.irelephant.net/), [2](https://kg.meowing.de) / [.onion](http://instab6cpzrbczpkrvjj3gutly5qx3o2xzpyhlmtwthtzjmjw4tppvad.onion/) / [Source Code](https://codeberg.org/irelephant/kittygram), [Dumpor](https://dumpor.io/), [anonyig](https://anonyig.com/) or [Imginn](https://imginn.com) - Instagram Frontends / Viewers
* [⁠ReelSave](https://reelsave.app/), [FastDL](https://fastdl.app/en2) or [SaveFromWeb](https://www.savefromweb.com/) - Instagram Video / Audio Downloaders
* [IG Helper](https://greasyfork.org/en/scripts/404535) / [GitHub](https://github.com/SN-Koarashi/ig-helper/) or [IG Download Button](https://greasyfork.org/en/scripts/406535-instagram-download-button) - Userscript Downloaders

***

# ► TikTok Tools

* ⭐ **[EinzzTools](https://einzzcookie.org/)** - TikTok User Lookup & Archive / Monitor / Viewer / Link Tracker / Comment & Video Exporter & more / [Telegram](https://t.me/tiktracksite)
* [Urlebird](https://urlebird.com/) - TikTok Frontend / Viewer
* [SSSTik](https://ssstik.io/), [⁠TikWM](https://tikwm.com/originalDownloader.html), [myfaveTT](https://myfavett.com/), [TokSave](https://toksave.social/) or [tiktok-to-ytdlp](https://github.com/Dinoosauro/tiktok-to-ytdlp) - TikTok Video Downloaders
* [TikTok Tools](https://omar-thing.site/) - TikTok User Finder / Search / Story Viewer / Downloader / Link Tracker & more / [Telegram](https://t.me/tiktokinfosite)
* [⁠BXD Enhancer](https://method.billoxd.site/) - Bypass TikTok Compression
* [⁠TikFinity](https://tikfinity.zerody.one/) - TikTok Live Toolkit / [Discord](https://discord.gg/uthtmVdpy8)
* [TikTok Chat Reader](https://tiktok-chat-reader.zerody.one/) - Live TikTok Chat Reader
* [⁠TikTok Control Panel](https://github.com/ElectricArdvark/Tiktok-control-panel) - Control Panel / Extra Functionalities
* [⁠TikTok Video Seeking](https://greasyfork.org/scripts/585042) - Enable Arrow Seeking for TikTok
* [TikTok CSE](https://cse.google.com/cse?cx=c42f6b58703f83683) - TikTok Search

***

# ► Blogging Tools

* ⭐ **[Bear Blog](https://bearblog.dev/)** / [GitHub](https://github.com/HermanMartinus/bearblog), **[⁠TinyBones](https://tinybones.pages.dev/)**, [Mataroa](https://mataroa.blog/), [btw](https://www.btw.so/) / [Discord](https://discord.com/invite/vbDysPXJuF) / [GitHub](https://github.com/btw-so/btw)
 or [smol.pub](https://smol.pub/) / [Key](https://m15o.ichi.city/smolpub/key-request.html) - Minimalist Blogging Platforms
* [Telescope](https://telescope.ac/) - Publishing Platform
* [Dreamwidth](https://www.dreamwidth.org/) - Blogging Platform
* [Haven](https://havenweb.org/) or [WriteFreely](https://writefreely.org/) - Self-Hosted Blogging Platforms
* [Notepin](https://notepin.co/) - Anonymous Blogging Platform
* [Hexo](https://hexo.io/) - Static Blog Template / [Themes](https://hexo.io/themes/) / [GitHub](https://github.com/hexojs/hexo)
* [Zonelets](https://zonelets.net/) - Static Blog Template
* [twtxt](https://github.com/buckket/twtxt) - Decentralized Minimalist Microblogging Service
* [Emanates Docs](https://emanates.deepjyoti30.dev/) - Make GitHub-Based Blogs
* [CoverView](https://coverview.vercel.app/) - Blog Banner Creator

***

# ► Tumblr Tools

* [Tumlook](https://www.tumlook.com/), [Tumgik](https://www.tumgik.com/) or [PriviBlur](https://github.com/syeopite/priviblur) - Tumblr Frontends
* [tumblr-utils](https://github.com/cebtenzzre/tumblr-utils) - Tumblr Utilities
* [XKit](https://github.com/AprilSylph/XKit-Rewritten) - Tumblr Enhancement Extension
* [tumbex](https://www.tumbex.com/) - Tumblr Search
* [Outbox for Tumblr](https://github.com/AprilSylph/Outbox-for-Tumblr) - Tumblr Outbox
* [TumblrOriginalPostFinder](https://jetblackcode.com/TumblrOriginalPostFinder) - Tumblr Post Finder
* [Tumbl Backup Guide](https://docs.google.com/document/d/1yBWlk-yEgpSoEh3c9oLhz_kbLtUGqbqzOpCtJsvQgjI/) or [TumblThree](https://tumblthreeapp.github.io/TumblThree/) - Tumblr Backup Tools
* [Palettes for Tumblr](https://github.com/AprilSylph/Palettes-for-Tumblr) - Tumblr Palettes
* [Filtering Plus](https://github.com/AprilSylph/Filtering-Plus) - Improved Filtering

***

# ► Fediverse Tools

* 🌐 **[Fediverse.Party](https://fediverse.party/)** - Fediverse Software Index
* 🌐 **[⁠FediDB](https://fedidb.com/)** - Fediverse Server List / Statistics
* [Fediverse Near Me](https://umap.openstreetmap.fr/en/map/fediverse-near-me_828094)
* [pixelfed](https://pixelfed.org/) - Decentralized Image Sharing Social Network / Requires Sign-Up / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/social-media#wiki_.25B7_pixelfed_tools) / [Android](https://github.com/pixelfed/pixelfed)
* [Nostr](https://nstart.me/), [2](https://nostr.com/) - Twitter Alternative / [Apps](https://nostrapps.com/) / [Resources](https://nostr.net/)
* [FediDB](https://fedidb.org/) - Network Statistics
* [Fedi.Tips](https://fedi.tips/) - Fediverse Guide
* [FediSearch](https://fedi-search.com/) - Fediverse Search
* [Fedi.Garden](https://fedi.garden/) - Curated User Directory
* [Fediverse People Directory](https://fediverse.info/explore/people) - Self-Submitted User Directory
* [Hubzilla Public Sites](https://hubzilla.org/pubsites) - Hubzilla Instances
* [Friendica Directory](https://dir.friendica.social/servers) - Friendica Instances
* [Lemmy](https://join-lemmy.org/) / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/social-media/#wiki_.25B7_lemmy_tools), [Mastodon](https://joinmastodon.org/) / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/social-media/#wiki_.25B7_mastodon_tools), [Diaspora](https://diasporafoundation.org/) or [Friendica](https://friendi.ca) - Decentralized Social Networks
* [FediverseRedirect](https://github.com/zacharee/MastodonRedirect) - Frontend Redirect
* [Bridgy Fed](https://fed.brid.gy/) - Fediverse Bridge
* [PodcastAP](https://podcastap.com/) - Podcast Feed Bridge
* [The Fediverse Report](https://fediversereport.com/) - Fediverse News
* [FediBuzz](https://fedi.buzz/in/en) - Fediverse Trends

***

## ▷ Mastodon Tools

* 🌐 **[Awesome Mastodon](https://hueyy.github.io/awesome-mastodon/)**, [2](https://github.com/hyperupcall/awesome-mastodon) - Mastodon Resources
* ⭐ **[instances.social](https://instances.social/)** - Mastodon Instances
* ⭐ **[Mastodon Apps](https://joinmastodon.org/apps)** - Mastodon Client List
* [Phanpy](https://phanpy.social/) / [GitHub](https://github.com/cheeaun/phanpy) or [Mastodeck](https://mastodeck.com/) - Mastodon Clients
* [Fediwall](https://fediwall.social/) - View Public Timelines / Hashtags
* [Followgraph](https://followgraph.vercel.app/) or [StreetPass](https://streetpass.social/) - Find Mastodon Users
* [MastoGizmos](https://mastogizmos.com/) - Mastodon Search Tools
* [western.social](https://western.social/) - User Search
* [Tootfinder](https://www.tootfinder.ch/) - Opt-In Full Text Search
* [Mastodon Scheduler](https://scheduler.mastodon.tools/) or [FediPlan](https://plan.fedilab.app/) - Schedule Posts
* [Mastodon List Manager](https://www.mastodonlistmanager.org/main) or [Mastodon Lists Manager](https://mastodon-lists-manager.huey.xyz/) - Bulk List Editors
* [Mastodon Share Bookmarklet Creator](https://eai04191.github.io/mastodon-share-let-maker/index.html) - Quick Share Bookmarklet
* [fedv.link](https://fedv.link/) - Mastodon Link Redirect
* [Mastodon Embed Timeline](https://gitlab.com/idotj/mastodon-embed-timeline) or [Mastofeed](https://mastofeed.com/) - Embedded Mastodon Feeds
* [Cheap Bots, Toot Sweet!](https://cheapbotstootsweet.com/) - Create Bots
* [emojos.in](https://emojos.app/) - Mastodon Custom Emoji Lists
* [MastoMetrics](https://mastometrics.com/) - Mastodon Analytics

***

## ▷ Lemmy Tools

* ⭐ **[Lemmy Explorer](https://lemmyverse.net/)** or [Awesome Lemmy Instances](https://github.com/Fedihosting-Foundation-Forks/awesome-lemmy-instances) - Lemmy Instances
* ⭐ **[Lemmy Apps](https://join-lemmy.org/apps)** - Lemmy Client List
* ⭐ **[Divisions by zero](https://lemmy.dbzer0.com/)** - Piracy Focused Instance
* [Quiblr](https://quiblr.com/) - Lemmy Instance Browser / [GitHub](https://github.com/Technicolor-Dreamcoat/Quiblr)
* [LemmyTools](https://github.com/howdy-tsc/LemmyTools) - Lemmy Improvement Extension

***

## ▷ Pixelfed Tools

* 🌐 **[Pixelfed Apps](https://pixelfed.org/mobile-apps)** - Pixelfed Client List
* [FediDB Pixelfed](https://fedidb.com/software/pixelfed) - Pixelfed Instances
* [Fediverse Observer Pixelfed](https://pixelfed.fediverse.observer/list) - Pixelfed Instances
* [Pixelfed.social](https://pixelfed.social/) - Pixelfed Instance

***

## ▷ Peertube Tools

* 🌐 **[Peertube Apps](https://docs.joinpeertube.org/use/third-party-application)** - Peertube Client List
* [Sepia Search](https://joinpeertube.org/browse-content), [2](https://sepiasearch.org/) - Peertube Search Engine
* [Peertube Instances](https://joinpeertube.org/instances), [2](https://instances.joinpeertube.org/instances) - Peertube Instances
* [FediDB Peertube](https://fedidb.com/software/peertube) - Peertube Instances
* [Fediverse Observer Peertube](https://peertube.fediverse.observer/list) - Peertube Instances

***

# ► 4chan Tools

* [⁠4chan-neXT](https://4chan-next.com/) - 4chan Features Userscript
* [Chance](https://github.com/moffatman/chan) - 4chan Mobile App
* [RedditChan](https://reddit-chan.vercel.app/) - Reddit Style 4chan Web Client
* [4Webm](https://www.4webm.org/) - Load All Webm Videos in 4chan Thread
* [4stats](https://4stats.io/) - 4chan Board / Thread Stats
* [Mass Reply](https://github.com/HamletDuFromage/4chan-mass-reply) - Mass Reply on 4chan
* [Anon Files Names](https://greasyfork.org/en/scripts/435220) - Anonymizes File Names
* [4chan GhostPostMixer](https://github.com/g-gundam/4chan-ghostpostmixer) - Interleave Deleted Posts from Archives
* [Bypass Derefer](https://greasyfork.org/en/scripts/451259) - Remove Link Derefer
* [Extra Flags for 4chan](https://gitlab.com/flagtism/Extra-Flags-for-4chan) - Add More Flags to 4chan
* [ss21](https://github.com/saxamaphone69/ss21) or [4cheddit](https://greasyfork.org/en/scripts/16672) - 4chan Themes

***

## ▷ 4chan Archives

* **Note** - Keep in mind that some of these contain both SFW and NSFW content.

***

* [4chanSearch](https://4chansearch.com/) or [4search](https://4search.neocities.org/) - Search 4chan Archives
* [sup/tg/](https://suptg.thisisnotatrueending.com/), [Palanq.win](https://archive.palanq.win/), [AyaseQuart](https://ayasequart.org/fts), [Desuarchive](https://desuarchive.org/), [arch.b4k](https://arch.b4k.dev/), [Archived.Moe](https://archived.moe/) or [The /b/ Archive](https://thebarchive.com/) - Misc 4chan Archives
* [Oldfriend Archive](https://old.sage.moe/) - 2004 - 2014 Archive
* [Ten Billion](https://archive.org/details/4chan_threads_archive_10_billion) or [4Museum](https://4museum.neocities.org/) - 2006 - 2008 Archive
* [Archive.4plebs](https://archive.4plebs.org/) - 2013 - 2023 Archive
* [BibAnon](https://vyrd.bibanon.org/) - Vyrd's Archive
* [Yotsuba Catalog](https://catalog.neet.tv/) - Yotsuba Archive
