***
***
**[◄◄ Back to Wiki Index](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/index)**
***
***

* **Note** - Use this section for media (movies, music, books). For installing software, games, or APKs, use the English sections unless the source is highly trusted (e.g., m0nkrus). Try a [VPN](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_vpn) if sites are blocked.

***

# ► Arabic / العربية

* 🌐 **[⁠Faharys](https://t.me/faharys)** - Telegram Channel Index
* [Aosus](https://discourse.aosus.org/) - FOSS, Privacy & Linux Community / [Matrix](https://matrix.to/#/#aosus:aosus.org) / [Telegram](https://t.me/aosus) / [Discord](https://discord.gg/YJUzEhU955)
* [AdslGate](https://www.adslgate.com/) - Tech Forum
* [⁠Elfehrest](https://elfehrest.com/) - Blog Aggregator
* [ZeroTaxJobs](https://zerotaxjobs.com/) - Software Engineer Jobs
* [⁠MiraiAnime](https://miraianime.net/) - Anime Subtitles

## ▷ Downloading / تحميل

* ⭐ **[EgyDead](https://tv10.egydead.live/)** - Movies / TV / Anime / Sub / 1080p / Use [Adblock](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_adblocking)
* [Stardima](https://www.stardima.com/) - Anime / Cartoon / [Telegram](https://t.me/+Phq8ETiiBAIwNzJk)
* [MyCima](https://mycima.gdn/) - Movies / TV / Anime / Hard Subs
* [FilmCity](https://m.filmcity12.com/) - Movies
* [TukTukCinema](https://tuktukcinemas.com/) - Movies / TV / Anime
* [TopCinema](https://topcinemaa.vip/) - Movies / TV / Anime / Use [Adblock](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_adblocking)
* [Anime3rb](https://anime3rb.com/) - Anime / Sub / 1080p / Use [Adblock](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_adblocking)
* [nghmat](https://songs.nghmat.com/) - Music / MP3 / Use [Adblock](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_adblocking)
* [⁠Sama3y - سماعي](https://www.sama3y.net/) - Music / Classical / Forum / Sign-Up Required
* [ArabicFonts](https://arabicfonts.net/) or [ARFonts](https://www.arfonts.net/) - Fonts
* [Eternal Dream Arabization](https://www.etrdream.com/) - Modern / Official / Retro Games Arabic Localization

## ▷ Torrenting / التورنت

* [ArabP2P](https://www.arabp2p.net/) - Video / Private Tracker / Signup Required

## ▷ Streaming / البث

* ⭐ **[EgyDead](https://tv10.egydead.live/)** - Movies / TV / Anime / Sub / 1080p / Use [Adblock](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_adblocking)
* ⭐ **[Anime3rb](https://anime3rb.com/)** - Anime / Sub / 1080p / Use [Adblock](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_adblocking)
* ⭐ **[WitAnime](https://witanime.site/)** - Anime / Sub / 1080p
* [TopCinema](https://topcinemaa.vip/) - Movies / TV / Anime / Use [Adblock](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_adblocking)
* [EgyBest](https://egybest.la/) - Movies / TV / Anime
* [⁠My Cima](https://mycima.gdn/) - Movies / TV
* [Laroza TV](https://llaroza.monster/) - Movies / TV
* [⁠ahwak tv](https://yam.ahwaktv.net/), [2](https://ahwaktv.beer/) - Movies / TV
* [TukTukCinema](https://tuktukcinemas.com/) - Movies / TV / Anime
* [kirmalk](https://kirmalk.com/kr19) - Movies / TV
* [⁠Anime4up](https://anime4up.rest/) - Anime
* [⁠Animerco](https://animerco.org/) - Anime
* [AnimeZid](https://animezid.org/) - Anime / Cartoons
* [RistoAnime](https://ristoanime.me/) - Anime
* [Kawaii Anime](https://kawaiianime.cc/) - Anime
* [shahiid](https://shahiid-anime.net/) - Anime / Sub / 720p
* [⁠ani-cli-arabic](https://ani-cli-arabic.dev/) - Anime CLI / [GitHub](https://github.com/np4abdou1/ani-cli-arabic)
* [arabic-toons](https://www.arabic-toons.com/) - Cartoons
* [al-fann](https://www.al-fann.net/) - Music
* [PlayTorrio](https://playtorrio.xyz/), [2](https://playtorrio.pages.dev/) - All Platforms / Anime / Live TV / Use PlayTorrioHTTP Plugin / [Subreddit](https://www.reddit.com/r/PlayTorrio/) / [Discord](https://discord.gg/bbkVHRHnRk)
* [⁠Rwaq](https://rwaq.org/) - Courses / Signup Required
* [⁠Edraak](https://www.edraak.org/) - Courses / Signup Required

## ▷ Reading / القراءة

* ⭐ **[⁠Arabic Collections Online (ACO)](https://aco.dlib.nyu.edu/)** - Public Domain Books
* ⭐ **[hindawi](https://www.hindawi.org/)** - Educational Books
* [Noor Book](https://www.noor-book.com/) - Books
* [Shamela](https://shamela.ws/) - Books / Documents
* [FoulaBook](https://foulabook.com/) - Books
* [books-library](https://books-library.website/) - Books
* [AlarabiMag](https://www.alarabimag.com/) - Books
* [⁠e3raf](https://books.e3raf.co/) - Books
* [⁠متميزون للكتب](https://t.me/Motamayezon7) / [2](https://t.me/Motamayz00n) - Books
* [Abjjad](https://www.abjjad.com/) - Books
* [⁠8ghrb](https://8ghrb.com/) - Books / Light Novels
* [⁠Waqfeya](https://waqfeya.net/) - Public Domain Books
* [GedoLibrary_bot](https://telegram.me/GedoLibrary_bot) - Book Telegram Bot
* [⁠Kindleeon](https://t.me/kindleeon) - Books for Kindle
* [Azoramoon](https://azorafly.com/) - Manga
* [KenManga](https://ar.kenmanga.com/) - Manga
* [hijala](https://www.hijala.com/) - Manga / [Discord](https://discord.com/invite/sGTBCDeE2J)
* [Stellar Saber](https://stellarsaber.pro/) - Manga
* [⁠Arab Comics](https://arabcomics.net/) - Comics / Signup Required
* [Aldiwan](https://www.aldiwan.net/) - Poems / [Telegram](https://t.me/AldiwanNet)
* [Almaany](https://www.almaany.com/) - Multilingual Dictionary
* [⁠Archive Alsharekh](https://archive.alsharekh.org/) - Journals / Magazines
* [dohadictionary](https://www.dohadictionary.org/) - Historical Dictionary
* [Mo3jam](https://ar.mo3jam.com) - Colloquial / Slang Dictionary

***

# ► Bangla / বাংলা

* ⭐ **[Avro Keyboard](https://www.omicronlab.com/avro-keyboard.html)** - Bangla Typing Tool / Spellcheck / [WebUI](https://avro.im/)
* [aapathshala](https://aapathshala.com/library/) - Test Practice
* [Python Maateen](https://python.maateen.me/) - Python Guide
* [Chorcha](https://chorcha.net/) - Test Prep App

## ▷ Reading / পড়া

* ⭐ **[ebanglalibrary](https://www.ebanglalibrary.com/)** - Books
* [24livenewspaper](https://www.24livenewspaper.com/bangla-newspaper) or [allbanglanewspaper](https://www.allbanglanewspaper.xyz/) - Bangla Newspapers
* [IQGAW](https://t.me/IQGamer_PDFStore) - PDF Library for BD HSC Candidates
* [BanglaBookshelf](https://www.banglabookshelf.com/) - Fiction / Islamic / Tech Books
* [AmarBooks](https://www.amarbooks.org/) - Books
* [Boimate](https://boimate.com/) - Books
* [BengaliEbook](https://www.worldmets.com/) - Books
* [bengaliebook](https://bengaliebook.com/) - Books
* [amarboi](https://www.amarboi.com/) - Books
* [boierthikana](https://www.boierthikana.com/) - Books
* [banglabooks](https://www.banglabooks.in/) - Books
* [kindlebangla](https://www.kindlebangla.com/) - Books
* [banglaclassicbooks](https://banglaclassicbooks.blogspot.com/) - Books
* [allbanglaboi](https://allbanglaboi.com/) - Books
* [granthagara](https://granthagara.com/) - Books
* [jyotirjagat](https://jyotirjagat.wordpress.com/) - Books
* [⁠Banglabook](https://www.banglabook.org/) - Books
* [SovietBooksinBengali](https://sovietbooksinbengali.blogspot.com/) - Soviet Books

## ▷ Downloading / ডাউনলোডিং

* [MLSBD](https://mlsbd.co/) - Movies / TV
* [Bangla Song](https://www.music.com.bd/) - Bangla Song / Music / Radio / MP3
* [Bhoot FM](https://bhoot-fm.com/) - Bhoot FM Archive / Paranormal Radio Show

## ▷ Streaming / স্ট্রিমিং

* [Fibwatch](https://fibwatch.art/) - Movies / TV
* [jadoocinema](https://jadoocinema.net/) - Movies / TV / Sub / Dub / 1080p

***

# ► Bulgarian / Български

* [YavkA](https://yavka.net/), [subsunacs](https://subsunacs.net/) or [subs.sab.bz](http://subs.sab.bz/) - Subtitles

## ▷ Streaming / Стрийминг

* [NovaPlay](https://play.nova.bg/) - Live TV / TV / Sub / Dub / 1080p
* [Filmifen](https://filmifen.com/) - Movies / Sub / Dub
* [BGTVI](https://bgtvi.com/) - TV / Sub / Dub / 720p
* [BGESTV](https://bgestv.com) - TV / Sub / Dub / 720p
* [Seir Sanduk](https://seirsanduk.online/) - Live TV

## ▷ Reading

* [chitanka](https://chitanka.info/) - Books

***

# ► Chinese / 华语

* 🌐 **[heji](https://233heji.com/)** or [bajins](https://www.bajins.com/) - Chinese Sites / Tools Indexes
* 🌐 **[Awesome GitHub Repo](https://github.com/Wechat-ggGitHub/Awesome-GitHub-Repo)** - Programming Resources Index
* 🌐 **[RecTG](https://github.com/jackhawks/rectg)** - Chinese Telegram Groups / Bots
* [Linux Do](https://linux.do/) - AI, Tech and Linux Forum
* [⁠Arch Linux Concise Guide](https://arch.icekylin.online/) or [⁠ArchlinuxCN](https://archlinuxcn.org/) - Arch Linux Guides
* [Diaosi Forum](https://assbbs.com/) - Piracy Discussion Forum
* [assrt](https://assrt.net/), [srtku](https://srtku.com/) or [zimuku](https://zimuku.org/) - Subtitles
* [Bangumi](https://bangumi.moe/) - Anime Subtitles
* [Anti-Ad](https://anti-ad.net/) - Adblock Filters
* [Gridea](https://open.gridea.dev/) - Blog Writing Client
* [taioan](https://ji.taioan.org/) - Chinese Spell Check
* [itaigi](https://itaigi.tw/) - Chinese to Taiwanese Translator
* [CatoCR](https://catocr.com/) - Image to Text
* [todaiinews](https://chinese.todaiinews.com/) - Language Learning
* [Oh.Taigi](https://oh.taigi.info/) - Learn Taiwanese
* [Bangumi.tv](https://bangumi.tv/), [2](https://chii.in/) - Media Database / [Mobile Client](https://github.com/czy0729/Bangumi)
* [TopHub](https://tophub.today/), [Rebang](https://rebang.today/) or [Chinadaily](https://cn.chinadaily.com.cn/) - News
* [IT Home](https://www.ithome.com/) - Tech News
* [jialezi](https://blog.jialezi.net/) - Tech Tutorials
* [Lofter](https://www.lofter.com) - Novel Fan Art
* [⁠ScriptCat Index](https://scriptcat.org/) - Userscript Index
* [Bing China](https://www.bing.com/?mkt=zh-CN), [Toutiao](https://www.toutiao.com/) or [sogou](https://www.sogou.com/) - Search Engines
* [ICIBA](https://www.iciba.com/) / [Client](https://cp.iciba.com/), [Fanyi](https://fanyi.qq.com/) or [YouDao](https://fanyi.youdao.com/) - Translators
* [Hack Game](https://hack-games.com/) - Incremental Games
* [Funn](https://fuun.fun/) - Fun Sites
* [V2EX](https://v2ex.com/), [CNBlogs](https://www.cnblogs.com/) or [ZongScan](https://www.zongscan.com/) - Developer / Programming Forums
* [Gitee](https://gitee.com/) - GitHub Alternative
* [HelloGitHub](https://hellogithub.com/) - GitHub Projects
* [hkslbrowser](http://www.cslds.org/hkslbrowser/index.jsp) or [special.moe](https://special.moe.gov.tw/signlanguage/) - Chinese Sign Language Dictionaries

## ▷ Great Firewall

* **Note** - Keep in mind some VPNs claiming to bypass GFW are made by Chinese agencies as a way to get user info. We recommend avoiding any generic ones, and sticking to ones listed in the [VPN section](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_vpn).

***

* ↪️ **[Anti-Censorship Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25B7_anti-censorship)** / **[Proxy Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_proxy)**
* [Censorship Bypass](https://rentry.co/chinese-censorship-bypass-guide) - Censorship Bypass Guide
* [gfwlist](https://github.com/gfwlist/gfwlist) - Blocked Sites List
* [r/dumbclub](https://www.reddit.com/r/dumbclub/) - GFW Discussion
* [gfw.report](https://gfw.report/) - GFW Information
* [GHProxy](https://ghproxy.link/) - GitHub Proxy (not blocked by GFW)
* [⁠GFWMass](https://github.com/eli32-vlc/gfwmass) - Proxy Deployment Tool
* [Accesser](https://github.com/URenko/Accesser/) - SNI RST Solver
* [China Firewall Test](https://www.dotcom-tools.com/china-firewall-test), [ChinaFirewallTest](https://www.chinafirewalltest.com/), [BlockedInChina](https://www.comparitech.com/privacy-security-tools/blockedinchina/) or [Chinese Firewall](https://viewdns.info/chinesefirewall/) - Chinese Firewall Blocking Test

## ▷ Downloading / 下载

* [HaiSo ⁠海搜](https://haisou.cc/) - Video / Audio / Books
* [⁠ZMX](https://bbs.itzmx.com/) - Video / Audio
* [AnimeNep](https://t.me/AnimeNep) - Anime
* [J-pop Music Download](https://jpop.xyz/category/c-pop/) - Music / FLAC / MP3
* [icourse163](https://www.icourse163.org/) / [Icourse163 Downloader](https://greasyfork.org/en/scripts/372684) - Courses
* [CN GreenLumaGUI](https://github.com/clinlx/CN_GreenLumaGUI) - Offline Steam DRM Bypass / DLC Unlocker
* [SuperLosslessMusic](https://t.me/SuperLosslessMusic) - Audio / FLAC
* [flac_file](https://t.me/flac_file) - Audio / FLAC
* [VmoMusic](https://t.me/VmoMusic) - Audio / FLAC
* [feiku6](https://www.feiku6.com/) - Books / Reading / Listening
* [Salty Leo](https://tstrs.me/search) - Books / Fiction / Non-Fiction / Downloading

## ▷ Torrenting / 下载种子

* [qBittorrent Enhanced](https://github.com/c0re100/qBittorrent-Enhanced-Edition) - qBittorrent for Chinese Users
* [Csze BT](https://bt.orzx.im/) - Video / Audio / Books
* [acgnx](https://www.acgnx.se/) - Video / Audio / Books / NSFW
* [Share.dmhy](https://share.dmhy.org/) - Video / Anime / NSFW
* [⁠1Lou](https://www.1lou.me/) - Video
* [seedhub](https://www.seedhub.cc/) - Video
* [btbtla](https://www.btbtla.com/) - Video
* [ACG.rip](https://acg.rip/) - Anime / Audio
* [MioBT](https://www.miobt.com/) - Anime
* [VCB-S](https://vcb-s.com/) - Anime
* [ACGNX](https://share.acgnx.se/) - Anime
* [Snow-Raws](https://snow-raws.com/) - Anime / [Official Tracker](https://www.skyey2.com/)
* [Mikan](https://mikanani.me/) - Anime
* [Auto_Bangumi](https://github.com/EstrellaXD/Auto_Bangumi) - Anime Torrent Auto Download
* [AnimeTrackerList](https://github.com/DeSireFire/animeTrackerList) - Anime Trackers List

## ▷ Streaming / 串流

* 🌐 **[Chinese Drama Site Index](https://www.reddit.com/r/CDrama/wiki/streaming)** - Chinese Drama Sites Index
* 🌐 **[klyingshi](https://www.klyingshi4.com/)** - Chinese Streaming Sites Index
* ⭐ **[BiliBili](https://www.bilibili.com/)** or [BiliBili.tv](https://www.bilibili.tv/) - YouTube and TikTok Alt / [Resources / Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/social-media/#wiki_.25BA_bilibili_tools)
* [Tencent Video](https://v.qq.com/) - Movies / TV / Anime / Cartoons / Sub / Dub / 1080p / [Downloader](https://weibomiaopai.com/online-video-downloader/tencent)
* [MoMoVOD](https://momovod.app/) - Movies / TV / Anime / Sub / 1080p
* [VidHub](https://vidhub2.top/) - Movies / TV / Anime / Sub / 1080p
* [xiaobaotv](https://www.xiaobaotv.com/) - Movies / TV / Anime / Hard-Sub / Dub / 1080p
* [ztv.tw](https://ztv.tw) - Movies / TV / Anime
* [chinaq.app](https://chinaq.app/) - Movies / TV / Anime
* [Imaple](https://imaple8.co/) - Movies / TV / Sub / 1080p
* [xiaoyakankan](https://xiaoyakankan.com/) - Movies / TV / 720p
* [IYF](https://www.iyf.tv/) - Movies / TV / Sub / Dub / 720p
* [gimytw](https://gimytw.cc/) - Movies / TV / Cartoons / Dub
* [viu](https://viu.tv/) - Movies / TV / Free w/ Ads
* [hoy](https://hoy.tv/) - Movies / TV / Free w/ Ads
* [KokoTV](https://kokotv.me/) - Drama / Sub / Dub / 1080p
* [nunuju](https://nunuju.com/) - Drama / Sub / Dub / 1080p
* [dramaq](https://dramaq.xyz/) - Drama / Sub / Dub / 1080p
* [duanjuhk](https://duanjuhk.com/) - Short Drama / Sub / Dub / 1080p
* [xgcartoon](https://www.xgcartoon.com/) - Anime / Sub / Dub / 1080p
* [Anime1](https://anime1.me/) - Anime / Sub / 1080p
* [Myself-BBS](https://myself-bbs.com/) - Anime / Sub / 1080p
* [AGE Anime](https://www.agedm.io/) - Anime / Sub / 1080p / [App](https://www.ageapp.app/) / [Mirrors](https://github.com/agefanscom/website), [2](https://rentry.org/agefans)
* [⁠OMOFUN](https://www.omofuns.com/) - Anime / Cartoon / Sub / 1080p
* [bimiacg](https://www.bimiacg14.net/) - Anime / Sub / 1080p
* [Animeko](https://github.com/open-ani/animeko) - Anime Streaming + Torrent App / All Platforms
* [ixigua.com](https://www.ixigua.com/) - YouTube and TikTok Alt
* [music.163](https://music.163.com/) - Music
* [5nd](https://www.5nd.com/) - Music
* [MissEvan](https://www.missevan.com/) - Music / Podcasts / Audio Comics
* [Kilamanbo](https://kilakila.cn/) - Audio Comic Drama
* [Huya](https://www.huya.com/) - Live Streaming
* [IPTV807](https://iptv807.com/) - Live TV
* [IPTV Playlists](https://rentry.co/FMHYB64#iptv-playlists) - IPTV Playlists
* [數學老師張旭](https://space.bilibili.com/521685904) - Math Lessons
* [free-project-course](https://github.com/resumejob/free-project-course) - Programming Courses
* [Baidu SkyDrive Video Player](https://greasyfork.org/en/scripts/426952-%E7%99%BE%E5%BA%A6%E7%BD%91%E7%9B%98%E8%A7%86%E9%A2%91%E6%92%AD%E6%94%BE%E5%B0%8A%E4%BA%AB-vip-%E8%A7%A3%E9%94%81%E8%A7%86%E9%A2%91%E5%80%8D%E6%95%B0-%E8%A7%A3%E9%94%81%E5%85%A8%E9%83%A8%E6%B8%85%E6%99%B0%E5%BA%A6) - Baidu VIP Video Player
* [acfun.cn](https://www.acfun.cn/) - Video Streaming / YouTube Alt

## ▷ Reading / 阅读

* ⭐ **[69xinshu](https://www.69shuba.com/)** - Fiction
* [tuoverse](https://tuoverse.com/) - Fiction
* [⁠EPUB.MOE](https://epub.moe/) - Fiction / Nonfiction
* [BooksThatMakeYouThink](https://t.me/BooksThatMakeYouThink) - Nonfiction
* [AutumnWindBookstore](https://www.qiufengshuwu.com/) - Fiction
* [ixdzs](https://ixdzs.tw/) - Fiction
* [99csw.com](https://99csw.com/) - Fiction / Non-fiction
* [nunubook.com](https://nunubook.com/) - Fiction / Non-fiction
* [haodoo](https://haodoo.org/) - Fiction
* [Wenku](https://wenku.mojimoon.top/) - Fiction / Non-fiction
* [24hbook](https://24hbook.com/) - Fiction / Non-fiction
* [5165.org](https://5165.org/) - Fiction / Nonfiction
* [52shuku](https://www.52shuku.net/) - Books / Light-Novels
* [books.l3zc](https://books.l3zc.com/) - Fiction / Non-fiction
* [talebook](https://www.wenyuange.org/) - Fiction / Non-fiction
* [ttkan](https://www.ttkan.co) - Books / Light-Novels
* [Piaotian](https://www.piaotia.com/) - Books / Light-Novels
* [qqszz](https://www.35ppt.com/) - Books / Light-Novels / Requires Sign-Up
* [256zw](https://www.256zw.org/) - Light-Novels
* [Readfine](https://t.me/Readfine) - FanFiction / [Discussion](https://t.me/ReadfineChat)
* [shuge](https://www.shuge.org/) - Rare / Ancient Books
* [Wikimedia Commons Books](https://commons.wikimedia.org/wiki/Category:Library_back_up_project) or [Wikimore](https://git.private.coffee/privatecoffee/wikimore#instances) - Educational Books
* [CText](https://ctext.org/), [ChineseNotes](https://chinesenotes.com/) or [quanxue](https://www.quanxue.cn/) - Chinese Historic Text Archives
* [guoxue](http://www.guoxue.com/) - History / Journals
* [NG Tech](https://ng-tech.icu/) - Documents
* [Chinese Programming Books](https://github.com/justjavac/free-programming-books-zh_CN) - Programming Books
* [kangxizidian](https://kangxizidian.com/) - Chinese Kangxi Dictionary
* [Shufazidian](https://www.shufazidian.com/) - Chinese Calligraphy Dictionary
* [CBeta](https://www.cbeta.org/) or [Goodweb](http://goodweb.net.cn/sutra/) - Chinese Buddhist Scriptures
* [Open Literature](http://open-lit.com/html/) - Classic Chinese Novels
* [21dzk](https://21dzk.l.u-tokyo.ac.jp/SAT/index.html) - Chinese Buddhist Scriptures
* [wenku](https://pypi.org/project/wenku/) - Baidu Wenku Downloader
* [Trtag](https://trtag.com/) - Movies / TV Encyclopedia

## ▷ Light Novels

* [jpxs123.cc](https://jpxs123.top/) - Light-Novels / Use [Adblock](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_adblocking)
* [kanunu8](https://www.kanunu8.com/) - Light-Novels
* [hetushu](https://hetushu.com/) - Light-Novels
* [Zongheng](https://www.zongheng.com/) - Light-Novels
* [Bixiange](https://www.bixiange.top/) - Light-Novels
* [qinkan](https://www.qinkan.net/) - Light-Novels
* [ffxs8](https://ffxs8.com/) - Light-Novels
* [powanjuan](https://powanjuan.cc/) - Light-Novels

## ▷ Manga

* [AC.QQ](https://ac.qq.com/) - Manga
* [BiliBili](https://manga.bilibili.com/) - Manga
* [DM5](https://www.dm5.com/), [2](https://tel.1kkk.com/) - Manga / Manhua
* [godamanga.site](https://godamh.com/) - Manga
* [xmanhua.com](https://xmanhua.com/) - Manga / Some NSFW
* [manhuagui](https://www.manhuagui.com/) - Manga
* [dumanwu](https://dumanwu.com/) - Manga
* [mkzhan](https://www.mkzhan.com/) - Manga
* [manhuapi](https://www.manhuapi.cc/) - Manga
* [36mh](https://www.36mh.org/) - Manga
* [komiic](https://komiic.com/) - Manga
* [manben](https://www.manben.com/) - Manga
* [manhuazhan](https://www.manhuazhan.com/) - Manga
* [rumanhua](https://www.rumanhua2.com/) - Manga
* [fengchemh](https://www.fengchemh.com/) - Manga
* [yibenmanhua](https://www.yibenmanhua.com/) - Manga
* [dongmanmanhua](https://www.dongmanmanhua.cn/) - Manga
* [baozimh](https://baozimh.one/) - Manhua
* [acgn.cc](https://comic.acgn.cc/) - Manga
* [Mangabz](https://www.mangabz.com/) - Manga
* [Baozimh](https://baozimh.org/) - Manga / Manhua / Manhwa
* [Baozimh](https://www.baozimh.com/) - Webtoons

***

# ► Czech / Čeština

* [uschovna](https://www.uschovna.cz/) - Czech File Hosts
* [NoCard](https://nocard.cz/) - Public Czech Club Cards / [Android App](https://github.com/HelloOO7/Karticky)
* [spojenka](https://spojenka.cz/) - Public Czech Transport App
* [⁠Metroskop](https://metroskop.cz/) - Prague Public Transport Map

## ▷ Downloading / Stahování

* ⭐ **[hellspy](https://hellspy.to/)** - Video / Region Locked
* [prehraj](https://prehraj.to/) - Video
* [WebShare](https://webshare.cz/) - Video / Audio / Books / NSFW
* [War-Forum](https://war-forum.net/) - Video / Audio / Books / Comics / NSFW / Requires Sign-Up
* [WarezCenter](https://warcenter.cz/) - Video / Audio / Books / NSFW / Requires Sign-Up
* [FastShare.cloud](https://fastshare.cloud/) - Video / Audio / Books / NSFW
* [Datoid](https://datoid.cz/) - Video / Audio / Books / NSFW / Requires Sign-Up for 1GB+ Files

## ▷ Torrenting

* [sktorrent](https://sktorrent.eu/) - Movies / TV / Anime

## ▷ Streaming / Streamování

* [Bombuj](https://bombuj.si/) - Movies / TV
* [Sledujteto](https://www.sledujteto.cz/) - Movies / TV / Anime / 1080p
* [filmbot](https://filmbot.tv/) - Movies / TV / Anime
* [mrkaj](https://mrkaj.me/) - Movies / TV / Anime / Region Locked
* [uzi.la](https://uzi.la/) - Movies / TV / Anime / 1080p / Region Locked
* [svetserialu](https://svetserialu.io/) - Movies / TV / Anime / 1080p
* [sledujfilmy](https://ww.sledujfilmy.io/) or [serialy](https://sledujserialy.io/) - Movies / TV / Anime / 1080p
* [najserialy](https://www.najserialy.io/) - Movies / TV / Anime / 1080p
* [Ceskatelevize](https://www.ceskatelevize.cz/ivysilani/) - Movies / TV
* [sweet.tv](https://sweet.tv/pl/) - Free w/ Ads / Channels Only / [Live TV Bypass](https://github.com/Julmik647/sweet-tv-no-login)
* [CSFD](https://www.csfd.cz/) - Czech Film Database

## ▷ Reading / Čtení

* [xTrance](https://xtrance.info/) - Books / Download / Requires Sign-Up
* [eBookForum](https://ebookforum.sk/) - Books / Download / Requires Sign-Up
* [PDF Books](https://pdfknihy.maxzone.eu/index.html) - Public Domain Books
* [databazeknih](https://www.databazeknih.cz/) - Czech Book Database
* [eknihovna](https://eknihovna.maxzone.eu/index.html) - Books
* [prirucka](https://prirucka.ujc.cas.cz) - Dictionaries
* [WebArchive](https://webarchiv.cz/) - Documents

***

# ► Filipino / Pinoy

## ▷ Streaming / Nanonood

* [Movies Ni Pipay](https://moviesnipipay.me/) - Movies / TV / Anime / Some NSFW / Sub / Dub / 1080p
* [Pinoy Movies Hub](https://pinoymovieshub.win/) - Movies / TV / Anime / NSFW / Sub / Dub / 720p
* [cinema](https://cinema.com.ph) - Movies / TV / Anime / Some NSFW
* [Pinoymoviepedia](https://pinoymoviepedia.ru/) - Movies / TV / Some NSFW / Sub / Dub / 720p
* [Pinoy Albums](https://pinoyalbums.com/) - Music

***

# ► Finnish / Suomi

* [finna.fi](https://www.finna.fi/) - Media Archive / Requires Library Card
* [Sanuli](https://sanuli.fi/) - Finnish Wordle
* [Viittomaluettelot](https://suvi.viittomat.net/) - Sign Language Dictionary
* [⁠Fintraffic](https://matka.fintraffic.fi/) - Public Transport Route Planner

## ▷ Streaming / Suoratoisto

* [Elonet](https://elonet.finna.fi/) - Classic Movies
* [Areena](https://areena.yle.fi/) - Movies / TV / 1080p
* [Viddla](https://www.viddla.fi/) - Movies / TV / Requires Library Card
* [TVKaista](https://www.tvkaista.org/) - Finnish IPTV
* [Podcast24](https://podcast24.fi/) - Podcasts
* [helpotnopat](https://helpotnopat.fi/) - Courses

## ▷ Reading / Lukeminen

* [Lonnrot](http://www.lonnrot.net/) - Books
* [HistDoc](https://histdoc.net/) - Historical Finnish Documents
* [Journal.fi](https://journal.fi/) - Academic Journals

***

# ► French / Français

* 🌐 **[⁠Tipiakeries](https://rentry.co/alpagang)** - French Piracy Mega / [Subreddit](https://www.reddit.com/r/FrancePirate/)
* ⭐ **[Dealabs](https://www.dealabs.com/)** - Track Deals / Freebies
* ⭐ **[⁠Mes Aides](https://mes-aides.1jeune1solution.beta.gouv.fr/)** - Student Financial Benefits Guide / Simulator
* [Sous-Titres](https://www.sous-titres.eu/) or [SubFactory](https://subfactory.fr/) - Subtitles
* [Tseret](https://tseret.com/) - Game Guides
* [BonPatron](https://bonpatron.com/) - Spelling and Grammar Check
* [GoTo10](https://www.goto10.fr/) - BBS and Minitel Archives
* [DropReference](https://dropreference.com/) - PC Building Site
* [nuit-blanche](https://nuit-blanche.ch/) - Drug Detox Help
* [Remonterletemps](https://remonterletemps.ign.fr) - France Geographic / Forestry Info and Maps
* [nooSFere](https://www.noosfere.org/) - Science Fiction Media Database
* [Perspective Monde](https://perspective.usherbrooke.ca/) - Datasets / Statistics
* [carto.tchoo](https://carto.tchoo.net/) - Live Train Map
* [Prix Carburants](https://www.prix-carburants.gouv.fr/) - Gas Prices
* [Donnons](https://donnons.org/) or [⁠Geev](https://www.geev.com/) - Free Stuff Exchange / Gifting
* [Signsuisse](https://www.sgb-fss.ch/signsuisse/fr/), [lsfdico](https://lsfdico.injs-metz.fr/) or [LSQ](https://lsq-fr.ca/) - French Sign Language Dictionaries
* [I Say LSF](https://dico.swax-lsf.fr/) - French Sign Translator

## ▷ Downloading / Téléchargement

* ⭐ **[⁠Loadix](https://loadix.fun/)** - Movies / TV / Anime
* [WawaCity](https://www.wawacity.press/) - Movies / TV / [Status](https://wawacity-info.com/) / [Telegram](https://t.me/Wawacityofficiel)
* [Extreme-Down](https://www.extreme-down.press/) - Video / Audio / Books
* [MuaDib](https://muaddib-sci-fi.blogspot.com/) - Sci-Fi Movies
* [PiratePunk](https://www.pirate-punk.net/) - Punk Music / Radio / Concerts Dates / Forum
* [Emurom](https://www.emurom.net/) - Retro ROMs
* [Abandonware Magazines](https://www.abandonware-magazines.org/) - Retro Computer / Games Magazines
* [Abandonware France](https://www.abandonware-france.org/index.php) - Abandonware
* [Abandonware Videos](https://www.abandonware-videos.org/) - Retro Game Related Videos

## ▷ Torrenting

* [⁠C411](https://c411.org/) - Video / Audio / Books / Signup Required

## ▷ Streaming

* ⭐ **[⁠FlixVison](https://flixvision.xyz/)** - Movies / TV / Anime
* [yablom](https://pirvab.com/) - Movies / TV / Anime
* [French Stream](https://fs27.lol/), [2](https://fsurl.top/) - Movies / TV / Anime / [Status](https://fstream.info/)
* [⁠Purstream](https://purstream.wiki/) - Movies / TV / Anime
* [Aether](https://aether.ist/), [2](https://aether.cx/) - Movies / TV / Anime / Auto-Next / [Extensions](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/movie-web-sources.md) / [Discord](https://discord.gg/MadMF7xb5q)
* [frembed](https://frembed.uno/) - Movies / TV / Anime / Dub
* [dulourd](https://www.dulourd.boo/) - Movies / TV / Geoblocked
* [⁠Bowd](https://bowdtv.com/) - Movies / TV / Live TV
* [Paradise lost.666](https://mfp666.blogspot.com/) - Classic French Movies / TV / Music
* [Film à Revoir](https://filmarevoirnad.blogspot.com/) - Classic French Movies
* [Ciné-Bis-Art](https://humungus-cinebisart.blogspot.com/) - Movies / Requires Sign-Up
* [Stigstream](https://stigstream.ru/) - Movies / TV / Anime / Auto-Next
* [TF1](https://www.tf1.fr/) - Live TV / Movies / TV / Anime / Requires French VPN for Some Content
* [1jour1film0626](https://1jour1film0926.cyou/) - Movies / TV / Anime
* [myfluneo](https://myfluneo.eu/) - Movies / TV / Anime
* [⁠streaming-integrale](https://streaming-integrale.com/) - Movies / TV / Anime
* [flemmix](https://flemmix.party/) - Movies / TV / Anime / [Mirrors](https://ww1.wiflix-adresses.fun/) / [Telegram](https://t.me/flemmixwiflix)
* [cinelibre](https://cinelibre.fr/) - Free w/ Ads Aggregator
* [Play RTS](https://www.rts.ch/play/tv) - Free w/ Ads
* [Cinémathèque de Bretagne](https://www.cinematheque-bretagne.bzh/) - Classic / Amateur Movies
* [ICI Tou.tv](https://ici.tou.tv/) - Canada Public Broadcaster / Movies / TV / Docs / Cartoons / Requires Sign-Up
* [Télé-Québec](https://www.telequebec.tv/) - Québec Public Broadcaster / Movies / TV / Docs / Requires Sign-Up
* [TV5+](https://www.tv5plus.ca/) - Multiple Broadcasters / Movies / TV / Docs / No Sign-Up Required
* [TFO](https://www.tfo.org/) - Ontario French Public Broadcaster / Movies / TV / Docs / Anime / No Sign-Up Required
* [DocStream](https://docstream.fr/) - Documentaries
* [Voiranime](https://voir-anime.to/) - Anime / Sub / 1080p
* [FRAnime](https://franime.fr/) - Anime / Sub / 1080p
* [vostfree](https://vostfree.ws/) - Anime / Sub / 1080p
* [anime-sama](https://anime-sama.to/), [2](https://anime-sama.pw/) - Anime
* [French Anime](https://french-anime.com/) - Anime / Sub / 1080p
* [dessinanime](https://dessinanime.cc/) - Cartoons / Anime
* [FSTV](https://fstv.rest/) - Live TV
* [WITV](https://witv.football/) - Live TV
* [molotov.tv](https://www.molotov.tv/) - Live TV
* [tvradiozap](https://tvradiozap.eu/) - Live TV
* [callofliberty](https://callofliberty.fr/tv/tv.php) - Live TV
* [kiboanime](https://www.kiboanime.app/) - Anime Streaming Mobile App
* [Grafikart](https://grafikart.fr/) - Programming Courses
* [RTS Podcasts](https://www.rts.ch/audio-podcast/) - Podcasts
* [fluxradios](https://www.fluxradios.com/) - Radio Stations
* [programmes-radio](https://www.programmes-radio.com/fr/) - Radio Schedule / Streaming

## ▷ Reading / Lecture

* [Bookys](https://www.bookys-ebooks.com/) - Books / Comics / Magazines / Newspapers / Some NSFW
* [zone-ebook.com](https://zone-ebook.com/) - Books / Comics / Magazines / Newspapers / Audiobooks
* [⁠FourToutIci](https://fourtoutici.cc/) - Books / Manga / Magazines
* [Nos Livres](https://noslivres.net/) - Public Domain Books
* [⁠Gallica](https://gallica.bnf.fr/) - Books / Documents
* [Audiocite](https://www.audiocite.net/) - Audiobooks
* [litteratureaudio](https://www.litteratureaudio.com/) - Audiobooks / [Ripper](https://github.com/L-at-nnes/litteratureaudio.com-ripper)
* [Origines](https://mangas-origines.fr/) - Manga / Manhwa / Manhua / Some NSFW
* [Mangadraft](https://www.mangadraft.com/) - Manga / Comics / Webtoons / Light-Novels
* [Planete-BD](https://planete-bd.org/) - Manga / Comics
* [SushiScan](https://sushiscan.net/) - Manga
* [lelscanfr](https://lelscanfr.com/) - Manga
* [Theses.fr](https://www.theses.fr/) - Theses
* [FRDownMags](https://fr.downmagaz.net/) - Magazines / Some NSFW
* [Arlima](https://www.arlima.net/) - Medieval Literature Archive
* [ORAEDES](https://oraedes.fr/) - Occult / Esoteric

***

# ► German / Deutsch

* [xrel](https://www.xrel.to/) - Scene Release / P2P Tracker
* [Boerse](https://boerse.am/) - German Data Sharing Discussion Forum
* [animexx](https://www.animexx.de/) - German Anime Community
* [WiiDatabase](https://wiidatabase.de/) - Nintendo Homebrew
* [⁠BetterBahn](https://betterbahn.eu/) - Train Changeover App / [Mobile](https://github.com/l2xu/betterbahn)
* [⁠FirstWeek](https://www.firstweek.de/) or [All About Berlin](https://allaboutberlin.com/) - Expat Guides / Relocation Tools
* [F-Online](https://app.f-online.at/) - Austrian Driving License Learning App
* [Signsuisse](https://www.sgb-fss.ch/signsuisse/), [GebaerdenLernen](https://gebaerdenlernen.de/) or [SignDict](https://signdict.org) - German Sign Language Dictionaries / Learning

## ▷ Downloading / Herunterladen

* [Usenet DE Guide](https://github.com/PCJones/usenet-guide) - German Usenet Guide / [Discord](https://discord.gg/src6zcH4rr)
* [Radar / Sonarr DE Guide](https://github.com/PCJones/radarr-sonarr-german-dual-language/blob/main/GERMAN_DUAL_LANGUAGE_GUIDE_GER.md)
* [Crawli](https://crawli.net/) - Download Search
* [DarkLight](https://darklight.to/community/) - Video / Audio / ROMs / Books / Magazines / NSFW
* [Goldesel](https://goldesel.bz/) - Video / Audio / NSFW
* [Boerse](https://myboerse.bz/) - Video / Audio / NSFW
* [byte.to](https://byte.to/) - Video / Audio / Books / NSFW
* [Nima4k](https://nima4k.org/) - Video / Audio
* [FilmFans](https://filmfans.org/) - Video
* [hd-source](https://hd-source.to/) or [DDL-Warez](https://ddl-warez.cc/) - Video / NSFW
* [MLCBoard](https://mlcboard.com/) - Movies
* [MediathekView](https://mediathekview.de/) - Public Service Stream Download Tool
* [Anime-Loads](https://www.anime-loads.org/) - Anime
* [CannaPower](https://canna-power.to/) - Audio

## ▷ Streaming

* ⭐ **[Moflix](https://moflix-stream.xyz/)** - Movies / TV / Dub / 1080p / Select Free Source (Scroll Down)
* ⭐ **[Kinoger](https://kinoger.com/)** - Movies / TV / 1080p
* ⭐ **[S.TO](https://serienstream.to/)**, [2](https://serien.domains/) - TV / Anime / Dub / 720p
* ⭐ **[Movie2k](https://movie2k.cx/)** - Movies / TV / Dub
* ⭐ **[FilmPalast](https://filmpalast.to)** - Movies / TV / Dub / 720p
* [Kinoking](https://kinoking.cc/) - Movies / TV / Anime / Dub / 1080p
* [flixfilmplus](https://flixfilmplus.de/) - Movies / TV / Anime / Requires Sign-Up
* [Filmo](https://filmo.to/) - Movies / TV / Anime / 720p / [Mirrors](https://filmo.domains/)
* [Aether](https://aether.ist/), [2](https://aether.cx/) - Movies / TV / Anime / Auto-Next / [Discord](https://discord.gg/MadMF7xb5q)
* [megakino3](https://megakino20.com/) - Movies / TV / Anime
* [streamkiste.taxi](https://streamkiste.bid/) - Movies / TV / Dub / 720p
* [Einschalten](https://einschalten.in/) - Movies / Dub / 720p
* [Haschcon](https://haschcon.com/) - Movies / 720p
* [ardmediathek](https://www.ardmediathek.de/) - Public Broadcast
* [zdf](https://www.zdf.de/) - Public Broadcast
* [Burning Series](https://burningseries.ac/), [2](https://burningseries.cx/) - TV / Dub / 720p
* [Anime-Loads](https://www.anime-loads.org/) - Anime / Dub / 1080p
* [Aniworld](https://aniworld.to) - Anime / Sub / Dub / 720p / [Status](https://aniworld.domains/) / [Discord](https://discord.com/invite/xTkw6292Uj)
* [⁠TOGGO](https://www.toggo.de/) - Cartoons
* [dokustreams](https://dokustreams.de/) or [dctp.tv](https://www.dctp.tv/) - Documentaries
* [Stiftung imai](https://stiftung-imai.de/) - Video Archive
* [Edels Gute Stube](https://edels-stube.eu/) - Live TV / Sports / Movies / TV / Documentaries / Dub / 720p
* [LiveTV](https://livetv.sx/dex/) - Sports
* [SRF.CH](https://www.srf.ch/) - Live TV / Sports / Requires Swiss VPN
* [2ix2](https://www.2ix2.com/) - Live TV
* [livestream](https://www.livestream.ad/) - Live TV
* [⁠Zapp](https://github.com/mediathekview/zapp) - Live TV / Android
* [Studyflix](https://studyflix.de/) - Courses
* [mediathekviewweb](https://mediathekviewweb.de/) - IPTV
* [hoerspielprojekt](https://www.hoerspielprojekt.de/) - Radio

## ▷ Reading / Lesen

* [Dokumen](https://dokumen.pub/) - Books
* [EBook Land](https://www.ebook-land.cc/index.php) - Books / Magazines
* [DownMagaz](https://de.downmagaz.net/) - Magazines / NSFW
* [MyComics](https://www.mycomics.de/) - Comics
* [Projekt Gutenberg](https://www.projekt-gutenberg.org/) - Classic German Books
* [Sagen](https://www.sagen.at/) - European Ethnology / Folklore
* [deutschelyrik](https://www.deutschelyrik.de/) - Poetry
* [⁠DWDS](https://www.dwds.de/) - Dictionary

***

# ► Greek / Ελληνικά

## ▷ Streaming

* [Greek-Movies](https://greek-movies.com/) - Movies / TV / Live / Courses / Dub / 720p
* [filmatic](https://filmatic.online/) - Movies / TV
* [gamatotv](https://gamatotv.com.co/) - Movies / TV
* [movio](https://movio.club/) - Movies / TV
* [tainio-mania](https://tainio-mania.store), [2](https://tenies-online.best/), [3](https://voody-online.com/), [4](https://moomza.com/) - Movies / TV
* [eltube](https://www.eltube.gr/) - Movies
* [ertflix](https://www.ertflix.gr/en/) - Movies / TV
* [An1me](https://an1me.to/) - Anime / Sub / Dub / 1080p / [Discord](https://discord.com/invite/qPcUxRH)
* [GRecoTM Builds](https://grecotm.club/) - Kodi Builds / [Guide](<https://web.archive.org/web/20210925022803/https://en.iguru.gr/odigos-egkatastasis-ellinikou-build-sto-kodi/>) / [Discord](https://discord.com/invite/zVVfbDY)
* [GreekTV](https://greektv.app/) - IPTV
* [stokourbeti](https://stokourbeti.online/) - Live Sports
* [greekdocumentaries2](https://greekdocumentaries2.blogspot.com/) - Documentaries
* [Live24](https://live24.gr/) or [e-Radio](https://www.e-radio.gr/) - Radio
* [Subs4series](https://www.subs4series.com/), [greeksubs](https://greeksubs.net) or [subs4free](https://www.subs4free.club/) - Greek Subtitles

## ▷ Torrenting

* [AnimEclipse](http://www.animeclipse.com/) - Anime Torrents / [Discord](https://discord.com/invite/VU6UScPPCU)

***

# ► Hebrew / עברית

* [Ktuvit](https://www.ktuvit.me/) or [⁠Wizdom](https://wizdom.xyz/) - Subtitles
* [TranslationsMovieHEB](https://t.me/translationsmoviesheb) - Request Subtitle Translations
* [RedAlert](https://redalert.me/index_en.html), [Tzevaadom](https://www.tzevaadom.co.il/) or [RocketAlert](https://rocketalert.live/) - Rocket Alerts
* [⁠Danfish Gold](https://isl.danfishgold.com/) - Israeli Sign Language Dictionary

## ▷ Streaming / הזרמה

* [JFC](https://jfc.org.il/) - Israel Movie Archive
* [Animeil-TV](https://www.animeil-tv.com/) - Anime
* [aniplus](https://aniplus.co/) - Anime
* [GURUTV](https://gurutv.online/) - Live TV
* [israelTV](https://israeltv.online/) - Live TV
* [zradio](https://zradio.live/) - Radio Stations

## ▷ Downloading / הורדה

* [AnimeBlood](https://animebloodsub.net/) - Anime / Download / Sub

## ▷ Reading / קרוא

* [mangashelf](https://mangashelf.co.il/) - Manga

***

# ► Hungarian / Magyar

* [Turistautak](https://turistautak.hu/) - Hungarian Maps

## ▷ Streaming / Streamelés

* [hdmozi](https://hdmozi.hu/) - Movies / TV / Sub / Dub / 1080p
* [OnlineFilmekIngyen](https://www.onlinefilmekingyen1.com/) - Movies / Sub / Dub / 1080p
* [filmezek](https://filmezek.com/) - Movies
* [animedrive](https://animedrive.hu/) - Anime
* [Myonlinerádió](https://myonlineradio.hu/) - Radio Stations

## ▷ Torrenting / Torrentezés

* [HunTorrent](https://huntorrent.org/) - Movies / TV / Sub / Dub / 1080p
* [TorrentEmpire](https://torrent-empire.me/) - Torrent Discussion

***

# ► Indian Languages

* ↪️ **[India Exam Prep](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7_india_exam_prep)**
* [Ad-Link Bypass Bot](https://t.me/Nick_Bypass_Bot)
* [Indic-Keyboard](https://gitlab.com/indicproject/indic-keyboard) - Indian Android Keyboard
* [Bhashini](https://bhashini.gov.in/) - Live Translation App / Text and Speech
* [PCPriceTracker](https://pcpricetracker.in/) - PC Component Price Tracking
* [⁠Plan Compare](https://plancompare.in/) - Mobile Data Plan Comparisons
* [Jagraan Josh](https://www.jagranjosh.com/) - Indian Education / Exam News
* [NDL](https://www.ndl.gov.in/) - Indian Educational Resources / Books
* [⁠Tathya](https://tathyakosh.in/) - Indian Datasets
* [TalkingHands](https://talkinghands.co.in/) - Indian Sign Language Dictionary / Learning
* [IndianSignLanguage](https://indiansignlanguage.org/) - Indian Technical Sign Language Dictionary
* [RailRadar](https://railradar.in/railradar), [2](https://www.railjournal.in/) - India Live Train Map

## ▷ Downloading

* ⭐ **[VegaMovies](https://1vegamovies.baby/)** - Movies / TV / Anime / 4K / 1080p / [Telegram](https://telegram.dog/vega_officials)
* ⭐ **[UHDMovies](https://modlist.in/?type=uhdmovies)** - Movies / 4K
* ⭐ **[HDHub4u](https://hdhub4u.fr/)** - Movies / TV / 1080p / 4K
* ⭐ **[MoviesMod](https://mmodlist.org/?type=hollywood)** - Movies / TV / Sub / Dub / 1080p / [Bypass](https://greasyfork.org/en/scripts/474747)
* ⭐ **[ToonWorld4All](https://toonworld4all.me/)** - Anime / Cartoon / Geoblocked
* ⭐ **[ToonsHub](https://www.toonshub.my.id/)** - Anime / Dub / 1080p / [Telegram](https://t.me/s/toonshubupdates) / [Discord](https://dsc.gg/toonshub)
* ⭐ **[TamilMV](https://www.1tamilmv.lease/)** - Movies / TV / Anime / Sub / Dub / 4K / 1080p / Indian Languages
* [SSR Movies](https://ssrmovies.blue/) - Movies / TV / Sub / Dub / 1080p
* [TheMoviesBoss](https://themoviesboss.fans/) - Movies / TV
* [⁠4KHDHub](https://4khdhub.one/) - Movies / TV / 4K
* [⁠HindMoviez](https://hindmoviez.cafe/) - Movies / TV / Anime / 1080p
* [BollyMod](https://bollymod.study/) - Movies / TV / Anime / 1080p
* [⁠MoviesDrive](https://new2.moviesdrive.christmas/) - Movies / TV / 1080p
* [⁠Bollyflix](https://bollyflix.bi/) - Movies / TV / 1080p
* [KMMovies](https://kmmovies.life/) - Movies / TV / Anime / 1080p
* [KatMovieHD](https://new.katmoviehd.top/) - Movies / TV / Anime / Sub / Dub / 1080p
* [⁠GokuHD](https://www.gokuhd.com/) - Movies / TV / Anime / 1080p
* [OlaMovies](https://olamovies.dad/) - Movies / TV / Sub / Dub / 4K / 1080p / Use [Adblock](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_adblocking) / [Requests](https://space.olamovies.dad/)
* [DesireMovies](https://desiremovies.my/) - Movies / TV / Sub / Dub / 1080p
* [⁠CloudMoviez](https://new.cloudmoviez.shop/) - Movies / TV / Anime / 1080p / [Telegram](https://t.me/+yUWixySD57wyYThl)
* [Anime Dub Hindi](https://www.animedubhindi.link/) - Anime / Dub / 1080p
* [Toonhub4u](https://toonhub4u.co/) - Anime / Cartoon / Dub / 1080p / Geoblocked / [Telegram](https://telegram.me/joinchat/oHRgJ6SMZ6c3OTI1)
* [Indian Flac Songs](https://t.me/indianflacsongs) - Music / FLAC
* [Malayalam Film Songs](https://t.me/cc_NewMalayalamMp3) - Music
* [DJPunjab](https://djpunjab.is/) - Punjabi / Music
* [Isaimini](https://isaimini.com.co/) - Movies Music

## ▷ Torrenting

* ⭐ **[TamilMV](https://www.1tamilmv.lease/)** - Movies / TV / Anime / Sub / Dub / 4K / 1080p / Indian Languages

## ▷ Streaming

* ⭐ **[Kartoons](https://kartoons.to/home)** - Cartoons / [Discord](https://discord.com/invite/5fKH3TYVmE)
* ⭐ **[PirateXPlay](https://piratexplay.cc/)** - Cartoons / Anime / [Mirrors](https://piratexplay.com/)
* ⭐ **[ToonStream](https://toonstream.vip/)** - Cartoons / Anime / 1080p / [Telegram](https://telegram.me/toonstream)
* ⭐ **[MultiMovies](https://multimovies.wtf/)** - Movies / TV / .guru Always Redirects to Main / [Telegram](https://telegram.me/+8Is7Ezz56fNkZDZl)
* ⭐ **[Anime World India](https://watchanimeworld.one/)**, [2](https://animesalt.cx/) - Anime
* [TamilMV](https://www.1tamilmv.lease/) - Movies / TV / Anime / Sub / Dub / 4K / 1080p / Indian Languages / [Telegram](https://t.me/tmvog)
* [Einthusan](https://einthusan.tv/) - Movies / 1080p / VPN Required
* [saicord](https://saicord.com/hi/) - Movies / TV
* [PlayTorrio](https://playtorrio.xyz/), [2](https://playtorrio.pages.dev/) - All Platforms / Use PlayTorrioHTTP Plugin / [Subreddit](https://www.reddit.com/r/PlayTorrio/) / [Discord](https://discord.gg/bbkVHRHnRk)
* [CinemaOS](https://cinemaos.live/), [2](https://cinemaos.tech/) - Movies / TV / Anime / Auto-Next / Watch Parties / [Discord](https://discord.gg/38yFnFCJnA)
* [TamilGun](https://tamilgun.now/) - Tamil Movies / TV / Dub / 1080p / 720p
* [1Shows](http://1shows.org), [1Flex](https://www.1flex.org/) or [1Tube](https://www.1tube.org/) - Movies / TV / Anime / Auto-Next / [4K Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/1shows-note.md)
* [TamilCrow](https://www.1tamilcrow.net/) - Tamil Movies
* [tamilbulb](https://tamilbulb.cc/) - Tamil Movies
* [tamilblasters](https://www.1tamilblasters.tech/) - Movies / TV / Anime
* [BollyZone](https://www.bollyzone.to/) - Movies / TV / 1080p
* [flixsix](https://flixsix.com/) - Movies / TV / Dub / 1080p
* [HydraHD](https://hydrahd.com/) - Movies / TV / Anime / Auto-Next / [Status](https://hydrahd.info/)
* [Anime Joker](https://animejoker.com/) - Movies / TV / Anime
* [Abibli](https://abibli.com/) - Movies / TV
* [myflixbd](https://myflixbd.to/) - Movies / TV / Anime
* [PRMovies](https://prmovies.exchange/) - Movies / TV / Anime
* [UniqueStream](https://uniquestream.net/) - Movies / TV / Anime / 720p
* [Screenscape](https://screenscape.me/) - Movies / TV / Anime
* [Movi](https://www.movi.pk/) - Movies / TV / Dub / 1080p
* [1tamilyogi](https://1tamilyogi.ro/) - Movies / TV
* [5movierulz](https://www.5movierulz.fitness/) - Movies / TV / Anime
* [Cloudy](https://cloudy.pk/) - Movies / TV / Cartoons / Sub / Dub / 720p / [Telegram](https://t.me/cloudypkmovies)
* [⁠MX Player on Prime](https://www.primevideo.com/collection/streamfree?tr=in) - Movies / TV / Free w/ Ads
* [IndianCine](https://indiancine.ma/) - Indian Short / Classic Movies
* [⁠Anixo](https://anixohindi.cc/) - Anime
* [⁠Anime Sky](https://animesky.app/) - Anime
* [1XAnime](https://1xanimes.com/) - Anime / [Telegram](https://t.me/onexanimes)
* [Aniflix](https://aniflix.uno/) - Anime / [Telegram](https://t.me/Aniflix_Anime_Requests)
* [desidubanime](https://www.desidubanime.me/) - Anime
* [mxplayer](https://www.mxplayer.in/) - Movies
* [Desi Serials](https://www.desi-serials.to/) - TV
* [desitv](https://www.desitv.to/) - TV
* [⁠All In One Live TV](https://allinonelivetv.pages.dev/) - Live TV
* [crickmail](https://crickmail.pages.dev/channel-13) - Live Cricket
* [Vega App](https://github.com/Zenda-Cross/vega-app) - Movies / TV / Android App
* [Indian IPTV App](https://github.com/kananinirav/Indian-IPTV-App) - IPTV Android App
* [OnlineFMRadio](https://www.onlinefmradio.in/) - Radio
* [hungama](https://www.hungama.com/music/) - Music
* [jiosaavn](https://www.jiosaavn.com/) or [Hayasaka](https://hayasaka.8man.in/) - Music
* [Swayam Central](https://swayam.gov.in/) - Free Courses
* [GateSmashers](https://www.youtube.com/@GateSmashers) - Gate Preparation / Educational

## ▷ Reading

* [Digital Library of India](https://dli.sanskritdictionary.com) - Books
* [⁠Bankelal Comics Lite](https://play.google.com/store/apps/details?id=com.comicslover.bankelalcomics) - Classic Comics App / Use Adblocker
* [NDLI](https://ndl.iitkgp.ac.in/) - Educational Resources / Documents
* [Sanskrit Documents](https://sanskritdocuments.org) or [sanskritsahitya](https://sanskritsahitya.org/) - Esoteric Texts
* [Hindwi](https://hindwi.org/) - Hindi Poems
* [Jainism Library of Jain Literature](https://www.atmadharma.com/index.html) - Jainism Texts

***

# ► Indonesian / Bahasa Indonesia

* [bebasid](https://github.com/bebasid/bebasid) - Indonesian Site Unblock Proxies / [DNS](https://github.com/bebasid/bebasdns) / [Script](https://gist.github.com/mul14/eb05e88fcec5bb195cbb)

## ▷ Downloading / Mengunduh

* ⭐ **[Lendrive](https://lendrive.web.id/)** - Movies / Anime / Sub / Dub / 1080p / x265
* [ngefilm](https://new39.ngefilm.site/) - Movies / TV / Anime
* [Kusonime](https://kusonime.com/) - Anime / Sub / Dub / 1080p / [Discord](https://discord.com/invite/4A7RqFraZW)
* [AniBatch](https://www.animebatch.id/) - Anime / Dub / 1080p
* [Samehadaku](https://samehadaku.care/) - Anime / Sub / 1080p / [Telegram](https://t.me/samehadaku_care)
* [Doronime](https://doronime.id/) - Anime / Sub / 1080p
* [IndonesiaEbook](https://ebook.twointomedia.com/) - Books
* [madrotter-treasure-hunt](https://madrotter-treasure-hunt.blogspot.com/) - Music

## ▷ Streaming / Menyiarkan

* ⭐ **[OtakuDesu](https://otakudesu.cloud/)** - Anime / Sub / 720p
* [idlixku](https://idlix.net/) - Movies / TV
* [klikxxi](https://klikxxi.shop/), [2](https://www.klikxxi.com/) - Movies / TV
* [Samehadaku](https://samehadaku.care/) - Anime / Sub / 1080p / [Telegram](https://t.me/samehadaku_care)
* [Irama Nusantara](https://www.iramanusantara.org/en) - Music

## ▷ Reading / Membaca

* [Pustaka Langka](https://langka.logosid.app/) - Classic Books
* [Komiku](https://komiku.org/) - Manga
* [maid.my](https://www.maid.my.id/) - Manga
* [softkomik](https://softkomik.co/) - Manga
* [sora-ich](https://sora-ich.vercel.app/) - Manga
* [⁠Voratoon](https://voratoon.id/) - Manhwa / Manga / Manhua
* [BacaLightNovel](https://bacalightnovel.co/) - Light Novels
* [Sakuranovel](https://sakuranovel.id/) - Light Novels
* [meionovels](https://meionovels.com/) - Light Novels
* [catatannusantara](https://www.catatannusantara.com/pustaka) - History Books
* [sastra](https://www.sastra.org/) - History Wiki

***

# ► Italian / Italiano

* 🌐 **[The Italian Corsairs](https://rentry.co/the-italian-corsairs)** - Piracy Sites List
* [⁠Raiscuola](https://www.raiscuola.rai.it/italianoperstranieri) - Italian Language Learning
* [Signsuisse](https://www.sgb-fss.ch/signsuisse/) - Italian Sign Language Dictionary

## ▷ Downloading / Scaricare

* ⭐ **[Ipersphera](https://www.ipersphera.com/)** - Movies / TV / Sub
* [OverDay](https://overday.org/) - Courses / Books / [Mirrors](https://justpaste.it/OVERPOSTING) / [2](https://filecrypt.co/Container/B25EED8329.html) / [Telegram](https://t.me/Overposting1)
* [HD4ME](https://rentry.co/FMHYB64#hd4me) - Movies
* [XDCC Mule](https://www.xdccmule.org/) - IRC Download Search

## ▷ Torrenting

* [MIRCrew](https://mircrew-releases.org/) - Movies / TV / Anime
* [ICV Crew](https://www.icv-crew.com/forum/) - Torrent Forum
* [TNT Village](https://tntvillage-db.programmiedovetrovarli.it/) - Torrent Aggregator

## ▷ Streaming

* [StreamingUnity](https://streamingunity.fun/it) - Movies / TV / Anime
* [StreamingCommunity](https://streamingcommunityz.photos/) - Movies / TV / 1080p / [Status](https://telegra.ph/Link-Aggiornato-StreamingCommunity-09-29) / [Telegram](https://t.me/+YID6ZoJtgjg5NGEx)
* [CB01](https://cb01uno.cyou/) - Movies / TV / Dub / 1080p / [Telegram](https://t.me/s/cb01_nuovo_indirizzo_ufficiale)
* [7Movies](https://7movies.ac/) - Movies / TV / Anime / Auto-Next / [Discord](https://discord.gg/JxgRaYMVHF)
* [Mediaset Infinity](https://mediasetinfinity.mediaset.it/) - Live TV / Movies / TV / Documentaries / Radio / Dub / Requires Italian VPN / Sign-Up Unlocks Extra Features
* [RaiPlay](https://www.raiplay.it/) - Live TV / Movies / TV / Dub / Requires Italian VPN / Sign-Up Unlocks Channel History
* [AnimeWorld](https://www.animeworld.ac/) - Anime / Sub / Dub / 1080p / [Mirrors](https://www.animeworlditalia.com/) / [Telegram](https://t.me/AnimeWorldITA2)
* [AnimeSaturn](https://www.animesaturn.net/) - Anime / Sub / Dub / 1080p / [Mirrors](https://www.animesaturn.me/) / [Telegram](https://t.me/AnimeSaturnRedirect)
* [AnimeUnity](https://www.animeunity.co/) - Anime / Sub / Dub / 1080p / [Telegram](https://t.me/animeunitytv)
* [Toonitalia](https://toonitalia.xyz/) - TV / Anime / Sub / Dub
* [Arcoiris TV](https://www.arcoiris.tv/) - Italian TV / 720p
* [Stream4Me](https://guruhitech.com/kodi-on-demand-e-rinato-ora-si-chiama-stream4me-kodi/) - Streaming Kodi Addon
* [⁠Federica Web Learning](https://federica.eu/) - Courses
* [Raiplay Sound](https://www.raiplaysound.it/) - Podcasts / Radio

## ▷ Reading / Leggere

* [LiberLiber](https://liberliber.it/opere/libri/) - Books
* [MangaWorld](https://www.mangaworld.mx/) - Manga / [Telegram](https://t.me/MangaWorldITA)
* [hastateam](https://ddt.hastateam.com/) - Manga
* [Slumberland](https://www.slumberland.it/) - Comic Encyclopedia
* [EFP Fanfiction](https://efpfanfic.net/) - Fanfiction

***

# ► Japanese / 日本語

* [MiniTokyo3D](https://minitokyo3d.com/) - Tokyo Public Transport Map
* [Poipiku](https://poipiku.com/) - User-Made Images
* [⁠Voicevox](https://voicevox.hiroshiba.jp/) - FOSS Japanese TTS / Singing Synthesis
* [Annict](https://annict.com/) - Anime Tracker
* [Japanese Subtitles](https://gist.github.com/tatsumoto-ren/78ba4e5b7c53c7ed2c987015fa05cc2b) or [AJATT](https://subtitles.ajatt.top/) - Subtitles
* [Jimaku](https://jimaku.cc/) - Anime Subtitles
* [Japan Reference](https://jref.com/) - Japanese Culture Forum
* [fuseji](https://fuseji.net/) - Hidden Character Search
* [Yahoo Japan](https://search.yahoo.co.jp/) - Search
* [megalodon](https://megalodon.jp/) or [gyo.tc](https://gyo.tc/) - JP Web Archive Tool
* [Pixiv Guides](https://www.pixiv.net/howto) / [Ideas](https://www.pixiv.net/idea/) - Drawing Guides / Inspiration
* [MangaMaterials](https://www.youtube.com/channel/UCnx8zKs3c3yeFPYQ2QzMqLA/) / [X](https://x.com/mangamaterials2), [animesijyuku](https://www.youtube.com/@animesijyuku/) or [DoKiDoKiDrawing](https://www.youtube.com/@DoKiDoKiDrawing/) - Manga Video Tutorials / [Pixiv](https://www.pixiv.net/en/users/16776564)

## ▷ Downloading / ダウンロード

* ⭐ **[TheMoeWay](https://learnjapanese.moe/)** - Japanese Media / [Discord](https://discord.gg/nhqjydaR8j)
* [Akiba-Online](https://www.akiba-online.com/) - Video / Audio / Comics / NSFW / 1080p
* [JPop Singles](https://www.jpopsingles.eu/) - Music / MP3 / FLAC
* [Doujin Cafe (Discord)](https://discord.gg/doujincafe) - Music / MP3 / FLAC
* [Doujin Music](https://rentry.co/FMHYB64#doujin-music) - Music / MP3
* [DoujinStyle](https://doujinstyle.com/) - Music / MP3 / FLAC
* [J-pop Music Download](https://jpop.xyz/) - Music / MP3 / FLAC
* [Perfect Dark](https://perfectdark.benri-tool.net/) - P2P App

## ▷ Streaming / ストリーミング

* ↪️ **[Anime Streaming](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25B7_anime_streaming)** - Anime Streaming Sites
* [NicoVideo](https://www.nicovideo.jp/) - Japanese YouTube Alternative / [Desktop](https://github.com/tor4kichi/Hohoema)
* [Japanese Animated Film Classics](https://animation.filmarchives.jp/index.html) - Japanese Animation Archive
* [Abema](https://abema.tv/) - Live TV
* [⁠JapanTV](https://japantv.app/) - YouTube TV Style Browser
* [iptv-jp](https://rentry.co/FMHYB64#iptv-playlists) - Japanese IPTV Resources
* [National Film Archive of Japan](https://meiji.filmarchives.jp/) - Japanese Movie Archive
* [SimulRadio](https://simulradio.info/) - Radio
* [Kagakueizo](https://www.kagakueizo.org/) - Science Documentaries
* [Twitcasting](https://twitcasting.tv/) - Live Streaming

## ▷ Reading / 読書

* 🌐 **[Rawmangaz](https://clarasguide.valeena.workers.dev/Guides/rawmangaz/)** or **[EverythingMoe Raws](https://everythingmoe.com/section/manga?filter=Raws)** - List of Raw Manga Sites
* [⁠EPUB.MOE](https://epub.moe/) - Books
* [shobon](http://17db.pw/) - Novels / Magazines
* [senmanga](https://raw.senmanga.com/) - Manga / Novels / NSFW
* [DLRaw](https://dlraw.app/), [2](https://manga-zip.my/), [3](https://manga-zip.is/), [4](https://ww0.13dl.app/), [5](https://ww13.manga-zip.app/) - Manga
* [Raw-Zip](https://raw-zip.com/) - Manga
* [MangaZone](https://www.manga-zone.org/) - Manga
* [RawCans](https://raw-cans.net/) - Manga
* [BSZip](https://bszip.com/) - Manga
* [DLZip](https://dl-zip.com/) - Manga
* [MangaBox](https://www.mangabox.me/) - Manga
* [Mangaz](https://www.mangaz.com/) - Manga
* [shinmoemanga](https://shinmoemanga.neocities.org/) - Manga
* [Comic Walker](https://comic-walker.com/) - Manga
* [mangajikan](https://mangajikan.is/) - Manga
* [Rawkuma](https://rawkuma.com/) - Manga
* [soraraw](https://soraraw.com/) - Manga
* [KL](https://klz9.com/idx) - Manga
* [A-zmanga](https://www.a-zmanga.net/) - Manga
* [AsianMediaBlog Manga](https://asiamediablog.com/media/comic/manga/) - Manga
* [Comic77.com](https://comic77.com/) - Manga
* [888DL](https://888dl.ps/) - Manga
* [KLManga](https://klz9.com/) - Manga
* [rawfree](https://rawfree.to/) - Manga
* [rawkuma](https://rawkuma.net/) - Manga
* [raw1001](https://raw1001.net/) - Manga
* [mangakoma01](https://mangakoma01.net/) - Manga
* [mangakoma](https://mangakoma.net/) - Manga
* [rawfree](https://rawfree.buzz/) - Manga
* [spoilerplus](https://spoilerplus.tv) - Manga
* [boroboro](https://boroboro.neocities.org/) - Manga
* [tonarinoyj](https://tonarinoyj.jp/) - Manga
* [Honto](https://honto.jp/cp/ebook/recent/free.html) - Manga / NSFW
* [CMOA](https://www.cmoa.jp/) - Manga
* [youngaceup](https://web-ace.jp/youngaceup/) - Manga

***

# ► Korean / 한국어

* ⭐ **[wrtn](https://wrtn.ai/)** - GPT-4 Chatbot / [Android](https://play.google.com/store/apps/details?id=com.wrtn.app) / [iOS](https://apps.apple.com/us/app/%EB%A4%BC%ED%8A%BC-%EB%AA%A8%EB%91%90%EB%A5%BC-%EC%9C%84%ED%95%9C-ai-%ED%8F%AC%ED%84%B8/id6448556170) / No Sign-Up
* [Arca](https://arca.live/) - Forum
* [dic.daum](https://dic.daum.net/) - Korean Translator / Spellchecker
* [TadakTadak](https://tadaktadak.co.kr/) - Korean Practice / English Learning
* [EBS](https://www.ebs.co.kr/) - Korean Courses for the Visually / Hearing Impaired
* [Awesome Cafe](https://github.com/utilForever/awesome-cafe) - Korean Cafe List
* [Sldict](https://sldict.korean.go.kr/) - Sign Language Learning
* [Free Korean Fonts](https://www.freekoreanfont.com/) - Korean Fonts
* [Etoland](https://etoland.co.kr/) - Bulletin Board
* [litt.ly](https://start.litt.ly/) - Personal Link Homepage

## ▷ Downloading

* [CinEast](https://cineaste.co.kr/) - Movies / TV / Sub / 1080p
* [K-pop Music Download](https://jpop.xyz/category/k-pop/) - Music / MP3 / FLAC
* [KPopExplorer](https://kpopexplorer.net/) - Music / MP3 / FLAC
* [ilKPOP](https://ilkpop.in/) - Music / MP3

## ▷ Streaming

* [OnDemandKorean](https://www.ondemandkorea.com/) - Movies / TV / 720p
* [UniqueStream](https://uniquestream.net/) - Movies / TV / Anime / 720p
* [AQ Stream](https://aqstream.com/) - Live TV / [Discord](https://discord.com/invite/dVhgAgwxHE)
* [Chzzk](https://chzzk.naver.com/) - Live Streams
* [eHistory](https://www.ehistory.go.kr/) - Video Archive / Cultural Films

## ▷ Reading

* [kakao](https://page.kakao.com/) - Manga
* [MangaViewAndroid](https://junheah.github.io/MangaViewAndroid/) - Manga
* [GoodToon](https://www.goodtoon003.com/) - Manhua / [Telegram](https://t.me/goodtoon_url)
* [Namu Wiki](https://namu.wiki/w/나무위키:대문) - Korean Wiki

***

# ► Persian / فارسی

* 🌐 **[Awesome Freedom](https://github.com/hiddify/awesome-freedom)** - Tools Index
* 🌐 **[Free VPN Telegram Channels](https://bin.disroot.org/?85b66e37980b245e#DRbHouuNMfXGRdqPs68y6nGLULhHdvdXzuPdDmBxsyi2)** - Free VPNs Index
* [cscot](https://cscot.pages.dev/2023/07/10/v2ray-geoip-iran/) - V2Ray GeoIP Guide
* [MasterDnsVPN](https://github.com/masterking32/MasterDnsVPN) - Censorship Bypass Tool / [Support](https://t.me/MasterDnsVPNGroup) / [Telegram](https://t.me/masterdnsvpn)
* [⁠projectXhttp](https://t.me/projectXhttp) - Xray-Core Telegram Group
* [Persian Calendar](https://github.com/persian-calendar/persian-calendar) - Android Persian Calendar
* [⁠FilterWatch](https://filter.watch/) - Censorship News / Articles
* [parseek](https://www.parseek.com/) - Search

## ▷ Downloading / دانلود

* 🌐 **[Persian Telegram Courses](https://rentry.co/sn66v)** - Persian Courses Index
* [git_ir](https://t.me/git_ir) - Programming Courses
* [DigiMovie](https://digimoviez.com/) - Movies / TV / Sub / Dub / 1080p
* [iranianfilmarch](https://t.me/iranianfilmarch) - Iranian Movies / 1080p
* [AnimeSubtitle](https://animesubtitle.ir/) - Anime Subtitles
* [TeleLeecherbot](https://t.me/TeleLeecherbot) - Movie Leech Telegram Bots
* [FilmgramBot](https://t.me/FilmgramBot) or [FileMovieBot](https://t.me/FileMovieBot) - Movie Search Telegram Bots
* [hoseinwave](https://rj.hoseinwave.ir/) - Javen Radio Downloader

## ▷ Streaming / پخش

* [Live Farsi](https://www.diycraftsguide.com/safeasli) - Persian Movies / TV / Live / 1080p
* [Nostalgik](https://nostalgiktv.org/) - Persian Movies / TV / Cartoons / 720p
* [imvbox](https://www.imvbox.com/) - Movies / TV / Sub
* [hikoca](https://persiamovbox.com/) - Movies / TV
* [Cineverse](https://streaming.cineverse.com/) - Free w/ Ads
* [ParsaTV](https://www.parsatv.com/) - Live TV
* [Awesome Persian Podcasts](https://github.com/ashkanRmk/awesome-persian-podcasts) - Podcasts

## ▷ Reading / خواندن

* [Afghanistandl](https://afghanistandl.nyu.edu/) - Historical Books

***

# ► Polish / Polski

* [Poland.gg](https://poland.gg/) - Data & Statistics
* [JakDojade](https://jakdojade.pl/) - Public Transport Map
* [Tekstowo](https://www.tekstowo.pl/) - Lyrics
* [Napisy24](https://napisy24.pl/), [GrupaHatak](https://grupahatak.pl/) or [KickAssSubtitles](https://kickasssubtitles.com/pl) - Subtitles
* [AnimeSub.info](http://animesub.info/) - Anime Subtitles
* [slownikpjm](https://www.slownikpjm.uw.edu.pl/) - Polish Sign Language Dictionary

## ▷ Downloading / Pobieranie

* ⭐ **[Grupa Mirai](https://www.grupa-mirai.pl/)** - Anime / Sub / 1080p / [Discord](https://discord.gg/WyXrp6ZK5J)
* [Polish Abandonware](https://polish-abandonware.pl/) - Abandonware / [Discord](https://discord.gg/TuDSpDzDsh)

## ▷ Torrenting / Torrentowanie

* ⭐ **[Grupa Mirai](https://www.grupa-mirai.pl/)** - Anime / Sub / 1080p / [Discord](https://discord.gg/WyXrp6ZK5J)
* [polskie-torrenty](https://helltorrents.com/index.php) - Video / Audio / Books / NSFW
* [devil-torrents](https://devil-torrents.pl/) - Video / Audio / Books / NSFW
* [Electro Torrent](https://electro-torrent.pl/) - Video / Audio / Books

## ▷ Streaming

* 🌐 **[Polish Kodi Addons](https://github.com/mtr81/kodi_addons)**
* 🌐 **[FilmWeb](https://www.filmweb.pl/vod/free)** - Free w/ Ads Service Index
* ⭐ **[Shinden](https://shinden.pl/)** - Anime / Sub / 1080p / [Discord](https://discord.gg/xyH5uS6)
* ⭐ **[Obejrzyj](https://www.obejrzyj.to/)** - Movies / TV
* ⭐ **[Grupa Mirai](https://www.grupa-mirai.pl/)** - Anime / Sub / 1080p / [Discord](https://discord.gg/WyXrp6ZK5J)
* ⭐ **[Strumyk](https://strumyk.pk/)** or [Strims24](https://strims24.pl/) / [2](https://strims24.st/) - Stream Aggregator / [Status](https://strumyk.domains/)
* [Virpe](https://virpe.cc/) - Movies / TV
* [Vestroiakr](https://vestroiakr.blogspot.com/) - Movies / TV / Anime
* [Zaluknij](https://zaluknij.cc/) - Movies / TV / Anime
* [filmyonline](https://filmyonline.cc/) - Movies / TV / Anime
* [ninateka](https://ninateka.pl/) - Movies
* [Bajeczki24](https://bajeczki24.pl/) - Movies / TV
* [Ekino-TV](https://ekino.ws/), [2](https://ekino.sx/), [3](https://ekino.ws/) - Movies / TV / Sub / 720p / [Mirrors](https://ekino-tv.link/)
* [KreskówkaSubs](https://kreskowkasubs.blogspot.com/) - Cartoons / Sub / Dub
* [Filman](https://filman.cc/) - Movies / TV
* [iitv](https://iitv.info) - TV
* [centrum-dramy](https://centrum-dramy.pl/) - Asian Drama
* [Rakuten](https://www.rakuten.tv/pl/gardens/avod-fast) - Free w/ Ads
* [sweet.tv](https://sweet.tv/pl/) - Free w/ Ads / Channels Only / [Login Bypass](https://github.com/Julmik647/sweet-tv-no-login)
* [vod.tvp](https://vod.tvp.pl/) - Free w/ Ads
* [Pilot](https://pilot.wp.pl/) - Free w/ Ads
* [megogo](https://megogo.net/) - Free w/ Ads
* [player.pl](https://player.pl/) - Free w/ Ads
* [FilmPolski](https://filmpolski.pl/fp/index.php) - Polish Video Archive
* [docchi](https://docchi.pl/) - Anime / Sub / 1080p / [Kodi Addon](https://github.com/skoruppa/plugin.video.docchipl)
* [animezone](https://www.animezone.pl/) - Anime / Sub / 720p
* [FrixySubs](https://frixysubs.pl/) - Anime / Sub / 1080p
* [Nana Subs](https://nanasubs.com/) - Anime / Sub / 1080p
* [Anime Odcinki](https://anime-odcinki.pl/) - Anime / Sub / 1080p
* [OgladajAnime](https://ogladajanime.pl/) - Anime / Sub / 1080p
* [Desu-Online](https://desu-online.pl/) - Anime / Sub / 1080p
* [Sport TVP](https://sport.tvp.pl/) - Live Sports
* [35mm](https://35mm.online/) - Film Archive / [Database](https://filmpolski.pl/fp/index.php)
* [dokumentalne](https://dokumentalne.net/) - Documentaries
* [radio-polska](https://www.radio-polska.pl/) or [radioyanosik](https://radioyanosik.pl/) - Radio
* [Purevideo](https://majusss.github.io/) - Streaming App / Android / [GitHub](https://github.com/majusss/purevideo)
* [FlowFlix](https://flowflix.vercel.app/) - Streaming App / Windows, Android / [Discord](https://discord.gg/VSUWb283RK) / [GitHub](https://github.com/qJulianx/FlowFlixWeb)
* [Naikamu](https://github.com/FezMLG/Naikamu) - Anime Streaming App / [Altstore](https://api.altstore.io/source/api.naikamu.com/api/store?app=com.tltcode.naikamu) / Android, iOS
* [adapter](https://adapter.pl/) - Descriptive Audio for Blind Users

## ▷ Reading / Czytanie

* [wolnelektury](https://wolnelektury.pl/) - Books / Fiction / Audiobooks
* [Audiobook PL](https://audiobookpl.tumblr.com/) - Audiobooks
* [Academica](https://academica.edu.pl/) - Online Library
* [Docer PL](https://docer.pl/) - Books / [Downloader](https://github.com/seszele64/docer-downloader) / [Firefox Extension](https://addons.mozilla.org/firefox/addon/docer-downloader/)
* [Shinden](https://shinden.pl/) - Manga / [Discord](https://discord.gg/xyH5uS6)

***

# ► Portuguese / Português

* **Note** - Brazil is known for blocking some piracy sites, try using a [VPN](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_vpn) if you can't access one.

***

* 🌐 **[Pirataria Megathread](https://pirataria.link)** - Portuguese /r/Piracy Mega / [Subreddit](https://www.reddit.com/r/pirataria/)
* 🌐 **[Invertexto](https://www.invertexto.com)** - Online Tools Index
* 🌐 **[Tudo Que Você Precisa](https://rentry.co/FMHYB64#tudo-que-voc%C3%AA-precisa)** - Portuguese TTRPG Resources
* [SAPO](https://www.sapo.pt) - Search
* [Legendas Brasil](https://legendasbrasil.org) - Subtitle Search App
* [Legendas.net](https://legendas.net) or [Legenda Oficial](https://legendei.net/) - Subtitles
* [Educa Mais Brasil](https://www.educamaisbrasil.com.br/enem/guia-enem) - ENEM Study Material
* [Flutterando](https://github.com/Flutterando/roadmap) - Flutter Guides
* [Escola Kids](https://escolakids.uol.com.br) - Kids Learning
* [Atari2600](https://www.atari2600.com.br) - Browser Emulator
* [Racha Cuca](https://rachacuca.com.br) - Puzzles / Trivia
* [Jogorama](https://jogorama.com.br) - Game Index / Tips
* [Dicionário MPB](https://dicionariompb.com.br) - Top Song Charts

## ▷ Downloading / Baixar

* ⭐ **[WR Educacional](https://www.wreducacional.com.br)** - Courses
* [Os Reformados](https://osreformados.com) - Video / Audio / Magazines / Some NSFW / Sub / Dub / 1080p
* [Online Cursos Gratuitos](https://onlinecursosgratuitos.com) - Courses
* [Escola Educação](https://escolaeducacao.com.br/estude-gratis) - Courses
* [Mundo Ubuntu](https://www.mundoubuntu.com.br) - Courses / Tech Guides

## ▷ Torrenting

* 🌐 **[Trackers.md](https://pirataria.link/trackers)** - Private Tracker Index
* [Download Cult](http://downloadcult.org) - Classic Movies
* [Sua Música](https://www.suamusica.com.br) - Audio / MP3

## ▷ Streaming

* ⭐ **[Gyn Cursos](https://gyncursos.com.br)**, [Curso em Vídeo](https://www.cursoemvideo.com), [iEstudar Cursos](https://iestudar.com) or [Pensar Cursos](https://www.pensarcursos.com.br) - Courses
* [99](https://www.99.media/pt/) - Documentaries / Sub / 1080p
* [Libreflix](https://libreflix.org) - Portuguese TV / Documentaries / 720p
* [AnimeFire](https://animefire.one/) - Anime / Sub / 1080p
* [redecanais](https://redecanais.af/) - Movies / TV / Anime
* [goyabu](https://goyabu.io/) - Anime / Sub
* [NetMovies](https://www.netmovies.com.br) - Movies / TV / Requires Login
* [Bombozila](https://bombozila.com) - Movies / TV / Requires Login
* [Olhos na TV](https://www.olhosnatv.com.br) - Live TV / Sports
* [CXTv](https://www.cxtv.com.br) - Live TV
* [TV Gazeta](https://www.tvgazeta.com.br/aovivo/) - Live TV
* [TV Cultura](https://cultura.uol.com.br/aovivo/) - Live TV
* [Kultivi](https://kultivi.com/) - Courses
* [Prime Cursos](https://www.primecursos.com.br) - Courses
* [UNIASSELVI](https://portal.uniasselvi.com.br/cursolivre) - Courses
* [Canal do Ensino](https://canaldoensino.com.br/blog/) - Courses
* [Omie](https://academy.omie.com.br) - Courses
* [MOOC GGTE](https://moocs.ggte.unicamp.br) - Courses
* [Núcleo do Conhecimento](https://www.nucleodoconhecimento.com.br) - Courses
* [Escola Virtual Gov](https://www.escolavirtual.gov.br/catalogo) - Courses
* [Veduca](https://veduca.org) - Courses
* [Eaulas](https://eaulas.usp.br/portal/home) - Learning Videos
* [Moodle](https://moodle.ifrs.edu.br/course/index.php?categoryid=38) - MOOC Courses
* [Marcos Aba](https://www.youtube.com/@MarcosAba/videos) - Math Courses
* [DIO](https://www.dio.me) - Development Courses
* [Palco MP3](https://www.palcomp3.com.br) - Music / MP3
* [Rádio J-Hero](https://radiojhero.com) - Radio
* [Radios.com.br](https://www.radios.com.br) - Radio
* [Radiosaovivo.net](https://radiosaovivo.net) - Radio
* [radio.net](https://br.radio.net) - Radio
* [tudoradio.com](https://tudoradio.com) - Radio
* [Super Rádio Tupi](https://www.tupi.fm) - Radio
* [A Rádio Rock](https://www.radiorock.com.br) - Radio
* [Vagalume FM](https://vagalume.fm) - Radio
* [Hunter.FM](https://hunter.fm) - Radio
* [M80 Rádio](https://m80.pt) - Radio
* [TSF](https://www.tsf.pt) - Radio
* [Radio.pt](https://www.radio.pt) - Radio
* [Antena 1](https://www.antena1.com.br) - Radio
* [CXRadio](https://www.cxradio.com.br) - Radio
* [Harpa Cristã](https://harpacrista.org), [2](https://play.google.com/store/apps/details?id=br.com.masterapps.harpacristagratis) - Christian Music / MP3
* [Papo de Gordo](https://www.papodegordo.com.br/category/podcast/) - Podcasts
* [Kboing FM](https://www.kboingfm.com.br/podcast/) - Podcasts

## ▷ Reading / Leitura

* [Bússola Escolar](http://www.bussolaescolar.com.br) - Educational Search Engine
* [Livros Narrados](https://livrosnarrados.blogspot.com) - Audiobooks
* [Biblioteca Brasiliana](https://digital.bbm.usp.br/handle/bbm/1) - Books
* [Baixe Livros](https://www.baixelivros.com.br) - Books
* [eBooksBrasil](https://ebooksbrasil.org) - Books
* [Online Cursos Gratuitos](https://onlinecursosgratuitos.com) - Books
* [Doceru](https://doceru.com/) - Books
* [⁠Biblioteca Digital](https://bibliotecadigital.aemrt.pt/) - Public Domain / Educational Books
* [Cultura Acadêmica](https://www.culturaacademica.com.br) - Educational Books
* [Toomics](https://global.toomics.com/br) - Comics
* [Arte HQs](http://www.artehqs.com.br) - Comics
* [Tropa BR](https://tropabrscans.blogspot.com) - Comics
* [Banda Desenhada](https://bandadesenhada-pt.blogspot.com/) - Comics
* [Novel Mania](https://novelmania.com.br) - Light Novels
* [Central Novel](https://centralnovel.com) - Light Novels
* [Tsundoku Traduções](https://tsundoku.com.br) - Light Novels
* [syosetu](https://syosetu.com/) - User Light Novels
* [fanfiction.com](https://fanfiction.com.br/) - Fanfiction
* [Revista PROGRAMAR](https://www.revista-programar.info) - Programming Magazine
* [Escritas.org](https://www.escritas.org) - Poetry / Quotes
* [Luso-Poemas](https://www.luso-poemas.net) - Poetry
* [Poesias Online](https://salmosonline.com/) - Poetry
* [Site de Poesias](https://sitedepoesias.com) - Poetry
* [A Magia da Poesia](https://poemassemerros.wordpress.com) - Poetry
* [bibliotecaelfica](https://bibliotecaelfica.org/) - RPG Books
* [Superarquivo](https://super.abril.com.br/superarquivo/) - Magazines
* [Jornais e Revistas](https://www.jornaiserevistas.com) - Magazines
* [VerCapas](https://www.vercapas.com.br) - Magazines
* [Revista do Linux](https://augustocampos.net/revista-do-linux/index.html) - Linux Magazine
* [Jornais Brasileiros](https://www.jornaisbrasileiros.net.br) - News App
* [Toda Matéria](https://www.todamateria.com.br) - Learning Material
* [Brasil Escola](https://brasilescola.uol.com.br) - Learning Material
* [Mundo Educação](https://mundoeducacao.uol.com.br) - Math / History
* [Acessaber](https://acessaber.com.br) - Math Lessons
* [BORE](https://obrasraras.usp.br) - Historical Documents
* [Recanto das Letras](https://www.recantodasletras.com.br) - Text Archive
* [RetroArquivo](https://retroarquivo.wordpress.com) - Portuguese Game Magazines
* [Arquivo.pt](https://arquivo.pt) - History / Sociology / Linguistics Archives
* [Desciclopédia](https://desciclopedia.org/wiki/P%C3%A1gina_principal) - Wikipedia Parody

***

# ► Romanian / Limba Română

* [arhivabac](https://www.arhivabac.com/) or [pro-matematica](https://www.pro-matematica.ro/) - Romanian Exam Prep

## ▷ Downloading

* [xCinema.ro](https://www.xcinema.ro/) - Movies / TV / Sub / 720p
* [FilmePeAlese](https://www.filmepealese.com/) - Movies / TV / Sub / 720p
* [lib2life](https://rentry.co/FMHYB64#lib2life) - Historical Books

## ▷ Streaming

* [Namaste Serials](https://namasteserials.com/) - Movies / TV / Sub / 720p
* [Deseneledublate](https://deseneledublate.com/) - Movies / TV / Sub / 720p
* [fsonline](https://www3.fsonline.app/) - Movies / TV / Sub
* [desenefaine](https://desenefaine.com/) - Movies / TV / Sub
* [xfilme](https://xfilme.ro/) - Movies
* [clicksud](https://click-sud.pro/) - TV
* [filmflix](https://filmflix.ro/) - Movies
* [vezihd](https://vezihd.ro/) - Movies
* [ClickSud](https://clicksud.co/) - Movies / TV / Sub / 720p
* [VoxFilmeOnline](https://voxfilmeonline.biz/) - Movies / TV / Sub / 720p
* [luminsangelsseriale](https://luminsangelsseriale.com/) - Movies / TV
* [DozaAnimată](https://www.dozaanimata.net/) - Anime / Cartoons / Sub / Dub / 720p
* [Cool TV Online](https://www.cool-etv.net/) - Live TV / Sports
* [Subs.ro](https://subs.ro/), [Subtitrari](https://www.subtitrari-noi.ro/) or [Titrari](https://www.titrari.ro/) - Subtitles

***

# ► Russian / Русский

* [Ru.Board](https://forum.ru-board.com/) - Piracy Discussion Forum
* [subtitry](https://subtitry.net/) or [DXP](https://dxp.ru/) - Subtitles
* [TGStat](https://tgstat.ru/) - Telegram Channel Stats
* [WASM](https://www.wasm.in/) - Web Assembly Forum
* [ScreenChat](https://screenchat.live/) - Create Fake Texts
* [government_rus](https://t.me/government_rus) - Official Government Telegram
* [zakupki_time](https://t.me/zakupki_time) - Government Procurement Watch
* [Што за шрифт?](https://t.me/+lZD1qlHA3sFhMzQy) - Fonts

## ▷ Russian Anti-Censorship

* ↪️ **[Anti-Censorship Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25B7_anti-censorship)** / **[Proxy Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_proxy)**
* [⁠VPN Traffic Light](https://vpn.maximkatz.com/) - Russian VPN Statuses
* [rks_org_Bot](https://t.me/rks_org_bot) or [protocol_vpn](https://t.me/protocol_vpn) - Censorship Discussion Telegrams
* [⁠EtoNeYa](https://etoneya.su/), [wl](https://github.com/zieng2/wl) or [⁠LowiK](https://lowik.gitverse.site/lowik/) - Mobile Network Censorship Bypass

## ▷ Downloading / Скачивание

* ⭐ **[4PDA](https://4pda.to/forum/)** / Android, iOS / [App](https://github.com/slartus/4pdaClient-plus)
* [Androeed](https://androeed.store/), [2](https://androeed.ru/) / Android
* [tancpol](https://tancpol.net/) - Music / MP3
* [Course Hunter](https://coursehunter.net/) or [Sliwbl](https://s1.sliwbl.com/) - Programming Courses

## ▷ Torrenting / Торрентинг

* 🌐 **[toptracker](https://toptracker.ru/)** - Torrent Site List
* 🌐 **[UpTracker](https://www.uptracker.ru/)** - Torrent Tracker Index
* ⭐ **[RuTracker](https://rutracker.org/)**, [2](https://rutracker.net/) - Video / Audio / Comics / Magazines / Requires VPN / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent#wiki_.25BA_torrent_sites)
* [krasfs](https://krasfs.ru/) or [torrent.by](https://torrent.by/) - Torrent Search
* [rutor](https://rutor.info/) - Video / Audio / Books / ROMs / Magazines
* [PiratBit](https://pb.wtf/), [2](https://piratbit.top/) - Video / Audio / Books / Comics / Magazines / NSFW
* [rustorka](https://rustorka.com/forum/index.php) - Video / Audio / Books / ROMs / Games / Magazines
* [Korsars](https://korsars.pro/) - Video / Audio / Books
* [DDGroupClub](http://ddgroupclub.win/) - Video / Audio / Books / ROMs
* [Spaider](https://spaider.net/) - Video / Audio / ROMs
* [NNM-Club](https://nnmclub.to/) - Video / Audio
* [RIPS](https://rips.club/) - Movies / TV / Concerts
* [Fast torrent](http://fast-torrent.ru/) - Movies / TV / Anime
* [Animelayer](https://animelayer.ru/) - Anime
* [bitru](https://bitru.org/) - Movies
* [Selezen](https://www.selezen.club/) - Movies
* [RGFootball](https://rgfootball.net/) - Sports

## ▷ Streaming / Стриминг

* ⭐ **[Kinohub](https://on.kinohub.vip/)**, [2](https://tv.kinohub.vip/), [3](https://kinomix.web.app/) - Movies / TV / Anime / Sub / Dub / 1080p / [Telegram](https://t.me/KinohubLive)
* ⭐ **[KinoGo](https://kinogo.ec/)**, [2](https://kinogo.luxury/), [3](https://kinogo2026.com/) - Movies / TV / Anime / Sub / Dub / 1080p / [Telegram](https://t.me/+itg2xfHPNQg2MGVk)
* ⭐ **[YummyAnime](https://ru.yummyani.me/)** - Anime / Sub / Dub / 1080p / [Telegram](https://t.me/yummyanime) / [Discord](https://discord.com/invite/yummyanime-1103691943881474048)
* ⭐ **[AnimeLIB](https://animelib.org/)** - Anime / Sub / Dub / 1080p (account required) / [Telegram](https://t.me/mangalib_social)
* [HD VideoBox](https://strannikmodz.me/apps/media/135-hdvideobox-222.html) - Movies / TV / Anime / Aggregator / Android App / [AMOLED](https://strannikmodz.me/other_modz/sirenes_team/127-hd-videobox-st-221.html)
* [KinoBase](https://kinobase.org/) - Movies / TV / Sub / Dub / 1080p
* [kinokong](https://kinokong.es/) - Movies / TV / Dub / 1080p
* [EX-FS](https://ex-fs.net/) - Movies / TV / Anime / Dub / 1080p
* [Zona Plus](https://w140.zona.plus/) - Movies / TV / Anime / Dub
* [KinoFlux](https://kinogo.fit/) - Movies / TV / Dub / 1080p
* [filmix](https://filmix.gg/) - Movies / TV / Anime / 720p
* [Kinotochka](https://kinovibe.cc/) - Movies / TV / Anime / Dub / 720p
* [filmozavr](https://filmozavr.com/) - Movies / TV / Anime / Dub
* [seasonvar](https://seasonvar.ru/) - TV / Dub / 720p
* [Shiza Project](https://shiza-project.com/) - Anime / Dub / 720p
* [AniFilm](https://anifilm.pro/) - Anime / Sub / 1080p
* [AniLiberty](https://aniliberty.top/) - Anime / Sub / Dub / 1080p / [Telegram](https://t.me/aniliberty_tv) / [Discord](https://discord.gg/M6yCGeGN9B)
* [Animestars](https://animesss.com/) - Anime / Sub / 1080p
* [Anidub](https://anidub.pro/) - Anime / Sub / Dub / 1080p / [Telegram](https://t.me/anidubofficial) / [Discord](https://discord.com/invite/QF6Kn99tsu)
* [Tunime](https://an0ncer.github.io/) - Anime / Sub / 1080p
* [yummyanime](https://yummyanime.tv/) - Anime
* [AniLabX](https://anilabx.xyz/) - Android Anime / Cartoons / Drama App
* [RUkino](https://rukino.org/) - Russian Movies / TV / 1080p
* [Soviet Movies Online](https://sovietmoviesonline.com/) - Soviet Movies / Sub
* [Dokonlin](https://www.dokonlin.online/) - Documentaries / Dub / 1080p
* [liveam](https://liveam.tv/) - TV
* [mult-fan](https://mult-fan.tv/) - Cartoons
* [Ok.ru](https://ok.ru/), [VK](https://vk.com/) - Russian Video Sharing Sites
* [animatsiya](https://animatsiya.net/) - Russian Animation Archive
* [TurkishTV](https://turkishtv.co/), [turserial](https://turserial.info/), [KinoTurk](https://kinoturk.net/) or [TurkRu.TV](https://turkrutv.net/) - Turkish TV w/ Russian Subs
* [TVRF](https://tvrf.online/) - Live TV
* [Viks](https://live.viks.tv/) - Live TV
* [Telik](https://telik.top/) - Live TV
* [ontivi](https://ip.ontivi.net/) - Live TV
* [smotret](https://smotret.tv/) - Live TV
* [federal](https://federal.tv/) - Live TV
* [RUTube Live](https://rutube.ru/feeds/live/) - Live TV
* [televizor](https://televizor24.tv/tv/) - Live TV
* [livestream](https://www.livestream.ad/) - Live TV
* [Glaz.tv](https://glaz.tv/) - Live TV
* [DomaTV](http://live.domatv.net/) - Live TV
* [finttv](https://finttv.in/) - Live Sports
* [Anixart](https://anixart-app.com/) - Anime / Sub / Dub / 720p / Android App / [Telegram](https://t.me/anixart)
* [z3.fm](https://z3.fm/) - Music
* [E:\\music\\](https://vk.com/e_music) - Music
* [Russian Records](https://www.russian-records.com/) - Russian Record Recordings
* [Top Radio](https://top-radio.ru/) - Radio
* [recradio](https://t.me/recradio) - Radio
* [Teach.in](https://teach-in.ru/) - Lectures
* [videotuts](https://videotuts.ru/) - Design Video Tutorials

## ▷ Reading / Чтение

* ⭐ **[CyberLeninka](https://cyberleninka.ru/)** - Articles / Educational / Scientific / Legal
* ⭐ **[Lib.ru](http://lib.ru/)** - Books
* ⭐ **[Flibusta](https://flibusta.is/)** - Books / [.onion](http://flibustaongezhld6dibs2dps6vm4nvqg2kp7vgowbu76tzopgnhazqd.onion/) / [.i2p](http://flibusta.i2p/), [2](http://zmw2cyw2vj7f6obx3msmdvdepdhnw2ctc4okza2zjxlukkdfckhq.b32.i2p/)
* [Knowledge Base](https://dontaz.com/knowledge-base), [2](https://dontaz.github.io/), [3](https://dontaz.pages.dev/), [4](https://dontaz.vercel.app/) - Educational Recommendations
* [VK Book DL Pages](https://redd.it/kne0ba)
* [Twirpx](https://www.twirpx.com/) - Books / Educational
* [alleng](https://www.alleng.org/) - Textbooks
* [11klasov](https://so.11klasov.net/) - Textbooks
* [rusneb](https://rusneb.ru/) - Books
* [obuchalka.org](https://obuchalka.org/) - Books / Homework Solutions
* [Flibusta](https://flibusta.site/) - Books
* [coollib](https://coollib.xyz/) - Books
* [libking](https://libking.ru/) - Books
* [Maxima Library](https://maxima-library.com/) - Books
* [rulit](https://www.rulit.me/) - Books
* [bookscafe](https://bookscafe.net/) - Books / Some NSFW
* [freedomist](https://t.me/freedomist_7ks_bot) - Books / Telegram Bot
* [MirKnig.sur](https://mirknig.su/) - Books / Fiction / Nonfiction
* [Litgu.ru](https://litgu.ru/) - Books / Audiobooks
* [Fantasy Worlds](https://fantasy-worlds.org/) - Books / Audiobooks
* [booktracker](https://booktracker.org/) - Books / Audiobooks / Comics / Magazines / NSFW
* [LibraryOfDos](https://t.me/lib_of_dos_old_vk) - Esoteric Literature
* [AniLabX](https://anilabx.xyz/) - Manga / Comics / Light Novels
* [⁠HexNovels](https://hexnovels.me/) - Light Novels / Web Novels
* [Gameland](https://gameland.ru/archive/) - Country of Games Magazine Archive
* [MangaLIB](https://mangalib.me/) - Manga / Comics / [Telegram](https://t.me/mangalib_social)
* [MangaPoisk](https://mangapoisk.me/) - Manga
* [ReManga](https://remanga.org/) - Manga / Comics / [Telegram](https://t.me/Remanga) / [Discord](https://discord.gg/5UHGXajYPD)
* [Manga Hub](https://mangahub.ru/) - Manga
* [⁠Com-X](https://com-x.life/) - Comics
* [mmnt](https://www.mmnt.ru/) - Document Search
* [Samlib](http://samlib.ru/) - Document Search
* [militera](http://militera.org/) - Military History
* [Arzamas](https://arzamas.academy/) - Cultural History
* [geokniga](https://www.geokniga.org/) - Geology Documents
* [Playing Soviet](https://commons.princeton.edu/soviet/) - Children's Books
* [Baza Knig](https://baza-knig.top/), [Flibusta_Anglysky](https://t.me/flibusta_anglysky), [Аkniga](https://akniga.org/), [Bibl](https://biblus.org/) - Audiobooks
* [Science Lab](https://fantlab.ru/) - Sci-Fi Book Discussion

***

# ► Slovak / Slovenčina

## ▷ Streaming

* [jOj Archive](https://www.joj.sk/relacie) - Movies / TV
* [tuu.to](https://tuu.to/) - Movies / TV / Geoblocked
* [Markiza](https://www.markiza.sk/) - Movies / TV
* [rtvs](https://www.rtvs.sk/televizia/archiv) - TV
* [Bombuj](https://bombuj.si/) - Movies / TV
* [sweet.tv](https://sweet.tv/) - Free w/ Ads / Channels Only / [Login Bypass](https://github.com/Julmik647/sweet-tv-no-login)
* [MojeVideo](https://www.mojevideo.sk/), [2](https://m.mojevideo.sk/) - User Videos

## ▷ Torrenting

* [sktorrent](https://sktorrent.eu/) - Movies / TV / Anime

## ▷ Reading

* [pdfknihy](https://pdfknihy.sk/zadarmo/) - Books
* [eknizky](https://eknizky.sk/) - Books / Requires Sign-Up for Downloads

***

# ► Spanish / Español

* 🌐 **[Awesome Telegram Redcarpet](https://listados.gitlab.io/awesome-telegram-redcarpet/)**, [2](https://gitlab.com/listados/awesome-telegram) - Telegram Channel Index
* [Minijuegos](https://www.minijuegos.com/) - Browser Games
* [AIfindy](https://aifindy.com/) - AI Tools Index
* [Diccionario RAE en un clic](https://chromewebstore.google.com/detail/diccionario-rae-en-un-cli/gejdeepcjkfbepfkcfdgiodgoglakiii) - Dictionary Extension
* [SubDivX](https://www.subdivx.com/) - Subtitles
* [⁠Fundacion CNSE](https://fundacioncnse-dilse.org/) - Spanish Sign Language Dictionary
* [Diccionario de LESCO](https://diccionario.handsonlesco.com/) or [⁠Diccionario LESCO](https://lesco.cenarec.go.cr/index.php/diccionariolesco) - Costa Rican Sign Language Dictionaries
* [WikiDex](https://www.wikidex.net/) - Pokémon Wiki / [Discord](https://discord.com/invite/Tb6B3Fq)

## ▷ Downloading / Descargar

* ⭐ **[eMule](https://www.emule-project.com/home/perl/help.cgi?l=17&rm=show_topic&topic_id=586)** - Video / Audio / Reading / NSFW / Castilian
* ⭐ **[Curso_vip](https://t.me/Curso_vip)** - Courses / Books
* [identi](https://identi.io/) - Video / Audio / Reading / Latino / Castilian
* [Zinfinal](https://zinfinal.com/) - Video / Audio / Reading / Latino / Castilian / Signup Required / [Discord](https://discord.com/invite/TyxzVb5xPA)
* [ExVagos](https://www.exvagos.org/) - Video / Audio / Reading / Castilian
* [Gun's Cave](https://lacuevadeguns.com/forum/index.php?action=forum) - Video / Audio / Reading / Castilian
* [latabernadelcangrejo](https://www.latabernadelcangrejo.eu/) - Video / Audio / Signup
* [SomosMovies](https://somosmovies.org/) - Movies / TV / 1080p
* [Fiuxy2](https://fiuxy2.co/) - Video / Audio / Reading / NSFW
* [PelisEnHD](https://pelisenhd.org/) - Movies / TV / Anime / 4K / Latino / Castilian
* [LatinoMegaHD](https://www.latinomegahd.net/) - Movies / TV / 4K / 1080p / Latino
* [⁠Descargatepelis](https://descargatepelis.com/) - Movies / TV / [Telegram](https://t.me/descargatepelis_oficial)
* [Hackstore.rs](https://hackstore2.com/) - Movies / TV / Anime / 1080p / Latino
* [Mega1080](https://www.mega1080.com/) - Movies / Documentaries / 1080p / Latino
* [MegaPeliculasRip](https://megapeliculasrip.me/) - Movies / Classics / TV / Animation / 1080p / Latino
* [SeiresHD](https://seireshd.com/) - Movies / TV / Animation / 1080p / Latino
* [mirandopeliculas](https://www.mirandopeliculas.com/) - Movies / TV / Latino
* [Cine24h](https://cine24h.online/) - Movies / TV / Sub / Dub / 720p
* [relampagomovies](https://relampagomovies.com/) - Movies / TV
* [subtituladas.com](https://subtituladas.com/) - Movies / Sub / 720p
* [Bajalo Gratis](https://bajalogratis.com/) - Movies / Latino
* [Mega DVDRip](https://peliculas-dvdrip.com/) - Movies / TV / Latino / Castilian
* [Gatonplayseries](https://gatonplayseries.com/) - Movies / TV / Latino / Anime
* [Peliculas Google Drive](https://www.peliculasgd.net/) - Movies / Latino
* [TodoDVDFull](https://www.tododvdfull.com/) - Movies / Latino
* [DescargasDD](https://descargasdd.org/) - Video / Audio / Castilian / Latino / Requires Waitlist / [Telegram](https://t.me/joinchat/VAWOu0TNfOXfnauA)
* [Info Real](https://rentry.co/FMHYB64#info-real) - Argentine Films
* [RetroCanal](https://retrocanal.net/) - Classical Movies / TV
* [DivX Clásico](http://www.divxclasico.com/) - Classical Movies / TV / ED2K Links
* [RebeldeMule](https://www.rebeldemule.org/) - Movies / Classics / TV / Documentaries / Reading / ED2K Links / [Telegram](https://telegram.me/rebeldemule)
* [exploradoresp2p](https://exploradoresp2p.com/) - Movies / Classics / TV / Documentaries / ED2K Links
* [Shadow-Rangers](https://shadowrangers.net/) - Anime / Sub / Dub / Latino / Castilian
* [Daemon Anime](https://www.daemonanime.net/) - Anime / Sub / Dub / Latino
* [japanpaw](https://japanpaw.com/) - Anime
* [ivanime](https://www.ivanime.com/) - Anime / [Discord](https://discord.gg/PTbSKQbBJc)
* [DW Anime](https://dw-anime.net/) - Anime
* [AZ Anime](https://www.az-animex.com/) - Anime
* [sphinxanime](https://sphinxanime.com/) - Anime
* [CrisAnime](https://crisanimex.com/) - Anime / Sub / Dub
* [TioDonghua](https://tiodonghua.lat/) - Anime / Sub / Light Novels
* [Fukou-Da!](https://fukou-da.net/) - Anime / Sub / Light Novels / [Discord](https://discord.com/invite/MqmX3ZJApE)
* [punkconpunk](https://punkconpunk.blogspot.com/) - MP3 / Punk Music
* [⁠Roms en Español](https://romsenespanol.com/) - ROMs / Use [Redirect Bypass](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools#wiki_.25B7_redirect_bypass)
* [Hello-Python](https://github.com/mouredev/Hello-Python) or [python-web](https://github.com/mouredev/python-web) - Python Courses

## ▷ Torrenting / Torrentear

* ⭐ **[MejorTorrent](https://www46.mejortorrent.eu/)** - Movies / TV / Documentaries / Castilian / [Status](https://privtr.ee/@mejortorrent)
* [DonTorrent](https://dontorrent.moi/), [2](https://donproxies.com/) - Movies / TV / Documentaries / Castilian / [.onion](https://dontorufwmbqhnoe2wvko5ynis6axf7bqod6wkmdvxmjyek64tantlqd.onion/) / [Status](https://privtr.ee/@dontorrent) / [Telegram](https://t.me/s/DonTorrent)
* [EliteTorrent](https://www.elitetorrent.com/) - Movies / TV
* [Wolfmax4k](https://wolfmax4k.com/) - Movies / TV / 4K / 1080p
* [CalidadTorrent](https://calidadtorrent.com/) - Movies / TV / Documentaries / Casti
* [PasateaTorrent](https://pasateatorrent.org/) - Movies / TV / Castilian
* [DiXvA](https://www.sinsitio.site/) - Movies / TV / Music / NSFW / [Telegram](https://t.me/+YSdB1y9VdjAzNDkx)
* [Hacktorrent](https://hacktorrent.cc/) - Movies / TV / Anime / Latino
* [Unionfansub](https://foro.unionfansub.com/index.php) - Anime
* [Akiba-kei](http://akiba-team.org/) - Anime / [Discord](https://discord.com/invite/8bPmS3q)

## ▷ Streaming / Streamear

* ⭐ **[HDFull](https://dominioshdfull.com/)** - Movies / TV / Anime / 1080p / Signup Required / Castilian / Latino
* ⭐ **[PelisForte](https://pelisforte.se/)** - Movies / TV / [Telegram](https://t.me/+AoDIyo4alws1OGMx)
* ⭐ **[Cinubo](https://cinubo.com/)** - Movies / TV / Anime / Signup Required / [Status](https://enlaces.ly/) / [Telegram](https://t.me/seriesly) / [Discord](https://discord.com/invite/pmDQYHxjnA)
* ⭐ **[AnimeAV1](https://animeav1.com/)** - Anime
* ⭐ **[LaQuay TDT Channels](https://www.tdtchannels.com/)** - Live TV / Live Radio / IPTV / Castilian / [GitHub](https://github.com/LaQuay/TDTChannels)
* [Zonaleros](https://www.zona-leros.com/peliculas-hd-online-lat) - Movies / TV / 1080p / Latino
* [Solo Latino](https://sololatino.net/) - Movies / TV / Anime / 1080p / Latino
* [PlayTorrio](https://playtorrio.xyz/), [2](https://playtorrio.pages.dev/) - All Platforms / Use PlayTorrioHTTP Plugin / [Subreddit](https://www.reddit.com/r/PlayTorrio/) / [Discord](https://discord.gg/bbkVHRHnRk)
* [Tubepelis](https://www.tubepelis.com/) - Movies / TV
* [7Movies](https://7movies.ac/) - Movies / TV / Anime / Auto-Next / [Discord](https://discord.gg/JxgRaYMVHF)
* [LaMovie](https://lamovie.org/) - Movies / TV / Anime / [Telegram](https://t.me/centrodeactividades)
* [hackstore2](https://hackstore2.com/) - Movies / TV
* [Aether](https://aether.ist/), [2](https://aether.cx/) - Movies / TV / Anime / Auto-Next / [Status](https://rentry.co/aetherdomains) / [Discord](https://discord.gg/MadMF7xb5q)
* [Cinezo](https://www.cinezo.st/) - Movies / TV / Anime / Auto-Next / Watch Parties / [Discord](https://discord.gg/yWWKfMbtm3)
* [RaroVHS](https://www.rarovhs.com/) - Rare Spanish Content
* [PelisPedia](https://pelispedia.mov/) - Movies / TV / Latino
* [⁠CompucaliTV](https://compucalitv.lol/) - Movies / TV / [Telegram](https://t.me/compucalitv_peliculas)
* [⁠Descargatepelis](https://descargatepelis.com/) - Movies / TV / [Telegram](https://t.me/descargatepelis_oficial)
* [fuegocine](https://www.fuegocine.com//) - Movies / TV / [Telegram](https://t.me/Cine_Fuego)
* [⁠Pelisgo](https://pelisgo.online/) - Movies / TV / [Telegram](https://t.me/pelisgochat)
* [⁠El Videoclub Argento](https://www.elvideoclubargento.com.ar/) - Argentine Films
* [Zoowomaniacos](https://zoowomaniacos.org/) - Movies / TV / Rare Films
* [Tubi Spanish](https://tubitv.com/category/spanish_language) - Free w/ Ads / May Require VPN
* [Plex Spanish](https://watch.plex.tv/es/on-demand/category/en-espanol) / [Live TV](https://watch.plex.tv/es/live-tv) - Free w/ Ads
* [Pluto Spanish](https://pluto.tv/) - Free w/ Ads
* [tele-libre](https://tele-libre.live/) - Live TV
* [⁠Teleonline](https://teleonline.org/) - Live TV
* [rtvcplay](https://rtvcplay.co/) - Free Public Colombian TV
* [angulismotv](https://angulismotv.pages.dev) - Live Sports
* [stream-xhd](https://streamxhd.com/) - Live Sports
* [librefutboltv](https://futbol-libre.com.co/) - Live Football
* [Listas-IPTV](https://rentry.co/FMHYB64#iptv-playlists) - Spanish IPTV Resources
* [Cinecalidad](https://www.cinecalidad.am/) / [LaMovie](https://lamovie.org/) - Movies / TV / Animation / Latino / [Telegram](https://t.me/micinecalidad)
* [detodopeliculas](https://detodopeliculas.nu/) - Movies / TV
* [verpeliculasonline](https://verpeliculasonline.org/), [2](https://ver-peliculas-online.org/) - Movies / TV
* [PelisPedia.is](https://pelispedia.is/) - Movies / TV
* [CineHDPlus](https://cinehdplus.org/) - Movies / TV
* [EntrePeliculasySeries](https://entrepeliculasyseries.nz/) - Movies / TV / Anime
* [VerPeliculasUltra](https://verpeliculasultra.com/) - Movies
* [Cinedeantes](https://cinedeantes2.weebly.com/) - Classic Films
* [Series Peruanas](https://seriesperu.com/) - TV / Drama
* [Doramasflix](https://doramasflix.co/) - Asian Drama / Sub / Latino / [Telegram](https://t.me/+BnaUn49pKwZkZDMx)
* [Asialiveaction](https://asialiveaction.com/) - Asian Drama
* [Doramasyt](https://www.doramasyt.com/) - Asian Drama
* [Vix](https://www.vix.com/tv/) - TV / LATAM Only
* [Cine Libre Online](https://www.cinelibreonline.com/) - YouTube Movies
* [Argentine Cinema](https://www.youtube.com/@argentinecinemawithenglish4476/) - Argentine YouTube Movies
* [Cine.Arplay](https://play.cine.ar/) - Argentinian Movies / TV
* [Cinemargentino](https://www.cinemargentino.com/) - Movies / Documentaries / Signup Required
* [⁠retinalatina](https://www.retinalatina.org/) - Movies / Documentaries
* [Platfo Filmo](https://filmo.platfo.es/pages/home) - Spanish Film Archives
* [CCLM](https://www.cclm.cl/cineteca-online) - Chilean Film Archives
* [Naranjas de Hiroshima](https://www.naranjasdehiroshima.com/) - Documentaries / Archives
* [DocumaniaTV](https://www.documaniatv.com/) - Documentaries
* [Area Documental](https://www.area-documental.com/) - Documentaries / [Remove Watermark](https://pastebin.com/e77cHmgm), [2](https://github.com/acridsoul/Clear-Mark)
* [Latanime](https://latanime.org/) - Anime / Sub / Dub / Latino
* [JKAnime](https://jkanime.net/) - Anime / Sub
* [Animejara](https://animejara.com/) - Anime / Sub / [Discord](https://discord.com/invite/MTzZTPffXs)
* [TioAnime](https://tioanime.com/) - Anime / Sub
* [⁠InfinityAnime](https://infinityanime.net/) - Anime
* [Animed23](https://animed23.com/) - Anime / [Telegram](https://t.me/+8nmOjT1PWFczZDhh)
* [veranimes](https://wwv.veranimes.net/) - Anime
* [mundodonghua](https://www.mundodonghua.com/) - Anime / Sub
* [estrenosanime](https://estrenosanime.net/) - Anime
* [animeonline](https://ww3.animeonline.ninja/) - Anime / Sub
* [LACartoons](https://www.lacartoons.com/) - Cartoons
* [LatinLucha](https://latinlucha.es/) - WWE / MMA Replays / Latino
* [EventosHQ](https://www.eventoshq.me/) - WWE / MMA Replays / Latino
* [Tangos78rpm](https://www.tangos78rpm.com/) - Classic Records

## ▷ Reading / Leer

* ⭐ **[EpubLibre](https://www.epublibre.org/)** - Books / Torrents / May Require VPN
* ⭐ **[Spanish Reading CSE](https://cse.google.com/cse?cx=85e4a562f2abf40f6)** - Multi-Site Book Search
* [eBiblioteca](https://ebiblioteca.org/) - Books
* [LectuEpub](https://lectuepublibre6.com/) - Books
* [LectuEpubGratis](https://lectuepubgratis3.com/) - Books
* [Lectulandia](https://ww3.lectulandia.com/), [2](https://ww3.lectulandia.co/) - Books
* [Bibliotecasecreta](https://telegra.ph/Biblioteca-Secreta-09-22-2) - Telegram Book Bot
* [Elejandría](https://www.elejandria.com/) - Books
* [El Libro Total](https://www.ellibrototal.com/ltotal/) - Books / Audiobooks
* [⁠Textos](https://www.textos.info/) or [⁠BNE Digital](https://bdh.bne.es/) - Public Domain Books
* [FreeLibros](https://www.freelibros.net/) - Textbooks / Books / Audiobooks / Magazines / Courses / Documentaries
* [Librotecarios](https://librotecarios.blogspot.com/) - Textbooks
* [⁠Clásicos de Historia](https://clasicoshistoria.blogspot.com/) - History Books
* [⁠Biblioteca Antológica](https://www.biblioteca-antologica.org/es/) - XIII-XX Centuries Literature Archive
* [Libros de la Nube](https://librosdelanube.blogspot.com/) - Textbooks
* [albalearning](https://albalearning.com/) - Audiobooks
* [LibriVox](https://librivox.org/search?primary_key=5&search_category=language&search_page=1&search_form=get_results&search_order=alpha) - Audiobooks
* [Nova](https://novelasligeras.net/) - Manga / Light Novels
* [⁠Yupmanga](https://www.yupmanga.com/) - Manga / Light Novels
* [Manga en Español](https://t.me/manga_es) - Manga
* [HeavenManga](https://heavenmanga.com/) - Manga
* [ShadowManga](https://shademanga.com/) - Manga / [Telegram](https://t.me/+ABwdbE41wtMzMGM0) / [Discord](https://discord.com/invite/WFyMxAreEr)
* [⁠Ikigai Mangas](https://ikigaimangas.com/) - Manga
* [InManga](https://inmanga.com/) - Manga
* [kumanga](https://www.kumanga.com/) - Manga / Some NSFW
* [absorbiendomangas2](https://absorbiendomangas2.blogspot.com/) - Manga
* [lexmangas](https://www.lexmangas.com/) - Manga
* [⁠MangaOni](https://manga-oni.com/) - Manga / Some NSFW
* [Scanlation](https://olympusxyz.com/) - Manga
* [mangavault](https://mangavault.lat/) - Manga / Some NSFW / [Discord](https://discord.com/invite/GEzeWRRShM)
* [⁠Spnmanga](https://www.spnmanga.com/) - Manga
* [⁠M440](https://m440.in/) - Manga
* [⁠Animebbg](https://animebbg.net/) - Manga
* [anzmangashd](https://www.anzmanga25.com/) - Manga
* [vermanhwa](https://vermanhwa.com/) - Manga
* [manhwaweb](https://manhwaweb.top/) - Manhwa / Manga / Some NSFW / [Discord](https://discord.com/invite/BRY6qya8uc)
* [SkyMangas](https://www.skymangas.com/) - Manga / [Discord](https://discord.com/invite/4aS7HBNFkf)
* [faneo](https://www.faneo.es/) - Manga
* [⁠RN scalation](https://rncalation.online/) - Manga / [Discord](https://discord.com/invite/drzqCgaZgU)
* [⁠Capibaratraductor](https://capibaratraductor.com/) - Manga
* [Izicomics](https://www.izicomics.com/) - Manga / Comics
* [⁠Marmota](https://marmota.me/) - Comics
* [MegaComicsTV3](https://megacomicstv3.blogspot.com/) - Comics
* [novenadimension](https://foro.novenadimension.com/) - Comics / Downloads
* [⁠SkyNovels](https://www.skynovels.net/) - Light Novels
* [tupropiaaventura_bot](https://t.me/tupropiaaventura_bot) - Text Adventure / Telegram
* [Librosgratis](https://librosgratis.dev/) - Programming Books / [GitHub](https://github.com/midudev/libros-programacion-gratis)
* [booksmedicos](https://booksmedicos.org/) - Medical Textbooks
* [Manuales de instrucciones](https://www.manualpdf.es/) - Manuals
* [SciELO Chile](https://scielo.conicyt.cl/) - Scientific Journals
* [cervantesvirtual](https://www.cervantesvirtual.com/portales/literatura/multimedia_videoteca_signada/) - Signed Literature for Deaf Users

***

# ► Swedish / Svenska

* [Eniro](https://www.eniro.se/) - Search
* [teckensprakslexikon](https://teckensprakslexikon.su.se/) - Swedish Sign Language Dictionary

## ▷ Streaming

* [SVT Play](https://www.svtplay.se/) - Movies / TV
* [Stockholmskallan](https://stockholmskallan.stockholm.se/sok/?cstids=6) - Public Domain Films

***

# ► Thai / ไทย

* [Thai Dictionary](https://dictionary.orst.go.th/)
* [TH-SL](https://www.th-sl.com/) - Sign Language Database

## ▷ Reading / อ่าน

* [kingsmanga](https://www.kingsmanga.net/) - Manga
* [novels108](https://www.novels108.com/) - Light Novels

***

# ► Turkish / Türkçe

* [Doğruluk Payı](https://www.dogrulukpayi.com/) - News Verification
* [Market Fiyatı](https://marketfiyati.org.tr/) - Market Prices

## ▷ Downloading / İndirme

* [Türkçe Altyazı](https://turkcealtyazi.org/) - Subtitles
* [Playstation Haber](https://playstationhaber.com/) / [MCpsp](https://www.mcpsp.com) - PlayStation Piracy Forums
* [Turkish Audio Center](https://www.turkishaudiocenter.com), [Shareses](https://shareses.com), [Türkçe Ses İndir](https://www.turkcesesindir.com/), [Turkce Ses Dosyası](https://turkce-sesdosyasi.blogspot.com/) or [Turkish Sound Track](https://trsoundtrack.blogspot.com/) - Turkish Dubs
* [Sinner Clown](https://sinnerclownceviri.net) / [Discord](https://discord.com/invite/nApvcT6Tt6), [Hangar](https://www.hangarceviri.com), [Calypso](https://www.calypsoceviri.com/) - Game Localizations
* [Mp3 indir dur](https://www.mp3indirdur.com.tr/), [Mp3 semti](https://mp3semti.com/) - Music / MP3s

## ▷ Streaming / İzleme

* ⭐ **[Dizipal](https://dizipal1453.com/)** - Movies / TV / Sub / Dub / 1080p / Requires VPN
* ⭐ **[Dizi Film Botu](https://t.me/Difix9Bot)** - Movies / TV / Anime / Sub / Dub / 4K / 2K / 1080p / Documentaries
* ⭐ **[Hdfilmcehennemi](https://www.hdfilmcehennemi.nl/)** - Movies / TV / Sub / Dub / 1080p / Region Locked
* ⭐ **[FullHDFilmizlesene](https://www.fullhdfilmizlesene.now/)** - Movies / Sub / Dub / 1080p
* ⭐ **[OpenAnime](https://openani.me/)** - Anime / Region Locked
* ⭐ **[AnimeciX](https://anm.cx/)** - Anime / Region Locked
* [Dizilla](https://dizilla.to/), [2](https://selcukflix.com/), [3](https://asyawatch.com/) - Movies / TV / Sub / Dub / 1080p / Region Locked
* [Yabancıdizi](https://yabancidizi.so/) - Movies / TV / Sub / Dub / 1080p
* [kultfilmler](https://kultfilmler.net/) - Movies / TV / Anime
* [Diziyou](https://www.diziyou.one/) - TV / Sub / Dub / 1080p
* [Dizibox](https://www.dizibox.live/) - TV / Sub / 1080p
* [Jet Film izle](https://jetfilmizle.net/) - Movies / Requires VPN
* [Turkish123](https://ahs.turkish123.com/) or [Yoturkish](https://www.yoturkish.com) - Turkish TV w/ Eng Subs
* [WebDramaTurkey](https://webdramaturkey2.com/) - Asian Drama
* [⁠AniHub](https://anihub.com.tr/) - Anime / Region Locked
* [AsyaAnimeleri](https://asyaanimeleri.top/) - Anime
* [cizgimax](https://cizgimax.online/) - Cartoons
* [belgeselx](https://belgeselx.com/) - Documentaries
* [Canlı TV](https://www.canlitv.me/) - Live TV / Requires VPN
* [Kral Bozguncu](https://discord.gg/kral) - Talk and watch football.

## ▷ Reading / Okuma

* [Kitap](https://t.me/addlist/ioGiM9KIZvhjOTZk) - Books
* [E kütüphanem](https://t.me/addlist/og2-cDRwlu9mOTY0) - Books
* [⁠Hattusa](https://hattusa.club/) - Books
* [kitab-evi](https://kitab-evi.com/) - Books
* [Manga Denizi](https://www.mangadenizi.net/) - Manga / [Discord](https://discord.com/invite/8zBMSGZ)
* [Trwebtoon](https://trmanga.com/) - Manga
* [Tortuga-ceviri](https://tortugaceviri.com/) - Manga / [Discord](https://discord.gg/bSxwMNM9mm)
* [Raindrop](https://www.raindropteamfan.com/) - Manga
* [Uzaymanga](https://uzaymanga.com/) - Manga
* [dergipark](https://dergipark.org.tr/tr/) or [trdizin](https://trdizin.gov.tr/) - Academic Journals

***

# ► Ukrainian / Українська

* [⁠NoWar.help](https://www.nowar.help/) - War Resources / Help

## ▷ Torrenting / Торрентінг

* [Mazepa](https://mazepa.to/) - Video / Audio / Books
* [Toloka](https://toloka.to/) - Torrent Tracker

## ▷ Reading / Читання

* [manga.in](https://manga.in.ua/) - Manga

## ▷ Streaming / Стрімінг

* [Kinostrain](https://kinostrain.com/) - Movies / TV / Anime / Use [VPN](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_vpn) / [Telegram](https://t.me/uaserialchannel)
* [UAKino-Bay](https://uakino-bay.biz/) - Movies / TV / Anime
* [UASerials](https://uaserials.my/) - Movies / TV / Anime
* [KinoUKR](https://kinoukr.tv/) - Movies / TV / Use [VPN](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_vpn)
* [anitube](https://anitube.in.ua/) - Anime
* [sweet.tv](https://sweet.tv/pl/) - Free w/ Ads / Channels Only / [Login Bypass](https://github.com/Julmik647/sweet-tv-no-login)

***

# ► Uzbek / Ўзбек

## ▷ Downloading

* [AsilMedia](https://asilmedia.org/) - Movies / TV / [Telegram](https://t.me/asilmedia_tarjima_kinolar)

## ▷ Streaming

* [uzmax.net](https://uzmax.net/) - Movies / TV
* [FreeKino](https://freekino.net/) - Movies / TV
* [AsilMedia](https://asilmedia.org/) - Movies / TV / [Telegram](https://t.me/asilmedia_tarjima_kinolar)

## ▷ Reading

* [FaylZona](https://t.me/megadokbot) - Books / Documents / Slides
* [⁠Ziyouz](https://n.ziyouz.com/) - Books

***

# ► Vietnamese / Tiếng Việt

* ⭐ **[Voz.vn](https://voz.vn/)**, [VN-Z](https://vn-z.vn/) or [TECHRUM.VN](https://www.techrum.vn/) - Tech Forum
* ⭐ **[J2team](https://www.facebook.com/groups/j2team.community)** - Tech Community
* ⭐ **[Unikey](https://www.unikey.org/)** - Vietnamese Keyboard / [Source Code](https://sourceforge.net/projects/unikey/)
* ⭐ **[Báo Mới](https://baomoi.com/)** - News Aggregator / [Android](https://play.google.com/store/apps/details?id=com.epi) / [iOS](https://apps.apple.com/app/báo-mới-đọc-báo-tin-mới-24h/id651979466)
* [hostsVN](https://github.com/bigdargon/hostsVN/wiki) - Adblocking Guides
* [Quantrimang](https://quantrimang.com/) or [Anonyviet](https://anonyviet.com/) - Tech News
* [⁠HocMai Hướng Nghiệp](https://huongnghiep.hocmai.vn/) - Career + University Guidance
* [DOL THPT](https://dolthpt.vn/) or [DOL IELTS](https://tuhoc.dolenglish.vn/) - Exam Prep
* [Forumvi](https://www.forumvi.com/) - Forum Creator
* [MuaThongMinh](https://muathongminh.vn/) - E-commerce Price Tracker
* [Unity_Cheat_Sheet](https://github.com/NaomiLe1811/Unity_Cheat_Sheet_Tieng_Viet) - Unity Game Engine Cheat Sheet

## ▷ Torrenting / Tải tệp bằng torrent

* [NetHD](https://nethd.org/) - Video / Audio / Requires Sign-Up

## ▷ Streaming / Phát trực tuyến

* [⁠Sofaflix](https://sofaflix.rest/) - Movies / TV / Anime / Sub / Dub / 1080p / [Telegram](https://t.me/addlist/66uKS-YYSyZmM2M1)
* [kkphim](https://kkphim.com/) - Movies / TV / Anime / Sub / Dub / 1080p
* [NguonC](https://phim.nguonc.com/) - Movies / TV / Anime / Sub / Dub / 1080p
* [⁠Tram Phim](https://tramphim.app/) - Movies / TV / Anime / Sub / Dub / 1080p / 4K / [Telegram](https://t.me/Adtramphim)
* [AnimeTVN](https://animetvn.com/) - Anime / Chinese Animation / Sub / 1080p
* [AnimeVietsub](https://animevietsub.link/) - Anime / Chinese Animation / Sub / 1080p / [Telegram](https://t.me/animevietsub)
* [HCMUT ⁠Courseware](https://www.hcmut-courseware.org/courses) - Unofficial HCMUT Courses

## ▷ Free w/ Ads / Miễn phí với quảng cáo

* [THVL](https://www.thvli.vn/) - Live TV / Movies / TV / Music / Dub / 1080p
* [TV360](https://tv360.vn/) - Live TV / Movies / TV / Sub / Dub / 1080p
* [VieON](https://vieon.vn/) - Live TV / Movies / TV / Anime / Sub / Dub / 720p
* [Danet](https://danet.vn/) - Live TV / Movies / TV / Anime / Sub / 720p
* [HTV](https://hplus.com.vn/), [2](https://htvc.com.vn/) - Live TV / TV / 1080p
* [ZingMP3](https://zingmp3.vn/) or [NhacCuaTui](https://www.nhaccuatui.com/) - Music

## ▷ Reading / Đọc

* ⭐ **[hoc10](https://hoc10.vn/)** - Textbooks, Study Material, Lecture Notes, etc.
* ⭐ **[Thư Viện Pháp Luật](https://thuvienphapluat.vn/)** - Legal Information Portal / [Facebook](https://www.facebook.com/ThuVienPhapLuat.vn/)
* ⭐ **[VietJack](https://vietjack.com/)**, **[LoiGiaiHay](https://loigiaihay.com/)**, **[VNDoc](https://vndoc.com/)** or **[Tech12h](https://tech12h.com/)** - Study References
* [Thoát Porn Luận](https://thu-tram.github.io/tpl/) - Porn Quitting Guide / EasyPeasy Translation
* [Thivien](https://www.thivien.net/) - Poetry
* [tieulun](https://tieulun.hd.free.fr/) - Books
* [SachHay](https://www.sachhayonline.com/) - Books
* [tailieuonthi](https://tailieuonthi.edu.vn/) - Textbooks
* [TruyenQQ](https://truyenqqko.com/) - Manga / Manhwa / Manhua
* [COMI](https://comi.mobi/) - Manga / Manhwa / Manhua / Novel
* [Sonako](https://sonako.fandom.com/vi/wiki/Sonako_Light_Novel) - Light Novels / [Facebook](https://www.facebook.com/SonakoWiki/)
* [TruyenFull](https://truyenfull.live/) - Manga / Light Novels
* [Hako](https://docln.net/) - Light Novels / [Facebook](https://www.facebook.com/groups/hako.group)
* [Babla](https://vn.bab.la/), [VDict](https://vdict.com/) or [VTuDien](https://vtudien.com/) - Dictionary

***

# ► Other Languages

* 🌐 **[Non-English Ebook & Audiobook Sites](https://redd.it/gehkl0)**
* ↪️ **[Asian Drama Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video#wiki_.25B7_drama_streaming)**
* [kool.to](https://www.kool.to/) - Multilingual / Live TV
* [Keyman](https://keyman.com/) - Multilingual / Keyboard Files
* [⁠Albkanale](https://albkanale.com/) - Albanian / Live TV / Android
* [amharicbookss](https://t.me/amharicbookss) - Amharic / Books
* [BooksWorld](https://t.me/Books_worldd) - Amharic / Audiobooks
* [Yoda](https://yoda.az/) - Azerbaijani / Live TV
* [euskal](https://www.euskal-encodings.eus/) - Basque / Download / Movies / TV
* [radioplayer.be](https://ecoutezvosoreilles.be/radioplayer/) - Belgian Radio Stations / French / Dutch
* [lupiteam](https://lupiteam.net/) - Corsican / Manga
* [BalkanDownload](https://balkandownload.org/) - Croatian / Serbian / Slovene / Download / Video / Audio / Games / Books / Comics
* [WarezHR](https://www.warezhr.org/) - Croatian / Download / Video / Audio / Games / Books / Comics
* [JockanTV](https://jockantv.eu/) - Croatian / Streaming / Dubbed Cartoons / Use [Adblock](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_adblocking)
* [DR.DK](https://www.dr.dk/) - Danish / Movies / TV / Live / Signup Required
* [⁠Schatkamer](https://schatkamer.beeldengeluid.nl/) - Dutch / Rare Media
* [CyberSkills](https://discord.com/invite/2tTwMvbSXu) - Danish Cybersecurity Discord
* [tegnsprog](https://www.tegnsprog.dk/) - Danish Sign Language Dictionary
* [NPO](https://npo.nl/) - Dutch / TV Streaming
* [Oorboekje](https://oorboekje.nl/) or [luisterradio](https://luisterradio.fm/) - Dutch Radio Stations
* [corpusngt](https://www.corpusngt.nl/) - Dutch Sign Language Dictionary
* [Woordenboek](https://woordenboek.vlaamsegebarentaal.be/) - Flemish Sign Language Dictionary
* [Warez.Ge](https://warez.ge/) - Georgian / Download / Video / Audio
* [Deildu](https://deildu.net/) - Icelandic / Torrents
* [kzkitap](https://t.me/kzkitap) - Kazakh Books
* [Shafilm](https://shafilm.vip/) - Kurdish / Streaming / Movies / TV / Anime / Cartoons
* [KurdCinema](https://www.kurdcinama.com/) - Kurdish / Streaming / Movies / TV / Anime / Cartoons
* [KRDTV](https://www.krdtv.online/) - Kurdish / Live TV
* [Kurdsubtitle](https://kurdsubtitle.net) - Kurdish / Subtitles
* [Redzidzirdilatviju](https://www.redzidzirdilatviju.lv/) - Latvian / Documents
* [vaizdopamokos](https://vaizdopamokos.lt/) - Lithuanian Educational Videos
* [Lowyat](https://forum.lowyat.net/) - Malay / Tech Forum
* [Paper](https://paper.naya.com.np/) - Nepali / Text Tools
* [NRK TV](https://tv.nrk.no/) - Norwegian / Stream / Movies / TV / Documentaries / Sub / 1080p
* [Nasjonalbiblioteket](https://www.nb.no/en/digitizing-at-the-national-library/) - Norwegian / Books / Journals / Magazines / Maps / Music Sheets
* [Tegnordbok](https://www.minetegn.no/Tegnordbok-2016/) - Norwegian Sign Language Dictionary
* [Play RTR](https://www.rtr.ch/play/tv) - Romansh / Free w/ Ads Streaming
* [animesrbija](https://www.animesrbija.com/) - Serbian / Streaming / Anime
* [Anime Balkan](https://animebalkan.org/) - Serbian / Streaming / Anime / 1080p
* [gledajcrtace](https://www.gledajcrtace.rs/) - Serbian / Dubbed Cartoons
* [Singapore Sign](https://blogs.ntu.edu.sg/sgslsignbank/) - Singapore Sign Language Dictionary
* [subsl](https://subsl.top/) - Sinhalese / Streaming / Movies / TV / Anime
* [zoom.lk](https://zoom.lk/) or [Cineru.lk](https://cineru.lk/) - Sinhalese / Subtitles
* [Najdi.si](https://www.najdi.si/) - Slovene / Search
* [BSF](https://bsf.si/) - Slovene Film Database
* [iptv-ch](https://rentry.co/FMHYB64#iptv-playlists) - Swiss / IPTV Resources
* [Segoideas](https://segoideas.com/) - Taiwanese / Streaming / TV
* [wlext](https://wlext.is/) - Turkish / Filipino / Thai / Streaming / Movies
* [Machine Learning ka Chilla](https://www.youtube.com/playlist?list=PL9XvIvvVL50HHzaLPtFBOuikAWa0JdhMW) - Urdu / Machine Learning Course
* [PSL Dictionary](https://psl.org.pk/dictionary) - Urdu Sign Language Dictionary
