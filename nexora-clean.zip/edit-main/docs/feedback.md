---
title: Feedback
description: Anonymous comments taken from Reddit, Discord, X.com and our feedback system.
next: false
prev: false
lastUpdated: false
outline: false
---

### Feedback

:::tip What is this?
Anonymous comments taken from Reddit, Discord, X.com and our feedback system.
:::

***

* *"Your sources have allowed me to give my father whatever shows or movies he asks for. Old stuff from when he was younger and all that. Stuff I wouldn't be able to access otherwise. It means a lot since he had heart surgery in Feb 2020 and cant really do much anymore, so its one of the few ways he can keep himself busy. Thank you."*

* *"Best Wiki ever. Wifey has stage 4 cancer. I am a working joe keeping this household afloat on warehouse wages while supporting our family. Finding this wiki has kept us close to our old way of life for free-fifty, lol! Books for the paperwhite, movies, TV, gaming, education, etc., etc. There is so much here that has enhanced our lives. And I find more in the depths every time I go exploring. Please don't ever quit updating/adding to this library of awesomeness! Anyway, I just wanted to drop an anonymous thank you for everything here. Amazing resource. Happy to have a carefully curated list instead of roaming blind into the internet wilds. You are doing some amazing works here. Basically my homepage now. Infinite Kudos!"*

* *"I am elderly and poor. Being able to watch movies and TV at home for free is saving my mental health. Your service is essential to so many people who need relief from the hardships of life at this time in history and from failing health after a lifetime of work."*

* *"That's why I love FMHY so much. Before id spend hours and hours every day trying to hunt useful websites for myself."*

* *"I love this website so much. I literally have it labelled as "Everything" in my favorites."*

* *"You have saved me in so many ways that it could not fit here in terms of the amount of text. I'm from a poor "third world" country and a portal like this allows me endless things that I simply can't afford! Keep up the good spirit and I wish you all the best from the bottom of my heart!"*

* *"I love this website so much. I'm a current college student and the resources offered on this page have eased my stress in terms of finding textbooks and readings - thank you!"*

* *"Y'all have helped not only me but my friends through college and the pandemic in ways you all probably don't even realize."*

* *"Thank you so much for this effort, guys, you are amazing, I stopped searching on google for stuff and got addicted to your website, keep going :)"*

* *"Literally, when I need something, all I need to do is check here first! thank you for being here, for being access to everyone and anyone, I really really appreciate it!"*

* *"Shoutout to you guys for letting my 60 year old mother feel like ms hackerman and enjoy her shows."*

* *"Me and my friends call your site the keys to the internet, its kinda amazing."*

* *"This website is genuinely a candidate for top 3 greatest websites to ever exist on the web. Thanks to it I was able to download games, build a whole local music library, watch all the movies and tv shows I want, read all the books I want. This website has genuinely enlightened me and guided me into new life and im forever thankful."*

* *"Thank you to whoever made the website,it has made things easier for a lot of people. I pinned this website on an old laptop I installed linux mint xfce on for one of my dads friends who is about 65 years old and he loves it, free media is awesome."*

* *"A really great and detailed job of putting everything together. I hope you hear this a lot, but thanks for all the work you put in this, people appreciate it more than you think <3."*

* *"Thanks to FMHY, I was able to find a piece of software that upped my efficiency at work three-fold. Literal life-saver. Thank you!"*

* *"Great site! It's so useful, I now know about a lot more apps and such. Definitely made my life easier!"*

* *"The entirety of the site is a treasure trove for anybody that's looking access for virtually anything possible. I'm proud of you guys and the work you do. This site to me, is on par with the Internet Archive in terms of importance. Take care and keep going."*

* "*Your single domain which is now printed in my memory (fmhy.net) has been so much of a help to me cannot explain truly in words. Each one of you and others who contribute in this are saviors for us, I regularly check your site and visit some section to see some cool stuff, and yes I eventually find them. I should also mention the monthly updates which occurs when the month ends, I love to scroll through it entirely to check what I missed the last month, so yeah keep growing and keep providing the things you do.*."

* *"I am in egypt where everything is not cheap and i discovered FMHY mid 2021, it has been one of the best websites for me as I have learned about computers and piracy as a whole, I also learned to use linux and programming which has lead me to find a job way easier now and I could provide for my whole family. You also made me the IT guy of the house and made me look like the cool nerd guy who has a website for anything."*

* *"I recently finished my exams and im happy to say i got into med school. i am so beyond grateful for what you do. I didnt have the money for cram school and tutoring, i heavily relied on the resources here, and i will probably continue to do so. I want to become a gynecologist and hopefully bring some real change for the health of my fellow women. Thank you all!"*

* *"I want to express my sincere appreciation for the wiki of useful resources. It has proven to be an invaluable source of information, providing a wide range of knowledge on various topics. The well-organized and comprehensive nature of the wiki has been instrumental in aiding my research and learning. I am truly grateful for the effort and dedication that has gone into curating and maintaining such a valuable repository of knowledge. Thank you for this exceptional resource."*

* *"I've never had a dedicated site I can immediately go to that has virtually everything I need all in one singular organized, accessible and easy-to-use place. One thing I personally love is the flow of how everything is designed, it's super simple yet also very informative while still being incredibly appealing visually. Thank you to everyone who contributed to the compilation of this website!"*

* *"FMHY has truly transformed my life, and I am honored to support it with my contributions. I genuinely cherish the opportunity to learn from and explore valuable resources, and FMHY brings me joy every day. I take great pleasure in sharing its helpful insights with my friends. I was excited to introduce my family to this wonderful website, and I am pleased to say they have come to love it just as much as I do."*

* *"FREE MEDIA, HECK YEAH! THAT SITE SAVED MY DAMN LIFE, AND I DON'T CARE WHO JUDGES ME FOR IT! YOU WANNA LOOK AT ME LIKE I'M CRAZY? GO AHEAD! I'LL SCREAM IT FROM THE ROOFTOPS WHILE POUNDING MY FIST ON THE TABLE! It's my lifeline, my everything, and you can't take that away from me!"*

* *"I'm not kidding when I say my quality of life would be SO. MUCH. LOWER. if it wasn't for the people running this thing, as well as the people running all the tools we get to use. I seriously pray we get at least several more solid years of this style of internet."*

* *"FMHY genuinely made my life better. I am someone who loves video editing and I think it is my true passion, and if it weren't for fmhy and r/piracy megathread, I would be extremely sad. Editing would be so pay to win. I don't think I have spent money in the last while because while most people window shop or look for stuff to buy to fill the void in their hearts, I can just find cool plugins and resources. Thank you to everyone in the community, your hard work is greatly appreciated."*

* *"You guys have made this wonderful piece of combined knowledge into website, its like being exposed to what not I haven't seen/experienced in my life. I am really grateful for this initiative as I am not that financially blessed and I cannot afford a lot of the software out in the market, but due to fmhy I have access to nearly everything."*

* *"Amazing stuff. Spent almost whole day browsing this and I got introduced to tons of great software. Thank you!!"*

* *"I can't begin to express how much of a godsend this website is! Please keep up the terrific work and know that you are making a massive difference in the lives of students like me who can't always pay for subscriptions, or are just looking for a neat tool!"*

* *"Me and my sibling have made visiting this site a ritual. Seriously, we can't thank you enough for your work! Our broke third world living country asses would've never dreamed of seeing this much media."*

* *"I love FMHY's wiki, to the point I can't use the internet without it."*

* *"In this age of the internet, search engines are getting worse to find stuff we searching for. This site has helped me not only the when I can't find something on search engines, but also to find new stuff I didn't know existed. I go here first before I consult google. Thank you and everyone for your hard work. Don't loose this site, no matter the cost."*

* *"Before finding this, I've been searching google myself and have experienced viruses, fake info, and just bad advice. But the amazing guides and links on FMHY really make it so much safer and simpler to find the things I need. I'm sort of the tech person in my family, so it saves me from so much testing and work."*

* *"This wiki is one of the best out there, seriously. Keep up the great work!"*

* *"This is the best wiki EVER, and I hope that the admins/people maintaining this wiki keep on adding cool stuff like this!"*

* *"I love having an extreme amount of privacy. And it's not just for piracy, so this is REALLY useful. Thanks!"*

* *"Every person I share this sub with is always completely grateful, and it's no wonder why."*

* *"Finding out about FMHY's wiki is the best thing that has happened to me, it has helped me so much in every way imaginable, i'm very grateful, keep it up!"*