---
title: Changelog Sites
description: Added Changelog Sites
date: 2025-12-12
next: false

prev: false

footer: true
---

<Post authors="nbats" />

**https://fmhy-tracker.pages.dev/**

This covers links that have been added, updated, or removed by watching GitHub for changes

**https://fmhy.net/recently-removed**

This page lists sites that were removed from the wiki in the last 30 days

**https://fmhy.net/feed.rss**

FMHY RSS Feed

***

Note that we also make monthly posts on both reddit + our site with the bigger changes, and you can also follow them yourself by joining our [Discord](https://redd.it/17f8msf), or watching the [Commits Page](https://github.com/fmhy/edit/commits/main/) on GitHub.