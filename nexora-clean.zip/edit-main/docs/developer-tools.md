***
***
**[◄◄ Back to Wiki Index](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/tools-index)**
***
***

# ► Dev Communities

* ⭐ **[StackOverflow](https://stackoverflow.com/)** - Developer Forum
* ⭐ **[XDA](https://xdaforums.com/)** - App Development Forum / [Discord](https://discord.com/invite/e4v8qtkcBw)
* [Spiceworks Community](https://community.spiceworks.com/) - Developer Forum
* [DEV Community](https://dev.to/) - Developer Forum
* [Blind](https://www.teamblind.com/) - Developer Forum
* [IndieHackers](https://www.indiehackers.com/) - Developer Forum
* [⁠late.sh](https://late.sh/) - Command-Line Style Clubhouse / [GitHub](https://github.com/mpiorowski/late-sh)
* [⁠Graphics Programming](https://discord.gg/graphicsprogramming) - Graphics Programming Discord Server / [Subreddit](https://www.reddit.com/r/GraphicsProgramming/)
* [⁠Functional Programming](https://discord.gg/K6XHBSh) - Functional Programming Community / Discord
* [Tech-Blogs](https://tech-blogs.dev/) or [HN Popularity](https://popularity.refactoringenglish.com/) - Blogs for Developers
* [The Devs Network](https://thedevs.network/) - Developer Chat

***

# ► Dev News

* ⭐ **[KrebsOnSecurity](https://krebsonsecurity.com/)** - Cybersecurity News
* ⭐ **[Lobsters](https://lobste.rs/)** - Dev News / [Highlighter](https://greasyfork.org/en/scripts/40906)
* [DevURLs](https://devurls.com/) - Dev News
* [daily.dev](https://daily.dev/posts) - Dev News
* [⁠Frontend Dogma](https://frontenddogma.com/) - Web Dev News Aggregator
* [CyberInsider](https://cyberinsider.com/) - Cybersecurity News
* [This Week in Rust](https://this-week-in-rust.org/) - Rust News / Updates
* [hackertab.dev](https://hackertab.dev/) - Dev Browser Startpages / [GitHub](https://github.com/medyo/hackertab.dev)

***

# ► [Developer Learning](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25BA_developer_learning)

***

# ► Developer Tools

* 🌐 **[⁠Awesome Minimalist](https://github.com/neiesc/awesome-minimalist)** - Curated Minimal Dev Frameworks
* ↪️ **[Data Visualization / Diagrams](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage/#wiki_data_visualization_tools)**
* ↪️ **[Machine / Deep Learning](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/ai#wiki_.25BA_machine_learning)**
* ↪️ **[Markup Tools / Markdown Editors](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools#wiki_.25BA_markup_tools)**
* ⭐ **[DevToys](https://devtoys.app/)** - Dev Multi-Tool App / Windows, macOS, Linux / [GitHub](https://github.com/DevToys-app/DevToys)
* ⭐ **[DevDocs](https://devdocs.io/)** / [GitHub](https://github.com/freeCodeCamp/devdocs) or [ZealDocs](https://zealdocs.org/) - Dev Documentation / Windows, macOS, Linux /
* ⭐ **[ImHex](https://imhex.werwolv.net/)** / [Web Version](https://web.imhex.werwolv.net/) / Windows, macOS, Linux, Web / [GitHub](https://github.com/WerWolv/ImHex) or [HexEd.it](https://hexed.it/) - Hex Editors
* ⭐ **[Free for Developers](https://free-for.dev/)** - Tool Index / [GitHub](https://github.com/ripienaar/free-for-dev)
* [Tiny Helpers](https://tiny-helpers.dev/) - Tool Index / [GitHub](https://github.com/stefanjudis/tiny-helpers)
* [Tiny Tools](https://tinytools.directory/) - Tool Index
* [Free For Life](https://free.hrsn.dev/) - Tool Index / [GitHub](https://github.com/wdhdev/free-for-life/)
* [WebdevHome](https://webdevhome.github.io/) - Tool Index
* [Free Developer Stuff](https://freestuff.dev/) - Tool Index
* [⁠Awesome Stars](https://github.com/ManUtopiK/awesome-stars) - Tool Index
* [Addy](https://toolkit.addy.codes/) - Tool Index
* [Prototypr](https://prototypr.io/toolbox/page/1) - Tool Index
* [StackShare](https://stackshare.io/) - Tech Stack Collaboration
* [Awesome Sys Admin](https://github.com/awesome-foss/awesome-sysadmin) - System Admin Resources
* [Awesome Design Patterns](https://github.com/DovAmir/awesome-design-patterns) - Design Pattern Resources
* [Devhints](https://devhints.io/) - Developer Cheat Sheets
* [Student Developer Pack](https://education.github.com/pack) - Free Developer Tools for Students
* [choose-a-license](https://writefreesoftware.org/learn/participate/choose-a-license/), [tl;drLegal](https://www.tldrlegal.com/), [SPDX License List](https://spdx.org/licenses/) or [ChooseALicense](https://choosealicense.com/) - License Picking Guides / Lists
* [Eternal Terminal](https://eternalterminal.dev/) or [Termius](https://termius.com/) - SSH Clients / Servers
* [Beszel](https://beszel.dev/) - Dev Data Dashboard / [iOS App](https://github.com/Loriage/Beszel-Swift-App)
* [PuTTY](https://www.chiark.greenend.org.uk/~sgtatham/putty/) - SSH & Telnet Client
* [Webhook.site](https://webhook.site/) - Webhook Tools
* [⁠Nept](https://nept.cloud/) - Instantly Deploy 20+ Frameworks (Deploy Next.js, Python, Go, etc.)
* [Libraries.io](https://libraries.io/) - Package, Framework & Tool Search
* [Deps.dev](https://deps.dev/) - Open Source Package Search
* [⁠bin](https://github.com/marcosnils/bin) - Binary Manager / Windows, macOS, Linux
* [N8N](https://github.com/n8n-io/n8n) / [Workflow Index](https://github.com/Zie619/n8n-workflows) - Workflow Automation
* [⁠lastversion](https://github.com/dvershinin/lastversion) - Find / Download Latest Project Releases
* [Sentry](https://sentry.io/) or [Darkly](https://launchdarkly.com/) - Error Tracking Platforms
* [Mockaroo](https://mockaroo.com/) or [Mockium](https://softwium.com/mockium/) - Generate Test Data
* [Big List of Naughty Strings](https://github.com/minimaxir/big-list-of-naughty-strings) - Check for Edge Case Inputs
* [overmind](https://github.com/DarthSim/overmind) - Process Managers
* [Wakatime](https://wakatime.com/) - Programmer Stat Tracking

***

## ▷ Online Toolkits

* ⭐ **[AppDevTools](https://appdevtools.com/)**
* [Sharevb IT Tools](https://sharevb-it-tools.vercel.app/) / [GitHub](https://github.com/sharevb/it-tools) or [IT Tools](https://it-tools.tech/) / [GitHub](https://github.com/CorentinTh/it-tools)
* [Web Toolbox](https://web-toolbox.dev/en)
* [devina](https://devina.io/)
* [Coders Tool](https://www.coderstool.com/)
* [UUID Tools](https://www.uuidtools.com/) / [GitHub](https://github.com/th-alanreed/uuidtools.com) or [⁠UUID Generator](https://toolkitvault.com/uuid-generator) - UUID Generators

***

## ▷ Software Dev Tools

* 🌐 **[Awesome Software Quality](https://github.com/ligurio/sqa-wiki/wiki)** - Software Quality Testing Resources
* 🌐 **[Awesome DOS](https://github.com/balintkissdev/awesome-dos)** - DOS App Development Resources
* 🌐 **[Awesome Smart TV](https://github.com/vitalets/awesome-smart-tv)** - Smart TV App Development Resources
* ⭐ **[Every Programmer Should Know](https://github.com/mtdvio/every-programmer-should-know)** or [bookmarks](https://github.com/SansGuidon/bookmarks) - Software Development Tools
* ⭐ **Electron Tools** - [App Store](https://www.electronjs.org/apps/) / [Debugger](https://github.com/pd4d10/debugtron) / [Builder](https://www.electron.build/)
* [Budibase](https://budibase.com/) or [Appsmith](https://www.appsmith.com/) - Internal Tool Builders
* [Open Source Guides](https://opensource.guide/) - Open Source Software Tips / [GitHub](https://github.com/github/opensource.guide)
* [Dokploy](https://github.com/dokploy/dokploy) - App Deployment
* [PublicWWW](https://publicwww.com/) or [grep.app](https://grep.app/) - Source Code Search
* [PM2](https://pm2.keymetrics.io/) - Process Manager
* [namae](https://namae.dev/) - App Name Availability Check
* [Crontab Guru](https://crontab.guru/) - Crontab Editor / Job Scheduler
* [Platform.uno](https://platform.uno/) / [GitHub](https://github.com/unoplatform/uno) or [Enact](https://enactjs.com/) - App Frameworks
* [Slint](https://slint.dev) - GUI Development Tools / [GitHub](https://github.com/slint-ui/slint)
* [Inno Setup](https://jrsoftware.org/isinfo.php) or [InstallForge](https://www.installforge.net/) - Create Installation Programs
* [Etebase](https://www.etebase.com/) - Encrypted App Backend

***

## ▷ Mobile Dev Tools

* 🌐 **[Awesome iOS](https://github.com/vsouza/awesome-ios)** - iOS Development Resources
* 🌐 **[Mobbin](https://mobbin.com/)** or [ScreensDesign](https://screensdesign.com/) - Mobile UI Resources
* ↪️ **[App Mockups](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_app_.2F_site_mockups)**
* ⭐ **[Android Developer Roadmap](https://github.com/skydoves/android-developer-roadmap)**
* ⭐ **[Android Studio](https://developer.android.com/studio)** - Android App Creator / Builder
* ⭐ **[Shizuku Fork](https://github.com/thedjchi/Shizuku)**, [Shizuku](https://shizuku.rikka.app/) / [GitHub](https://github.com/RikkaApps/Shizuku) or [Dhizuku](https://github.com/iamr0s/Dhizuku) - Let Apps Use System API (Android)
* [App ideas](https://github.com/florinpop17/app-ideas) - Collection of App Ideas
* [IconKitchen](https://icon.kitchen/) - App Icon Generator
* [⁠ChromeXt](https://github.com/JingMatrix/ChromeXt) - Add Dev Tools / Inspect Element to Mobile Browsers
* [⁠APKEditor](https://github.com/REAndroid/APKEditor) or [Apktool M](https://github.com/Maximoff/Apktool-M-updates) - APK Editing / Merging
* [⁠CS Android](https://cs.android.com/) - Android Code Search
* [useAnimations](https://useanimations.com/index.html) - Animated Icon Pack
* [Official Android Courses](https://developer.android.com/courses) - Android Training Courses
* [Android Libhunt](https://android.libhunt.com/) - Android Packages
* [AndroidAssetStudio](https://romannurik.github.io/AndroidAssetStudio/) - Android App Assets
* [React Native Apps](https://github.com/ReactNativeNews/React-Native-Apps/) - React App Examples
* [xtool](https://xtool.sh/) - iOS App Creator / Builder / [GitHub](https://github.com/xtool-org/xtool)
* [⁠IPSW Diffs](https://github.com/blacktop/ipsw-diffs) - iOS Update Decompiled Diffs
* [iOS Icon Gallery](https://www.iosicongallery.com/) - iOS Icon Examples
* [⁠HandDrawnFont](https://handdrawn.software/) - Create Hand-Drawn Animated Fonts for iOS Apps / [GitHub](https://github.com/jipvandervelde/HandDrawnFont)
* [PrivacyFlash-Pro](https://github.com/privacy-tech-lab/privacyflash-pro) - Generate iOS Privacy Policies

***

## ▷ Database Tools

* 🌐 **[DB Engines](https://db-engines.com/en/ranking)** or [DBDB](https://dbdb.io/stats) - Database Rankings
* 🌐 **[⁠Awesome DB Tools](https://github.com/mgramin/awesome-db-tools)** - Database Resources
* 🌐 **[Awesome Big Data](https://github.com/oxnr/awesome-bigdata)** - Big Data Resources
* 🌐 **[Awesome MySQL](https://github.com/shlomi-noach/awesome-mysql)** - MySQL Resources
* ⭐ **[DB Browser](https://sqlitebrowser.org/)** / Windows, macOS, Linux, [SQLook](https://sqlook.com/) or [SQL Lite Studio](https://letos.org/) - SQLite Browsers
* [DuckDB](https://duckdb.org/) - Database Manager
* [Qdrant](https://qdrant.tech/) - Database Manager
* [Gel](https://www.geldata.com/) - Database Manager
* [Beekeeper Studio](https://www.beekeeperstudio.io/) - Database Manager / [GitHub](https://github.com/beekeeper-studio/beekeeper-studio)
* [AirTable](https://airtable.com/) - Database Manager / Requires Sign-Up
* [Baserow](https://baserow.io/) - Database Manager / Requires Sign-Up / [GitLab](https://gitlab.com/baserow/baserow)
* [NocoDB](https://github.com/nocodb/nocodb) - Database Manager / Requires Sign-Up
* [Sqlable](https://sqlable.com/) - SQL Tools
* [Grafana](https://grafana.com/) - Self-Hosted Dev Data Dashboard / [GitHub](https://github.com/grafana/grafana)
* [DBeaver](https://dbeaver.io/) - Universal Database Tool
* [ChartDB](https://chartdb.io/) - Database Visualization / [GitHub](https://github.com/chartdb/chartdb)
* [Ingestr](https://bruin-data.github.io/ingestr/) - Transfer Data between Databases
* [franchise](https://franchise.cloud/) - SQL Notebook

***

## ▷ Git Tools

* 🌐 **[Console](https://console.substack.com/)** - Search Projects on OpenSourceHub.io
* 🌐 **[Forge Comparison](https://git.sdf.org/humanacollaborator/humanacollabora/src/branch/master/forge_comparison.md)** or [Forgejo](https://forgejo.org/compare/#only-develops-free-software) - Git Collab Tool Comparison
* ↪️ **[Git Project Indexes](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_git_project_indexes)**
* ⭐ **[Fork](https://git-fork.com/)** (infinite trial), [SourceGit](https://sourcegit-scm.github.io/) or [GitButler](https://github.com/gitbutlerapp/gitbutler) - Git Desktop Clients
* [⁠git.gay](https://git.gay/), [GitHub.com](https://github.com/), [⁠CodeFloe](https://codefloe.com/), [⁠Tangled](https://tangled.org/) / [Discord](https://discord.com/invite/W7SRR4xHhd), [GitLab](https://about.gitlab.com/), [Radicle](https://radicle.dev/), [⁠Upd.dev](https://upd.dev/), [Codeberg](https://codeberg.org/) / [Matrix](https://matrix.to/#/#codeberg-space:matrix.org), [git.sr.ht](https://git.sr.ht/), [GitGud.io](https://about.gitgud.io/), [GitGud](https://gitgud.io/) or [Notabug](https://notabug.org/) - Git Hosting Services
* [Forgejo](https://forgejo.org/) or [Gitea](https://about.gitea.com/) - Self-Hosted Repository Platforms
* [Git](https://git-scm.com/) or [Jujutsu](https://www.jj-vcs.dev) - Version Control Systems
* [⁠Git Cheat Sheet](https://wizardzines.com/git-cheat-sheet.pdf) - Git Cheat Sheet
* [git-sim](https://github.com/initialcommit-com/git-sim) - Visually Simulate Git Operations Before Running
* [GitKraken](https://www.gitkraken.com/), [Ungit](https://github.com/FredrikNoren/ungit) or [RelaGit](https://rela.dev/) - Git GUIs
* [lazygit](https://github.com/jesseduffield/lazygit) or [gitui](https://github.com/gitui-org/gitui) - Git TUIs
* [Gut](https://gut-cli.dev/), [GitHub Cli](https://cli.github.com/) or [gitu](https://github.com/altsem/gitu) - Git CLI / TUI
* [multi-gitter](https://github.com/lindell/multi-gitter) - Bulk Repository Updater
* [⁠Difftastic](https://difftastic.wilfred.me.uk/) / [GitHub](https://github.com/Wilfred/difftastic) or [Delta](https://github.com/dandavison/delta) - Syntax Highlighting / Diff Tools
* [⁠Conventional Commits](https://www.conventionalcommits.org/) - Commit Standardization / [GitHub](https://github.com/conventional-commits/conventionalcommits.org)
* [pre-commit](https://pre-commit.com/) - Manage / Maintain Pre-Commit Hooks / [GitHub](https://github.com/pre-commit/)
* [commitlint](https://commitlint.js.org/) - Lint Commit Messages / [GitHub](https://github.com/conventional-changelog/commitlint)
* [GIT Quick Stats](https://git-quick-stats.sh/) - View Git Statistics / [GitHub](https://github.com/git-quick-stats/git-quick-stats)

***

## ▷ GitHub Tools

* 🌐 **[OSS Insight](https://ossinsight.io/)** - GitHub Project Indexes
* 🌐 **[Awesome First PR Opportunities](https://github.com/MunGell/awesome-for-beginners)** or [up-for-grabs](https://up-for-grabs.net/) - Beginner FOSS Project Index
* 🌐 **[Awesome Actions](https://github.com/sdras/awesome-actions)** - GitHub Action Resources
* 🌐 **[Awesome Browser Extensions](https://stefanbuck.com/awesome-browser-extensions-for-github)** - GitHub Browser Extensions
* 🌐 **[Awesome README](https://github.com/matiassingers/awesome-readme)** - GitHub Readme Resources
* 🌐 **[Awesome Badges](https://dev.to/envoy_/150-badges-for-github-pnk)** - GitHub Badge Resources
* ⭐ **[refined-github](https://github.com/refined-github/refined-github)** - Improved GitHub Interface
* ⭐ **[GitHub Desktop](https://github.com/apps/desktop)** / [Linux](https://github.com/desktop-plus/desktop-plus) - GitHub Desktop Client
* [⁠Is GitHub Cooked?](https://isgithubcooked.com/) - GitHub Incident History
* [Gothub](https://codeberg.org/gothub/gothub) - GitHub Frontend
* [GitHub Cheat Sheet](https://github.com/tiimgreen/github-cheat-sheet) - GitHub Cheat Sheet
* [Languish](https://tjpalmer.github.io/languish/) - GitHub Programming Language Stats
* [GitHub Dorks](https://webdorks.vercel.app/) - GitHub Search Tool
* [Imgbot](https://imgbot.net/) - GitHub Image Compression / [GitHub](https://github.com/imgbot/Imgbot)
* [Octobox](https://octobox.io/), [Gitify](https://www.gitify.io/) or [CatLight](https://catlight.io/) - GitHub Notifications
* [Download Directory](https://download-directory.github.io/) - Download GitHub Repo Sub-Folders / Files
* [useful-forks](https://useful-forks.github.io/), [GitPop3](https://andremiras.github.io/gitpop3/) or [Active-Forks](https://techgaun.github.io/active-forks/index.html) / [GitHub](https://github.com/techgaun/active-forks) - Find Active GitHub Forks
* [Graphite](https://graphite.com/) or [Stacking](https://stacking.dev/) - Improve Pull Request Workflow
* [SemanticDiff](https://app.semanticdiff.com/) - Review Pull Requests using Language Aware Diff
* [Mirrobot](https://mirrowel.github.io/Mirrobot-agent/?bot=Mirrobot-Agent) - Customizable AI GitHub Pull Request Review / [GitHub](https://github.com/Mirrowel/Mirrobot-agent)
* [⁠Diffshub](https://diffshub.com/) - GitHub Diff Checker
* [OctoLinker](https://octolinker.vercel.app/) - Make GitHub Code References Clickable
* [Octotree](https://www.octotree.io/) - GitHub Repo File Tree View
* [Nightly.link](https://nightly.link/) - GitHub Shareable Nightly Links
* [⁠GhGrab](https://ghgrab.readthedocs.io/) - GitHub Specific File Downloader / [GitHub](https://github.com/abhixdd/ghgrab)
* [act](https://nektosact.com/) - Run GitHub Actions Locally / [GitHub](https://github.com/nektos/act)
* [Star History](https://star-history.com/) - Repository Star History Graph
* [Gitstar Ranking](https://gitstar-ranking.com/) - Git Repo Star Rankings
* [GithubReleasesBot](https://telegram.me/GithubReleasesBot) - Repository Change Feeds
* [GitHub Stats Extended](https://github.com/stats-organization/github-stats-extended) - Dynamically Generated GitHub Readme Stats
* [Skill Icons](https://skillicons.dev/) or [⁠Badges 4 README](https://github.com/alexandresanlim/Badges4-README.md-Profile) - Skill Badges for GitHub Readme / Resumes
* [For the Badge](https://forthebadge.com/) or [⁠Fancy Badges](https://jmcrafter26.github.io/badges/) / [GitHub](https://github.com/JMcrafter26/badges) - Custom GitHub Badges
* [⁠Profile Readme Generator](https://github.com/maurodesouza/profile-readme-generator) - GitHub Profile Generator / Editor
* [GitHub Spray](https://annihil.github.io/github-spray-generator) - Draw on GitHub Contribution Page
* [GitHub Snake](https://dev.to/mishmanners/how-to-enable-github-actions-on-your-profile-readme-for-a-contribution-graph-4l66) - Enable Snake Game on GitHub Readme
* [GitHub Profile Readme Generator](https://rahuldkjain.github.io/gh-profile-readme-generator/) - GitHub Readme Generators
* [GitStalk](https://gitstalk.netlify.app/) - GitHub Profile Info Search
* [Beautify GitHub Profile](https://github.com/rzashakeri/beautify-github-profile) - Custom GitHub Profile Resources
* [github-material-icons-extension](https://github.com/material-extensions/material-icons-browser-extension) - Material Icons
* [gist.io](https://gist.io/) - Git Blog Platform

***

## ▷ Docker Tools

* 🌐 **[Awesome Docker](https://average.joe.dev/awesome-docker/)** - Docker Services Index / [GitHub](https://github.com/veggiemonk/awesome-docker)
* 🌐 **[Selfhosted-Apps-Docker](https://github.com/DoTheEvo/selfhosted-apps-docker)** - Self-Hosted Docker Apps / Guides
* ⭐ **[Docker](https://www.docker.com/)** / [Desktop App](https://www.docker.com/products/docker-desktop/) - Build, Manage and Run Apps in Containers
* ⭐ **[Podman](https://podman.io/)** / [2](https://podman-desktop.io/) - Root-less, Daemon-less, Open Source Docker Alternative / [GitHub](https://github.com/containers/podman) / [Compose](https://github.com/containers/podman-compose)
* ⭐ **[Portainer](https://portainer.io/)** / [GitHub](https://github.com/portainer/portainer), [Dockhand](https://dockhand.pro/) / [GitHub](https://github.com/Finsys/dockhand), [DockGE](https://dockge.kuma.pet/) or [moncho](https://moncho.github.io/dry/) - Container Managers
* ⭐ **[Composerize](https://www.composerize.com/)** - Compose Docker Files
* ⭐ **[Docker Hub](https://hub.docker.com/)**, [2](https://linuxserver.io/), [3](https://hotio.dev/) - Docker Images
* [LazyDocker](https://github.com/jesseduffield/lazydocker), [oxker](https://github.com/mrjackwills/oxker), [Arcane](https://getarcane.app/) / [GitHub](https://github.com/getarcaneapp/arcane) or [Isaiah](https://github.com/will-moss/isaiah) - Docker Managers / TUIs
* [Dockle](https://github.com/goodwithtech/dockle) - Image Linter
* [Dive](https://github.com/wagoodman/dive) - Analyze Images
* [WatchTower](https://watchtower.nickfedor.com/) - Container Automation / [GitHub](https://github.com/nicholas-fedor/watchtower)
* [Dozzle](https://dozzle.dev/) - Log Viewer
* [Docker AutoHeal](https://github.com/willfarrell/docker-autoheal) - Container Monitor
* [Diun](https://crazymax.dev/diun/) - Docker Notifications
* [Termible](https://termible.io/) - Docker Powered Site Terminals

***

## ▷ CLI Tools

* ↪️ **[CLI Cheat Sheets](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_cli_cheat_sheets)**
* [⁠VHS](https://github.com/charmbracelet/vhs) - Write Terminal GIFs as Code
* [Charm](https://charm.land/) - Add Backend to Terminal-Based Apps
* [OhMyPosh](https://ohmyposh.dev/) - Terminal Theme Engines
* [Lip Gloss](https://github.com/charmbracelet/lipgloss) - Style Definitions for Terminal Layouts
* [sshx](https://sshx.io/) - Share Terminal Screen / [GitHub](https://github.com/ekzhang/sshx)
* [ripgrep](https://github.com/BurntSushi/ripgrep) or [Sift](https://sift-tool.org/) - `grep` Alternatives
* [⁠bat](https://github.com/sharkdp/bat) / [Extras](https://github.com/eth-p/bat-extras/) or [Shiki](https://shiki.style/) - Log Highlighters
* [Edbrowse](https://edbrowse.org/) - Command Line Editor / Browser / Mail Client
* [Command Not Found](https://command-not-found.com/) - Install Missing Commands
* [Atuin](https://atuin.sh/) - Sync, Search and Backup Shell History
* [pueue](https://github.com/Nukesor/pueue) - Shell Command Manager
* [Zoxide](https://github.com/ajeetdsouza/zoxide) - Improved CD Command
* [yoctocolors](https://github.com/sindresorhus/yoctocolors) - Command Line Coloring Package
* [open](https://github.com/sindresorhus/open) - Open URLs, Files, Executables in CLI or Scripts
* [VisiData](https://www.visidata.org/) - Spreadsheet CLI Editor

***

## ▷ API Tools

* 🌐 **[Public APIs](https://github.com/public-apis/public-apis)**, [API List](https://apilist.fun/), [Public APIs](https://publicapis.dev/), [APIsList](https://apislist.com/), [APIs Guru](https://apis.guru/), [FreePublicAPIs](https://www.freepublicapis.com/), [Public API Lists](https://github.com/public-api-lists/public-api-lists) or [⁠PublicAPIs](https://publicapis.io/) - API Indexes
* 🌐 **[Streaming APIs / Embedding / Resolvers](https://rentry.co/FMHYB64#streaming-apis)**
* 🌐 **[Manga APIs](https://rentry.co/manga-apis)** - Manga Site APIs
* 🌐 **[Dev Scraping APIs](https://github.com/cporter202/scraping-apis-for-devs)** - ⁠Scraping APIs for Developers
* 🌐 **[⁠awesome-transit](https://github.com/MobilityData/awesome-transit)** - Transit Focused APIs
* 🌐 **[⁠NASA API](https://api.nasa.gov/)** - NASA Open APIs
* 🌐 **[⁠Free AI Tools](https://freeaitoolslist.vercel.app/)** / [GitHub](https://github.com/ShaikhWarsi/free-ai-tools), [OpenRouter](https://openrouter.ai/models?max_price=0) or [API Together](https://api.together.xyz/playground) - LLM / AI API Indexes
* 🌐 **[AI Price Compare](https://countless.dev/)** or **[PricePerToken](https://pricepertoken.com/)** - AI / LLM API Price Comparisons
* ⭐ **[hoppscotch](https://hoppscotch.io/)** / [GitHub](https://github.com/hoppscotch/hoppscotch), [Firecamp](https://firecamp.dev/) or [Strapi](https://strapi.io/) - API Builders
* [⁠CoorenLabs](https://coorenlabs.com/) / [Discord](https://discord.gg/r5tfDZmADV) / [GitHub](https://github.com/coorenlabs/cooren) or [Consumet](https://docs.consumet.org/list-of-providers) - Piracy Site Metadata APIs / Scraping
* [⁠Resend](https://resend.com/) - Email API
* [Meilisearch](https://www.meilisearch.com/) - Open-Source Site Search Engine / [GitHub](https://github.com/meilisearch/meilisearch)
* [Secrets To AI](https://discord.com/invite/mMyN7dYdCJ) - AI API Gateway
* [⁠OmniRoute](https://omniroute.online/) / [GitHub](https://github.com/diegosouzapw/OmniRoute) - Proxy for Developers
* [Wyzie Subs](https://sub.wyzie.io/) - Subtitle Scraping API / [Setup](https://quiz.wyzie.io/) / [Plugins](https://store.wyzie.io/plugins) / [NPM Package](https://www.npmjs.com/package/wyzie-lib) / [Docs](https://docs.wyzie.io/)
* [HTTPie](https://httpie.io/) - Test REST, GraphQL, and HTTP APIs
* [Rest Test Test](https://resttesttest.com/) - Test REST / CORS Services
* [Beeceptor](https://beeceptor.com/) - Mock REST APIs
* [Pipedream](https://pipedream.com/) - Connect APIs
* [FastAPI](https://fastapi.tiangolo.com/) - API Framework
* [Posting](https://posting.sh/) / [GitHub](https://github.com/darrenburns/posting), [Insomnia](https://insomnia.rest/) or [Yaak](https://yaak.app/) - API Clients
* [Bruno](https://www.usebruno.com/) - API Testing Client
* [ReDoc](https://redocly.github.io/redoc/) - Generate API Documentation
* [{JSON} Placeholder](https://jsonplaceholder.typicode.com/), [jsoning](https://jsoning.com/api/) or [WireMock Cloud](https://www.wiremock.io/) - Mock APIs
* [Stein](https://steinhq.com/) - Turn Google Sheets into Database API
* [Userdoccers](https://docs.discord.food/) - Unofficial Discord API Documentation
* [discord-api-libs](https://github.com/Apacheli/discord-api-libs) - Community Libraries for Discord API
* [Lanyard](https://github.com/Phineas/lanyard) - Export Discord Rich Presence to API Endpoint / Websocket / [Discord](https://discord.gg/lanyard)
* [Telegram Bot API](https://core.telegram.org/bots) / [GitHub](https://github.com/tdlib/telegram-bot-api) or [PHP Telegram Bot](https://github.com/php-telegram-bot/core) - Telegram Bot API
* [cf-workers-telegram-bot](https://github.com/codebam/cf-workers-telegram-bot) - Serverless Telegram Bot / [GitHub](https://github.com/codebam/cf-workers-telegram-bot)
* [Plaid](https://plaid.com/) - Financial Account API / [GitHub](https://github.com/plaid)

***

# ► Game Dev Tools

* 🌐 **[PCGamingWiki Engine List](https://www.pcgamingwiki.com/wiki/Category:Engines)**, [Wiki Engine List](https://wikipedia.org/wiki/List_of_game_engines), [Awesome Game Engine](https://github.com/stevinz/awesome-game-engine-dev) or [Game-Engines](https://rentry.co/Game-Engines) - Game Engine Development Resources
* 🌐 **[EnginesDatabase](https://enginesdatabase.com/)** - Game Engines Database
* 🌐 **[Awesome Game Dev](https://github.com/Calinou/awesome-gamedev)** - Game Dev Resources
* 🌐 **[⁠Valve Developer Community](https://developer.valvesoftware.com/)** - Valve Developer Community / Resources 
* 🌐 **[Awesome Game Production](https://github.com/vhladiienko/awesome-game-production)** - Game Production Resources
* ↪️ **[Learn Game Development](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu/#wiki_.25B7_game_development)**
* [⁠GameDev Torch](https://gamedevtorch.com/) - Multi-Site Game Dev Search Engine
* [HiddenPalace](https://hiddenpalace.org/) - Game Development Media Archive
* [Tommti Systems](https://www.tommti-systems.de/go.html?http://www.tommti-systems.de/main-Dateien/files.html) - 3D Benchmark Tools
* [Tracy Profiler](https://github.com/wolfpld/tracy) - Frame Profiler
* [⁠RenderDoc](https://renderdoc.org/) - Graphics Debugging Tool / [GitHub](https://github.com/baldurk/renderdoc)
* [⁠Rialto](https://github.com/playtabegg/rialto1) - Create Custom Disc ISOs / Installer Menus
* [Doshaven Programming List](https://www.doshaven.eu/programming-tools/) - DOS Game Creator Tools
* [Fantasy Consoles / Computers](https://github.com/paladin-t/fantasy) - List of Fantasy Consoles and Computers
* [Xelu's Controller Prompts](https://thoseawesomeguys.com/prompts/) - Free Game Prompts / [Video](https://youtu.be/d6GtGbI-now)
* [Basic Computer Games](https://github.com/coding-horror/basic-computer-games) - Basic Computer Game Examples
* [⁠Decompedia](https://decomp.wiki/) - Game Decomp Resources
* [Forgix](https://github.com/PacifistMC/Forgix) - Merge Minecraft Mod Loaders
* [pygame-ce](https://github.com/pygame-community/pygame-ce) - Python Game Dev Resources

***

## ▷ Game Assets

* ↪️ **[Sound Effect Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/audio#wiki_.25B7_sfx_.2F_loops)**
* ⭐ **[Kenney](https://www.kenney.nl/)** - Free Game Assets
* [Itch.io Assets](https://itch.io/game-assets/free) - Free Game Assets
* [Dev Assets](https://devassets.com/) - Free Game Assets
* [Quaternius](https://quaternius.com/) - Free Game Assets
* [Game UI Database](https://www.gameuidatabase.com/) - Game UI Database
* [Game-icons](https://game-icons.net/) - Game Icons
* [r/GameAssets](https://www.reddit.com/r/gameassets/) - Reddit Community
* [AssetRipper](https://github.com/AssetRipper/AssetRipper) / [Discord](https://discord.gg/XqXa53W2Yh) or [AssetStudio](https://github.com/zhangjiequan/AssetStudio) - Extract Assets from Unity Files
* [CraftPix](https://craftpix.net/freebies/) - 2D Game Assets
* [xonotic](https://github.com/xonotic) or [Warsow](https://github.com/Warsow) - FPS Game Assets
* [GameDev Market](https://www.gamedevmarket.net/) - Assets for Indie Developers
* [OpenGameArt.org](https://opengameart.org/) - Game Art Community
* [AssetStore](https://assetstore.unity.com/search#cf-ec_category=3d&nf-ec_price_filter=0...0) or [GameDevUE](https://t.me/GameDevUE) - Unity & Unreal Engine Assets
* [SteamGridDB](https://www.steamgriddb.com/) - Custom Video Game Assets / [Automation](https://www.steamgriddb.com/boop)
* [S2V](https://s2v.app/) - Source 2 Viewer & Decompiler / [GitHub](https://github.com/ValveResourceFormat/ValveResourceFormat)

***

## ▷ Asset Creation

* ↪️ **[3D Models / Modeling Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25B7_3d_models)**
* ↪️ **[Design Tools / Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools/)**
* ↪️ **[Art Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu/#wiki_.25B7_art_.2F_editing)**
* ↪️ **[Animation Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video-tools/#wiki_.25B7_animation_tools)**
* ↪️ **[Writing Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_writing_tools)**
* [Nuklear](https://github.com/Immediate-Mode-UI/Nuklear) - Game GUI Creator
* [HUDSxGUIS](https://www.hudsandguis.com/) - UI Design Concepts
* [SPARTAN Procedural](https://pnjeffries.itch.io/spartan-procjam-edition) - Procedural Tile Generator
* [Game Sounds](https://gamesounds.xyz/) - Royalty Free Game Sounds
* [Bleeper](https://pixwlk.itch.io/bleeper) or [jfxr](https://jfxr.frozenfractal.com/) - Game Sound Effects Creators
* [Engine Simulator](https://www.engine-sim.parts/) - Engine Sound Simulator / [GitHub](https://github.com/ange-yaghi/engine-sim)
* [EZ Conversion](https://spacefoon.itch.io/ez-game-audio-format-conversion) - Game Audio Converter

***

## ▷ Map Creators / Editors

* ↪️ **[RPG / Fantasy Building Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools/#wiki_.25B7_rpg_worldbuilding)**
* ⭐ **[Sprite Fusion](https://www.spritefusion.com/)** / [Discord](https://discord.gg/8sCEAspmBV), [Tiled](https://www.mapeditor.org/) or [Tilesetter](https://www.tilesetter.org/) - Tilemap Editors
* [LDtk](https://ldtk.io/) or [OGMO Editor](https://ogmo-editor-3.github.io/) - 2D Level Editors
* [CharPad](https://subchristsoftware.itch.io/charpad-c64-free) - Commodore 64 Graphics Editor
* [Laigter](https://azagaya.itch.io/laigter) - Map Generator for 2D Sprites

***

# ► IDEs / Code Editors

* 🌐 **[⁠Awesome Web Editor](https://github.com/xjh22222228/awesome-web-editor)** - FOSS Web Editor Index
* ↪️ **[Text Editors / Notes](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25BA_text_editors)**
* ⭐ **[VSCodium](https://vscodium.com/)** or **[Visual Studio Code](https://code.visualstudio.com/)**, [2](https://vscode.dev/), [3](https://cs50.dev/) - Code Editor / [Tools / Extensions](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/dev-tools#wiki_.25B7_vscode_tools)
* ⭐ **[zed](https://zed.dev/)** - Code Editor / [Themes](https://zed-themes.com/) / [GitHub](https://github.com/zed-industries/zed) / Windows, macOS, Linux
* ⭐ **[JetBrains](https://jetbrains.com/)** - Professional IDEs / [Features](https://rentry.co/FMHYB64#jbrains) (occasional downtime) / Windows, macOS, Linux
* ⭐ **[Neovim](https://neovim.io/)** - Code Editor / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/dev-tools#wiki_.25B7_vim_.2F_neovim_tools) / [Matrix](https://matrix.to/#/#neovim:matrix.org) / Windows, macOS, Linux
* ⭐ **[Lite XL](https://lite-xl.com/)** or [Pragtical](https://pragtical.dev/) - Code Editor / [Plugin Manager](https://github.com/lite-xl/lite-xl-plugin-manager) / [Plugins](https://github.com/lite-xl/lite-xl-plugins) / [Themes](https://github.com/lite-xl/lite-xl-colors) / Windows, macOS, Linux
* ⭐ **[Emacs](https://www.gnu.org/software/emacs/)** - Code Editor / [Resources](https://github.com/emacs-tw/awesome-emacs) / Windows, macOS, Linux, Android
* ⭐ **[WebDen](https://webden.dev/)**, [Sharplab](https://sharplab.io/), [LiveCodes](https://livecodes.io/) / [GitHub](https://github.com/live-codes/livecodes), [tech.io](https://www.codingame.com/learn) or [CodingGround](https://www.tutorialspoint.com/codingground.htm) - Code Playgrounds
* [Heynote](https://heynote.com/) - Code Editor / Notepad
* [Edna](https://edna.arslexis.io/) - Web App / Code Editor / Notepad
* [Trinket](https://trinket.strivemath.org/) - Web App / Live Preview / Requires Sign-Up / Online Workspace
* [Helix](https://helix-editor.com/) - Kakoune & Neovim Inspired Code Editor
* [Geany](https://www.geany.org/) - Lightweight Code Editor
* [Fresh](https://getfresh.dev/) - TUI Code Editor
* [Brackets](https://brackets.io/) - Webapp / Live Preview
* [Bluefish](https://bluefish.openoffice.nl/index.html) - Code Editor / [Templates](https://templates.openoffice.org/)
* [CudaText](https://cudatext.github.io/) - Code Editor
* [Lapce](https://lap.dev/lapce/) - Code Editor / [GitHub](https://github.com/lapce/lapce/)
* [ecode](https://github.com/SpartanJ/ecode) - Code Editor
* [GRAM](https://gram-editor.com/) - Code Editor / [Source Code](https://codeberg.org/GramEditor/gram)
* [Competitive Editor](https://cpeditor.org/) - Competitive Programming Editor
* [JSON Hero](https://jsonhero.io/) - JSON Viewer / Editor
* [Blazepack](https://github.com/ameerthehacker/blazepack), [Flox](https://flox.dev/) or [DevPod](https://devpod.sh) - Development Environments
* [Apache NetBeans](https://netbeans.apache.org/), [KDevelop](https://www.kdevelop.org/), [Mitosis](https://mitosis.builder.io/), [Lazarus](https://www.lazarus-ide.org/) or [OpenShift](https://developers.redhat.com/products/openshift-dev-spaces/overview) - Cross-Platform IDEs
* [TidalCycles](https://tidalcycles.org/) - Live Algorithmic Coding Environment / [Discord](https://discord.com/invite/ugFq7KfGnB)
* [Codeface](https://github.com/chrissimpkins/codeface), [Monaspace](https://monaspace.githubnext.com/), [Programming Fonts](https://www.programmingfonts.org/) or [Dev Fonts](https://devfonts.gafi.dev/) - Fonts for Coding / [Comparison](https://www.codingfont.com/)

***

## ▷ Cloud IDEs / Collab

* 🌐 **[cloud](https://gist.github.com/imba-tjd/d73258f0817255dbe77d64d40d985e76#file-cloud-md)** - Cloud Platform Index
* 🌐 **[Heroku-Alt](https://rentry.co/Heroku-Alt)** or [heroku-free-alternatives](https://github.com/meanands/heroku-free-alternatives) - Heroku Alternatives
* ↪️ **[Code Collaboration Platforms](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools#wiki_.25B7_text_.2F_code_collaboration)**
* ⭐ **[Google Colaboratory](https://colab.research.google.com/)** - Cloud IDE
* ⭐ **[CodeSandbox](https://codesandbox.io/)** or [StackBlitz](https://stackblitz.com/) - VSCode Cloud IDE
* ⭐ **[judge0](https://ide.judge0.com/)** - Online Code Editor / [Discord](https://discord.com/invite/GRc3v6n)
* [Atheos](https://www.atheos.io/) - Requires Server / Cloud IDE / [GitHub](https://github.com/Atheos/Atheos)
* [Datalore](https://datalore.jetbrains.com/) - Cloud IDE
* [JSFiddle](https://jsfiddle.net/) - Cloud IDE
* [html-css-js](https://html-css-js.com/) - Cloud IDE
* [CoderPad](https://app.coderpad.io/sandbox) - Cloud IDE
* [Ideone](https://www.ideone.com/) - Cloud IDE
* [PlayCode](https://playcode.io/) - Cloud IDE
* [pad.ws](https://github.com/pad-ws/pad.ws) - Whiteboard Style Cloud IDE
* [Openshift](https://workspaces.openshift.com/) - Cloud IDE / Eclipse Che
* [Shell Cloud](https://shell.cloud.google.com/) - Google Cloud Shell Environment
* [glot.io](https://glot.io/) - Pastebin with Runnable Snippets, API & Compiler
* [Notebooks.azure](https://visualstudio.microsoft.com/vs/features/notebooks-at-microsoft/) - Access Jupyter Notebooks in VS Code
* [Jupyter Server](https://jupyter-server.readthedocs.io) - Jupyter Services / APIs
* [Anywidget](https://anywidget.dev) - Create Jupyter Widgets / [GitHub](https://github.com/manzt/anywidget)
* [CoCalc](https://cocalc.ai/) - Virtual online workspace
* [CodePen](https://codepen.io/), [⁠Web Maker](https://webmaker.app/) / [GitHub](https://github.com/chinchang/web-maker/) or [Liveweave](https://liveweave.com/) - Code Sandbox
* [InstantDB](https://www.instantdb.com/) - Collaborative App Framework

***

## ▷ Android Code Editors

* ⭐ **[Acode](https://acode.app)** - Android Code Editor / [GitHub](https://github.com/Acode-Foundation/Acode)
* ⭐ **[Squircle-CE](https://github.com/massivemadness/Squircle-CE)** - Android Code Editor
* ⭐ **[Xed-Editor](https://github.com/Xed-Editor/Xed-Editor)** - Android Code Editor
* [Sora](https://github.com/Rosemoe/sora-editor) - Android Code Editor
* [Visual Code Space](https://github.com/Visual-Code-Space/Visual-Code-Space) - Android Code Editor
* [Spck Editor](https://play.google.com/store/apps/details?id=io.spck) - Android Code Editor
* [⁠AndroidHarness](https://github.com/Sanuu7/AndroidHarness) - Native AI Coding Agent
* [VHEditor](https://github.com/vhqtvn/VHEditor-Android) - VSCode Editor
* [diohub](https://github.com/NamanShergill/diohub), [PuppyGit](https://github.com/catpuppyapp/PuppyGit) or [OctoDroid](https://github.com/slapperwan/gh4a) - Android Git Clients
* [GitSync](https://github.com/ViscousPot/GitSync) - Android Git Remote Repo Sync
* [FlutterMarkdownEditor](https://github.com/adeeteya/FlutterMarkdownEditor) - Markdown Editor

***

## ▷ Coding Tools

* 🌐 **[Awesome Creative Coding](https://github.com/terkelg/awesome-creative-coding)** - Creative Coding Resources
* [Prettier](https://prettier.io/), [Biome](https://biomejs.dev/) / [GitHub](https://github.com/biomejs/biome/) or [codebeautify](https://codebeautify.org/) - Code Formatting Tools
* [editorconfig](https://editorconfig.org/) - Maintain Code Styles Across Editors
* [Dracula](https://draculatheme.com/) - Code Editor Themes
* [Freeze](https://github.com/charmbracelet/freeze) - Generate Images of Code / Terminal Output
* [Tokei](https://github.com/XAMPPRocky/tokei) - Code Statistics Tool
* [myCompiler](https://www.mycompiler.io/), [Compiler Explorer](https://compiler-explorer.com/) / [2](https://godbolt.org/), [OneCompiler](https://onecompiler.com/), [ryugod](https://www.ryugod.com/) or [Wandbox](https://wandbox.org/) - Online Compilers / Explorers
* [DogBolt](https://dogbolt.org/) - Decompiler Explorers / [GitHub](https://github.com/decompiler-explorer/decompiler-explorer)
* [Code2Flow](https://app.code2flow.com/) or [Flowchart.js](https://flowchart.js.org/) - Code to Flowchart Converter
* [tuc](https://github.com/riquito/tuc) - Improved Code Cut
* [massCode](https://masscode.io/) - Code Snippet Manager
* [Ray](https://www.ray.so/), [Carbon](https://carbon.now.sh/), [CodeImage](https://codeimage.dev/), [ShowCode](https://showcode.app/), [Beauty Codes](https://code.html.zone/) or [Chalk](https://chalk.ist/) - Code Screenshot Tools
* [Meld](https://meld.app/) / [2](https://meldmerge.org/) or [WinMerge](https://winmerge.org/) - File / Directory Comparison Tools
* [0xacab](https://about.0xacab.org/) - Code Host
* [RTutor](https://rtutor.ai/) - Translate Natural Language to R code / No Sign-Up
* [BrickHub](https://brickhub.dev/) - Share Code Brick Templates
* [Sourcegraph](https://sourcegraph.com/search) or [SeaGOAT](https://github.com/kantord/SeaGOAT) - Code Searching
* [Sourcecodester](https://www.sourcecodester.com/), [Code Projects](https://code-projects.org/), [Codastro](https://codeastro.com/), [Kashipara](https://www.kashipara.com/) or [ItSourceCode](https://www.itsourcecode.com/) - Source Code Projects
* [ShortCode](https://shortcode.dev/) or [CodeList](https://codelist.cc/v3/) - Script / Code Indexes
* [AnimateCode](https://www.animate-code.com/) - Create Code Animations
* [DelphiTools](https://www.delphitools.info/) - Code Profiler / Delphi
* [⁠Zathura](https://www.zathura.dev/) - GUI Debugger for Assembly
* [Adrenaline](https://useadrenaline.com/) or [Console Ninja](https://console-ninja.com/) - Code Debugging
* [JBin](https://jsbin.com/) or [Replay](https://www.replay.io/) - Collaborative Code Debugging
* [Winddown](https://github.com/schneefux/vscode-winddown) or [Sandman](https://alexanderepstein.github.io/Sandman/) - Coding Break Reminders
* [Decompiler](https://www.decompiler.com/) - Online Decompiler

***

## ▷ Vim / Neovim Tools

* 🌐 **[Awesome Neovim](https://github.com/rockerBOO/awesome-neovim)** or [NeoVimCraft](https://neovimcraft.com/) - NeoVim Plugins Collections
* ⭐ **[Vim Bootstrap](https://vim-bootstrap.com/)** - Bootstrap Config for Vim
* [NeoVim Kickstart](https://github.com/nvim-lua/kickstart.nvim), [AstroNvim](https://astronvim.com), [LazyVim](https://github.com/LazyVim/LazyVim) or [NvChad](https://nvchad.com/) - Neovim Configs
* [DotFyle](https://dotfyle.com/) - Neovim Config Search
* [Lazy.nvim](https://github.com/folke/lazy.nvim) or [packer.nvim](https://github.com/wbthomason/packer.nvim) - Neovim Plugin Managers
* [FireNVim](https://github.com/glacambre/firenvim) - Neovim in Browser
* [neovide](https://neovide.dev), [gnvim](https://github.com/vhakulinen/gnvim), [Neovim wiki (GUIs)](https://github.com/neovim/neovim/wiki/Related-projects##gui) - Neovim GUIs
* [instant.nvim](https://github.com/jbyuki/instant.nvim) - Collaborative Neovim Editing
* [Vim Plug](https://github.com/junegunn/vim-plug) or [vim-pathogen](https://www.vim.org/scripts/script.php?script_id=2332) / [GitHub](https://github.com/tpope/vim-pathogen) - Vim Plugin Managers
* [VimAwesome](https://vimawesome.com/) - Vim Plugins
* [oil.nvim](https://github.com/stevearc/oil.nvim) or [nvim-tree](https://github.com/nvim-tree/nvim-tree.lua) - Vim Tree Explorer
* [VimColorSchemes](https://vimcolorschemes.com/) - Vim Color Schemes
* [The Ultimate vimrc](https://github.com/amix/vimrc) - Vim Config
* [Vim Markdown](https://github.com/preservim/vim-markdown) or [Markdown Preview](https://github.com/iamcco/markdown-preview.nvim) - Vim Markdown Plugins

***

## ▷ VSCode Tools

* 🌐 **[Awesome VSC Extensions](https://hl2guide.github.io/Awesome-Visual-Studio-Code-Extensions/)**, [VS Studio Marketplace](https://marketplace.visualstudio.com/) or [vsixhub](https://www.vsixhub.com/)
* [VSCodium Guide](https://rentry.co/vscodiumguide) - Install Microsoft Marketplace Extensions
* [VSCode Web](https://code.visualstudio.com/docs/setup/vscode-web) - VSCode Web Version / Guide
* [⁠VSCode Neovim](https://github.com/vscode-neovim/vscode-neovim) - Vim Mode for VSCode
* [github-vscode-icons](https://github.com/dderevjanik/github-vscode-icons) - VSCode Icons
* [Open VSX](https://open-vsx.org/) - Open VSX Registry
* [snippet-generator](https://snippet-generator.app/) - Snippet Generator
* [Dendron](https://www.dendron.so/) - Knowledge Management
* [vscode-smart-clicks](https://github.com/antfu/vscode-smart-clicks) - Smart Clicks
* [code-server](https://coder.com/) - Web Server / [GitHub](https://github.com/coder/code-server)
* [vscode-settings](https://github.com/antfu/vscode-settings) - VSCode Settings
* [insiders.vscode](https://insiders.vscode.dev/) - Insider Build
* [VSCodeThemes](https://vscodethemes.com/) or [VSColors](https://www.vscolors.com/) - VSCode Themes
* [oslo](https://oslo-vsc.netlify.app/) - Theme Generator

***

# ► AI Tools

## ▷ Coding Harnesses / Extensions

* **Note** - Keep in mind many coding AIs run in root, so it's best to avoid giving them full drive / root access to avoid any sort of issues or accidental deletions as they can modify files and execute terminal commands. Remember to backup code first before running the AI or prompts, as they can sometimes break things. Running in a container or VM is recommended.

***

* ↪️ **[AI Agents](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/ai#wiki_.25BA_ai_agents)**
* ⭐ **[OpenCode](https://opencode.ai/)** - Coding AI / DeepSeek V4.1 Flash / GLM-5.3-Flash / MiMo-V2.6-Flash / [Config Manager](https://opencode-studio.micr.dev/) / [Discord](https://discord.com/invite/opencode) / [GitHub](https://github.com/anomalyco/opencode)
* ⭐ **[⁠Pi](https://pi.dev/)** - Terminal Coding Agent / [GUI](https://pi-docs.aiuo.net/) / [GitHub](https://github.com/earendil-works/pi)
* ⭐ **[OpenChamber](https://openchamber.dev/)** - Coding AI Client / [GitHub](https://github.com/openchamber/openchamber)
* [Cline](https://cline.bot/) / [Discord](https://discord.gg/cline) / [GitHub](https://github.com/cline/cline) or [⁠Zoo Code](https://github.com/Zoo-Code-Org/Zoo-Code/) / [Subreddit](https://www.reddit.com/r/ZooCode/) - Autonomous VS Code Agents
* [Paseo](https://paseo.sh/) - Multi-Agent Coding Environment / All Platforms / [GitHub](https://github.com/getpaseo/paseo)
* [OpenHands](https://www.openhands.dev/) - Coding AI / [GitHub](https://github.com/All-Hands-AI/OpenHands)
* [Cursor](https://rentry.co/FMHYB64#cursor) - Coding AI
* [GitWit](https://gitwit.dev/) - Coding AI
* [⁠DeepSeek Harness](https://deepseek.com/harness/) - Coding AI / [Multi-Bot Team Plugin](https://github.com/Fei2411/DeepSeek-Bot) / [GitHub](https://github.com/deepseek-ai/deepseek-harness)
* [⁠Google Antigravity](https://antigravity.google/) - Coding AI / Gemini 3 / Limits Reset Weekly / [VSCode Marketplace](https://gist.github.com/tejainece/85408c51ff5e3555ebc4b5b4417a9b6b) / [Add Skills](https://github.com/sickn33/antigravity-awesome-skills) / [Usage Tracker](https://open-vsx.org/extension/crsx/ag-usage)
* [AI SDK](https://ai-sdk.dev/) - Coding AI / [GitHub](https://github.com/vercel/ai)
* [Open Interpreter](https://github.com/OpenInterpreter/open-interpreter) - Local Code Interpreter / No Sign-Up / [Discord](https://discord.gg/Hvz9Axh84z)
* [⁠T3 Code](https://t3.codes/) - Multi-Platform Agent Client / [GitHub](https://github.com/pingdotgg/t3code)
* [Code Web Chat](https://github.com/robertpiosik/CodeWebChat) - Coding AI / No Sign-Up / [Discord](https://discord.com/invite/KJySXsrSX5) / [Subreddit](https://www.reddit.com/r/codewebchat/)
* [Supermaven](https://supermaven.com/) - Tab Completion Coding AI / No Sign-Up / [Discord](https://discord.com/invite/QQpqBmQH3w)
* [Qodo](https://www.qodo.ai/) - Coding AI
* [⁠ZCode](https://zcode.z.ai/) - Coding AI / [GitHub](https://github.com/zai-org/ZCode)
* [Ampcode](https://ampcode.com/) - Coding AI
* [⁠FreeBuff](https://freebuff.com/) - Coding Agent / Cloud Sandbox / MiMo 2.5
* [⁠jcode](https://jcode.sh/) - Terminal Coding Agent / [Discord](https://discord.com/invite/nBe9vGyK9a) / [GitHub](https://github.com/1jehuang/jcode)
* [omp](https://omp.sh/) - Terminal Coding Agent / [GitHub](https://github.com/can1357/oh-my-pi)
* [⁠cmux](https://cmux.com/) - Terminal Emulator for Agents / macOS / [GitHub](https://github.com/manaflow-ai/cmux)
* [⁠Poolside AI](https://docs.poolside.ai/api/overview) - Coding AI API
* [getdesign.md](https://getdesign.md/) - AI-Ready Design Systems

***

## ▷ AI Web Coding

* **Note** - Note that most [General LLMs](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/ai#wiki_.25B7_official_model_sites) are also capable of coding.

***

* [Arena](https://arena.ai/code) - Multiple Coding AI / Multiple Models / Sign-Up (Direct mode) / [X](https://x.com/arena) / [Discord](https://discord.com/invite/lmarena)
* [Design Arena](https://www.designarena.ai/) - Multiple Coding AI / No Direct Mode / Reset Limits / w Temp Mail / [Discord](https://discord.com/invite/Bw9Ajcb3pR)
* [⁠Z.ai](https://chat.z.ai/) - GLM-5.2 (Deep Think Max) / GLM-5 Turbo / Coding AI / Sign-Up / [Discord](https://discord.gg/QR7SARHRxK)
* [Kimi](https://www.kimi.ai/agent), [2](https://www.kimi.com/agent) - Kimi K3 (Max) / Kimi K2.6 / Coding AI / Google Login or Phone # Required / [Subreddit](https://www.reddit.com/r/kimi/) / [Discord](https://discord.gg/TYU2fdJykW) / [GitHub](https://github.com/MoonshotAI)
* [Google AI Studio](https://aistudio.google.com/app/apps) - Gemini 3.8 Flash / Gemini 3.1 Pro Preview / Gemini 3.5 Flash-Lite / Google Sign-Up / Coding AI / [Subreddit](https://www.reddit.com/r/Bard/) / [Discord](https://discord.com/invite/gemini)
* [Qwen](https://chat.qwen.ai/) - Qwen 3.8 Max (Thinking) / Qwen 3.7 Plus / Coding AI / Sign-Up / Unlimited / [Subreddit](https://www.reddit.com/r/Qwen_AI/) / [Discord](https://discord.com/invite/CV4E9rpNSD) / [GitHub](https://github.com/QwenLM)
* [MiniMax AI](https://agent.minimax.io/) - MiniMax M3 (Thinking) / Coding AI / Sign-Up [GitHub](https://github.com/MiniMax-AI/)
* [⁠Cloud CLI](https://github.com/siteboon/claudecodeui) - AI Coding Agent Web Manager
* [Perchance](https://perchance.org/minimal#edit) / [Subreddit](https://www.reddit.com/r/perchance/) / [Discord](https://discord.gg/43qAQEVV9a), [Fragments](https://fragments.e2b.dev/) / [Discord](https://discord.com/invite/U7KEcGErtQ) / [GitHub](https://github.com/e2b-dev), [Websim](https://websim.com/) / [Subreddit](https://www.reddit.com/r/websim) / [X](https://x.com/websim_ai), [⁠AnyCoder](https://huggingface.co/spaces/akhaliq/anycoder), or [Llama Coder](https://llamacoder.together.ai/) / [GitHub](https://github.com/Nutlope/llamacoder) - App Builders
* [v0](https://v0.app/) - Text to Site Code
* [Bolt.new](https://bolt.new/) - AI Web App Builder / [Discord](https://discord.com/invite/stackblitz) / [GitHub](https://github.com/stackblitz/bolt.new)

***

## ▷ Developer Utilities

* 🌐 **[⁠Awesome AI Coding Tools](https://github.com/ai-for-developers/awesome-ai-coding-tools)** - Index of AI Dev Tools
* 🌐 **[⁠MCP Market](https://mcpmarket.com/)** - MCP Server Index
* 🌐 **[Skills](https://skills.sh/)** or **[⁠an-eye](https://rentry.co/an-eye)** - AI Agent Skill Indexes
* ⭐ **[⁠CodeRabbit](https://www.coderabbit.ai/)** / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/CodeRabbit.md) or [PR-Agent](https://github.com/qodo-ai/pr-agent) - Pull Request Reviews / Feedback
* [Honey](https://github.com/Green-PT/honey-for-devs) or [⁠Ponytail](https://ponytail.dev/) - Make AI Coding Agents More Efficient / Save Tokens / [GitHub](https://github.com/DietrichGebert/ponytail)
* [⁠9Router](https://github.com/decolua/9router) - Local AI Model Proxy & Token Saver
* [CC Switch](https://ccswitch.io/en/) - AI Coding Agent Manager / [GitHub](https://github.com/farion1231/cc-switch)
* [⁠Impeccable](https://impeccable.style/) / [GitHub](https://github.com/pbakaus/impeccable) or [⁠Taste Skill](https://www.tasteskill.dev/) / [GitHub](https://github.com/Leonxlnx/taste-skill) - Design Languages for AI Coding Agents
* [⁠Which AI Made This?](https://www.whichai.dev/) - Compare AI Model Frontend + Motion Designs / [GitHub](https://github.com/SunkenInTime/which-ai)
* [⁠book-to-skill](https://github.com/virgiliojr94/book-to-skill) - Convert Technical Books / Documents to Agent Skills
* [⁠Anti Slop](https://github.com/miqdadbadjuber/anti-slop) - Prevent Coding Agents Generating Generic Code (aka slop)
* [Orca](https://onorca.dev/) - Agentic Development Environment / Parallel Agents / [GitHub](https://github.com/stablyai/orca)
* [Langfuse](https://langfuse.com/) - LLM Engineering & Debugging Platform / [GitHub](https://github.com/langfuse/langfuse)
* [⁠Archify](https://github.com/tt-a1i/archify) - Turn Codebases into Diagrams
* [⁠Ccusage](https://ccusage.com/) - Track Token Usage for AI Coding / [GitHub](https://github.com/ryoppippi/ccusage)
* [Asciify](https://asciify.org/) - ASCII Engine for Coding Agents
* [⁠Code2prompt](https://github.com/mufeedvh/code2prompt) - Codebase To LLM Prompt
* [Querit](https://www.querit.ai/) - AI Web Search API / [CLI](https://pypi.org/project/querit-cli/) / [MCP Server](https://github.com/querit-ai/querit-mcp) / [Discord](https://discord.com/invite/4xXsFA8Ed2) / [GitHub](https://github.com/querit-ai)
* [Gitingest](https://gitingest.com/) or [Repomix](https://repomix.com/) / [GitHub](https://github.com/yamadashy/repomix) - GitHub Repo To Prompt Text
* [Pieces](https://pieces.app/) - Multi-LLM Coding Search Engine
* [⁠HyperFrames](https://github.com/heygen-com/hyperframes) - Code-Based AI Video Generation Framework

***

## ▷ Machine Learning

* 🌐 **[Awesome Machine Learning](https://github.com/josephmisiti/awesome-machine-learning)** - Machine Learning Framework Index
* 🌐 **[Awesome ML](https://github.com/underlines/awesome-ml)**, [⁠Awesome LLM Resources](https://github.com/ilsilfverskiold/Awesome-LLM-Resources-List/) or [ML Resources](https://ml-resources.vercel.app/) - Machine Learning / LLM Resources
* ↪️ **[AI / ML Learning](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7_ai_.2F_ml_learning)** - Educational AI / ML Resources
* ⭐ **[Hugging Face](https://huggingface.co/)**, [ModelScope](https://www.modelscope.ai/), [LLM Papers](https://potent-twister-29f.notion.site/b0fc32542854456cbde923e0adb48845?v=e2d14d2ef0c848f5a1d5b71f9977d7c5) or [OpenML](https://www.openml.org/) - Machine Learning Datasets / Papers
* ⭐ **[Deep playground](https://playground.tensorflow.org/)** - Neural Networks Playground
* ⭐ **[⁠Unsloth](https://unsloth.ai/)** - LLM Finetuning / Text Completion / [Notebooks](https://github.com/unslothai/notebooks) / [Guide](https://unsloth.ai/docs/get-started/fine-tuning-llms-guide) / [GitHub](https://github.com/unslothai/unsloth)
* [ModelScope Finetuning](https://modelscope.ai/civision/model-training) - Image Gen Model Finetuning / Up to 100 Images Per LoRA
* [Markdown Web Browser](https://github.com/Dicklesworthstone/markdown_web_browser) - Webpage > Markdown Converter
* [DeepSpeed](https://www.deepspeed.ai/) - Deep Learning Optimization Library
* [Netron](https://github.com/lutzroeder/netron) - Visualizer for Neural Network, Deep Learning, and Machine Learning Models
* [MMDeploy](https://mmdeploy.readthedocs.io/en/latest/) - Deep Learning Model Deployment Toolset / [GitHub](https://github.com/open-mmlab/mmdeploy)
* [ChatGPT-Next-Web](https://github.com/ChatGPTNextWeb/ChatGPT-Next-Web) - Cross-Platform ChatGPT / Gemini UI
* [Nixified](https://nixified.ai/) - Nix Flake for AI Projects

***

# ► Programming Languages

* 🌐 **[⁠Awesome Explorer](https://awexplor.github.io/)** - Dev Awesome List Frontend / [GitHub](https://github.com/AweXplor/awexplor.github.io)
* 🌐 **[Awesome Cheatsheets](https://lecoupa.github.io/awesome-cheatsheets/)**, **[QuickRef.me](https://quickref.me/)**, [HowDoI](https://github.com/gleitz/howdoi), [OverApi](https://overapi.com/), [Reference](https://cheatsheets.zip/) / [GitHub](https://github.com/Fechin/reference) or [Cheat Sheets](https://www.cheat-sheets.org/) - Programming Cheat Sheets
* 🌐 **[Codigo](https://codigolangs.com/)** - Programming Language Repository
* 🌐 **[Awesome Go](https://awesome-go.com/)** or [Go Recipes](https://github.com/nikolaydubina/go-recipes) - Go Resources
* 🌐 **[TheAlgorithms](https://the-algorithms.com/)** - Coding Algorithms / [GitHub](https://github.com/TheAlgorithms/)
* ↪️ **[Learn Programming](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu/#wiki_.25B7_programming_languages)**
* ⭐ **[Benchmarks Game](https://benchmarksgame-team.pages.debian.net/benchmarksgame/)** - Measure PL Speeds
* ⭐ **[Language Benchmarks](https://programming-language-benchmarks.vercel.app/)** - Benchmarks for PLs & Compilers
* ⭐ **[30 Seconds of Code](https://www.30secondsofcode.org/)** or [FreeFrontend](https://freefrontend.com/) - Find Code Snippets
* ⭐ **[generatedata.com](https://generatedata.com/)** - Generate Test Data in Different Languages
* [Try It Online](https://tio.run/) - Programming Language Interpreters
* [nunu](https://github.com/go-nunu/nunu) - Build Go Programs
* [Learn X in Y minutes](https://learnxinyminutes.com/) - Programming Language Rundowns / [GitHub](https://github.com/adambard/learnxinyminutes-docs)
* [OneLang](https://ide.onelang.io/) - Convert Code to Multiple Languages
* [Crystalline](https://github.com/elbywan/crystalline) - Crystal Language Server
* [explaine.rs](https://jrvidal.github.io/explaine.rs/) - Rust Syntax Explanations
* [⁠Verus](https://github.com/verus-lang/verus) - Rust Code Verification Tool

***

## ▷ Python

* ⭐ **[Automate The Boring Stuff](https://automatetheboringstuff.com/)** - Python Automation Book
* [Python Cheatsheet](https://gto76.github.io/python-cheatsheet/) or [SpeedSheet](https://speedsheet.io/) - Python Cheat Sheets
* [Python Patterns](https://python-patterns.guide/) - Python Design Patterns
* [Clean Code Python](https://github.com/zedr/clean-code-python) - Clean Up Python Code
* [RustPython](https://rustpython.github.io/) - Python Interpreter
* [uv](https://github.com/astral-sh/uv) - Python Package / Project Manager
* [Thonny](https://thonny.org/) - Python IDE
* [Pydroid 3](https://play.google.com/store/apps/details?id=ru.iiec.pydroid3) - Android Python IDE + Learning
* [ty](https://github.com/astral-sh/ty) - Static Code Analyzer
* [Online Python Compiler](https://www.onlinegdb.com/online_python_compiler) - Online Python Editor & Tester

***

## ▷ C Languages

* 🌐 **[Awesome C++](https://github.com/fffaraz/awesome-cpp)** - C++ Resources
* [RoslynPad](https://roslynpad.net/) - C# Editor
* [RoslynQuoter](https://roslynquoter.azurewebsites.net/) - C# Syntax Tree API Viewer
* [The Algorithms - C++](https://thealgorithms.github.io/C-Plus-Plus) - C++ Algorithms
* [⁠C++ Insights](https://cppinsights.io/) or [cpp.sh](https://cpp.sh/) - Online C++ Compiler / Explorers
* [⁠CompCert](https://compcert.org/) - Formally-Verified C Compiler / [GitHub](https://github.com/AbsInt/CompCert)
* [CP-Algorithms](https://cp-algorithms.com/) - C++ Algorithms
* [cppreference](https://en.cppreference.com/w/) - C++ Cheat Sheets

***

## ▷ Java / Kotlin

* 🌐 **[Awesome Java](https://github.com/akullpp/awesome-java)** - Java Resources
* 🌐 **[Awesome Kotlin](https://kotlin.link/)** - Kotlin Resources / [GitHub](https://github.com/Heapy/awesome-kotlin)
* 🌐 **[Obfuscator List](https://github.com/3000IQPlay/obfuscator-list)** - Java Obfuscator Index
* [Adoptium](https://adoptium.net/) - Download OpenJDK Binaries
* [Recaf](https://www.coley.software/Recaf/) - Java Bytecode Editor / [GUI](https://github.com/Col-E/Recaf-Launcher/)
* [bytecode-viewer](https://bytecodeviewer.com), [jd-gui](https://github.com/java-decompiler/jd-gui), [Krakatau](https://github.com/Storyyeller/Krakatau), [Luyten](https://github.com/deathmarine/Luyten), [Vineflower](https://github.com/Vineflower/vineflower), [JavaDecompiler](https://www.javadecompilers.com/) or [Fernflower](https://github.com/fesh0r/fernflower) - Java Decompilers
* [JEnv For Windows](https://github.com/FelixSelter/JEnv-for-Windows) - Change Java Version
* [⁠WhichJDK](https://whichjdk.com/) - JDK Version Cheatsheet / Info
* [jadx](https://github.com/skylot/jadx) - Dex to Java Decompiler
* [GraalVM](https://www.graalvm.org/) - Advanced Multi-language JVM

***

# ► Web Development

## ▷ HTML

* ⭐ **[HTML Reference](https://htmlreference.io/)** - HTML Cheat Sheet
* [HTML-Minifier](https://github.com/j9t/html-minifier-next) - HTML Minifier
* [HTMLRev](https://htmlrev.com/) - Free HTML Templates
* [Markdown to HTML](https://markdowntohtml.com/) - Markdown to HTML Converter
* [ArtPlayer.js](https://artplayer.org/) / [GitHub](https://github.com/zhw2590582/ArtPlayer), [APlayer](https://aplayer.js.org/), [DPlayer](https://dplayer.diygod.dev/) or [xgplayer](https://h5player.bytedance.com/en/) - HTML5 Video Players

***

## ▷ CSS

* 🌐 **[Awesome CSS](https://github.com/awesome-css-group/awesome-css)** - CSS Resources
* 🌐 **[Awesome CSS Frameworks](https://github.com/troxler/awesome-css-frameworks)** - CSS Frameworks Index
* 🌐 **[Classless CSS](https://github.com/dbohdan/classless-css)** - Classless CSS Themes & Frameworks
* 🌐 **[Awesome TailwindCSS](https://github.com/aniftyco/awesome-tailwindcss)** - Tailwind CSS Resources
* ↪️ **[CSS Framework Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage/#wiki_css_framework_tools)**
* ⭐ **[You Don't Need JavaScript](https://github.com/you-dont-need/You-Dont-Need-JavaScript)** - CSS Demos
* ⭐ **[Tailwind CSS](https://tailwindcss.com/)**, [⁠Panda CSS](https://panda-css.com/) / [GitHub](https://github.com/chakra-ui/panda) or [UnoCSS](https://unocss.dev/) - CSS Frameworks
* [CSS Cheat Sheet](https://docs.emmet.io/cheat-sheet/) or [CSS Tricks (Snippets)](https://css-tricks.com/snippets/) - CSS Cheat Sheets
* [⁠WhatUnit](https://whatunit.com/) - CSS Length Unit Chart
* [Easings](https://easings.net/) - CSS Animation Cheat Sheet
* [CSS Layout Generator](https://layout.bradwoods.io/) - CSS Layout / Grid Generators
* [CSSPeeper](https://csspeeper.com/) - Smart CSS Viewer
* [Project Wallace](https://www.projectwallace.com/) - CSS Analyzer
* [CSS Protips](https://github.com/AllThingsSmitty/css-protips), [Modern CSS](https://moderncss.dev/) or [CSS Reference](https://cssreference.io/) - CSS Guides
* [Style Stage](https://stylestage.dev/) - Modern CSS Styles
* [PixelArtCSS](https://www.pixelartcss.com/) - Pixel Art to CSS
* [CSS Doodle](https://css-doodle.com/) - CSS Pattern Generator
* [Codioful](https://codioful.com/), [WebGradients](https://webgradients.com/) / [GitHub](https://github.com/itmeo/webgradients), [GradientMagic](https://www.gradientmagic.com/) or [heropatterns](https://heropatterns.com/) - CSS Patterns / Gradients
* [FilterBlend](https://ilyashubin.github.io/FilterBlend/) - CSS Blend Modes
* [Animista](https://animista.net/) - CSS Animations
* [Tailwind Toolbox](https://windytoolbox.com/) - Tailwind Starter Templates & Components
* [daisyUI](https://daisyui.com/), [⁠Flowbite](https://flowbite.com/), [Float UI](https://floatui.com/) / [GitHub](https://github.com/MarsX-dev/floatui) or [Aceternity UI](https://ui.aceternity.com/) - Tailwind CSS Components

***

## ▷ JavaScript

* 🌐 **[Awesome JavaScript](https://github.com/sorrycc/awesome-javascript)** - JavaScript Resources
* ↪️ **[TypeScript Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage/#wiki_typescript_tools)**
* [Component Party](https://component-party.dev/) - Web Component JS Frameworks Overview / [GitHub](https://github.com/matschik/component-party.dev)
* [⁠Bun](https://bun.com/) - JavaScript Runtime, Bundler, Testing, and Package Manager / [GitHub](https://github.com/oven-sh/bun)
* [WebCrack](https://webcrack.netlify.app/), [jsdfe](https://avotoko.github.io/javascript-deobfuscator/) or [Deobfuscator](https://willnode.github.io/deobfuscator/), [Deobfuscate](https://deobfuscate.relative.im/) - JavaScript Deobfuscators
* [JS Compressor](https://jscompressor.treblereel.dev/) - JavaScript Minifiers
* [Underdash](https://surma.github.io/underdash/) - JavaScript Snippets
* [Node.js Best Practices](https://github.com/goldbergyoni/nodebestpractices) - Node.js Style Guide
* [Airbnb JavaScript Style Guide](https://github.com/airbnb/javascript) or [StandardJS](https://standardjs.com/) - JavaScript Style Guides
* [Discord.js Guide](https://discordjs.guide/) - Discord.js Guide

***

## ▷ React

* [Plate](https://platejs.org/) - React Code Editors
* [React Suite](https://rsuitejs.com/) / [GitHub](https://github.com/rsuite/rsuite), [React Bits](https://reactbits.dev/) / [GitHub](https://github.com/DavidHDev/react-bits), [21st](https://21st.dev/) / [GitHub](https://github.com/serafimcloud/21st) or [Radix UI](https://www.radix-ui.com/) / [GitHub](https://github.com/radix-ui) - React Components
* [Mantine](https://mantine.dev/) - Components and Templates / [GitHub](https://github.com/mantinedev/mantine)
* [Bulletproof React](https://github.com/alan2207/bulletproof-react) - React App Architecture
* [Refine](https://refine.dev/) - React App Builders
* [Puck](https://puckeditor.com/) - Create Simplified Visual Editors for Non-Devs / [GitHub](https://github.com/puckeditor/puck/)
* [Remotion](https://www.remotion.dev/) - React Video Editor
* [React SVG](https://react-svgr.com/playground/) or [SVG2JSX](https://svg2jsx.com/) - Convert SVG to React Components
* [Million](https://million.dev) - React Replacement
* [novu](https://novu.co/) - Real-Time React Notifications / [GitHub](https://github.com/novuhq/novu)
* [UseHooks](https://usehooks.com/) - React Hooks
* [React Query](https://tanstack.com/query/latest) - Fetch, Cache and Update React Data / [GitHub](https://github.com/TanStack/query)
* [MMKV](https://github.com/mrousavy/react-native-mmkv) - React Key / Value Storage
* [Vision Camera](https://visioncamera.margelo.com/) - React Camera Support / [GitHub](https://github.com/mrousavy/react-native-vision-camera)
* [React PDF](https://react-pdf.org/) - Create PDFs in React

***

## ▷ PHP

* 🌐 **[Awesome PHP](https://github.com/ziadoz/awesome-php)** - PHP Resources
* [⁠Laravel Herd](https://herd.laravel.com/windows) - PHP Dev Environment
* [3v4l](https://3v4l.org) - PHP Shell / Web
* [PHPStan](https://phpstan.org) - PHP Debugger / Web / [GitHub](https://github.com/phpstan/phpstan)
* [⁠Composer](https://getcomposer.org/) - PHP Dependency Manager / [GitHub](https://github.com/composer/composer)
* [Spatie](https://spatie.be/open-source) - Run PHP Concurrently / [GitHub](https://github.com/spatie/fork)

***

# ► Web Dev Tools

* 🌐 **[32 Bit Cafe](https://discourse.32bit.cafe/t/resources-list-for-the-personal-web/49)** - Web Dev Resources
* 🌐 **[Awesome Tunneling](https://github.com/anderspitman/awesome-tunneling)** - Tunneling Resources
* ↪️ **[Site Mockups](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_app_.2F_site_mockups)**
* ↪️ **[Archive / Scrape / Crawl Web Pages](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools/#wiki_.25BA_archiving)**
* ↪️ **[Selfhosted Image Galleries](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25B7_offline_galleries)**
* ⭐ **[GoAccess](https://goaccess.io/)** - Web Log Analyzer / [GitHub](https://github.com/allinurl/goaccess)
* ⭐ **[Formulaer](https://formulaer.com/)**, **[Tally](https://tally.so/)**, [FormBricks](https://github.com/formbricks/formbricks) or [Deformity](https://deformity.ai/) - Form Builders
* ⭐ **[Playwright](https://playwright.dev/)**, [Browser Use](https://browser-use.com/) / [Harness](https://browser-harness.com/) / [GitHub](https://github.com/browser-use/browser-use), [Selenium](https://www.selenium.dev/) or [Huginn](https://github.com/huginn/huginn) - Browser Automation
* [Automa](https://www.goautoma.com/extension/) or [Browserflow](https://browserflow.app/) - Browser Automation Extensions
* [⁠cron-job](https://cron-job.org/) - Web-Based Cron Job / Automation Scheduler
* [Flounder](https://flounder.online/) - Website Building Discussion
* [⁠Networking Toolbox](https://networkingtoolbox.net/), [Browserling Tools](https://www.browserling.com/tools/) or [WebCode](https://webcode.tools/) - Site Development Tools
* [⁠OG Image Generator](https://www.ogimage.website/) or [Link Preview JS](https://github.com/OP-Engineering/link-preview-js) - Create Link Previews / Graph Images
* [⁠Tech Playground](https://tech-playground.com/) - Playground for Server-Side Tech
* [Wappalyzer](https://www.wappalyzer.com/) - Identify Technologies on Websites / [Addons](https://www.wappalyzer.com/apps/)
* [shadcn-ui](https://ui.shadcn.com/) or [shadcn-svelte](https://shadcn-svelte.com) - Web Component Libraries / [Examples](https://github.com/ln-dev7/square-ui)
* [Web Developer](https://chromewebstore.google.com/detail/web-developer/bfbameneiokkgbdmiekhjnmfkcnldhhm) - Web Developer Toolbar Extension
* [GoatCounter](https://www.goatcounter.com/), [Cloudflare Web Analytics](https://www.cloudflare.com/web-analytics/), [Rybbit](https://github.com/rybbit-io/rybbit), [MS Clarity](https://clarity.microsoft.com/) or [Umami](https://umami.is/) - Site Analytics
* [ElasticSearch](https://www.elastic.co/elasticsearch) - Search & Analytics Engine / [GitHub](https://github.com/elastic/elasticsearch)
* [Wisp](https://wispweb.dev/) - Web Framework for Rust / [Source Code](https://code.wispweb.dev/wispdev/wisp/)
* [Tabler](https://tabler.io/) - Site Admin Dashboard
* [Octopus](https://octopus.do/sitemap) - Site Planning Tool
* [Giscus](https://giscus.app/) or [Remarkbox](https://www.remarkbox.com/) - Site Comment Systems
* [Wordpress](https://wordpress.org/) / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/dev-tools#wiki_.25B7_wordpress_tools) or [Joomla](https://www.joomla.org/) / [GitHub](https://github.com/joomla/joomla-cms) - Content Management Systems / CMS
* [The Website Specification](https://specification.website/) / [GitHub](https://github.com/jdevalk/specification.website) - Website Design Checklist
* [Dagu](https://github.com/dagu-org/dagu) - WebUI Job Manager
* [xh](https://github.com/ducaale/xh) - HTTP Clients / Transfer Data with URLs / [IP Lookup](https://ifconfig.me/) / [Recipes](https://catonmat.net/cookbooks/curl)
* [http-server](https://github.com/http-party/http-server) - No Config HTTP Server
* [Plow](https://github.com/six-ddc/plow) - HTTP Benchmarking
* [Transform](https://transform.tools/) - Polyglot Web Converter
* [Media Chrome](https://www.media-chrome.org/) - Media Player Elements / [GitHub](https://github.com/muxinc/media-chrome)
* [OneLinePlayer](https://onelineplayer.com/) - Vimeo / Dropbox Video Player
* [Motion](https://motion.dev/) - Animation Library
* [Medusa](https://medusajs.com) - Digital Commerce Development Tool
* [Can I Use?](https://caniuse.com/) - Browser Support Tables
* [Caddy](https://caddyserver.com/) / [GitHub](https://github.com/caddyserver/caddy) or [Nginx](https://nginx.org/) / [GitHub](https://github.com/nginx/nginx) - Web Servers
* [Directory Lister](https://directorylister.com/) - Web-Based Directory Listing / [GitHub](https://github.com/DirectoryLister/DirectoryLister)
* [The SSO Wall of Shame](https://sso.tax/) - Vendors without Built-in SSO
* [⁠TestLocally](https://testlocal.ly/) - Global Website Screenshot / Localization 
* [Pocket ID](https://pocket-id.org/) - Self-Hosted OIDC Provider with Passkeys / [GitHub](https://github.com/pocket-id/pocket-id)
* [Can I Email?](https://www.caniemail.com/) - Email Functionality Check
* [Typebot](https://typebot.com/) - Embedded Chat App
* [uMap](https://umap-project.org/) - Custom Embeddable Maps for Websites / [GitHub](https://github.com/umap-project/umap/)
* [Google Map Themes](https://snazzymaps.com/) - Google Map Themes for Web Developers
* [frp](https://github.com/fatedier/frp), [GoDoxy](https://github.com/yusing/godoxy) or [YARP](https://github.com/dotnet/yarp) - Reverse Proxies
* [wsrv.nl](https://wsrv.nl/) - Image Caching / Delivery / [GitHub](https://github.com/weserv/images)
* [WhatPWACanDo](https://whatpwacando.today/) - PWA Examples
* [PWABuilder](https://www.pwabuilder.com/) - Turn Site into Progressive Web App / [Discord](https://discord.com/invite/hXGv6HvtrK)
* [Chaos Frontend Toolkit](https://chaos-frontend-toolkit.web.app/) - Break Your Web Apps to Improve Them
* [LocalHost](https://localhost.run/) - Connect Web Apps to Internet
* [tailspin](https://github.com/bensadeh/tailspin) - Syntax Highlighter
* [Cloudflared](https://github.com/cloudflare/cloudflared), [⁠Pangolin](https://pangolin.net) / [GitHub](https://github.com/fosrl/pangolin), [⁠untun](https://github.com/unjs/untun) or [ngrok](https://ngrok.com/) - Introspectable Tunnel to Localhost Tools
* [Bore](https://github.com/ekzhang/bore) - TCP Tunnel to Expose Servers Local Ports
* [NConfig](https://www.digitalocean.com/community/tools/nginx) - Server Config
* [Nginx-Admins-Handbook](https://github.com/trimstray/nginx-admins-handbook) - Improve NGINX Performance
* [Null PHP Script](https://nullphpscript.com/) - Nulled Scripts

***

## ▷ Website Builders

* 🌐 **[Awesome Static Generators](https://myles.github.io/awesome-static-generators/)** / [GitHub](https://github.com/myles/awesome-static-generators) or **[Jamstack Generators](https://jamstack.org/generators/)** - Static Site Generator Indexes
* ⭐ **[Eleventy](https://11ty.dev/)** - Static Site Generator / [Discord](https://discord.gg/GBkBy9u) / [GitHub](https://github.com/11ty/eleventy)
* ⭐ **[Hugo](https://gohugo.io/)** - Static Site Generator
* ⭐ **[Webstudio](https://webstudio.is/)** - Website Builder
* ⭐ **[VitePress](https://vitepress.dev/)** - Static Site Generator
* ⭐ **[Astro](https://astro.build/)** - Static Site Generator / [X](https://x.com/astrodotbuild) / [Discord](https://discord.com/invite/grF4GTXXYm) / [GitHub](https://github.com/withastro/astro)
* ⭐ **[Docusaurus](https://docusaurus.io/)** - Static Markdown Website Generators / [GitHub](https://github.com/facebook/docusaurus)
* ⭐ **[Carrd](https://carrd.com/)** - Simple Website Builder
* [Retype](https://retype.com/) - Static Markdown Website Generator / [GitHub](https://github.com/retypeapp/retype)
* [Zola](https://www.getzola.org/) - Static Markdown Website Generator
* [Publii](https://getpublii.com/) - Static Markdown Website Generator / No Coding
* [Jekyll](https://jekyllrb.com/) - Static Markdown Website Generator
* [docsify](https://docsify.js.org/) - Static Markdown Website Generator
* [GitBook](https://www.gitbook.com/) - Static Site Generator
* [Pelican](https://getpelican.com/) - Static Site Generator
* [tilda](https://tilda.cc/) - Website Builder
* [cargo](https://cargo.site/) - Website Builder
* [Framer](https://www.framer.com/) - Website Builder
* [Temper](https://temper.one/) - Website Builder
* [Silex](https://www.silex.me/) - Website Builder
* [mmm](https://mmm.page/) - Website Builder
* [Straw.Page](https://straw.page/) - Website Builder
* [Feather Wiki](https://feather.wiki/) - Extensible Website Generator
* [SouPalt](https://soupault.net/) - Static Website Generator with HTML Element Tree
* [Vvveb](https://www.vvveb.com/), [Universe](https://onuniverse.com/), [Google Sites](https://sites.google.com/) or [Odoo](https://www.odoo.com/app/website) - Drag & Drop Website Builders
* [Tails](https://devdojo.com/tails) - Tailwind CSS Website Builder
* [Anvil](https://anvil.works/) or [Lowdefy](https://lowdefy.com/) - Web App Creators

***

## ▷ Color Schemes

* ↪️ **[Color Palette Generators](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25B7_palette_generators)**
* ↪️ **[Color Pickers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25B7_color_pickers)**
* ⭐ **[ColorHexa](https://www.colorhexa.com/)** - Color Hex Encyclopedia
* ⭐ **[Realtime Colors](https://realtimecolors.com/)** - Preview Color Palettes
* ⭐ **[Color & Contrast](https://colorandcontrast.com/)** - Color / Contrast Guide
* [Colors & Fonts](https://www.colorsandfonts.com/) - Quickly Copy Colors
* [Khroma](https://www.khroma.co/) or [Paletton](https://paletton.com/) - Color Scheme Designers
* [Palettte](https://www.bairesdev.com/tools/color-palette-app/editor/) - Color Palette Editor
* [Color Converter](https://ozdemir.dev/color-converter/) - Color Code Format Converter
* [PaletteGenerator](https://palettegenerator.com/) - Color Palette Extractor
* [Colorable](https://colorable.jxnblk.com/) / [GitHub](https://github.com/jxnblk/colorable), [color.review](https://color.review/), [accessible-color-matrix](https://toolness.github.io/accessible-color-matrix/) or [Accessible Brand Colors](https://abc.useallfive.com/) - Accessible Color Palette Builders
* [Color Oracle](https://colororacle.org/), [WhoCanUse](https://www.whocanuse.com/) or [Toptal](https://www.toptal.com/designers/colorfilter) - Color Blindness Simulator / Tests
* [Simpler Color](https://github.com/arnelenero/simpler-color) - Create Web Color System
* [ColorZilla](https://www.colorzilla.com/) - Color Picker, Gradient Generator & more
* [MakeTintAndShade](https://maketintsandshades.com/) - Tint and Shade Generator
* [Alphredo](https://alphredo.app/) - Create Translucent Colors
* [Contrast Checker](https://webaim.org/resources/contrastchecker/) or [Colour Contrast](https://colourcontrast.cc/) - Background / Text Contrast Checkers

***

## ▷ Frontend / UI Tools

* 🌐 **[Awesome Design Systems](https://github.com/alexpate/awesome-design-systems)** - UI Design Systems / Libraries
* 🌐 **[⁠mkdir](https://mkdir.directory/)** - Web Design Inspiration Site Index
* 🌐 **[Awesome Web Animation](https://awesome-web-animation.netlify.app/)** - Web Animation Resources
* ↪️ **[Design Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_design_resources)**, **[Image Design](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25BA_design_resources_.2F_ideas)** or [Open Source Design](https://opensourcedesign.net/)
* ⭐ **[Design Checklist](https://www.checklist.design/)**, [Performance Checklist](https://github.com/thedaviddias/Front-End-Performance-Checklist) or [Front-End Checklist](https://frontendchecklist.io/) - Frontend Development Checklist
* ⭐ **[ThemeWagon](https://themewagon.com/theme-price/free/)** - Free HTML Templates
* ⭐ **[awwwards](https://www.awwwards.com/websites)**, **[Boilerplate](https://html5boilerplate.com/)** or [html5up](https://html5up.net/) - Custom HTML Templates
* [UI Design Daily](https://www.uidesigndaily.com/) or [UIVerse](https://uiverse.io/) - Free UI Design Resources
* [CollectUI](https://collectui.com/), [Hoverstat](https://www.hoverstat.es/), [httpster](https://httpster.net/), [Recent](https://recent.design/), [Websitevice](https://websitevice.com/), [Dribbble](https://dribbble.com/), [ReallyGoodUX](https://goodux.appcues.com/) or [Pageflows](https://pageflows.com/) - UI / Site Design Inspiration
* [Templatemo](https://www.templatemo.com/) - Free CSS Templates
* [Repth Themes](https://repth.neocities.org/theme) - Y2K Anime Themes
* ⁠Human Interface Guidelines: [Windows](https://learn.microsoft.com/en-us/windows/apps/design/) / [Gnome](https://developer.gnome.org/hig/) / [KDE](https://develop.kde.org/hig/) / [Apple](https://developer.apple.com/design/human-interface-guidelines) - Interface Guidelines
* [Storybook](https://storybook.js.org/) or [Mockend](https://mockend.com/) - UI Development Tools
* [Open UI](https://open-ui.org/) - Open Standard UI
* [Same.new](https://same.new/) - Copy Sites User-Interface Code
* [CodeMyUI](https://codemyui.com/) or [Fomantic-UI](https://fomantic-ui.com/) - User Interface Code Snippets
* [Icon Shelf](https://icon-shelf.github.io/) - Icon Manager
* [Favicon Maker](https://formito.com/tools/favicon) or [Favicon Generator](https://www.favicon-generator.org/) - Create Favicons
* [Icon Horse](https://icon.horse/) or [Favicone](https://upset.dev/favicone) - Download a Site's Favicon / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/site-favicon-dl.md)
* [Meta-Mapper](https://meta-mapper.com/) - Website Metadata Thumbnails
* [Scrollbar.app](https://scrollbar.app/) - Design Custom Scrollbars
* [Emanote](https://emanote.srid.ca/) - Create Sites from Plain-Text Notes / [GitHub](https://github.com/srid/emanote)
* [Bloo](https://bloouikit.com/) - Prototype / Test Websites Idea
* [WebDesignMuseum](https://www.webdesignmuseum.org/) - Website Designs Over Time
* [PsdRepo](https://psdrepo.com/) - Templates, Mockups, Logos, Videos
* [Daft Page](https://daftpage.com/) - Landing Page Creator
* [SaaS Pages](https://saaspages.xyz/), [SaaS Landing Page](https://saaslandingpage.com/) or [lapa](https://www.lapa.ninja/) - Landing Page Templates / Ideas
* [Zeplin](https://zeplin.io/) - Design Templates / Editor
* [vite](https://vite.dev/) or [layoutit](https://layoutit.com/) - Frontend Development Tools
* [Dembrandt](https://www.dembrandt.com/) - Extract / Derive Site Design / [GitHub](https://github.com/dembrandt/dembrandt)
* [the component gallery](https://component.gallery/) - Design Components Gallery
* [UI Beats](https://www.uibeats.com/), [⁠Style UI](https://style.ai.id/) / [GitHub](https://github.com/miqdadbadjuber/style-ui) or [MagicUI](https://magicui.design/) - UI Components
* [Hydrogen](https://github.com/Shopify/hydrogen) - Online Store Templates
* [CSS Bed](https://www.cssbed.com/) - Classless CSS Templates / [GitHub](https://github.com/ubershmekel/cssbed)
* [Beer CSS](https://www.beercss.com/) - Lightweight CSS Framework / [GitHub](https://github.com/beercss/beercss)
* [dummyimage](https://dummyimage.com/) or [PicSum](https://picsum.photos/) - Site Placeholder Images
* [⁠BlurHash](https://blurha.sh/) - Compact Representation Algorithm for Image Placeholders / [GitHub](https://github.com/woltapp/blurhash)
* [Visiwig](https://www.visiwig.com/) - Copy / Paste Site Graphics
* [T3](https://github.com/tooll3/t3), [⁠Lottie Creator](https://creator.lottiefiles.com/) or [Mantra](https://jeremyckahn.github.io/mantra/) - Create Motion Graphics
* [HTTP Cats](https://http.cat/) - Put Cat Pictures in Your Status Codes

***

## ▷ WordPress Tools

* ⭐ **[Weadown](https://weadown.com/)** or [DDLCode](https://ddlcode.com/) - Premium Themes / Plugins
* ⭐ **[GPLDL](https://gpldl.com/)** - Premium Themes / Plugins / 25 Monthly / Requires Sign-Up
* [Babiato](https://babia.to/) - Themes / Plugins Forum / Requires Sign-Up
* [Visual CSS Editor](https://chromewebstore.google.com/detail/visual-css-editor/cibffnhhlfippmhdmdkcfecncoaegdkh) - WordPress Site Designer
* [LocalWP](https://localwp.com/releases/) - WordPress Site Deployment Tools
* [faustjs](https://faustjs.org) - WordPress Framework
* [Timber](https://upstatement.com/timber/) - WordPress Theme Creator / [GitHub](https://github.com/timber/timber)
* [KokoAnalytics](https://www.kokoanalytics.com/) - WordPress Analytics

***

## ▷ Regex Tools

* **Note** - You can use [AI chatbots](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/ai/#wiki_.25B7_online_chatbots) to create regex patterns more easily.

***

* ⭐ **[Regex Vis](https://regex-vis.com/)** - Regex Visualizer
* ⭐ **[regex101](https://regex101.com/)** or [RegExr](https://regexr.com/) - Regex Editors
* [RegexLearn](https://regexlearn.com/), [RegexOne](https://regexone.com/), [refrf.dev](https://refrf.dev/) or [learn-regex](https://github.com/ziishaned/learn-regex) - Regex Learning / Practice Resources
* [Regex Syntax Cheatsheet](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Regular_expressions/Cheatsheet) - Regex Cheatsheet (JS Flavor)
* [iHateRegex](https://ihateregex.io/) - Premade Regex Patterns List
* [Globster](https://globster.xyz/) - Test Glob Patterns

***

## ▷ Benchmarks / Accessibility

* 🌐 **[Awesome Accessibility](https://github.com/brunopulis/awesome-a11y)** - Accessibility Tools Index
* ⭐ **[LightTest](https://lightest.app/)**, [Yellow Lab Tools](https://yellowlab.tools/), [PageSpeed](https://pagespeed.web.dev/), [Geofetcher](https://geofetcher.appsinprogress.com/) or [GTmetrix](https://gtmetrix.com/) - Test Webpage Speed
* ⭐ **[Geekflare Tools](https://geekflare.com/tools/)** or [Frontend Dogma](https://frontenddogma.com/tools/check/) - Site Benchmarking Tools
* [LambdaTest](https://www.testmuai.com/) - Cross Browser Testing Cloud
* [Pa11y](https://pa11y.org/), [⁠Accessibility Support](https://a11ysupport.io/), [Wave](https://wave.webaim.org/), [Andi](https://www.ssa.gov/accessibility/andi/help/install.html) or [A11ygator](https://a11ygator.chialab.io/) - Accessibility Evaluation Tools
* [Accessibility Insights](https://accessibilityinsights.io/) - Fix Accessibility Issues
* [⁠ADG](https://www.accessibility-developer-guide.com/) / [GitHub](https://github.com/Access4all/adg), [⁠WebAIM](https://webaim.org/), [Accessibility Cheatsheet](https://moritzglantz.de/accessibility-cheatsheet/) or [A11Project](https://www.a11yproject.com/checklist) - Site Accessibility Guidelines / Learning
* [Web Vitals Leaderboard](https://vitals-leaderboard.pazguille.me/), [CodSpeed](https://codspeed.io/) or [Lighthouse Metrics](https://lighthouse-metrics.com/) - Website Performance Tests
* [Prometheus](https://prometheus.io/) - Site Metrics / [Setup](https://thanos.io/)
* [Carbon Calculator](https://www.websitecarbon.com/) - Estimate a Site's Carbon Footprint
* [UX Check](https://chromewebstore.google.com/detail/ux-check/giekhiebdpmljgchjojblnekkcgpdobp) - Site Heuristic Evaluation
* [Rankchart](https://rankchart.org/) - Optimization Reports
* [Testmail](https://testmail.app/) - Site Signup Test
* [Responsive Viewer](https://responsiveviewer.org/) - Test Site on Multiple Screen Types / [Chrome](https://chromewebstore.google.com/detail/responsive-viewer/inmopeiepgfljkpkidclfgbgbmfcennb)
* [Responsively](https://responsively.app/) or [Am I Responsive](https://fireship.dev/amiresponsive) - Website Responsiveness Tests
* [LightHouse](https://github.com/GoogleChrome/lighthouse) - Web App Performance Test

***

## ▷ SVG Tools

* ↪️ **[SVG / Vector Icons](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_svg_icons)**
* ↪️ **[Vector Editors](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25B7_painting_.2F_drawing)**
* [Method](https://editor.method.ac/), [SVG.wtf](https://svg.wtf/), [Lucide Studio](https://studio.lucide.dev/edit), [DrawSVG](https://drawsvg.org/), [Boxy SVG](https://boxy-svg.com/), [Mossaik](https://mossaik.app/) or [SVG Viewer](https://www.svgviewer.dev/) - SVG Editors / Viewers
* [fffuel](https://fffuel.co/) - SVG Generators
* [⁠3DSVG](https://3dsvg.design/) - 3D SVG Editor
* [SVGFilters](https://svgfilters.com/) - SVG Filter Builder
* [SVGArtista](https://svgartista.net/) or [⁠SVG Studio](https://svgstudio.org/) - SVG Animation Tools
* [⁠morphicons](https://www.morphicons.com/) - SVG Icon Morphing Tool / [GitHub](https://github.com/guillermolg00/morphicons)
* [FrameSVG](https://framesvg.romelium.cc/) - GIF to Animated SVG / [GitHub](https://github.com/Romelium/FrameSVG)
* [SVGO](https://github.com/svg/svgo) or [SVGCrop](https://svgcrop.com/) - SVG Optimization / [GUI](https://jakearchibald.github.io/svgomg/)
* [SVG Tutorial](https://svg-tutorial.com/) - Learn How to Code SVG Images
* [SVGX](https://svgx.app/) - SVG Assets Manager
* [Vector Express](https://vector.express/) - Vector Converters
* [svgco](https://svgco.de/) or [⁠SVGFast](https://svgfast.com/) - Image to SVG Converters
* [⁠GLORP](https://zack-gphom.itch.io/glorp-pixel-to-svg) - Convert Pixel Art to Optimized SVGs / Windows / [GitHub](https://github.com/ZackGphom/GLORP/)
* [⁠Book Of Shapes](https://bookofshapes.com/) - Customizable SVG Shape & Patterns
* [Pattern Monster](https://pattern.monster/) - SVG Pattern Generator
* [Blobs](https://lokesh-coder.github.io/blobs.app/) - SVG Shape Generator
* [Broider](https://maxbittker.github.io/broider/) - Create Border Designs
* [ShapeDivider](https://www.shapedivider.app/) - Make SVG Shape Divider
* [SVG Path](https://svg-path-visualizer.netlify.app/) - SVG Path Visualizer
* [svg-path-editor](https://yqnn.github.io/svg-path-editor/) - SVG Path Editor
* [SVGWave](https://svgwave.in/) / [GitHub](https://github.com/anup-a/svgwave) - SVG Wave Generator
* [AutoTracer](https://www.autotracer.org/), [⁠Vectorize Image](https://vectorize-image.app/) or [⁠vtracer](https://www.visioncortex.org/vtracer/) / [GitHub](https://github.com/visioncortex/vtracer) - Image Vectorizers / Autotracers

***

# ► Hosting Tools

* 🌐 **[FreeHosts](https://freehosts.eu/)** or **[Awesome-Web-Hosting](https://nuhmanpk.github.io/Awesome-Web-Hosting/)** / [GitHub](https://github.com/nuhmanpk/Awesome-Web-Hosting) - Free Hosting Provider Indexes
* 🌐 **[Awesome Cloudflare](https://github.com/irazasyed/awesome-cloudflare)** - Cloudflare Resource Index
* 🌐 **[VPS Comparison Chart](https://vpsfilter.com/)**, [VPS Rentals](https://vps.rentals/), [⁠servers.fyi](https://www.servers.fyi/), [⁠VPS Price Tracker](https://vpspricetracker.com/) or [Bitcoin VPS](https://bitcoin-vps.com/) - VPS Comparisons
* ↪️ **[DNS Adblocking](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25B7_dns_adblocking)** - DNS Providers & Adblocking
* ↪️ **[Self-Hosted Wiki Alts](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_self-hosted_wiki_alts)**
* ⭐ **[TLDES](https://tldes.com/)**, [TLDHub](https://tldhub.com/), [TLD-List](https://tld-list.com/) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/tld-list-note.md) or [SitePrice](https://www.siteprice.org/) - Domain Price Comparisons
* ⭐ **[censys](https://platform.censys.io/home)**, [WebDNA](https://webdna.xtra.wtf/), [⁠ICANN Lookup](https://lookup.icann.org/), [wtfis](https://github.com/pirxthepilot/wtfis), [whois_](https://whois.b1s4.xyz/) / [GitHub](https://github.com/b1s4/whois), [RDAP](https://client.rdap.org/), [digger.tools](https://digger.tools/), [LinkScope](https://accentusoft.com/), [DNSlytics](https://dnslytics.com/), [WhoisRequest](https://whoisrequest.com/), [⁠W.is](https://w.is/) or [Whois Lookup](https://whois.domaintools.com/) - Domain Info / Whois Search
* ⭐ **[Check-Host](https://check-host.net/)** or [Uptime](https://betterstack.com/uptime) - Web-Based Uptime Monitors
* [Secure Backend Guide](https://rentry.co/FMHYB64#backend-guide) - Secure Backend Guide
* [Oracle Cloud](https://www.oracle.com/cloud/free/) - Free VPS / Requires Real Information / [Guide (Important)](https://guides.viren070.me/selfhosting/oracle)
* [InstantDomain](https://instantdomainsearch.com/), [DomainTyper](https://domaintyper.com/), [⁠Micro Domains](https://micro.domains/), [IWantMyName](https://iwantmyname.com/), [Whois](https://www.whois.com/), [Domainr](https://domainr.com) or [Atlaq](https://atlaq.com) - Domains
* [Pyfunceble](https://pyfunceble.github.io/#/) - Domain Availability App / [GitHub](https://github.com/funilrys/PyFunceble)
* [DNForum](https://www.dnforum.com/) - Domain Name Forum
* [DNSTwist](https://dnstwist.it/) / [GitHub](https://github.com/elceef/dnstwist), [HaveIBeenSquatted](https://haveibeensquatted.com) or [DNSTwister](https://www.dnstwister.com/) - Typosquatting Checkers
* [OONI](https://ooni.org/) - Check Site Location Availability
* [Server Hunter](https://www.serverhunter.com/) or [ServerSearcher](https://www.serversearcher.com/) - Search / Compare Servers
* [GetDeploying](https://getdeploying.com/) - Compare Cloud Providers
* [srvrlss](https://srvrlss.io/) - Search / Compare Serverless Platforms
* [⁠Instances (Vantage)](https://instances.vantage.sh/) - Compare AWS, Azure, and GCP Instances / [GitHub](https://github.com/vantage-sh/ec2instances.info)
* [⁠Val Town](https://www.val.town/) - Serverless Scripting and Sharing
* [GoodBadISPs](https://gitlab.torproject.org/legacy/trac/-/wikis/doc/GoodBadISPs) - Best ISPs for Tor Hosting
* [Sandstorm](https://sandstorm.org/) / [GitHub](https://github.com/sandstorm-io/sandstorm), [Cosmos](https://cosmos-cloud.io/) / [GitHub](https://github.com/azukaar/cosmos-server) or [Cloudron](https://www.cloudron.io/) - Web App Hosts
* [overscript](https://overscript.net/) - Imageboard Hosting / [GitHub](https://github.com/tanami/overscript)
* [ProBoards](https://www.proboards.com/) - Forum & Imageboard Hosting
* [MyBB](https://www.mybb.com/) / [GitHub](https://github.com/mybb), [FreeFlarum](https://freeflarum.com/) or [phpBB](https://www.phpbb.com/) / [GitHub](https://github.com/phpbb) - Forum Hosting
* [HumHub](https://www.humhub.com) / [GitHub](https://github.com/humhub), [Hubzilla](https://hubzilla.org/page/info/home) / [GitLab](https://framagit.org/hubzilla/core) or [scuttlebutt](https://scuttlebutt.nz/) - Self-Hosted Social Network
* [UNIT3D](https://github.com/HDInnovations/UNIT3D) - Private Tracker Hosting
* [OpenPanel](https://openpanel.com/) / [GitHub](https://github.com/stefanpejcic/openpanel) or [Moonlight](https://moonlightpanel.xyz/) / [GitHub](https://github.com/Moonlight-Panel/Moonlight) - Web Hosting Panels
* [24x7](https://www.site24x7.com/tools.html) - Various Hosting Tools
* [Uptime Kuma](https://uptime.kuma.pet/) / [GitHub](https://github.com/louislam/uptime-kuma), [Checkmate](https://checkmate.so/) / [GitHub](https://github.com/bluewave-labs/Checkmate), [⁠Gatus](https://gatus.io/) / [GitHub](https://github.com/TwiN/gatus) or [UptimeRobot](https://uptimerobot.com/) - Uptime Monitors
* [Kener](https://kener.ing/) / [GitHub](https://github.com/rajnandan1/kener) or [cState](https://cstate.uncascade.com/) / [GitHub](https://github.com/cstate/cstate) - Self-Hosted Status Pages
* [redirect.name](https://redirect.name/) - URL Forwarding / [GitHub](https://github.com/frolic/redirect.name)
* [iana](https://www.iana.org/), [arin](https://www.arin.net/), [lacnic](https://www.lacnic.net/), [afrinic](https://www.afrinic.net/) or [apnic](https://www.apnic.net/) - Internet Registry Sites
* [AtSameIP](https://intercode.info/webtools/atsameip/) - Find Websites on the Same IP
* [Check for Cloudflare](https://checkforcloudflare.selesti.com/) - Check Sites for Cloudflare
* [Cloudflare Radar](https://radar.cloudflare.com/) - Cloudflare Insights
* [CloudFlare DDNS Updater](https://github.com/K0p1-Git/cloudflare-ddns-updater/) - Cloudflare Dynamic DNS Auto-Update Script
* [Meta Tag Gen](https://lewdev.github.io/apps/meta-tag-gen/) / [GitHub](https://github.com/lewdev/meta-tag-gen), [OpenGraph](https://www.opengraph.xyz/) or [MetaTags](https://metatags.io/) - Meta Tag Generators

***

## ▷ Dynamic Page Hosting

* **Note** - The tags for this section are as follows: Storage Limit / Monthly Bandwidth Limit.

***

* ⭐ **[Cloudflare Workers](https://www.cloudflare.com/products/workers/)** - Unlimited Bandwidth (20MB Each) / 3MB Max Script Size / 100K Requests Daily
* ⭐ **[vercel](https://vercel.com/)** - 1GB Storage / 100GB Bandwidth
* ⭐ **[alwaysdata.com](https://www.alwaysdata.com/en/)** - 1GB Storage / Unlimited Bandwidth / Unlimited DB / 256MB RAM
* [⁠Coolify](https://coolify.io/) - Self-Hosting Platform / [GitHub](https://github.com/coollabsio/coolify)
* [AwardSpace.com](https://www.awardspace.com/) - 1GB Storage / 5GB Bandwidth / 1 DB / 5K Monthly Visits
* [Freehostia.com](https://www.freehostia.com/) - 250MB Storage / 6GB Bandwidth / 1 DB
* [FreeHostingEU.com](https://www.freehostingeu.com/) - 200MB Storage / 4GB Bandwidth / 1 DB
* [Batcave.net](https://batcave.net/) - 1GB Storage / 5GB Bandwidth / 1 DB
* [CGIWebHost.com](https://www.cgiwebhost.com/) - 1GB Storage / 5GB Bandwidth / 1 DB
* [FreeHostingNoAds.net](https://freehostingnoads.net/) - 1GB Storage / 5GB Bandwidth / 1 DB
* [100WebSpace.com](https://www.100webspace.com/) - 100MB Storage / 3GB Bandwidth / 1 DB
* [netlify](https://www.netlify.com/) - 300 Credits / [Monthly](https://docs.netlify.com/manage/accounts-and-billing/billing/billing-for-credit-based-plans/how-credits-work/#credits-usage-for-metered-billing)
* [50Webs.com](https://www.50webs.com/) - 500MB Storage / 5GB Bandwidth / 0 DB
* [Somee.com](https://somee.com/) - 150MB Storage / 5GB Bandwidth / 1 DB
* [FreeWebPageHost.Net](https://freewebpagehost.net/) - 1GB Storage / 5GB Bandwidth / 1 DB
* [WebFreeHosting.net](https://webfreehosting.net/) - 1GB Storage / 5GB Bandwidth / 1 DB
* [Biz.ly](https://www.biz.ly/) - 50MB Storage / 1GB Bandwidth / 0 DB
* [biz.ht](https://biz.ht/) - 1GB Storage / 5GB Bandwidth / 1 DB
* [Freehostspace.com](https://www.freehostspace.com/) - 1GB Storage / 5GB Bandwidth / 1 DB
* [RUNHOSTING.com](https://runhosting.com/) - 1GB Storage / 5GB Bandwidth / 1 DB
* [FreeSiteHosting.com](https://freesitehosting.com/) - 1GB Storage / 5GB Bandwidth / 1 DB
* [Freehostpro.com](https://www.freehostpro.com/) - 1GB Storage / 5GB Bandwidth / 1 DB
* [Redwebhost.com](https://www.redwebhost.com/) - 1GB Storage / 5GB Bandwidth / 1 DB
* [Tekcities.com](https://www.tekcities.com/) - 1GB Storage / 5GB Bandwidth / 1 DB
* [Agilityhoster.com](https://www.agilityhoster.com/) - 1GB Storage / 5GB Bandwidth / 1 DB
* [125mb.com](https://www.125mb.com/) - 1GB Storage / 5GB Bandwidth / 1 DB
* [TinkerHost.net](https://tinkerhost.net/), [2](https://infinityfree.com/), [3](https://byet.host/free-hosting) - 5GB Storage / 100GB Bandwidth / Unlimited DB
* [biz.nf](https://www.biz.nf/) - 1GB Storage / 5GB Bandwidth / 1 DB
* [ATSPACE](https://www.atspace.com/) - 1GB Storage / Unlimited Bandwidth / 1 DB
* [UHostFull.com](https://www.uhostfull.com/) or [UHostAll.com](https://www.uhostall.com/) - 5GB Storage / Unlimited Bandwidth / Unlimited DB
* [Leprd](https://leprd.space/) - 1GB Storage / 10GB Bandwidth / Unlimited DB / Limited Registration
* [x10hosting](https://x10hosting.com/) - 500MB Storage / Unlimited Bandwidth / 2 DB
* [Profreehost](https://profreehost.com/) - 5GB Storage / Unlimited Bandwidth / Unlimited DB
* [Render](https://render.com/)
* [pythonanywhere](https://www.pythonanywhere.com/)
* [IBM Cloud](https://www.ibm.com/cloud/free)
* [Stormkit](https://www.stormkit.io/)

***

## ▷ Static Page Hosting

* **Note** - The tags for this section are as follows: Storage Limit / Monthly Bandwidth Limit.

***

* ⭐ **[Cloudflare Pages](https://www.cloudflare.com/products/pages/)** - 20K Files (25MB Each) / Unlimited / [Discord](https://discord.gg/cloudflaredev)
* ⭐ **[surge](https://surge.sh/)** - Unlimited / Unlimited / [X](https://x.com/surge_sh) / [GitHub](http://github.com/sintaxi/surge)
* ⭐ **[GitHub Pages](https://docs.github.com/en/pages)** - 1GB (100MB per File) / 100GB
* ⭐ **[Sourcehut Pages](https://srht.site/)** - 1GB / Unlimited
* ⭐ **[Neocities](https://neocities.org/)** - 1GB / 200GB / No Custom Domain / [Resources](https://rentryresource.neocities.org/) / [Free Tier Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/neocities.md)
* ⭐ **[nekoweb](https://nekoweb.org/)** - 500MB, 5K Files / Unlimited / [Bandwidth Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/nekoweb.md)
* [Web 1.0 Hosting](https://web1.0hosting.net/) - 100MB / Unlimited
* [⁠pages.gay](https://pages.gay/) - Unspecified / Unspecified
* [⁠AppWrite](https://appwrite.io/) - 2GB Stage / 5GB / [Discord](https://discord.com/invite/appwrite)
* [BitBucket](https://support.atlassian.com/bitbucket-cloud/docs/publishing-a-website-on-bitbucket-cloud/) - 1GB (Hard Limit 4GB) / Unlimited / No Custom Domain
* [Sevalla](https://sevalla.com/static-site-hosting/) - 1GB / 100GB / No Custom Domain
* [Codeberg Pages](https://codeberg.page/) - 750MB / Unlimited / Only Open-Source Projects / [Request Storage](https://codeberg.org/Codeberg-e.V./requests)
* [Reocities](https://www.reocities.xyz/) - 1GB / Unlimited / No Custom Domain

***

# ► Dynamic DNS & Subdomains

***

* ⭐ **[deSEC](https://desec.io/)** - Free Dynamic DNS with DNSSEC
* [DuckDNS](https://www.duckdns.org/), [ClouDNS](https://www.cloudns.net/), [FreeDNS](https://freedns.afraid.org/) / [Warning](https://freedns.afraid.org/queue/explanation.php), [dynu](https://dynu.com/), [myaddr](https://myaddr.tools/), [nsupdate](https://www.nsupdate.info/) / [GitHub](https://github.com/nsupdate-info/nsupdate.info) - Dynamic DNS Providers
* [DigitalPlat](https://domain.digitalplat.org/) / [GitHub](https://github.com/DigitalPlatDev/FreeDomain), [is-a.dev](https://www.is-a.dev/), [JS.ORG](https://js.org/), [TheDev](https://upset.dev/), [GetFreeDomain](https://www.getfreedomain.name/) - Free Subdomain Services

***

# ► Cybersecurity Tools

* 🌐 **[⁠Awesome Formal Verification](https://github.com/ElNiak/awesome-formal-verification)** - Verification / Model Checking Techniques Index
* 🌐 **[⁠Cyber Threat Intelligence](https://www.shenouda.nl/threat-intelligence-platform-comparison/)** - CTI Directory & Pricing Explorer
* ⭐ **[pyWhat](https://github.com/bee-san/pyWhat)**, [horsicq](https://ntinfo.biz/) / [GitHub](https://github.com/horsicq/) or [⁠CheckFileType](https://www.checkfiletype.com/) - File Type Identification Tools
* [Nuclei](https://docs.projectdiscovery.io/opensource/nuclei/overview) / [GitHub](https://github.com/projectdiscovery/nuclei), [Synk](https://security.snyk.io/) or [NVD](https://nvd.nist.gov/) - Vulnerability Tracking / Scanning
* [Open Source Security Software](https://open-source-security-software.net/) - Cybersecurity Software
* [osquery](https://osquery.io) or [Nmap](https://nmap.org/) / [Results](https://nmap.org/ndiff/) - Security Monitors
* [Canarytokens](https://canarytokens.org/generate) - Network Breach Check
* [masscan](https://github.com/robertdavidgraham/masscan) - Port Scanner
* [Zeek](https://zeek.org/), [Kismet](https://www.kismetwireless.net/), [ntop](https://www.ntop.org/) or [Sniffnet](https://sniffnet.app/) / [GitHub](https://github.com/GyulyVGC/sniffnet) - Network Monitors
* [Crowdsec](https://crowdsec.net/) - Crowd-Sourced Intrusion Detection / Prevention / [GitHub](https://github.com/crowdsecurity/crowdsec)
* [BBRadar](https://bbradar.io/), [⁠Open Bug Bounty](https://www.openbugbounty.org/) or [BugBountyHunting](https://www.bugbountyhunting.com/) - Bug Bounty Trackers
* [YARA](https://virustotal.github.io/yara/) / [GitHub](https://github.com/virustotal/yara) or [UnpacMe](https://www.unpac.me/) - Malware Identification Tools
* [OpenSCA-CLI](https://github.com/XmirrorSecurity/OpenSCA-cli) - Composition Analysis for Third Party Components
* [Unblob](https://unblob.org/) - Extraction Suite / [GitHub](https://github.com/onekey-sec/unblob)
* [Security Onion Solutions](https://securityonionsolutions.com/), [Wazuh](https://wazuh.com/) or [Snyk](https://snyk.io/) / [GitHub](https://github.com/snyk/cli) - Site Security Monitor
* [spur.us](https://spur.us/) - Block VPNs / Proxies
* [Greenbone](https://github.com/greenbone) - Vulnerability Management
* [Grype](https://github.com/anchore/grype) - Container Images Vulnerability Scanner
* [Evervault](https://evervault.com/) - Security / Compliance Infrastructure
* [Observatory](https://developer.mozilla.org/en-US/observatory) - HTTP Header Security Test
* [UUID Tools](https://www.uuidtools.com/) / [GitHub](https://github.com/t0thkr1s/allsafe-android/) or [⁠UUID Generator](https://toolkitvault.com/uuid-generator) - UUID Generators
* [favicon-hash](https://favicon-hash.kmsec.uk/) - Favicon Hash Generator
* [Al-Khaser](https://github.com/ayoubfaouzi/al-khaser) - Anti-Malware Stress Test
* [CVE Details](https://www.cvedetails.com/) or [⁠OpenCVE](https://app.opencve.io/cve/) - CVE Details / Search
* [AllSafe](https://github.com/t0thkr1s/allsafe) - Intentionally Vulnerable Android App

***

## ▷ Cybersecurity Indexes

* 🌐 **[Awesome Cyber Security](https://github.com/fabionoth/awesome-cyber-security)** - Cybersecurity Resources
* 🌐 **[Awesome CI/CD Security](https://github.com/myugan/awesome-cicd-security)** - CI/CD Security Resources
* ↪️ **[Cybersecurity Learning](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7_cybersecurity)**
* [⁠Threat Actor](https://www.shenouda.nl/threat-actor/), [⁠Ransomware.live](https://www.ransomware.live/) or [X-Force Exchange](https://exchange.xforce.ibmcloud.com/) - Threat Actor Intelligence Platforms
* [Advisory Database](https://github.com/github/advisory-database), [⁠VEXRA](https://redteam.asia/exploit-repo/), [ThreatFox](https://threatfox.abuse.ch/), [Exploit DB](https://www.exploit-db.com/) or [Att&ck](https://attack.mitre.org/) - Cybersecurity Defense Databases
* [Bazaar](https://bazaar.abuse.ch/), [MalShare](https://malshare.com/), [URLhaus](https://urlhaus.abuse.ch/), [PulseDive](https://pulsedive.com/) or [Malpedia](https://malpedia.caad.fkie.fraunhofer.de/) - Malware Search / Indexes
* [ThreatMap](https://threatmap.checkpoint.com/), [Threat Radar](https://radar.offseq.com/) or [CyberMap](https://cybermap.kaspersky.com/) - Live Malware Distribution Maps
* [Rawsec's CyberSecurity Inventory](https://inventory.raw.pm/) - Cybersecurity Resources
* [CybersecResources](https://www.cybersources.site/) - Cybersecurity Resources / [GitHub](https://github.com/bst04/cybersources)
* [Awesome List](https://github.com/0xor0ne/awesome-list) - Cybersecurity Resources
* [Infosec Resources](https://github.com/stong/infosec-resources) or [My Infosec Awesome](https://github.com/pe3zx/my-infosec-awesome) - Infosec Resources
* [CyberSecTools](https://cybersectools.com/) - Cybersecurity Resources

***

## ▷ Pen Testing

* 🌐 **[Awesome Pen Testing](https://github.com/enaqx/awesome-pentest)** - Penetration Testing Resources
* 🌐 **[Awesome Hacking](https://github.com/Hack-with-Github/Awesome-Hacking)** - Pentesting / Security Index
* [Metasploit](https://www.metasploit.com/) / [Cheatsheet](https://www.comparitech.com/net-admin/metasploit-cheat-sheet/) - Pentesting Framework
* [Pentest Contracts](https://github.com/cure53/Contracts) - Security Contract Templates
* [OSCP-Exam-Report-Template-Markdown](https://noraj.github.io/OSCP-Exam-Report-Template-Markdown/) - Offensive Security Exam Report Markdown / [GitHub](https://github.com/noraj/OSCP-Exam-Report-Template-Markdown)
* [Kali NetHunter](https://store.nethunter.com/) or [AndroGuard](https://github.com/androguard/androguard) - Penetration Testing / Forensics Apps

***

## ▷ DNS Tools

* ↪️ **[DNS Providers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25B7_dns_providers)** - Public & Privacy-Focused Providers
* ⭐ **[mess with dns](https://messwithdns.net/)** - Experiment with DNS / [GitHub](https://github.com/jvns/mess-with-dns)
* [DNS over HTTPS](https://github.com/curl/curl/wiki/DNS-over-HTTPS) - Encrypted DNS Providers & Resources / [Public Servers](https://github.com/curl/curl/wiki/DNS-over-HTTPS#publicly-available-servers) / [iOS + macOS Configs](https://github.com/paulmillr/encrypted-dns)
* [DNSPerf](https://www.dnsperf.com/dns-providers-list/) - DNS Provider Rankings / [Speed Benchmark](https://www.dnsperf.com/dns-speed-benchmark/)
* [DNS Speed Test](https://dnsspeedtest.online/) / [GitHub](https://github.com/BrainicHQ/DoHSpeedTest) - DNS Speed Tests
* [DNS Propagation](https://dnsaudit.io/tools/dns-propagation-check) - DNS Checker
* [⁠DNS.is](https://dns.is/) - DNS Resolution Check
* [⁠DNS Coffee](https://dns.coffee/) - DNS Search History Tool
* [MXToolBox](https://mxtoolbox.com/) - MX Record Lookup Tool
* [DNSDumpster](https://dnsdumpster.com/), [DNS Watch](https://dnswatch.info), [DNSHistory](https://dnshistory.org/) or [WhatsMyDNS](https://whatsmydns.net/) - DNS Lookup / Security
* [Web Check](https://web-check.xyz/) / [GitHub](https://github.com/Lissy93/web-check) or [NSLookup](https://www.nslookup.io/) - DNS Information Tools

***

## ▷ Web Security

* ⭐ **[Cap](https://trycap.dev/)** / [GitHub](https://github.com/tiagozip/cap), [LibreCaptcha](https://github.com/librecaptcha/lc-core), [mCaptcha](https://mcaptcha.org/) / [GitHub](https://github.com/mCaptcha/mCaptcha) or [Anubis](https://anubis.techaro.lol/) / [GitHub](https://github.com/TecharoHQ/anubis) - Bot Protection / Captchas
* [⁠Iocaine](https://iocaine.madhouse-project.org/) - Anti-Web Crawler Software / [Source Code](https://git.madhouse-project.org/iocaine/iocaine)
* [⁠The Crawler Zoo](https://crawlerzoo.com/) - Web Crawler Database / Bot Blocking Guides
* [SupaBase](https://supabase.com/), [PocketBase](https://pocketbase.io/) / [GitHub](https://github.com/pocketbase/pocketbase), [⁠Convex](https://www.convex.dev/) / [GitHub](https://github.com/convex) or [Neon](https://neon.com/) / [GitHub](https://github.com/neondatabase/neon) - Open-Source Backend Platforms
* [WebAuthn](https://webauthn.guide/) - Web Authentication API - [Demo](https://webauthn.io/)
* [Hydra](https://github.com/ory/hydra) - OAuth 2.0 Server / OpenID Connect Provider
* [SuperTokens](https://supertokens.com/), [⁠Better Auth](https://better-auth.com/) or [Lucia](https://lucia-auth.com/) - User Authentication
* [⁠crt.name](https://crt.name/) - Passive Subdomain Index / Search
* [SubDomainizer](https://github.com/nsonaniya2010/SubDomainizer), [Google Console](https://search.google.com/search-console/), [MerkleMap](https://www.merklemap.com/) or [SD Finder](https://subdomainfinder.c99.nl/) - Find Hidden Subdomains
* [⁠GNUnet](https://www.gnunet.org/en/) - Decentralized P2P Framework
* [ZAP](https://www.zaproxy.org/) - Web App Security Testing
* [IP Intelligence](https://getipintel.net/), [AbuseIPDB](https://www.abuseipdb.com/), [Scamalytics](https://scamalytics.com/) or [Proxy Check](https://proxycheck.io/) - Proxy / VPN / Bad IP Detection
* [Fail2Ban](https://github.com/fail2ban/fail2ban) - Protect Servers from Brute Force Attacks
* [Tempesta FW](https://tempesta-tech.com/) - DDoS / Web Attack Protection
* [IPv6 Leak Test](https://ip6.nl/) or [Test-IPv6](https://test-ipv6.com/) - IPv6 Test
* [How To Turn off IPv6](https://www.itechguides.com/disable-ipv6-windows-10/) - Prevent IPv6 Leaks

***

## ▷ Encryption / Certificates

* ⭐ **[Awesome Cryptography](https://github.com/sobolevn/awesome-cryptography)** - Cryptography Resources
* [mitmproxy](https://mitmproxy.org/) - Analyze and modify HTTPS traffic / [OpenAPI Converter](https://github.com/alufers/mitmproxy2swagger) / [GitHub](https://github.com/mitmproxy/mitmproxy)
* [HTTPToolkit](https://httptoolkit.com/) / [Pro](https://github.com/xenos1337/httptoolkit-patcher) - Intercept, Debug, and Mock HTTP(S)
* [TLSRef](https://configurator.tlsref.org/) - SSL Configuration Generator / [GitHub](https://github.com/tlsref)
* [SSLLabs](https://www.ssllabs.com/) - SSL Testing
* [Hitch](https://www.varnish-software.com/community/hitch) - SSL / TLS Proxy / [GitHub](https://github.com/varnish/hitch)
* [Let's Encrypt](https://letsencrypt.org/) or [ZeroSSL](https://zerossl.com/) - Free TLS Certificates
* [SSL for Free](https://www.sslforfree.com/) - Free SSL Certificates
* [CertAlert](https://certalert.net/) - TLS/SSL Certificate Expiration Alerts
* [acme.sh](https://github.com/acmesh-official/acme.sh) or [Certbot](https://certbot.eff.org/) - Automatically Configure / Renew Certificates
* [mkcert](https://github.com/FiloSottile/mkcert) - Locally Trusted Development Certificates
* [SSLMate CAA](https://sslmate.com/caa/) - CAA Record Helper
* [minisign](https://jedisct1.github.io/minisign/) - Sign Files / Verify Digital Signatures / [GitHub](https://github.com/jedisct1/minisign)

***

## ▷ Reverse Engineering

* 🌐 **[⁠Reverse Engineering Notes](https://gist.github.com/0xdevalias/d8b743efb82c0e9406fc69da0d6c6581)** or [ReversingBits](https://mohitmishra786.github.io/reversingBits/) / [GitHub](https://github.com/mohitmishra786/reversingBits) - Reverse Engineering Resources
* 🌐 **[Awesome Android Reverse Engineering](https://github.com/user1342/Awesome-Android-Reverse-Engineering)** - Android Reverse Engineering Resources
* 🌐 **[Awesome Malware Analysis](https://github.com/rshipp/awesome-malware-analysis)** - Malware Analysis Resources
* ⭐ **[IDA Pro](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent/)** (search) - Software Disassembler / Decompiler / [Plugins](https://plugins.hex-rays.com/)
* ⭐ **[GHIDRA](https://github.com/NationalSecurityAgency/ghidra)** - Reverse Engineering Framework / [Plugins](https://github.com/AllsafeCyberSecurity/awesome-ghidra)
* ⭐ **[Binary Ninja](https://binary.ninja/free/)** - Decompiler / Disassembler / Debugger / [Plugins](https://github.com/vector35/community-plugins)
* ⭐ **[Frida](https://frida.re/)** - Dynamic Instrumentation Toolkit / [GitHub](https://github.com/frida/frida)
* ⭐ **[x64dbg](https://x64dbg.com/)** - Debugger for Reverse Engineering / [Plugins](https://github.com/x64dbg/x64dbg/wiki/Plugins)
* [⁠Reverse Engineering](https://discord.gg/reverse-engineering-391398885819547652) (discord) - Reverse Engineering Community
* [⁠LemmeDebug](https://greasyfork.org/en/scripts/537775) - Disable Anti-Devtools for Reverse Engineering / Debugging
* [REA](https://rea.tools/) - Reverse Engineering Tools for AI Agents / [GitHub](https://github.com/morluto/rea)
* [Radare](https://www.radare.org/n/) - Free Reversing Toolkit / [Discord](https://discord.gg/YBey7CR9jf) / [GitHub](https://github.com/radareorg/radare2)
* [Rizin](https://rizin.re/) or [Cutter](https://cutter.re/) - Reverse Engineering Framework
* [Flare VM](https://github.com/mandiant/flare-vm) - Reverse Engineering Environment Setup Script
* [REMnux](https://remnux.org/) - Reverse Engineering / Malware Analysis
* [dnSpyEx](https://github.com/dnSpyEx/dnSpy) - .NET Debugger and Assembly Editor
* [Gaultier Blog](https://gaultier.github.io/blog/x11_x64.html) - Learn x86-64 Assembly
* [ROP Emporium](https://ropemporium.com/) - Learn Return-Oriented Programming
* [APK Editor Studio](https://qwertycube.com/apk-editor-studio/) / [GitHub](https://github.com/kefir500/apk-editor-studio) or [APKTool](https://apktool.org/) / [GitHub](https://github.com/iBotPeaches/Apktool) - APK Reverse Engineering
* [MSTG](https://mas.owasp.org/) or [DVIA-v2](https://github.com/prateek147/DVIA-v2) - App Security Testing / Reverse Engineering
* [Malimite](https://github.com/LaurieWired/Malimite) - iOS / macOS Decompiler
* [challenges.re](https://challenges.re/) - Reverse Engineer Code