***
***
**[◄◄ Back to Wiki Index](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/index)**
***
***

# ► Download Games

* **Note** - Many popular file hosts have download buttons that redirect to fake malicious download pages. Using the full version of [uBlock Origin](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_adblocking) can prevent this but it doesn't always work. Check [this guide](https://cs.rin.ru/forum/viewtopic.php?f=14&t=159345) to learn what fake malicious download pages look like and how to avoid them. A general rule is to avoid download pages that open in a new tab or redirected page, real downloads happen within the same page as the file host.

***

* 🌐 **[r/PiratedGames Mega](https://rentry.org/pgames)** / [Discord](https://discord.gg/dZWwhUy), **[CS.RIN Mega](https://cs.rin.ru/forum/viewtopic.php?f=10&t=95461)** or **[privateersclub](https://privateers.wiki/)** / [Discord](https://discord.gg/jz8dUnnD6Q) - Piracy Indexes
* 🌐 **[Wotaku](https://wotaku.wiki/games)** / [Discord](https://discord.gg/vShRGx8ZBC) or **[EverythingMoe](https://everythingmoe.com/section/game)** / [Discord](https://discord.gg/GuueaDgKdS) - Otaku Games Indexes
* ↪️ **[Game Download Clients](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools#wiki_.25B7_game_launchers)** - Launchers with Built-In Downloading & Torrenting
* ⭐ **[CS.RIN.RU](https://cs.rin.ru/forum)** - Download / Sign-Up / PW: `cs.rin.ru / csrin.org` / [.onion](http://csrinrutkb3tshptdctl5lyei4et35itl22qvk5ktdcat6aeavy6nhid.onion/forum)
* ⭐ **CS.RIN Tools** - [Status](https://csrinstaff.writeas.com/) / [Enhancements](https://github.com/SubZeroPL/cs-rin-ru-enhanced-mod) / [Steam Buttons](https://github.com/Altansar69/CS.RIN.RU-Enhanced-external) / [Steam Hover](https://greasyfork.org/scripts/580613) / [Search Guide](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/csrin-search.md)
* ⭐ **[AnkerGames](https://ankergames.net/)** - Download / Torrent (Sign-Up, 7 Monthly) / Pre-Installed / [Fluxer](https://fluxer.gg/1Tt9Lw5B) / [Subreddit](https://www.reddit.com/r/Anker_Games_/) / [Discord](https://discord.gg/nnMnGzDbwg)
* ⭐ **[SteamRIP](https://steamrip.com/)** - Download / Pre-Installed / PW: `steamrip.com` / [Subreddit](https://www.reddit.com/r/SteamRip/) / [Discord](https://discord.gg/NBVFJsmy9y)
* ⭐ **[AstralGames](https://astralgames.net/)** - Download / Pre-Installed / Achievements / [Subreddit](https://www.reddit.com/r/AstralGames/) / [Discord](https://discord.gg/snnf8RH8Fn)
* ⭐ **[GameBounty](https://gamebounty.world/)** - Download / Pre-installed / Achievements / [Discord](https://discord.gg/dmjUJ4xCEV)
* ⭐ **[⁠Kryoto](https://kryo.to/)** - Download / Pre-Installed / [Launcher](https://kryo.to/desktop) / [Subreddit](https://www.reddit.com/r/kryoto/) / [Discord](https://discord.com/invite/Q2S8hRzrep)
* ⭐ **[SteamUnderground](https://steamunderground.net/)** - Download / Pre-Installed / [Discord](https://discord.gg/hxdv7eJ5Yt)
* ⭐ **[⁠GOG Revived](https://gog-rev.com/)** - Download / Torrent / GOG Games Only / [Discord](https://discord.gg/pH6avrdHHC)
* ⭐ **[Online Fix](https://online-fix.me/)** - Download / Torrent / Multiplayer / PW: `online-fix.me` / Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators) / [Telegram](https://t.me/onlinefix) / [Discord](https://discord.gg/yExgFYncMD)
* ⭐ **[ZeiGames](https://zeigames.com/)** - Download / Pre-Installed / Multiplayer / [Discord](https://discord.gg/6KWStFYSTj)
* ⭐ **[Ova Games](https://www.ovagames.com/)** - Download / PW: `www.ovagames.com` / [Requires Redirect Bypass](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools#wiki_.25B7_redirect_bypass)
* ⭐ **[Torrminatorr](https://forum.torrminatorr.com/)** - Download / Forum / Requires Sign-Up
* ⭐ **[⁠HizSearch](https://hizsearch.pages.dev/)** / [Steam Button](https://github.com/hiz0147/HizSteamButton) / [Discord](https://discord.gg/QFnktdhedT), **[Virgil Game Search](https://virgil.samidy.com/?engine=games)**, [2](https://virgil-search.pages.dev/?engine=games) / [GitHub](https://github.com/SamidyFR/Virgil), [Game Download CSE](https://cse.google.com/cse?cx=006516753008110874046:cbjowp5sdqg), [Game Torrent CSE](https://cse.google.com/cse?cx=006516753008110874046:pobnsujblyx) or [r/PiratedGames CSE](https://cse.google.com/cse?cx=20c2a3e5f702049aa) - Multi-Site Search Engines
* [g4u](https://g4u.to/) - Download / PW: `404`
* [scene cat](https://rentry.co/FMHYB64#scenec) or [warez-chan](https://rentry.co/FMHYB64#warez-chan) - Scene Release Downloads
* [GLoad](https://gload.to/) - Download / Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators)
* [appnetica](https://appnetica.com/) - Download / Torrent / Pre-Installed / GOG Games / Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators) / [Telegram](https://t.me/+MoOJzMf3MJgyMzZi)
* [⁠Cracked-Games](https://cracked-games.org/) - Download / Use Adblock / [Discord](https://discord.com/invite/hG4TEBTBjw)
* [ElEnemigos](https://elenemigos.com/) - Download / PW: `elenemigos.com` / Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators) / [Telegram](https://t.me/ElEnemigos) / [Discord](https://discord.com/invite/juegos)
* [⁠Arkona](https://arkona.dev/) - Download
* [⁠IceQueens Portables](https://game-box.win/) - Torrent / Download / Portables
* [SteamOra](https://steamora.net/) - Download / Pre-Installed / [Discord](https://discord.gg/2bRYgFS8Rj)
* [TriahGames](https://triahgames.com/) - Download / PW: `www.triahgames.com` / [Discord](https://discord.gg/vRxJNNcJNh)
* [GamePCFull](https://gamepcfull.com/) - Download
* [SteamGG](https://steamgg.net/) - Download / Pre-Installed / [Subreddit](https://www.reddit.com/r/NotSteamGG/) / [Discord](https://discord.com/invite/Rw6AT3hZZE)
* [⁠The Dark Games](https://the-dark-games.com/) - Download / Pre-Installed / [Subreddit](https://www.reddit.com/r/WorldofPCGamess/)
* [⁠GOG Archive](https://gog.squid.wtf/) or [FreeGOGPCGames](https://freegogpcgames.com/) / [Hash Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/freegogpcgames-note.md) - Torrent / GOG Games Archives
* [⁠The Vulpes Archives](https://rentry.co/the-vulpes-archives) - Download
* [RuTracker Uploaders](https://rentry.co/rutrackertrustedgameuploaders) - ⁠Trusted RuTracker Game Uploaders
* [IRC Games](https://redd.it/x804wg) - Download Games via IRC
* [FreeToGame](https://www.freetogame.com/games) or [Acid Play](https://acid-play.com/) - F2P Games / [Trackers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25BA_free_stuff)
* [ROM Heaven CSF](https://rentry.co/FMHYB64#csf) - Clean Steam Files (or just use CS.RIN for Clean Files)

***

## ▷ Game Repacks

* **Note** - Repacks are compressed versions of games that exchange smaller downloads for longer installation times. They allow you to unselect unnecessary / optional bonus content, and occasionally have extras not included in other releases. Good if you have low bandwidth or data limits.

***

* ⭐ **[FitGirl Repacks](https://fitgirl-repacks.site/)** - Download / Torrent / ROM Repacks / [Unofficial Launcher](https://github.com/CarrotRub/Fit-Launcher/) / [Extractor / Unblocker](https://fitgirl-download-link-extractor.vercel.app/)
* ⭐ **[KaOsKrew](https://kaoskrew.org/)** - Download / [Redirect Bypass](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools/#wiki_.25B7_redirect_bypass) / [Discord](https://discord.com/invite/WF2pqPTFBs)
* [DODI Repacks](https://rentry.co/FMHYB64#dodi) - Torrent / [Redirect Bypass](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools/#wiki_.25B7_redirect_bypass) / [Discord](https://discord.gg/D9WU7C9FSE) / **[Site Warning](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/dodi-critical.md)**
* [Elamigos](https://elamigos.site/) - Download
* [⁠Klisza](https://klisza.uk/) - Download / ROM Repacks
* [Xatab Repacks](https://byxatab.com/) - Torrent / Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators)
* [Gnarly Repacks](https://rentry.co/FMHYB64#gnarly) - Download / PW: `gnarly`
* [M4CKD0GE Repacks](https://m4ckd0ge-repacks.site/) - Download / [Discord](https://discord.gg/693hNBdymb)
* [VHSTaPE](https://vhstaperepacks.com/) or [⁠Stevv Game](https://www.stevvgame.com/) - Download / [Discord](https://discord.gg/snbpB6pCK9)
* [Spinneret Repacks](https://spinneretrepacks.qzz.io/) - Download ⁠/ [Discord](https://discord.gg/bkCzeZWrDt)
* [ScOOt3r Repacks](https://discord.gg/xe3Fys8Upy) - Download / Torrent / [Discord](https://discord.com/invite/WF2pqPTFBs)
* [PM2G Repacks](https://rentry.co/FMHYB64#pm2g) - Download / PW: `pm2g` / [Discord](https://discord.gg/38FRNdYAEM)
* [⁠Vanya Games](https://vanya-games.site/) - Download
* [Dyren Repacks](https://rentry.co/FMHYB64#dyren) - Download / Torrent / [Discord](https://discord.com/invite/kw36u9cxd3)


***

## ▷ [Linux Games](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_linux_gaming)

***

## ▷ [Mac Games](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_mac_gaming)

***

# ► Special Interest

* 🌐 **[TheGamingEmporium](https://thegamingemporium.com/categories/open-source/)** - Open-Source, Decomps, Ports, Translations & more
* 🌐 **[OSGL](https://trilarion.github.io/opensourcegames/)**, [Open Source Games](https://github.com/bobeff/open-source-games), [Awesome Open Source Games](https://github.com/michelpereira/awesome-open-source-games) or [LibreGameWiki](https://libregamewiki.org/List_of_games) - Open-Source Games
* 🌐 **[Awesome Terminal Games](https://ligurio.github.io/awesome-ttygames/)** - ASCII Terminal Games
* ↪️ **[Genre Specific Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools#wiki_.25BA_genre_specific)** / **[Game Specific](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools#wiki_.25BA_game_specific)**
* [Necromanthus](https://necromanthus.com/) - 3D Shockwave Games
* [LemmaSoft](https://lemmasoft.renai.us/) - Visual Novel Games / [Discord](https://discord.gg/6ckxWYm)
* [⁠Adventure Game Studio](https://www.adventuregamestudio.co.uk/#play) - Point-And-Click Games / [Discord](https://discord.gg/BSvN5ZF) / [GitHub](https://github.com/adventuregamestudio/ags)
* [vgperson](https://vgperson.com/games/) - Simple Japanese Games
* [Visual Pinball](https://github.com/vpinball/vpinball) - Pinball Table Editor / Simulator / [Tables](https://www.vpforums.org/)
* [DoujinStyle](https://doujinstyle.com) - Doujin Games / [Discord](https://discord.com/invite/z2QDFdA)
* [MoriyaShrine](https://moriyashrine.org/) - Touhou Games
* [Kahvibreak](https://bluemaxima.org/kahvibreak/) - Java 2 Micro (J2ME) Games / [Discord](https://discord.gg/8TgbHAG)
* [Cemetech](https://cemetech.net/) - Calculator Games
* [UnorthodoxFun](https://github.com/rarelygoeshere/UnorthodoxFun) - Games on Unorthodox Platforms
* [⁠Fangame Archive](https://archive.dappermink.me/) / [Discord](https://discord.com/invite/HSeycPx) or [Delicious Fruit](https://delicious-fruit.com/) - I Wanna Be the Guy Fan Game Archives
* [GamesOnPDF](https://github.com/rarelygoeshere/GamesOnPDF) - PDF Games
* [Flashtro](https://flashtro.com/) - Cracker Intros

***

## ▷ Virtual Reality

* 🌐 **[r/QuestPiracy Mega](https://qpmegathread.top/)** - Quest VR Resources
* ↪️ **[PCVR Games](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/games#wiki_.25BA_download_games)**
* ⭐ **[ARMGDDN Browser](https://cs.rin.ru/forum/viewtopic.php?f=14&t=140593)** - PCVR Games / Avoid Software / [Telegram](https://t.me/ARMGDDNGames) / [Discord](https://discord.gg/abeChzCy8X)
* [Phoenix Place](https://phoenixplace.xyz/) - VR Games / Requires Sign-Up / [Discord](https://discord.gg/wfJs3eJvHa)
* [⁠The Gear VR Vault](https://vault.gearvr.net/) - VR Abandonware Games / Apps
* [⁠heyVR.io](https://heyvr.io/) - Browser VR Games / [Discord](https://discord.gg/tjbmKKH)
* [SideQuest](https://sidequestvr.com/) - VR Sideloading Platform / [Subreddit](https://www.reddit.com/r/sidequest)
* [VRCArena](https://www.vrcarena.com/) - Resources for Social VR Games / [Discord](https://discord.gg/UVs9V58)
* [Rec Room Revivals](https://rentry.co/FMHYB64#rec-room-revival) - Rec Room Revival Servers / [Image / Profile Archive](https://recroom.network/)
* [UEVR](https://uevr.io/) - Convert Unreal Engine Games to VR
* [ALVR](https://github.com/alvr-org/ALVR) - Stream VR Games from PC to Headset
* [SlimeVR](https://docs.slimevr.dev/) - DIY VR Full-Body Tracking System / Guides / [Discord](https://discord.gg/SlimeVR) / [GitHub](https://github.com/SlimeVR)

***

## ▷ Indie Games

* 🌐 **[Indie Rentry](https://rentry.org/hhtxv7ud)** - Indie Games List
* ↪️ **[Indie Browser Games](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/games#wiki_.25B7_indie_browser_games)**
* ⭐ **[itch.io](https://itch.io/games/new-and-popular/featured/free)** - Indie Games / [Discord](https://discord.gg/qDaYeXPsRK)
* ⭐ **itch.io Tools** - [Downloader](https://github.com/Emersont1/itchio) / [Desktop](https://github.com/itchio/itch) / [Mobile](https://sr.ht/~gardenapple/mitch/) / [Auto-Claim](https://github.com/Smart123s/ItchClaim)
* [Killed By A Pixel](https://frankforce.com/all-games/) - Indie Games
* [Gamdie](https://gamdie.com/) - Indie Games / [Discord](https://discord.gg/cDKH3R4nR2)
* [DigiPen](https://games.digipen.edu/) - Indie Games
* [Game Jolt](https://gamejolt.com/games?price=free) - Indie Games
* [⁠WFGames](https://wfgames.net/) - Weird itch.io Games

***

## ▷ Abandonware / Retro

* ⭐ **[AbandonwareGames](https://abandonwaregames.net/)** - Abandonware
* ⭐ **[Retro eXo](https://www.retro-exo.com/)** - Abandonware / Retro PC Games / Torrents
* ⭐ **[Zombs-Lair](https://www.zombs-lair.com/)** - Abandonware / [Discord](https://discord.com/invite/JdyPtRv)
* ⭐ **[VETUSWARE](https://vetusware.com/category/Games/)** - Abandonware
* ⭐ **[CollectionChamber](https://collectionchamber.blogspot.com/)** - Abandonware
* ⭐ **[My Abandonware](https://www.myabandonware.com/)** - Abandonware
* ⭐ **[LegendsWorld](https://www.legendsworld.net/)** - Retro PC Adventures
* ⭐ **[RAZE](https://github.com/ZDoom/Raze)** / [Discord](https://discord.com/invite/zdoom-edge-raze-official-268086704961748992) or [BuildGDX](https://m210.duke4.net/) / [Discord](https://discord.gg/zZw2eq3n7G) - Oldschool Shooter Engines
* [C.A.G.E](https://discord.gg/cage) - Abandonware / Requires Discord
* [Rohan Kar](https://rentry.co/FMHYB64#rohan-kar) - Abandonware / Applies Mods + Fixes
* [File Hunter](https://www.file-hunter.com/) - MSX Games
* [⁠⁠Abandonware France](https://www.abandonware-france.org/index.php) - Abandonware Games / Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators)
* [Old-Games](https://www.old-games.ru/) - Abandonware
* [Japanese PC Compendium](https://japanesepccompendium.blogspot.com/) - Retro Japanese PC Games
* [OldGamesDownload](https://oldgamesdownload.com/) - Abandonware
* [ClassicPCGames](https://archive.org/details/classicpcgames) - Abandonware
* [Old-Games.com](https://www.old-games.com/) - Abandonware / 2 Daily Downloads
* [Win7Games](https://win7games.com/) - Classic Windows Games
* [The U-M Software Archives](https://websites.umich.edu/~archive/) - Retro PC / Mac Games
* [DOS HAVEN](https://www.doshaven.eu/), [FreeDOSGames](https://www.freedosgames.de/) or [Abandonware DOS](https://www.abandonwaredos.com/) - DOS Games
* [⁠Commodore Software](https://commodore.software/search/) - Commodore 64 / Commodore 128 / VIC-20 Games
* [MSX Resource Center](https://www.msx.org/) - MSX Games
* [Generation MSX](https://www.generation-msx.nl/) - MSX Games
* [SpectrumComputing](https://spectrumcomputing.co.uk/) - Sinclair ZX Spectrum Games
* [whdload](https://www.whdload.de/) - Amiga Games6

***

## ▷ Decomps / Ports

* 🌐 **[Game Decompilations](https://decomps.fun/)**, [2](https://decomps.samidy.com/), [3](https://rentry.co/Decomps) - Game Decompilations / Ports / [GitHub](https://github.com/SamidyFR/Game-Decompilations)
* 🌐 **[RetroReversing](https://www.retroreversing.com/source-code/decompiled-retail-console-games)** - Game Decompilations / Ports
* 🌐 **[Awesome Game Decompilations](https://github.com/CharlotteCross1998/awesome-game-decompilations)** - Game Decompilations / Ports
* 🌐 **[Game Decomps That Aren't Vibe Coded](https://backloggd.com/u/WumpaGem/list/game-decompsrecomps-that-arent-vibe-coded/)** / [2](https://docs.google.com/document/d/17BgdKswrijiXCysCcE6Jk8fLoV8JuIzjLRxV2-MFXeo/) - Game Decompilations / Ports
* 🌐 **[Awesome Unofficial PC Ports](https://github.com/Sebastrion/awesome-unofficial-pc-ports)** - Game Decompilations / Ports
* 🌐 **[Galaxy of Games](https://galaxyofgames.neocities.org/)** - Game Decompilations / Ports
* 🌐 **[PCGamingWiki Ports](https://www.pcgamingwiki.com/wiki/List_of_unofficial_ports)** - Game Decompilations / Ports
* 🌐 **[⁠Awesome Decomp Games](https://github.com/SubmitGame/awesome-decomp-games)** - Game Decompilations / Ports
* 🌐 **[⁠PortsDR](https://portsdr.com/)** - Game Decompilations / Ports
* 🌐 **[TheGamingEmporium](https://thegamingemporium.com/categories/decompilations-recompilations/)** - Game Decompilations / Ports
* 🌐 **[GameTechWiki Ports](https://emulation.gametechwiki.com/index.php/Game_engine_recreations_and_source_ports)** - Game Decompilations / Ports
* 🌐 **[⁠recomp.fyi](https://recomp.fyi/)** - Recomp Status Tracker
* [Quiver Launcher](https://quiverlauncher.com/) / [GitHub](https://github.com/tgeorgiadis/quiver-launcher) or [GithubLauncher](https://github.com/SirDiabo/GithubLauncher) - Launch / Manage Recompiled Games ⁠
* [IOQuake3](https://github.com/ioquake/ioq3) - Quake 3 Source Port / [Discord](https://discord.gg/YY9UvMHGYb)
* [YQuake2](https://www.yamagi.org/quake2/) - Quake 2 Source Port / [GitHub](https://github.com/yquake2/yquake2)
* [Dusklight](https://twilitrealm.dev/) - Twilight Princess Port / [Discord](https://discord.com/invite/6NpMhefCK9) / [GitHub](https://github.com/TwilitRealm/dusklight)
* [Ship of Harkinian](https://www.shipofharkinian.com/) - Ocarina of Time Port / [Discord](https://discord.com/invite/harbourmasters) / [GitHub](https://github.com/HarbourMasters/Shipwright)
* [Zelda 64: Recompiled](https://github.com/Zelda64Recomp/Zelda64Recomp) / [Discord](https://discord.gg/AWZThJ4dPf) or [⁠2Ship2Harkinian](https://github.com/2ship2harkinian/2ship2harkinian) / [Discord](https://discord.com/invite/sxrPyuh697) - Majora's Mask Ports
* [Wiicompiled](https://github.com/patchzyy/wiicompiled) - Mario Kart Wii Recompilation w/ Unlocked Framerate / Can Be Installed via Wheel Wizard
* [Beyond All Reason](https://www.beyondallreason.info/) - Open-Source Total Annihilation / Supreme Commander / [Discord](https://discord.gg/beyond-all-reason) / [GitHub](https://github.com/beyond-all-reason)
* [⁠skate: recompiled](https://github.com/mchughalex/skate3recomp) - Skate 3 Xbox 360 Recompilation
* [Unleashed Recompiled](https://github.com/hedge-dev/UnleashedRecomp) - Sonic Unleashed Xbox 360 Recompilation
* [DFWorkshop](https://www.dfworkshop.net/) - Daggerfall Unity Engine Port
* [EDuke32](https://www.eduke32.com/) - Duke Nukem 3D Source Port / [Discord](https://discord.gg/ks5bHrH)
* [NBlood](https://github.com/NBlood/NBlood) - Reverse-Engineered Duke Nukem Ports
* [ECWolf](https://maniacsvault.net/ecwolf/) - Wolfenstein 3D, Spear of Destiny & Super 3D Noah's Ark Port
* [⁠Cut the Rope Home](https://ctrhome.github.io/) - Cut the Rope Game + Mod Archive
* [SRB2Kart](https://mb.srb2.org/threads/srb2kart.25868/) / [GitHub](https://github.com/STJr/Kart-Public) or [RingRacers](https://github.com/KartKrewDev/RingRacers) - Open-Source Sonic Kart Games
* [⁠P.T. PC](https://github.com/LoreanXavier/pt-pc/) - ⁠P.T. PC Port
* [Arx Libertatis](https://arx-libertatis.org/) - Arx Fatalis PC Port
* [Pixel Gun World](https://pgun.rilisoft.info/) / [Discord](https://discord.com/invite/pHteGmZzbU), [Pixel Gun Mayhem](https://pixelgunmayhem.net/) / [Discord](https://discord.gg/edfRwZrJFD) or [Pixel Gun X](https://discord.com/invite/8796Fs9tZm) - Pixel Gun 3D Revivals / PC Ports
* [Infinity Blade](https://www.reddit.com/r/infinityblade) - Infinity Blade Trilogy Ports / [Discord](https://discord.gg/GfX3pmC)
* [N64Recomp](https://github.com/N64Recomp/N64Recomp), [XenonRecomp](https://github.com/hedge-dev/XenonRecomp), [GB-Recompiled](https://github.com/arcanite24/gb-recompiled), [⁠RecompOne](https://github.com/BlackLabelHQ/RecompOne), [AnyPS5](https://github.com/boykopovar/AnyPS5) or [PS2Recomp](https://github.com/ran-j/PS2Recomp) - Static Recompilers / Native PC Porting Tools
* [⁠V-Alpha](https://discord.com/invite/dqs3VPxbC8) / [Telegram](https://t.me/VAlpha_Official) or [NAPL](https://rentry.co/FMHYB64#napl) - Mobile PC Ports
* [Visual Novels Android](https://t.me/visual_novels_android_eng) - Android Visual Novel Ports
* [⁠Flying With Gauss](https://discord.gg/CqgMJC7zsx) - GoldSrc Game Ports for Android + Other Platforms

***

## ▷ Remakes / Recreations

* 🌐 **[Awesome Game Remakes](https://github.com/radek-sprta/awesome-game-remakes)** or [Game Clones](https://osgameclones.com/) - Open-Source Remakes
* ⭐ **[OpenMW](https://openmw.org/)** - Open-Source Morrowind Re-implementation / [Multiplayer](https://github.com/TES3MP/TES3MP) / [GitHub](https://github.com/OpenMW/openmw)
* ⭐ **[OpenRCT2](https://openrct2.io/)** - Open-Source RollerCoaster Tycoon 2 / [Plugins](https://openrct2plugins.org/) / [Subreddit](https://www.reddit.com/r/openrct2/) / [Discord](https://discord.gg/ZXZd8D8) / [GitHub](https://github.com/OpenRCT2/OpenRCT2)
* ⭐ **[OpenBOR](https://github.com/DCurrent/openbor)** - 2D Side Scrolling / Beat 'Em Up Engine / [Wiki / Forum](https://www.chronocrash.com/) / [Resources](https://www.chronocrash.com/forum/resources/categories/openbor.2/)
* [Locomalito](https://locomalito.com/) or [RetroSpec](https://retrospec.sgn.net/) - Classic Game Remakes
* [Mugen](https://emulation.gametechwiki.com/index.php/Mugen) / [Resources](https://mugenguild.com/), [2](https://mugenfreeforall.com/), [3](https://www.andersonkenya1.net/), [4](https://juegosdemugen.com/en/) or [Ikemen GO](https://ikemen-engine.github.io/) / [Guides](https://ikemengo.com/) / [Discord](https://discord.com/invite/QWxxwjE) / [GitHub](https://github.com/ikemen-engine/Ikemen-GO) - 2D Fighting Game Engines / [Community + Assets](https://mugen.doomjoshuaboy.com/) / [Select-Screen Editor](https://vselect.neocities.org/)
* [⁠ZVitor](https://www.zvitor.com/home.html) - OpenBOR / MUGEN Fighting Game Index
* [Super Smash Flash](https://www.supersmashflash.com/) / [Discord](https://discord.com/invite/mcleodgaming) or [Smash Crusade](https://smash-crusade.itch.io/crusade) / [Forum](https://projectcrusade.forumotion.com/) / [Discord](https://discord.com/invite/9WBn6u65Fg) - Flash Super Smash Bros.
* [Luanti](https://www.luanti.org/) / [Discord](https://discord.gg/minetest) / [GitHub](https://github.com/luanti-org), [Classicube](https://www.classicube.net/) / [Discord](https://discord.com/invite/DvYYyRw) / [GitHub](https://github.com/UnknownShadow200/ClassiCube) or [Cubyz](https://pixelguys.github.io/Cubyz-Website/) - Open-Source Minecraft Clones / Alternatives
* [Chrono Divide](https://chronodivide.com/) / [Discord](https://discord.gg/uavJ34JTWY) / [GitHub](https://github.com/chronodivide) or [OpenRA](https://openra.net/) / [Discord](https://discord.com/invite/m5dVWH4aQE) / [GitHub](https://github.com/OpenRA/OpenRA) - Command & Conquer Recreations
* [The Dark Mod](https://www.thedarkmod.com/) - Modernized Thief Recreation / [Community Missions](https://www.thedarkmod.com/missions/)
* [Xonotic](https://xonotic.org/) - Open-Source Modified Quake Engine FPS / [GitLab](https://gitlab.com/xonotic/xonotic/)
* [Silent Hill 2: Enhanced Edition](https://enhanced.townofsilenthill.com/SH2/) - Silent Hill 2 Mod Project
* [OpenTTD](https://www.openttd.org/) - Open-Source Transport Tycoon / [Subreddit](https://www.reddit.com/r/openttd/) / [Discord](https://discord.gg/openttd) / [GitHub](https://github.com/OpenTTD/OpenTTD)
* [⁠CorsixTH](https://corsixth.com/) - Theme Hospital Re-Implementation
* [⁠DevilutionX](https://devilutionx.com/) - Open-Source Modified Diablo 1 / [GitHub](https://github.com/diasurgical/devilutionx)
* [Team Forever](https://teamforeveronline.wixsite.com/home) - Sonic 1 & 2 Enhanced / [S1F Mods](https://gamebanana.com/mods/games/10601) / [S2A Mods](https://gamebanana.com/mods/games/15019) / [YouTube](https://www.youtube.com/@teamforeverdev) / [BlueSky](https://bsky.app/profile/teamforever.bsky.social)
* [Sonic 3 A.I.R.](https://sonic3air.org/) - Sonic 3 & Knuckles Enhanced / [Mods (Official)](https://sonic3air.boards.net/board/6/mod-releases), [Alt](https://gamebanana.com/mods/games/6878) / [Discord](https://dc.railgun.works/s3air) / [GitHub](https://github.com/Eukaryot/sonic3air)
* [SRB2](https://www.srb2.org/) - Open-Source Sonic Fan Game / [Addons](https://mb.srb2.org/addons/) / [Discord](https://discord.com/invite/b3BGb8A) / [GitLab](https://git.do.srb2.org/STJr/SRB2)
* [Streets of Rage Remake](https://sorr.forumotion.net/t838-new-streets-of-rage-remake-v5-2-download-and-info) - Streets of Rage Remake
* [OpenSA](https://github.com/Dzierzan/OpenSA) - Swarm Assault Recreation / [Requires OpenRA](https://www.moddb.com/mods/opensa) / [Non OpenRA Version](https://dzierzan.itch.io/opensa)
* [doukutsu-rs](https://github.com/doukutsu-rs/doukutsu-rs) - Open-Source Cave Story Remake
* [Mars 3D](https://mars3d-game.wixsite.com/index) - Mars 3D Translation & Remake
* [Unciv](https://github.com/yairm210/Unciv) - Civilization V Remake / [Discord](https://discord.gg/bjrB4Xw)
* [FreeCiv](https://www.freeciv.org/) - Civilization Remake / [Web Version](https://freecivweb.com/) / [GitHub](https://github.com/freeciv)
* [⁠Widelands](https://www.widelands.org/) - Open-Source The Settlers II Successor / [GitHub](https://github.com/widelands/widelands)
* [CannonBall](https://github.com/djyt/cannonball) - OutRun Remake
* [KeeperFX](https://keeperfx.net/) - Fan-Made Dungeon Keeper Remake / [Discord](https://discord.gg/hE4p7vy2Hb) / [GitHub](https://github.com/dkfans/keeperfx)
* [Forge](https://card-forge.github.io/forge/) - Magic: The Gathering Fangame / [GitHub](https://github.com/Card-Forge/forge)
* [EDOPro](https://projectignis.github.io/) - Yu-Gi-Oh! TCG Fangame / [Discord](https://discord.gg/ygopro-percy) / [GitHub](https://github.com/ProjectIgnis)
* [⁠Hyper Dragon Ball Z](https://discord.gg/W85hmYcJB9) - Fan-Made Dragon Ball Z Inspired Fighting Game / Mugen + Ikemen GO
* [Pac-Man](https://github.com/masonicGIT/pacman) - Pac-Man with Added Features

***

## ▷ Revival Projects

* ↪️ **[Multiplayer Revivals / Mods](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools#wiki_.25B7_multiplayer_mods)**
* [Updated Classic](https://rentry.co/FMHYB64#updated-classic) - Classic Rockstar Games Fixes + QOL Improvements
* [Falcon BMS](https://www.falcon-bms.com/) - Falcon 4.0 Modernization Project / [Wiki](https://wiki.falcon-bms.com/) / [Forum](https://forum.falcon-bms.com/) / [YouTube](https://www.youtube.com/@falcon-bms) / [Subreddit](https://www.reddit.com/r/falconbms/) / [Discord](https://discord.gg/KQNHQBz)
* [FlightGear](https://www.flightgear.org/) - Open-Source Flight Simulator / [X](https://x.com/flightgearsim) / [GitLab](https://gitlab.com/flightgear/flightgear)
* [Sonic Runners Revival](https://sonicrunners.com/) - ⁠Sonic Runners Revival / [Discord](https://discord.gg/T5ytR6T)
* [Age of the Ring](https://www.moddb.com/mods/the-horse-lords-a-total-modification-for-bfme) - LOTR: The Battle for Middle-Earth II Revival Mod / [Discord](https://discord.com/invite/MB8Kj9N)
* [Aleph One](https://alephone.lhowon.org/) - Open-Source Marathon Continuation / [Discord](https://discord.com/invite/NvF3pdV)
* [OpenNox](https://github.com/opennox/opennox) - Nox Revival Project / [Discord](https://discord.gg/HgDUeXhAyW)
* [r/MinecraftStoryMode](https://www.reddit.com/r/MinecraftStoryMode/) - Minecraft Story Mode Revival Project
* [Peacock](https://thepeacockproject.org/) - Hitman World of Assassination Server Replacement / [GitHub](https://github.com/thepeacockproject/Peacock)
* [⁠Lunar Tear](https://lunar-tear.com/) - NieR Reincarnation Revival Project
* [SpaceCadetPinball](https://github.com/k4zmu2a/SpaceCadetPinball) - Space Cadet Pinball / [Android](https://github.com/fexed/Pinball-on-Android)
* [Cataclysm: Dark Days Ahead](https://cataclysmdda.org/) / [Wiki / Resources](https://www.reddit.com/r/cataclysmdda/comments/1tlw06n/) / [GitHub](https://github.com/CleverRaven/Cataclysm-DDA/) or [⁠Cataclysm: Bright Nights](https://github.com/cataclysmbn/Cataclysm-BN) / [Discord](https://discord.gg/XW7XhXuZ89) - Cataclysm Fan Fork / Roguelike Survival RPG

***

# ► Emulation / ROMs

## ▷ Emulators

* 🌐 **[Emulation Wiki](https://emulation.gametechwiki.com/)**, [Awesome Emulators](https://github.com/DerekTurtleRoe/awesome-emulators), [PlanetEmu](https://www.planetemu.net/), [EmuWiki](https://www.vincenzoscarpa.it/emuwiki/pmwiki/pmwiki.php?n=Emulators.Emulators&lng=en), [⁠Emu-France](https://www.emu-france.com/emulateurs/) or [EmuCR](https://www.emucr.com/) - Download Emulators
* 🌐 **[Multi System Frontends](https://emulation.gametechwiki.com/index.php/Frontends)** - Frontends with Multiple Consoles
* 🌐 **[Multi System Emulators](https://emulation.gametechwiki.com/index.php/Multi-system_emulators)** - Emulators with Multiple Consoles
* 🌐 **[RedSquirrel Project List](https://redsquirrel87.com/doku.php/projects-list)** - Emulator Tools
* 🌐 **[Multiplayer Emulation](https://emulation.gametechwiki.com/index.php/Netplay)** - Multiplayer Emulation Tools
* ↪️ **[Emulators on Android](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android/#wiki_.25B7_emulators_on_android)**
* ⭐ **[Recommended Emulator Specs](https://emulation.gametechwiki.com/index.php/Computer_specs)**
* ⭐ **[Emulator BIOS Files](https://emulation.gametechwiki.com/)** - Search for "Emulator Files"
* ⭐ **[RetroAchievements](https://retroachievements.org/)** - Achievements for Emulators / [Compatible Games](https://retroachievements.vercel.app/) / [DAT Files](https://rentry.co/FMHYB64#ra-dat)
* ⭐ **[Dolphin Guides](https://dolphin-emu.org/docs/guides/)** or [Dolphin Performance Guide](https://github.com/shiiion/dolphin/wiki/Performance-Guide) - Dolphin Setup / Performance Guides
* ⭐ **[Cemu Guide](https://cemu.cfw.guide/)** or [r/CemuPiracy Tutorial](https://www.reddit.com/r/CemuPiracy/wiki/tutorial/) - Wii U / BOTW Setup Guides
* [NetplayFinder](https://www.netplayfinder.com/) - Find Active Emulator Netplay Sessions / [Discord](https://discord.com/invite/SkRE39MGr7)
* [Switch Emulation](https://rentry.co/FMHYB64#switch-emulation) - Switch Emulator Setup Guides
* [Wiki of Axekin](https://wiki.axekin.com/) - Emulation Guides / [Discord](https://discord.gg/CUpf57y5Vg)
* [⁠Retro Game Corps](https://retrogamecorps.com/) - Console / Handheld Emulator Guides
* [Handhelds Wiki](https://handhelds.wiki/) - Retro Handhelds Wiki / Emulation Guides⁠
* [RetroCatalog](https://retrocatalog.com/) or [Handheld Emulation Compatibility](https://docs.google.com/spreadsheets/d/1irg60f9qsZOkhp0cwOU7Cy4rJQeyusEUzTNQzhoTYTU/) - Handheld Emulation Compatibility / Info
* [TOSEC](https://rentry.co/FMHYB64#tosec) - The Old School Emulation Center
* [CloudRetro](https://github.com/giongto35/cloud-game) - Cloud Gaming Service for Emulators
* [Two-Torial](https://re-two-torial.xyz/) - Arcade Game Emulation Guides
* [⁠EmulationRevival](https://emulationrevival.github.io/) - Xbox Series Emulation Guide
* [Emulation Collective](https://discord.com/invite/7pcAbZzpXj) - Xbox One/Series X|S UWP Emulation Discord
* [MouseInjector](https://github.com/garungorp/MouseInjectorDolphinDuck) - Add Mouse Support to Emulators
* [SaveFileConverter](https://savefileconverter.com/) - Convert Console Saves to Emulator Saves
* [⁠AndroidDSU](https://github.com/PlayXboxtion963/AndroidDSU#english-version) - Use Android as Motion Controls for Emulators
* [Motion Support Bypass](https://redd.it/gobcne) - Fix Cemu BOTW Motion Shrines
* [ns-emu-mod-downloader](https://github.com/exefer/ns-emu-mod-downloader) - Download Switch Emulator Mods
* [UniversalDynamicInput](https://github.com/Venomalia/UniversalDynamicInput) - Custom Dolphin Button Pack
* [TOTK Optimization](https://rentry.co/FMHYB64#totk-optimization) - TOTK Optimization / Fixes
* [Prime Hack](https://github.com/Kekun/primehack) or [Prime Hunter Hack](https://github.com/IBreakGames/PrimeHunterHack) - Add Mouse Support to Metroid Games
* [RPCS3 Setup Guide](https://docs.google.com/document/d/1gdjNab-CtVS97jH2diPPP5tCrpBeof9-qPIRRB9-BrU/edit) - RPCS3 Emulator Setup Guide
* [⁠AmigaVision](https://amiga.vision/) - Commodore Amiga Emulator Launcher & Setup
* [PCSX-Redux](https://pcsx-redux.consoledev.net) - PSCX Development Emulator
* [Modernized PCSX2 Settings](https://mega.nz/folder/WdNAlY5Z#K6PmrQFyDm2k7BEV8KoAmg) - Premade PCSX2 Settings
* [⁠Skate 3 RPCS3 Online](https://discord.gg/DFWCaTGyBT) - RPCS3 Skate 3 Multiplayer
* [⁠ArticBaseServer](https://github.com/azahar-emu/ArticBaseServer) - Broadcast 3DS Games to Emulators / Requires No Game Dump
* [PictoChat Online](https://pict.chat/) - Browser DS PictoChat
* [webnofrendo](https://zardam.github.io/webnofrendo/) - NES Numworks Emulator

***

## ▷ ROM Resources

* 🌐 **[ROM Managers](https://emulation.gametechwiki.com/index.php/ROM_managers)** - List of ROM Managers
* ⭐ **[Skraper](https://www.skraper.net/)** - ROM Cover / Metadata Scraper
* [RomStation](https://www.romstation.fr/) - ROM Downloader / Manager / Multiplayer
* [⁠Romm](https://romm.app/) - Self-Hosted ROM Manager / [Discord](https://discord.gg/RGPJHNMMwJ) / [GitHub](https://github.com/rommapp/romm)
* [⁠ROM Duplicate Manager](https://github.com/Anach/ROM_Duplicate_Manager) - Remove Duplicate ROM Files
* [Hash Tool](https://www.romhacking.net/hash/) - ROM Patch Compatibility Checker
* [⁠ROM Converto](https://github.com/DevYukine/rom-converto) - ROM Converter
* [RomPatcher](https://www.marcrobledo.com/RomPatcher.js/) / [GitHub](https://github.com/marcrobledo/RomPatcher.js/), [2](https://www.romhacking.net/patch/), [Hack64 Patcher](https://hack64.net/tools/patcher.php) or [FFF6Hacking Patcher](https://www.ff6hacking.com/patcher/) - Online ROM Patchers
* [No-Intro](https://no-intro.org/) - Cartridge (etc) Hash Database / [Discord](https://discord.gg/dvk6W6vZmp)
* [Redump](https://redump.info/) - Disc Hash Database
* [Dats.site](https://dats.site/) - Scene Release Hash Database
* [r/ROMs](https://www.reddit.com/r/ROMs/) - ROM Discussion Sub / [Wiki](https://www.reddit.com/r/Roms/wiki/) / [Matrix](https://matrix.to/#/#romz:matrix.org)
* [Kuribo64](https://kuribo64.net/) - ROM Modding Community
* [Code Converter ](https://dowdy.dev/utilities/code-converter/) - PS2 Cheat Code Converter (Single Player Only)

***

## ▷ ROM Sites

* 🌐 **[ROM Sites Wiki](https://emulation.gametechwiki.com/index.php/ROM_%26_ISO_Sites)** - List of ROM Download Sites
* 🌐 **[r/ROMs Mega](https://r-roms.github.io/)** - ROMs
* ⭐ **[Axekin](https://www.axekin.com/)** - ROMs / [Discord](https://discord.gg/CUpf57y5Vg)
* ⭐ **[Vimm's Lair](https://vimm.net/)** - ROMs / [Discord](https://discord.com/invite/XReX2ZGNcV)
* ⭐ **[No-Intro Archive](https://rentry.co/FMHYB64#no-intro)** - ROMs / Unofficial
* ⭐ **[ROM Heaven](https://romheaven.com/)** - ROMs
* ⭐ **[Ziperto](https://ziperto.com/)** - ROMs
* ⭐ **[LoLROMs](https://rentry.co/FMHYB64#lolroms)** - ROMs
* ⭐ **[RuTracker ROMs](https://rutracker.org/forum/viewforum.php?f=548)** - ROMs / Torrents / Use [VPN](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy/#wiki_.25BA_vpn) / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent#wiki_.25BA_torrent_sites)
* ⭐ **[RetroGameTalk](https://retrogametalk.com/)** (sign-up required) / [Subreddit](https://www.reddit.com/r/RetroGameTalk/), [⁠ROMHack.ing](https://www.romhack.ing/) / [Discord](https://discord.gg/uAufcgz), [ROMhacking](https://www.romhacking.net/) or [⁠ROMHack Plaza](https://romhackplaza.org/) / [Discord](https://discord.gg/5CKzeWmZZU) - ROM Fan Translations / Hacks
* [WowROMs](https://wowroms.com/en) - ROMs
* [RomsTime](https://romstime.com/) - ROMs
* [Retro Game Champion](https://www.retrogamechampion.com/) - Retro Game ROMs, Magazines, Music & more / [Discord](https://discord.gg/zueusZt)
* [Zophar's Domain](https://www.zophar.net/) - ROM Mods
* [⁠roms.by](https://www.roms.by/) - ROMs / Requires Sign-Up
* [TheRomDepot](https://theromdepot.com/) - ROMs / Requires Sign-Up
* [BlueRoms](https://www.blueroms.ws/) - ROMs / Torrents
* [ROMsFun](https://romsfun.com/) or [ROMsPURE](https://ROMspure.cc/) - ROMs
* [Arquivista ROMs](https://rentry.co/FMHYB64#arquivista) - ROMs
* [FinalBurn Neo](https://rentry.co/FMHYB64#finalburn-neo) - ROMs / Zip
* [Romsie](https://roms2000.com/) - ROMs
* [Retrostic](https://www.retrostic.com/) - ROMs
* [ROMsGames](https://www.romsgames.net/roms/) - ROMs
* [ConsoleROMs](https://www.consoleROMs.com/) - ROMs
* [ROMsHQ](https://romshq.com/) - ROMs
* [Emu-Land](https://www.emu-land.net/en) - ROMs
* [Player One](https://player1.eu/) - ROMs
* [HexRom](https://hexrom.com/) - ROMs / [Telegram](https://t.me/Hexrom_Com)
* [The Old Computer](https://www.theoldcomputer.com/) - ROMs
* [Minerva](https://rentry.co/FMHYB64#myrient-backup) - ROMs / Myrient Archive / [Subreddit](https://www.reddit.com/r/savemyrient/)
* [Emuparadise](https://www.emuparadise.me/) - ROMs / [Forum](https://www.epforums.org/) / [Fix Downloads](https://gist.github.com/infval/c69b479ff0bd590f2dd7e1975fe2fcad/raw/8be1b17f03837939c8baab3b2247eb60a22fa89a/emuparadise.download.user.js)
* [ROM-Collections](https://rentry.co/FMHYB64#rom-collections) - ROMs
* [Romspedia](https://www.romspedia.com/) - ROMs
* [RPGOnly](https://rpgonly.com) - ROMs
* [ROMSPack](https://www.romspack.com/) - ROMs
* [NGR](https://www.nextgenroms.com/) - ROMs / [Discord](https://discord.gg/BQPzkwj)
* [FantasyAnime](https://fantasyanime.com/) - ROMs
* [⁠EpicROMs](https://epicroms.net/roms/) - ROMs / Use Adblock / [Subreddit](https://www.reddit.com/r/EpicRoms/)
* [Rom Magnet Links](https://emulation.gametechwiki.com/index.php/ROM_%26_ISO_Sites#BitTorrent) - ROMs / Torrent
* [DLXbGame](https://dlxbgame.com/) - ROMs / Xbox 360 / Avoid PC Games
* [ROM CSE](https://cse.google.com/cse?cx=f47f68e49301a07ac) / [CSE 2](https://cse.google.com/cse?cx=744926a50bd7eb010) - Multi-Site ROM Search
* [Wad Archive](https://archive.org/details/wadarchive) - 83k WAD Files
* [Cah4e3](https://cah4e3.shedevr.org.ru/) - Unlicensed ROMs / Bootlegs / Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators)
* [AtariMania](https://www.atarimania.com/) - ROMs / Atari Consoles
* [PleasureDome](https://pleasuredome.github.io/pleasuredome/mame/), [⁠MDK](https://mdk.cab/) or [Arcade Database](https://adb.arcadeitalia.net/default.php) - Arcade MAME ROMs
* [PICOwesome](https://rentry.co/FMHYB64#picowesome) - PICO-8 ROMs
* [POP Unofficial Website](https://popuw.com/) - Prince of Persia ROMs / Mods
* [⁠FFHacktics](https://ffhacktics.com/smf/) - Final Fantasy Tactics Mods / [Discord](https://discord.gg/xpXa8VEV2k)
* [Castlevania: The Inverted Dungeon](https://www.inverteddungeon.com/index.php?section=fanworks) - Castlevania Fan Games + Mods
* [SAGE](https://sagexpo.org/) / [Discord](https://discord.sonicfangameshq.com/) or [Sonic Retro](https://forums.sonicretro.org/) / [GitHub](https://github.com/sonicretro/) - Sonic Fan Games + Mods
* [Mega Man Maker](https://megamanmaker.com/) - Create Mega Man Levels

***

## ▷ Nintendo ROMs

* ⭐ **[hShop](https://hshop.erista.me/)** / [Discord](https://discord.gg/dYKm279) or [3DS ROMS](https://3dsroms.org) - ROMs / 3DS
* ⭐ **[WiiUDownloader](https://github.com/Xpl0itU/WiiUDownloader)**, [WiiUSBHelper](https://github.com/FailedShack/USBHelperInstaller/releases) or [JNUSTool](https://gbatemp.net/threads/jnustool-nusgrabber-and-cdecrypt-combined.413179/) - ROMs / Wii U
* ⭐ **[NesFiles](https://www.nesfiles.com/)** or [FC Gallery](https://fcpic.nesbbs.com/index_en.html) - ROMs / NES / Famicom
* [Homebrew Hub](https://hh.gbdev.io/) - Homebrew ROMs / NES / Game Boy
* [64DD.org](https://64dd.org/) - ROMs / 64DD
* [NSWGame](https://nswgf.com/) - ROMs / DS / 3DS / Switch / Wii / WiiU / Avoid PC Games
* [Tensearch](https://tensear.ch/) - ROMs / Switch
* [ROMSLAB](https://romslab.com/) - ROMs / Switch 2 / Switch / [Telegram](https://t.me/GameCentrala) / [Discord](https://discord.com/invite/MmTjxwYvG9)
* [NXBrew](https://nxbrew.net/) - ROMs / Switch 2 / Switch
* [NSWPURE](https://nswpure.com/) - ROMs / Switch
* [GNS](https://rentry.co/FMHYB64#gns) - ROMs / Switch / Requires Telegram
* [RomSim](https://romsim.net/) - ROMs / Switch
* [nswvault](https://nswvault.com/) - ROMs / Switch / Avoid Fake Download Buttons
* [SmallGames](https://smallgames.ch/) - ROMs / Switch / [Discord](https://discord.com/invite/rgttByzYRY)
* [⁠NSWTL](https://nswtl.info/) - ROMs / Switch / Torrents / Requires Telegram
* [N R](https://nintendoroms.xyz/) - ROMs / Switch / 3DS / Wii / GCN / Requires Telegram / [Telegram](https://t.me/+VhTgmHwgmNk1NjY0)
* [NSWDB](https://www.nswdb.com) - Switch Release Tracker
* [3DSDB](https://3dsdb.com/) - 3DS Release Tracker
* [⁠ROMHacking.com](https://romhacking.com/) or [SM64ROMHacks](https://rentry.co/FMHYB64#sm64romhacks) / [Discord](https://discord.com/invite/BYrpMBG) - Super Mario 64 Mods
* [MFGG](https://mfgg.net/) - Super Mario Fan Games / Mods / [Discord](https://discord.gg/jchgfw5)
* [Newer Team](https://newerteam.com/) or [NSMBHD](https://nsmbhd.net/) / [Discord](https://discord.gg/x7gr3M9) - Super Mario Bros. DS / Wii Mods
* [SMW Hacks](https://rentry.co/FMHYB64#smw-hacks) or [SMWCentral](https://smwcentral.net/) - Super Mario World ROM Mods
* [Wario Land Vault](https://wario-land.github.io/HackVault/index.html) - Wario Land ROM Mods
* [Pokémon ROM Mods](https://rentry.co/FMHYB64#poke) - Pokémon ROM Mods
* [OOTMM](https://ootmm.com/) - Randomize + Merge Ocarina of Time with Majora's Mask
* [SMBX2](http://codehaus.wohlsoft.ru/index.php) - Super Mario Enhancement Mod / [Levels](https://rentry.co/FMHYB64#smbx-preservation) / [Discord](https://discord.com/invite/aCZqadJ)
* [⁠Super Mario Bros Remastered](https://github.com/JHDev2006/Super-Mario-Bros.-Remastered-Public) - Super Mario Bros. Remake / [Discord](https://discord.com/invite/A68uRsnja3)
* [⁠SMB Arena](https://www.smbarena.com/) - Super Mario Bros. 1 Mods
* [Super Mario and the Rainbow Stars](https://superstarshi.github.io/smatrs/) - Super Mario Mod / [Discord](https://discord.gg/GBXUa7NF2J)
* [⁠Super Mario War](http://smwstuff.net/) - Multiplayer Deathmatch Style Super Mario Bros.
* [⁠Mario Party Legacy](https://mariopartylegacy.com/forum/) - Mario Party Mods
* [Super Mario Bros Crossover](https://archive.org/details/SuperMarioCrossoverOffline) - Play SMB with Alternative Characters
* [MetroidConstruction](https://metroidconstruction.com/) - Metroid ROM Modding Community / [Discord](https://discord.gg/xDwaaqa)
* [⁠NS2DB](https://ns2db.com/) - Switch 2 / Switch / 3DS ROM Release Tracker

***

## ▷ Playstation ROMs

* ⭐ **[NoPayStation](https://nopaystation.com/)** - ROMs / PS3 / PSP / PSVita / [Discord](https://discord.com/invite/rNGrkUY)
* [⁠CHD Station](https://chdstation.com/) - ROMs / PS1 / PS2 / PSP
* [AlvRo](https://rentry.co/FMHYB64#alvro) - ROMs / PS2 / PW: `ByAlvRo`
* [DLPSGame](https://dlpsgame.com/) - ROMs / PS2 / PS3 / PS4 / PS5 / **Avoid PC Games**
* [Super PSX](https://www.superpsx.com/) - ROMs / PS3 / PS4 / PS5 / **Avoid PC Games**
* [PS Network Database](https://rentry.co/FMHYB64#ps-content) - ROMs / PS3
* [PKGPS4](https://www.pkgps4.click/) - ROMs / PS4
* [GFS Catalog](https://catalog.gfs-dlps.workers.dev/) - ROMs / PS5
* [Pippo Library](https://pippo26442999.github.io/.exFAT/) - ROMs / PS5 / PW: pippo
* [DownloadGamePSP](https://downloadgamepsp.org/) - ROMs / PSP / PSVita / **Avoid PC Games**
* [PS1 Covers](https://github.com/xlenore/psx-covers) or [PS2 Covers](https://github.com/xlenore/ps2-covers) - Cover Downloaders

***

## ▷ Retro Browser Emulators

* 🌐 **[Browser Emulator Index](https://emulation.gametechwiki.com/index.php/Emulators_on_browsers)** - List of Browser Emulators
* ↪️ **[EmulatorJS / NeptunJS](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_emulatorjs_.2F_neptunjs)** - Frontends for EmulatorJS / NeptuneJS
* ⭐ **[GAM.ONL](https://gam.onl/)**, [2](https://www.retrogames.onl/) - Multi-Console
* ⭐ **[webЯcade](https://play.webrcade.com/)** - Retro Consoles / [Discord](https://discord.gg/C4gXN2HJAv) / [GitHub](https://github.com/webrcade)
* ⭐ **[Console Living Room](https://archive.org/details/consolelivingroom)** - Multi-Console / Archive.org
* ⭐ **[Retro Online](https://retroonline.net/)** - Retro PC Browser Emulator / [Discord](https://discord.gg/5CBvdysSnZ) / [Telegram](https://t.me/RetroOnlineNet)
* ⭐ **[DOS Zone](https://dos.zone/)** - Retro PC Browser Emulator / [Discord](https://discord.com/invite/hMVYEbG)
* ⭐ **[Telemelt](https://telemelt.com/)** - Multiplayer Browser Emulator
* ⭐ **[RetroArch Web](https://web.libretro.com/)** - Multi-Console
* ⭐ **[CommodoreGames](https://www.commodoregames.net/)** or [C64Online](https://c64online.com/) - Commodore / C64 Browser Emulators
* ⭐ **[EmulatorJS](https://demo.emulatorjs.org/)** - Multi-Console / [Supported Systems](https://emulatorjs.org/docs/systems) / [Discord](https://discord.gg/6akryGkETU) / [GitHub](https://github.com/EmulatorJS/EmulatorJS)
* ⭐ **[Eclipse](https://eclipseemu.me/play/)** - Multi-Console / [Discord](https://discord.gg/dTCnM2r5e5)
* ⭐ **[RetroFab](https://itizso.itch.io/retrofab)** - Retro LCD Game Emulators
* [⁠ArcadeSpace](https://www.arcadespace.org/) - Retro Consoles / Multiple-Emulators / Sign-Up Required
* [⁠FreebieGames](https://freebie.games/) - Retro Consoles / Multiple-Emulators
* [AfterPlay](https://afterplay.io/play/recently-played) - Multi-Console / [Discord](https://discord.gg/PtgKse35q7)
* [Online Retro Games](https://www.vincenzoscarpa.it/emuwiki/pmwiki/pmwiki.php?n=OnlineGames.OnlineGames&lng=en) - Retro Consoles / Archive.org
* [RetroGames](https://www.retrogames.cz/) - Retro Consoles
* [Retro Games Bot](https://retrogamesbot.com/) - Retro Consoles
* [PlayGames](https://playgames.onl/) - Retro Consoles
* [⁠Savi Games](https://savigames.com/) - Retro Consoles
* [Aurora](https://skitty.xyz/aurora/) - Retro Consoles / [Discord](https://discord.gg/UAf7Bad)
* [Vizzed](https://www.vizzed.com/) - Retro Consoles / Multiple-Emulators
* [Online.OldGames](https://online.oldgames.sk/) - Retro Consoles / Multiple-Emulators
* [ClassicGames](https://www.classicgames.me/) - Retro Consoles / Multiple-Emulators
* [Virtual Consoles](https://virtualconsoles.com/) - Retro Consoles / Multiple-Emulators
* [ClassicReload](https://classicreload.com/) - Retro Consoles / Multiple-Emulators
* [Emupedia](https://emupedia.net/beta/) - Retro Consoles
* [⁠Retro Gaming](https://retrogaming.dpdns.org/) - Retro PC Browser Emulator
* [yag.im](https://yag.im/) - Retro Edutainment + Adventure Game Browser Emulator / Sign-Up Required / [Discord](https://discord.gg/N4QavHBBAG) / [GitHub](https://github.com/yag-im)
* [DOS Games Archive](https://www.dosgamesarchive.com/), [Best DOS Games](https://bestdosgames.com/), [Best Old Games](https://www.bestoldgames.net/), [DOSGames](https://dosgames.com/), [RGB Classic Games](https://www.classicdosgames.com/), [DosGames](https://dosgames.com/), [WePlayDOS](https://weplaydos.games/) / [Discord](https://discord.gg/82TAR6fJ8g) / [GitHub](https://github.com/muditjuneja/weplaydos.games) or [PlayDOSGames](https://www.playdosgames.com/) - DOS Browser Emulators
* [⁠Meowio](https://www.information-superhighway.net/meowio/) - NES Browser Emulator / Custom Music + Sounds
* [SNESFun](https://www.snesfun.com/) - SNES Browser Emulator / Multiplayer
* [PS1FUN](https://www.ps1fun.com/) - PS1 Browser Emulator
* [SSega](https://www.ssega.com/) - Sega Browser Emulators / Multiplayer
* [Sega Play](https://sega-play.online/) - Sega Browser Emulator
* [File-Hunter](https://www.file-hunter.com/) - MSX / Amiga Browser Emulator
* [MSXGamesWorld](https://www.msxgamesworld.com/) or [CheatMSX](https://www.cheatmsx.com/) - MSX Browser Emulators
* [⁠BBC Micro Games Archive](https://bbcmicro.co.uk/) - BBC Micro Emulator
* [QAOP](https://torinak.com/qaop/games) - ZX Spectrum Browser Emulator
* [⁠JavaGames](https://javagames.cc/) - Java 2 Micro (J2ME) Browser Emulator / [Discord](https://discord.gg/MYNtyZNFBa)
* [Homebrew Hub](https://hh.gbdev.io/) - Homebrew ROM Emulator / NES / Game Boy
* [Tiny8bit](https://floooh.github.io/tiny8bit/) - Vintage 8-Bit / [GitHub](https://github.com/floooh/chips-test)

***

# ► Puzzle Games

* 🌐 **[Think Labyrinth](https://www.astrolog.org/labyrnth.htm)** - Encyclopedia of Maze Algorithms and Resources
* ⭐ **[Simon Tatham's Puzzles](https://www.chiark.greenend.org.uk/~sgtatham/puzzles/)** - Multiple Puzzle Games / [Mobile](https://github.com/chrisboyle/sgtpuzzles)
* [⁠Puzzmo](https://www.puzzmo.com/), [Ponder Club](https://ponderclub.co/), [⁠GuessDash](https://guessdash.com/) or [Arkadium](https://www.arkadium.com/) - Daily Word, Guessing & Puzzle Games
* [⁠ThinkyGames](https://thinkygames.com/games/?free=true&platforms=Web) - Indie Puzzle Games
* [Puzzle Loop](https://www.puzzle-loop.com/) - Multiple Puzzle Games / [Discord](https://discord.gg/YJp77jFzWv)
* [Puzzle Party](https://artsandculture.google.com/experiment/puzzle-party/EwGBPZlIzv0KRw) - Multiplayer Jigsaws
* [PuzzlePrime](https://www.puzzleprime.com/) - Problems / Puzzles
* [⁠Brain Bashers](https://www.brainbashers.com/) - Multiple Puzzle Games
* [Game for the Brain](https://www.gamesforthebrain.com/) - Puzzles / Quizzes
* [⁠0x00-8191](https://0x00-8191.com/) - Cipher, Signal & Riddle Style Puzzles
* [MasasGames](https://masasgames.com/) - Virtual Escape Rooms
* [⁠Murdoku](https://murdoku.com/play/) - Weekly Murder Mystery Puzzles / [Discord](https://discord.com/invite/frYbdPpkSH)
* [Murdle](https://murdle.com/) - Daily Murder Mystery
* [⁠enclose.horse](https://enclose.horse/) - Daily Horse Enclosure Puzzle / Community Levels
* [Sokoban Online](https://www.sokobanonline.com/) - Sokoban Puzzles
* [DailyDungeon](https://dailydungeon.net/) - Puzzle Dungeon Crawler
* [Sokoban](https://suppilulemur.neocities.org/) - Zelda-Themed Sokoban Puzzles
* [All The 2048](https://true65536.github.io/allthe2048/), [DuckDuckgo 2048](https://duckduckgo.com/?q=play+2048&amp;ia=answer) or [2048](https://play2048.co/) - 2048 Puzzles
* [JetHolt](https://jetholt.com/hacking/), [⁠hack the terminal](https://bash.tv/mallory/hack-terminal) or [RebelWithoutACause](https://rebelwithoutarootcause.com/demos/terminal/) - Fallout Terminal Hacking Games
* [Rockbasher](https://www.rockbasher.com/) - Retro Style Puzzle Game
* [⁠Decelerate](https://dlc.kernal.bid/) - Tile Matching Game
* [⁠Queens Game](https://queensgame.io/) - N-Queens Problem Inspired Puzzle
* [⁠Squishy Billiards](https://squishybilliards.com/) - Daily Billiards Puzzle Game / [Discord](https://discord.gg/fkRCcvkhZh)
* [⁠Pips](https://www.nytimes.com/games/pips) - Daily Domino Puzzle
* [Orion](https://orion.lukasbach.com/) - Puzzle Game
* [⁠Cyadonia](https://cyadonia.com/) - Puzzle Game
* [Euclidea](https://www.euclidea.xyz/) - Geometric Puzzles
* [Pixel Puzzler](https://pixel-puzzler.playcurious.games/) or [UnFlip](https://unflipgame.com/) / [Discord](https://discord.com/invite/Hg6zVmTJeP) - Block Puzzles
* [⁠Stillgrid](https://stillgrid.app/), [⁠SudokuWiki](https://www.sudokuwiki.org/) or [Sudoku XV](https://keeri.place/sudoku-xv) - Sudoku + Sudoku Variants
* [UsDoku](https://www.usdoku.com/) - Multiplayer Sudoku
* [⁠Penpa+](https://swaroopg92.github.io/penpa-edit/) - Create / Solve Pencil Sudokus + Puzzles
* [picture dots](https://www.picturedots.com/) - Make & Play Dot Puzzles
* [Oh, My Dots!](https://www.ohmydots.com/) - Connect the Dots Game
* [BreakLock](https://maxwellito.github.io/breaklock/) - Pattern Lock Game / [GitHub](https://github.com/maxwellito/breaklock)
* [Kuku Kube](https://kuku-kube.com/) - Find the Different Squares
* [MazeGenerator](https://www.mazegenerator.net/), [Maze Toys](https://maze.toys/) or [Maze](https://www.epgsoft.com/maze/) - Maze Generators

***

## ▷ Rubiks Cube

* ↪️ **[Cubing Practice / Training](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu/#wiki_.25B7_rubiks_cube)**
* ⭐ **[Grubiks](https://grubiks.com/)** or **[Rubikverse](https://rubikverse.com/)** - Multi-Cube Types Simulators
* ⭐ **[Rubik's Cube Explorer](https://iamthecu.be/)** - 3x3 Cube Simulator
* [pCubes](https://twistypuzzles.com/forum/viewtopic.php?f=1&t=27054) - Multi-Cube Types App / Windows
* [The Cube](https://bsehovac.github.io/the-cube/) - Multi-Size Cube Simulator
* [FT Cube](https://shuantsu.github.io/ft_cube/) - Multi-Size Simulator & Net Generator
* [RubiksCu.be](https://rubikscu.be/solver/) - 3x3 Cube Solver
* [Rubik's Cube Solver](https://ruwix.com/cube-solver/) - 3x3 Cube Solver

***

## ▷ Minesweeper

* ⭐ **[Minesweeper.Online](https://minesweeper.online/)** / [Wiki](https://minesweeper.online/help) or [PROXX](https://proxx.app/) - Play Minesweeper
* [Authoritative Minesweeper](https://minesweepergame.com/) - Minesweeper Wiki
* [Minesweeper Advent Calendar](https://heptaveegesimal.com/2018/advent-calendar/) - 60+ Versions of Minesweeper
* [MinesweeperPro](https://www.minesweeperpro.com/), [Mines JD](https://minesjd.com/) or [m3o](https://play.m3o.xyz/) - Multiplayer Minesweeper
* [Minesweeper Infinity](https://www.minesweeperinfinity.com/) - Infinite Minesweeper
* [Minesweeper Twist](https://polyreplay.com/minesweepertwist) - Irregular Grid Minesweeper

***

## ▷ Crosswords

* ⭐ **[Crosshare](https://crosshare.org/)** - Crossword Puzzles / Creator
* [⁠Forkyz](https://gitlab.com/Hague/forkyz) - Multi-Platform Crossword App / [Sources](https://hague.gitlab.io/forkyz/)
* [BestCrosswords](https://www.bestcrosswords.com/) - Crossword Puzzles
* [Cross with Friends](https://www.crosswithfriends.com/) or [Hovercats](https://hovercats.gg/) - Multiplayer Crosswords
* [Truncate](https://truncate.town/) - Crossword Strategy Game
* [Regex Crossword](https://regexcrossword.com/), [2](https://jimbly.github.io/regex-crossword/) - Regex Crosswords
* [Web Paint-by-Number](https://webpbn.com/) or [Nonograms.org](https://www.nonograms.org/) - Graphic Crosswords (Nonograms)
* [Crossword Labs](https://crosswordlabs.com/), [Exet](https://viresh-ratnakar.github.io/exet.html), [Crosserville](https://www.crosserville.com/), [Puzzlemaker](https://puzzlemaker.discoveryeducation.com/) or [XWords](https://www.xwords-generator.de/en) - Crossword Creators / Editors
* [⁠Kakuro Puzzle](https://kakuro-puzzle.online/) - Kakuro / Number Crosswords

***

## ▷ Word Games

* 🌐 **[DLES.gg](https://dles.gg/)** or [DLES](https://dles.aukspot.com/) - Word Game Indexes
* 🌐 **[Wordleverse](https://wordleverse.net/)**, [WordleWeb](https://github.com/rarelygoeshere/WordleWeb), [Wordle Collection](https://rentry.org/v72n74fu), [Awesome Wordle](https://github.com/prakhar897/awesome-wordle), [Alldle](https://alldle.net/) or [Wordles of the World](https://rwmpelstilzchen.gitlab.io/wordles/) - Wordle Game Indexes
* ⭐ **[Wordle](https://www.nytimes.com/games/wordle/index.html)** or [⁠Infinite Wordles](https://infinitewordles.org/) - Original Wordle
* ⭐ **[Wordle Analyzer](https://wordle-analyzer.com/)** / [GitHub](https://github.com/jakearchibald/wordle-analyzer/)
* ⭐ **[Woogles](https://woogles.io/)**, [MoreWords](https://www.morewords.com/) or [PlayScrabble](https://playscrabble.com/) - Scrabble
* [TheWordSearch](https://thewordsearch.com/) - Word Search Puzzles
* [⁠Puzzmo](https://www.puzzmo.com/), [Ponder Club](https://ponderclub.co/) or [Arkadium](https://www.arkadium.com/) - Daily Word + Puzzle Games
* [⁠Wordsmyth](https://www.playwordsmyth.com/) - Daily Word Transformation Game
* [Make a Word Search](http://www.makeawordsearch.net/) or [Word Search Labs](https://wordsearchlabs.com/) - Word Search Creators
* [Connections](https://connections.swellgarfo.com/) - Custom Word Puzzles
* [RobinWords](https://www.robinwords.com/) - Word Ladder Game
* [⁠TiledWords](https://tiledwords.com/) - Daily Tile Rotation Word Game
* [⁠PlausibleGame](https://plausiblegame.com/) - Daily Word Game
* [⁠Blockle](https://blockle.au/) - Daily Word Game
* [⁠Lettered](https://lettered.io/) - Daily Word Game
* [⁠Word Nerd](https://wordnerd.co/) - Daily Word Game
* [Three Letters Game](https://threelettersgame.com/) - Daily Word Game
* [JKLM.FUN](https://jklm.fun/) - Multiplayer Word Games
* [eWordChallenge](https://www.ewordchallenge.net/) - Boggle Online
* [⁠Word Salad](https://wordsalad.online/) - Daily Word Puzzle
* [Squaredle](https://squaredle.app/) - Daily Word Puzzle / [Discord](https://discord.com/invite/aredl)
* [⁠Glyph](https://glyph.today/) - Daily Word Puzzle
* [⁠OneLook Games](https://onelook.com/games) - Word Games
* [Linxicon](https://linxicon.com/) - Word Connection Games
* [WordHub](https://wordhub.com/) - Text Twist Game
* [⁠Duotrigordle](https://duotrigordle.com/) - 32-Word Wordle & Variants
* [Wordle VS](https://wordlevs.com/) - Multiplayer Wordle
* [⁠Infinite Wordle](https://gregcameron.com/infinite-wordle/) or [Wordle Unlimited](https://wordleunlimited.org/) - Wordle without Daily Limits
* [Fusele](https://fusele.netlify.app/) - Wordle Variant
* [Word500](https://word500.com/) - Wordle + Mastermind
* [Wordly](https://wordly.org/) - Wordle Clone
* [Octordle](https://www.merriam-webster.com/games/octordle/) - Eight Word Wordle
* [⁠Crosswordle](https://crosswordle.com/) - Crossword-Style Wordle
* [Sqword](https://www.sqword.com/) - Deck-Based Wordle
* [Alphabeticle](https://alphabeticle.xyz/) - Alphabetical Wordle
* [WordMaze](https://wordmaze.click/) - Maze Style Wordle
* [Pixletters](https://pixletters.com/) - Pixel Style Wordle
* [Wourdle](https://wourdle.com/) - British English Wordle
* [Ridella](https://ridella.xyz/) - Riddle Wordle
* [⁠Bomb Party Local](https://cyfam.github.io/bombpartylocal/game) - Word Game Practice
* [Quackle](https://www.quackle.org/) - Scrabble AI, Game Analysis & Strategy Trainer / Windows, macOS, Linux / [GitHub](https://github.com/quackle/quackle)

***

# ► Tabletop Games

* 🌐 **[BoardGameGeek](https://boardgamegeek.com/)**, **[RPGGeek](https://rpggeek.com/)**, **[⁠EntertainMe](https://www.entertainme.fun/)**, **[Online Board Games](https://drive.google.com/file/d/1NO-05LM-SakbwqNajBXgIO4HuCSkBd6n/view)** or **[Kallax](https://kallax.io/)** - Board Game / TTRPG Databases
* 🌐 **[Pub Meeple](https://www.pubmeeple.com/rankings)** - Community Board Game Rankings
* ↪️ **[Tabletop Tools & Resources](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools/#wiki_.25B7_tabletop_tools)**
* ↪️ **[Go / Baduk / Weiqi Learning](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7__go_.2F_baduk_.2F_weiqi)**
* ⭐ **[Roll20](https://roll20.net/)** / [Discord](https://discord.gg/roll20), [⁠Cockatrice](https://cockatrice.github.io/) / [Discord](https://discord.gg/3Z9yzmA) / [GitHub](https://github.com/Cockatrice/Cockatrice) or [Rolisteam](https://rolisteam.org/) / [Discord](https://discord.gg/MrMrQwX) - Online Virtual Tabletop Platforms
* [⁠BoardGameplay](https://boardgameplay.com/) - Online Board Games / [Discord](https://discord.gg/EC5ZvQa7M5)
* [FlyOrDie](https://www.flyordie.com/) - Online Board Games
* [⁠VirtualTabletop](https://virtualtabletop.io/) - Online Board Games / [GitHub](https://github.com/ArnoldSmith86/virtualtabletop)
* [PlayOK](https://www.playok.com/) - Online Board Games
* [Screentop](https://screentop.gg/) - Online Board Games / [Discord](https://discord.gg/wva8ebh)
* [BoardSpace](https://boardspace.net/english/index.shtml) - Online Board Games / [GitHub](https://github.com/ddyer0/boardspace.net)
* [FreeBoardGames](https://www.freeboardgames.org/) - Online Board Games / [Discord](https://discord.gg/AaE6n3n) / [GitHub](https://github.com/freeboardgames/FreeBoardGames.org)
* [FunNode](https://www.funnode.com/) - Online Board Games
* [Board Game Online](https://www.boardgame-online.com/) - Online Board Games
* [Board Game Arena](https://en.boardgamearena.com/) - Online Board Games / Requires Sign-Up
* [MahjongFun](https://www.mahjongfun.com/), [⁠Mahjong Solitaire](https://mahjong-solitaire.app/), [⁠Voxjong](https://voxjong.com/), [Classic Mahjong](https://classic-mahjong.com/), [The Mahjong](https://themahjong.com/) or [Mahjong 4 Friends](https://mahjong4friends.com/) - Mahjong Solitaire
* [lishogi.org](https://lishogi.org/) - Shogi / [Discord](https://discord.gg/YFtpMGg3rR) / [GitHub](https://github.com/WandererXII/lishogi)
* [lidraughts.org](https://lidraughts.org/) - Multiplayer Checkers / [GitHub](https://github.com/RoepStoep/lidraughts)
* [⁠The Old King's Crown](https://oldkingscrown.fly.dev/) - ⁠The Old King's Crown Browser Adaptation
* [Colonist](https://colonist.io/) - Settlers of Catan Board Game / [Subreddit](https://www.reddit.com/r/Colonist/) / [Discord](https://discord.gg/colonist)
* [Party Project](https://char64.itch.io/partyproject) - Mario Party-Style Tabletop Games / [Discord](https://discord.gg/nhUQwpGEQR)
* [Richup.io](https://richup.io/) - Monopoly-Style Board Game / [Discord](https://discord.gg/r6uJ6bq8ZH)
* [Rally the Troops](https://www.rally-the-troops.com/) - Historical-Style Board Games / [Discord](https://discord.gg/CBrTh8k84A)
* [18xx](https://18xx.games/) - 18xx Board Games Online / [GitHub](https://github.com/tobymao/18xx)
* [Hexxagon](https://hexxagon.com/) - Rubies Vs Pearls
* [The Bafflement Fires](https://www.dpoetry.com/fires/) - 1950s Freemasonic Board Game

***

## ▷ Chess

* 🌐 **[ChessVariants](https://www.chessvariants.com/index/favorites.php)** - Chess Variant Encyclopedia
* ↪️ **[Chess Learning / Practice](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu#wiki_.25B7_chess)**
* ⭐ **[Lichess](https://lichess.org/)** - Chess Platform / [Discord](https://discord.com/invite/lichess) / [GitHub](https://github.com/lichess-org)
* ⭐ **Lichess Tools** - [Mobile Apps](https://lichess.org/app) / [Prettier UI](https://prettierlichess.github.io/) / [Themes](https://github.com/algertc/prettierlichess-themes) / [Leagues](https://www.lichess4545.com/) / [Enhancement Extension](https://siderite.dev/LiChessTools/) / [Extra Functionality](https://lichess.org/page/extend) / [Game Database](https://database.lichess.org/)
* ⭐ **[PyChess](https://www.pychess.org/)** - Chess Platform / [Discord](https://discord.gg/aPs8RKr) / [GitHub](https://github.com/gbtami/pychess-variants)
* [Chess.com](https://www.chess.com/) - Chess Platform / [Discord](https://discord.gg/3VbUQME)
* [GameKnot](https://gameknot.com/) - Chess Platform
* [SparkChess](https://www.sparkchess.com/) - Chess Platform
* [Kung Fu Chess](https://www.kfchess.com/) - Real-Time Chess Without Turns
* [⁠Blindfold Chess](https://www.blindfold-chess.online/) - Play Blindfold Chess Against Stockfish
* [Echo Chess](https://echochess.com/) - Morph-Style Chess / [Discord](https://discord.gg/echochess)
* [⁠Drawback Chess](https://www.drawbackchess.com/) - Drawback Modifier Style Chess / [Discord](https://discord.gg/FZ34XU7q2U)
* [⁠Totally Normal Chess](https://totallynormalchess.com/) - Random-Rules Chess
* [⁠picklechess](https://playpicklechess.com/) - Piece-Picking Style Chess / [Discord](https://discord.gg/Cuytzk8bDs)
* [Pokemon Chess](https://pokemonchess.com/) - Pokémon-Style Chess / [Discord](https://discord.gg/fp5bcCqg8q)
* [The Kilobyte's Gambit](https://vole.wtf/kilobytes-gambit/) - Retro-Style Chess
* [Chesses](https://pippinbarr.com/chesses/), [TheChessDirectory](https://thechessdirectory.com/play-chess) or [Omnichess](https://omnichess.club/) - Multiple Styles of Chess
* [Print Chess](https://www.printchess.com/) - Printable Paper Chess Set

***

## ▷ Card Games

* ↪️ **[Tabletop Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools#wiki_.25B7_tabletop_tools)**
* ⭐ **[World of Card Games](https://worldofcardgames.com/)** - Multiplayer Card Games
* ⭐ **[Codenames](https://codenames.game/)** - Party Card Game
* [⁠Cardlike](https://cardlike.io/), [2](https://channa.itch.io/cardlike) - Balatro-Style Game
* [⁠FizzPoker](https://www.fizzpoker.com/), [Poker Now](https://www.pokernow.com/) or [247 Free Poker](https://www.247freepoker.com/) - Multiplayer Poker
* [Blackjack Break](https://blackjackbreak.com/) or [HTML5 Blackjack](https://www.html5blackjack.net/) - Online Blackjack
* [CardGames.io](https://cardgames.io/) - Multiplayer Card Games
* [247Games](https://www.247games.com/) - Multiplayer Card Games
* [CardzMania](https://www.cardzmania.com/) - Multiplayer Card Games
* [BlacksReds](https://blacksreds.com/) - Multiplayer Card Games
* [PlayOK](https://www.playok.com/) - Multiplayer Card Games
* [PlayingCards.io](https://playingcards.io/) - Multiplayer Card Games
* [Lethal](https://playlethal.fun/) - Single Turn Card Game / [Discord](https://discord.gg/2sev8HA9sd)
* [TCG ONE](https://tcg.one/) - Online Pokémon Card Game / [Discord](https://discord.gg/MTBGxVE)
* [⁠Wikipedia Gacha](https://wikigacha.com/) - Wikipedia Gacha / Card Game
* [gTOONS Remastered](https://gtoons.app/) - Cartoon Network Strategy Card Game / [Discord](https://discord.gg/KM2ggJtkMr)
* [Picture Cards](https://picturecards.online/) / [Discord](https://discord.gg/kJB4bxSksw), [Bad Cards](https://bad.cards/) or [Pretend You're Xyzzy](https://pyx-1.pretendyoure.xyz/zy/game.jsp) - Online Cards Against Humanity
* [Cards Against Humanity](https://www.cardsagainsthumanity.com/) - Official CAH Site w/ Free Printable Set
* [Secret Hitler](https://secret-hitler.online/) - Online Secret Hitler Game / [Ruleset](https://www.secrethitler.com/assets/Secret_Hitler_Rules.pdf) / [GitHub](https://github.com/ShrimpCryptid/Secret-Hitler-Online/) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/sh-note.md)
* [Wikidata Card Game Generator](https://cardgame.blinry.org/) - Generate "Top Trumps" Cards Using Wikidata
* [Solitaired](https://solitaired.com/), [Solitr](https://www.solitr.com/), [⁠Classic Klondike Solitaire](https://classicklondikesolitaire.com/free-solitaire-games), [Solitaire Owl](https://solitaireowl.com/) or [World of Solitaire](https://worldofsolitaire.com/) - Online Solitaire
* [PySolFC](https://pysolfc.sourceforge.io/) - Portable Solitaire App / Windows, macOS, Linux / [GitHub](https://github.com/shlomif/PySolFC)

***

## ▷ [Dungeons & Dragons](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu/#wiki_.25B7_dungeons_.26amp.3B_dragons)

***

# ► Browser Games

* ↪️ **[Browser Toys / Games](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_random)** - Browser Toys / Game Indexes
* ⭐ **[Allchemy](https://allchemy.io/)**, [Little Alchemy](https://littlealchemy.com/), [Little Alchemy 2](https://littlealchemy2.com/) or [Infinite Craft](https://neal.fun/infinite-craft/) / [Wiki](https://expitau.com/InfiniteCraftWiki/) / [Search](https://infinibrowser.wiki/) - Infinite Item Crafting Games
* ⭐ **[The World's Biggest Pac-Man](https://worldsbiggestpacman.com/)** - Infinite Custom Pac-Man
* ⭐ **[Super Monkey Ball Web](https://rentry.co/FMHYB64#mb-online)** - Browser Super Monkey Ball
* ⭐ **[Marble Blast Gold Web](https://marbleblast.vaniverse.io/)** / [GitHub](https://github.com/Vanilagy/MarbleBlast) or [Marble Blast Ultra](https://marbleblastultra.randomityguy.me/) / [GitHub](https://github.com/RandomityGuy/MBHaxe) - Browser Marble Blast
* ⭐ **[QWOP](https://www.foddy.net/Athletics.html)** - Ragdoll Running Game
* [SMBGames](https://smbgames.be/) - Browser Super Mario
* [SMWGames](https://www.smwgames.com/) - Modded Browser Super Mario World
* [Level Share Square](https://levelsharesquare.com/) - Custom Mario Fangame Maps
* [Jelly Mario](https://jellymar.io/) - Jelly Super Mario
* [DB Evolution](https://www.txori.com/dbdevolution) - Dragon Ball Fighting Game
* [⁠Cut the Rope Home](https://ctrhome.github.io/play/) - Cut the Rope Games
* [Club Penguin Legacy](https://play.cplegacy.com/) or [Club Penguin Journey](https://cpjourney.net/) - ⁠Club Penguin Revivals / [Servers](https://penguintrack.com/)
* [Snubby](https://rentry.co/FMHYB64#sr-game) - Browser Slime Rancher
* [CelesteClassic](https://maddymakesgamesinc.itch.io/celesteclassic) - Full Classic Celeste
* [TENNIS!](https://snek-vunderkind.vercel.app/games/tennis.html) - JavaScript Pong
* [SpaceCadetPinball](https://pinball.alula.me/) - Browser Space Cadet Pinball
* [PlayAnyPage](https://playanypage.com/) or [KickassApp](https://kickassapp.com/) - Turn Webpages into Games
* [Google Snake Mods](https://googlesnakemods.com/) / [Discord](https://discord.gg/NA6vHg62An) / [GitHub](https://github.com/DarkSnakeGang/GoogleSnakeModLoader), [Fluppy](https://fluppy.pages.dev/), [Play Snake](https://playsnake.org/) or [Snake-Game](https://www.onemotion.com/snake-game/) - Snake Style Games
* [⁠LEGO Island Web Port](https://rentry.co/FMHYB64#bli) - Browser LEGO Island
* [Rayman Legends Beatbox](https://rentry.co/FMHYB64#rmb) - Browser Rayman Legends Beatbox
* [Lain Game](https://laingame.net/) - Lain Game Browser Emulator
* [You Have Not Died Of Dysentery](https://woe-industries.itch.io/you-have-not-died-of-dysentery) - Oregon Trail with Alt Dysentery Mechanics
* [⁠Glider 4.0](https://dbohdan.github.io/glider/) - Browser Glider 4.0 (1991) + Room Editor / [GitHub](https://github.com/dbohdan/glider)
* [⁠Hotfix](https://www.hotfix.fun/) - WarioWare-Style 'Hot-Fix' Micro-Game
* [The Circle](https://the-circle.app/) - Dodge Circles
* [Polka Dot Game](https://www.polkadotgame.com/) - Dodge & Eat Dots
* [Launch Ball](https://launchball.sciencemuseum.org.uk/) - Physics Game w/ Map Creator
* [⁠SUMIKIRI](https://sumikiri.vercel.app/) - Hack-And-Slash Game / [Docs](https://thvariableyt.github.io/SUMIKIRI-/) / [GitHub](https://github.com/ThVariableYT/SUMIKIRI-/)
* [Spinner](https://hyperspace-wizard.itch.io/spinner) - Spinner Timing Game
* [Ehmorris](https://ehmorris.com/lander/) - Spaceship Landing Game
* [⁠HALDANE-4](https://haldane4.denisbondare.com/) - ASCII Horror Game
* [Dino Swords](https://dinoswords.gg/) - Chrome Dino With Weapons
* [Rooms](https://rooms.xyz/) - Room Design Game
* [⁠Crazy Cattle 3D](https://crazycattle3d.github.io/) - Sheep Battle Royale
* [Haxball](https://www.haxball.com/) - Physics-Based Soccer
* [⁠Minigolfle](https://minigolfle.com/) - Browser Mini Golf
* [⁠Pen Fight](https://www.penfight.xyz/) - Pen Fight Game
* [Mexican Train](https://mexicantrain.online/) - Domino Train Game / Requires Sign-Up
* [The Multiverse](https://across-multiverse.com/) - Universe Exploration Game
* [⁠Messenger](https://messenger.abeto.co/) - Relaxing 3D Delivery Game
* [Starshine Legacy](https://starshine-legacy.starstable.com/index.html) - 3D Browser Mystery Game
* [Neopets](https://www.neopets.com/), [tamaNOTchi](https://tamanotchi.world/) or [Marapets](https://www.marapets.com) - Virtual Pet Games / Requires Sign-Up
* [Gaia Online](https://www.gaiaonline.com/) - Anime Virtual Pet / Requires Sign-Up
* [Edu-Games](https://www.edu-games.org/) - Educational Games

***

## ▷ Multi-Game Sites

* ⭐ **[Flash Arch](https://flasharch.com/en)** - Browser Game Aggregator / [Discord](https://discord.com/invite/guQ9Afn)
* ⭐ **[Kongregate](https://www.kongregate.com/)** - Browser Game Aggregator
* ⭐ **[Crazy Games](https://www.crazygames.com/)** - Browser Game Aggregator
* ⭐ **[⁠GamesFrog](https://gamesfrog.com/)** - Browser Game Aggregator
* ⭐ **[Flashpoint](https://flashpointarchive.org/)** - Flash Game Archive App / [Play Online](https://ooooooooo.ooo/browse) / [Discord](https://discord.gg/Z4gGtJvvn8)
* ⭐ **[Flash Museum](https://flashmuseum.net/)** - Browser Game Aggregator
* ⭐ **Flash Tools** - [Flash Emulator](https://ruffle.rs/) / [Clean Builds](https://github.com/darktohka/clean-flash-builds/) / [Mobile](https://github.com/ruffle-rs/ruffle-android)
* [⁠wasm.rip](https://wasm.rip/) - Browser PC Game Ports / [Discord](https://discord.gg/uubyGYPHQw) / [GitHub](https://github.com/wasmdotrip/wasm.rip)
* [Ported2Browser](https://ported2browser.com/) - Browser PC Game Ports
* [Arcadia](https://arcadia.baby/) - Browser PC Game Ports / Aggregator
* [⁠Fancade](https://play.fancade.com/) - Browser Game World / Creator
* [Andkon](https://andkon.com/arcade/) - Browser Game Aggregator
* [Addicting Games](https://www.addictinggames.com/) - Browser Game Aggregator
* [Game-Game](https://game-game.com/) - Browser Game Aggregator
* [Flash Library](https://rentry.co/FMHYB64#software-library-flash) - Browser Game Aggregator
* [Y8](https://www.y8.com/) - Browser Game Aggregator
* [Alfy](https://www.alfy.com/) - Browser Game Aggregator
* [⁠Plays.org](https://plays.org/) - Browser Game Aggregator
* [Miniplay](https://www.miniplay.com/) - Browser Game Aggregator
* [Poki](https://poki.com/) - Browser Game Aggregator
* [Quenq](https://quenq.com/) - Browser Game Aggregator / [Discord](https://discord.com/invite/9dFx9kKQS6)
* [⁠Flockyard](https://flockyard.pages.dev/) - Browser Game Aggregator
* [Snokido](https://www.snokido.com/) - Browser Game Aggregator
* [FreeGames](https://freegames.org/) - Browser Game Aggregator
* [GamezHero](https://www.gamezhero.com/) - Browser Game Aggregator
* [Web Games](https://webgames.me/) - Browser Game Aggregator
* [Yandex Games](https://yandex.com/games/), [PlayHob](https://playhop.com/) or [All Web Games](https://allwebgames.com/) - Browser Game Aggregator
* [yell0wsuit](https://yell0wsuit.page/games.html) - Browser Game Aggregator
* [⁠Play Games](https://www.play-games.com/) - Browser Game Aggregator / [Discord](https://discord.com/invite/JBShgaFPyD)
* [GamePix](https://www.gamepix.com/) - Browser Game Aggregator
* [⁠Gameflare](https://www.gameflare.com/) - Browser Game Aggregator
* [Friv](https://www.friv.com/) - Browser Game Aggregator / [Old Site](https://www.friv.com/old/)
* [⁠GamePuma](https://gamepuma.com/) - Browser Game Aggregator
* [RoundGames](https://www.roundgames.com/) - Browser Game Aggregator
* [⁠Agame](https://www.agame.com/), [2](https://games.co.uk/), [3](https://www.gamesgames.com/) - Browser Game Aggregator
* [Flash by Night](http://www.flashbynight.com/) - Browser Game Aggregator
* [FlashLegacy](https://www.flashlegacy.com/) - Browser Game Aggregator
* [⁠Web Design Museum](https://www.webdesignmuseum.org/flash-games) - Browser Game Aggregator
* [iogames.space](https://iogames.space/) - Browser Game Aggregator
* [IOGames](https://iogames.party/) - Browser Game Aggregator
* [Kevin Games](https://kevin.games/) - Browser Game Aggregator
* [TheBestarcade](https://html5.thebestarcadescript.com/) - Browser Game Aggregator
* [AlbinoBlackSheep](https://www.albinoblacksheep.com/games/) - Browser Game Aggregator
* [r/WebGames](https://reddit.com/r/WebGames) - Browser Games Subreddit
* [UB66](https://ub66.vercel.app/) - Browser Game Aggregator / Gmail Design
* [⁠Playlin](https://playlin.io/) or [⁠Listdle](https://listdle.com/) - Daily Game Aggregators
* [Spatial](https://www.spatial.io/) - 3D Browser Games
* [Curated PICO-8](https://nerdyteachers.com/PICO-8/Games/) - PICO-8 Browser Games
* [TIC-80 Games](https://tic80.com/play/games/top) - TIC-80 Browser Games
* [Noel Friedrich](https://www.noel-friedrich.de/terminal/) - Browser Terminal Games
* [ABA Games](https://www.asahi-net.or.jp/~cs8k-cyu/browser.html) - Single Button Games
* [Cool Math Games](https://www.coolmathgames.com/) - Educational Browser Games

***

## ▷ Indie Browser Games

* 🌐 **[Browser Craft](https://browsercraft.com/)** - Indie Browser Game Index / Tracker
* 🌐 **[⁠/r/ioGames Index](https://www.reddit.com/r/IoGames/wiki/index/)** - .io Game Index
* ⭐ **[Newgrounds](https://www.newgrounds.com/games)** - Indie Games / Community Developed
* ⭐ **[Armor Games](https://armorgames.com/)** - Indie Games / Official Publisher
* ⭐ **[Nitrome](https://www.nitrome.com/)** - Indie Games / In-House Dev Team
* ⭐ **[itch.io web games](https://itch.io/games/free/platform-web)** - Indie Games / Community Developed / [Game Charts](https://itchdb.info/) / [Discord](https://discord.gg/qDaYeXPsRK)
* [Js13kGames](https://js13kgames.com/games) - Indie Browser Game Competition
* [Deepnight](https://deepnight.net/) - Indie Games / In-House Dev Team
* [watabou](https://watabou.itch.io/), [2](https://watabou.github.io/) - Indie Games / In-House Dev Team
* [DAN-BALL](https://dan-ball.jp/en/) - Indie Games / In-House Dev Team
* [⁠Games by Will](https://games-by-will.com/) - Indie Games / In-House Dev Team
* [indie.fu](https://indie.fun/) - Indie Games / Community Developed
* [Kindanice](https://kindanice.itch.io/) - Indie Games / itch.io Developer
* [Graeme Borland](https://graebor.itch.io/) - Indie Games / itch.io Developer
* [Jezzamon](https://jezzamon.itch.io/) - Indie Games / itch.io Developer
* [⁠Donut 80](https://www.donut80.com/) - Donut Games 8-Bit Demakes
* [⁠heyVR.io](https://heyvr.io/) - Browser VR Games / [Discord](https://discord.gg/tjbmKKH)

***

## ▷ Unblocked Games

* **Note** - These are browser game collections that should be unblocked in most places.

***

* 🌐 **[⁠UBGHub](https://ubghub.org/)** - Index of Unblocked Game Sites / [Discord](https://discord.gg/7CMSEmzBDC)
* ⭐ **[Selenite](https://selenite.cc/)**, [2](https://selenite.skysthelimit.dev/), [3](https://selenite.skys.day/) - Browser Games / Ports / [Discord](https://discord.gg/7jyufnwJNf)
* ⭐ **[mizu](https://mizumath.com/study.html)** - Browser Games / [Discord](https://discord.gg/MwKRJkJrJB)
* [⁠Obsidian](https://playobsidian.com/store) - Browser Games / Ports
* [Ivy](https://ivy.rest/) - Browser Games / Ports / [Discord](https://discord.gg/ivyubg)
* [Truffled](https://truffled.lol/g) - Browser Games / Ports / [Discord](https://discord.com/invite/truffled)
* [fern](https://fern.best/) - Browser Games / Ports / [Discord](https://discord.com/invite/TV2tWzSU7x)
* [UBG365](https://ubg365.github.io/) - Browser Games
* [GN-Math](https://gn-math.dev/) - Browser Games / Ports / use Adblocker / [Discord](https://discord.com/invite/D4c9VFYWyU)

***

## ▷ Party / Multiplayer

* ⭐ **[NetGames](https://netgames.io/)** - Multiple Games / [Discord](https://discord.com/invite/chgD7WF)
* ⭐ **[Gidd.io](https://gidd.io/)** - Multiple Games / [Discord](https://discord.com/invite/gmt2d69DP7)
* ⭐ **[Gartic Phone](https://garticphone.com/)** - Telephone Game / [Discord](https://discord.gg/gartic)
* ⭐ **[skribbl](https://skribbl.io/)** / [Extra Features](https://typo.rip/) / [GitHub](https://github.com/toobeeh/skribbltypo), [DrawBattle](https://drawbattle.io/) / [Discord](https://discord.gg/D6aHB4hRhK), [Sketchful](https://sketchful.io/) / [Subreddit](https://reddit.com/r/Sketchful) / [Discord](https://discord.gg/MEvtMCv), [⁠DrawWars](https://drawwars.io/), [Drawize](https://www.drawize.com/) or [Gartic](https://gartic.io/) - Drawing / Guessing Game / Multiplayer
* [⁠GuessMe](https://guessme.io/) - Majority Answers Guessing Game / [Discord](https://discord.gg/U9YbWWBJn5)
* [⁠GamingCouch](https://gamingcouch.com/) / [Discord](https://discord.gg/UqSX9ZGz5u), [⁠Doot](https://doot.games/) or [Couchplay](https://www.couchplay.tv/index_en.php) - Multiplayer Couch Gaming / Phone + Gamepad Controller Games
* [⁠What's A Mook?](https://whatsamook.games/) - Multiplayer / Party Games / [Discord](https://discord.com/invite/NM7x5R6)
* [Billiards Pool Game](https://billiards.tailuge.workers.dev/lobby) - Multiplayer 3D Billiards, Pool and Snooker / [GitHub](https://github.com/tailuge/billiards)
* [⁠Tough Love Arena](https://toughlovearena.com/) - Multiplayer Browser Fighting Game / [Discord](https://discord.gg/gMBRaUPDT7)
* [AWBW](https://awbw.amarriner.com/) - Multiplayer Browser Advance Wars / [Discord](https://discord.com/invite/rPpWT2x)
* [PandaBomber](https://pandabomber.gg/) or [Game Of Bombs](https://gameofbombs.com/) / [Discord](https://discord.gg/YFJCCxkdFZ) - Multiplayer Bomberman Style Games
* [Windage](https://windage.online/) or [Scorch2000](http://www.scorch2000.com/) - Multiplayer Artillery Battle Games / Scorched Earth Remakes
* [⁠RocketGoal](https://rocketgoal.io/) - Rocket-League Style Game / [Discord](https://discord.com/invite/MjHEyuhMuG)
* [Golf Party](https://golfparty.io/), [Mini Golf Club](https://minigolfclub.io/) or [⁠putt.day](https://putt.day/) - Multiplayer Mini-Golf Games
* [⁠Multigolf](https://multi.golf/) - Multi-Screen Multiplayer Mini Golf
* [Slither.io](http://slither.com/io) - Grow the Longest Worm
* [⁠Neon Wardens](https://neonwardens.com/) - Multiplayer Elemental Tower Defense 
* [Make It Meme](https://makeitmeme.com/) - Meme Party Game / [Discord](https://discord.gg/t3GZmuQndv)
* [Sigmally](https://one.sigmally.com/) / [Discord](https://discord.com/invite/4j4Rc4dQTP) or [agar.io](https://agar.io/) - Become the Biggest Circle
* [Hexar.io](https://www.hexar.io/) or [splix.io](https://splix.io/) - Control the Map
* [Powerline.io](https://powerline.io/) - Multiplayer Snake
* [mope.io](https://mope.io/) - Become the Biggest Animal / [Discord](https://discord.com/invite/nQAVB9c)
* [TagPro](https://tagpro.koalabeast.com/) - Multiplayer Capture the Flag / [Discord](https://discord.com/invite/hhW3MDzrt3)
* [Bloob.io](https://bloob.io/) - Multiple Games
* [Yucata](https://www.yucata.de/en/) - Multiple Games
* [⁠GaleraGames](https://galeragames.com/) - Multiple Games
* [Foony](https://foony.com/) - Multiple Games
* [⁠Pomme](https://pomme.us/) - Image Pairing Game
* [Pixoguess](https://pixoguess.com/) - Guess Pixelated Images / [Discord](https://discord.gg/Rbu8uGCyM6)
* [Tensor Trust](https://tensortrust.ai/) - AI Prompting Multiplayer Skill Game / [Discord](https://discord.com/invite/9R2PaHf4RG)
* [AI Bingo](https://ai-bingo.lipsumar.io/) - AI Art Guessing Games
* [Deeeep.io](https://deeeep.io/) - Multiplayer Feeding Frenzy Games / Requires Sign-Up
* [fsh.zone](https://fsh.zone/) - Multiplayer Fishing Game / [Discord](https://discord.com/invite/FKEzJSf)
* [⁠Wizard Arena Online](https://wizardarenaonline.com/) - Multiplayer Survivors-Style Game
* [Moo Moo](https://moomoo.io/) - Multiplayer Survival Game
* [Really Boring Website](https://really.boring.website/) - Online Scattergories
* [Betrayal](https://betrayal.io/) - Among Us Clone
* [Death by AI](https://deathbyai.gg/) - Survival Plan Game / [Discord](https://discord.com/invite/fJ6K66TXUe)
* [Smash Karts](https://smashkarts.io/) - Kart Battles
* [Spacewar!](https://www.masswerk.at/spacewar/) - All 11 Versions / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/spacewar.md)
* [tix.tax](https://tix.tax/) - Tic-Tac-Toe

***

## ▷ Browser Minecraft

* 🌐 **[Top Eaglercraft Servers](https://topeaglerservers.com/)** - Public Eaglercraft Server List
* ⭐ **[Eaglercraft](https://eaglercraft.com/)** - Browser-Based Minecraft / [Discord](https://discord.gg/yxpa55BahB) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/eaglercraft-note.md)
* [q13x's Distros](https://eaglercraft.q13x.com/) - Custom Eaglercraft Clients
* [Eaglercraft.dev](https://eaglercraft.dev/) - Eaglercraft Client Directory & Launcher
* [WebMC](https://webmc.xyz/), [2](https://webmc.colbster937.dev/), [3](https://webmc-launcher.vercel.app/) - Eaglercraft Multi-Version Launcher
* [EaglerCraftX](https://client.eaglercraft.win/) - Eaglercraft Mirror / Alt Versions
* [MessCraft](https://mess.eu.org/) - Eaglercraft Server Network / [Discord](https://discord.com/invite/kbzUdZQWgd)
* [Hiracraft](https://craft.hira.im/) - Eaglercraft Mirror
* [Classic Launcher](https://radmanplays.github.io/classic-launcher/) or [Minecraft Classic](https://classic.minecraft.net/) - Browser-Based Pre-Classic / Classic Minecraft
* [ClassiCube](https://www.classicube.net/) - Browser-Based Minecraft Clone / [Discord](https://discord.com/invite/DvYYyRw) / [GitHub](https://github.com/UnknownShadow200/ClassiCube)
* [Bloxd](https://bloxd.io/) - Browser-Based Minecraft Clone / [Texture Editor / Assets](https://www.bloxdforge.com/) / [Discord](https://discord.com/invite/vwMp5y25RX)
* [MiniBlox](https://miniblox.io/) - Browser-Based Minecraft Clone / [Discord](https://discord.com/invite/nAwzkUJNmb)
* [EaglerForge](https://eaglerforge.github.io/) - Eaglercraft Mod Loader
* [EaglerForge Builder](https://eaglerforge-builder.vercel.app/) or [EaglerForgeBuilderNew](https://eaglerforge.github.io/EaglerForgeBuilderNew/) - Create Eaglercraft Mods
* [EaglercraftXServer](https://modrinth.com/organization/eaglercraftxserver) - Improved Eaglercraft Server Tool / [GitHub](https://github.com/lax1dude/eaglerxserver)

***

## ▷ Text Adventures

* **Note** - Oldschool text adventure games are known for being [unforgiving](https://www.ifwiki.org/Cruelty_scale), but you can usually find solutions / guides online. You can also try feeding the text to [AI chatbots](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/ai#wiki_.25B7_online_chatbots), which can be both helpful and amusing.

***

* 🌐 **[IFWiki](https://www.ifwiki.org/)** - Interactive Fiction Encyclopedia / Resources
* ⭐ **[IFDB](https://ifdb.org/)** - Text Adventures
* [Mudlet](https://www.mudlet.org/) - Text Adventure Platform / [Discord](https://discord.com/invite/kuYvMQ9) / [GitHub](https://github.com/Mudlet/Mudlet)
* [IFWizz](https://ifwizz.de/if-en.html) - Text Adventures
* [IFArchive](https://www.ifarchive.org/) - Text Adventures
* [Web Adventures](https://www.web-adventures.org/) - Text Adventures
* [Seedship](https://philome.la/johnayliff/seedship/play/index.html) - Text Adventures
* [TextAventures](https://textadventures.co.uk/) - User-Made Text Adventures
* [AI Dungeon](https://aidungeon.com/) - Open World Text RPG / [Subreddit](https://www.reddit.com/r/AIDungeon/) / [Discord](https://discord.com/invite/HB2YBZYjyf),
* [WrittenRealms](https://writtenrealms.com/), [Genesis](https://www.genesismud.org/), [Fateful Quest](https://fateful.quest/) or [Level 13](https://nroutasuo.github.io/level13/) - Individual Adventures
* [⁠Planedrift](https://planedrift.app/) - Web-Based Text Adventure Player
* [Muds](https://muds.fandom.com/wiki/) - Text Adventure ROMs
* [Obsessively Complete Infocom Catalog](https://eblong.com/infocom/) - Interactive Fiction Archive / Downloads
* [SolutionArchive](https://solutionarchive.com/) - Text Adventure Solutions

***

## ▷ Shooter

* ⭐ **[Play-CS](https://play-cs.com/)** - Browser Counter-Strike 1.6
* ⭐ **[NZP](https://nzp.gay/)** - Browser Retro Zombies Recreation
* ⭐ **[Krunker.io](https://krunker.io/)**, [2](https://browserfps.com/) - PvP FPS
* [Survev.io](https://survev.io/), [ZombsRoyale.io](https://zombsroyale.io/) or [Suroi](https://suroi.io/) / [Discord](https://discord.com/invite/j8pPtMa843) / [GitHub](https://github.com/HasangerGames/suroi) - Top-Down Battle Royale / Survev.io Based / [Discord](https://discord.gg/75RAK3p3K2)
* [OpenArena Live](https://kosmi.io/openarena) or [Q1K3](https://play.js13kgames.com/q1k3/) - Quake Inspired Games
* [⁠Quakelike](https://leereilly.net/quakelike/) - Quake w/ Procedurally Generated Levels / [GitHub](https://github.com/leereilly/quakelike)
* [WebLiero](https://www.webliero.com/) - Multiplayer Liero Clone
* [⁠Voxiom](https://voxiom.io/) - Minecraft Inspired PVP FPS / [Discord](https://discord.gg/GBFtRcY)
* [Debug Survivor](https://debug-survivor.leek.io/) - Dev Themed Roguelike Shooter
* [⁠Redcoats](https://redcoats.io/) - Revolutionary War PVP FPS
* [Venge](https://venge.io/) - PvP FPS
* [ev.io](https://ev.io/) - PvP FPS
* [⁠StickFrag](https://stickfrag.com/) - PvP FPS
* [Deadshot](https://deadshot.io/) - PvP FPS
* [LolShot](https://lolshot.io/) - PvP FPS
* [⁠Kirka.io](https://kirka.io/) - PvP FPS
* [ShellShock](https://www.shellshock.io/) - PvP FPS
* [MiniRoyale](https://miniroyale.io/) - Battle Royale Game
* [Hypersomnia](https://play.hypersomnia.io/) - Top-Down Shooter / [GitHub](https://github.com/TeamHypersomnia/Hypersomnia)
* [Copter.io](https://copter.io/) - Top-Down Copter Battle
* [Gats.io](https://gats.io/) - Top-Down Battle Royale / [Discord](https://discord.gg/8Tspptdupm)
* [Operius](https://mors-games.itch.io/operius) - Space Shooter
* [Galaxies](https://playcanv.as/p/Ikq6Uk6A/) - Space Combat Game
* [MK48](https://mk48.io/) - Ship Combat Game / [Discord](https://discord.com/invite/YMheuFQWTX) / [GitHub](https://github.com/SoftbearStudios/mk48)
* [Tanki](https://tankionline.com/) or [Diep](https://diep.io/) - Online Team VS Team Tank Games
* [webXash](https://x8bitrain.github.io/webXash/) - Half Life Demo

***

## ▷ Platformer

* ⭐ **[Bonk](https://bonk.io/)** - Multiplayer Physics Game
* ⭐ **[TotalJerkFace](https://totaljerkface.com/)** - Happy Wheels & Other Games
* ⭐ **[Line Rider](https://www.linerider.com/)** - Draw Sled Tracks
* [LOLBeans](https://lolbeans.io/) - Fall Guys Clone
* [⁠Surfd](https://surfd.net/) - CS:Source-Style Surfing / [Discord](https://discord.gg/D5CYH7SBs6)
* [Free Rider HD](https://www.freeriderhd.com/) - Draw / Race Bike Tracks
* [Raptjs](https://madebyevan.com/rapt/) or [Synesthesia in Space](http://synesthesiagame.com/) - Puzzle Platformer
* [⁠Vector](https://vector.game/) - 2D Platformer
* [Pixel Run](https://pixelrun.localplayer.dev/) - 2D Pixel Runner / Platformer / [Discord](https://discord.gg/QZKEVEuFbh)
* [⁠Pixel Quest RPG](https://thvariableyt.github.io/Pixel-Quest-Deluxe/) - 2D Platformer / [GitHub](https://github.com/ThVariableYT/Pixel-Quest-Deluxe)
* [Tales of Dorime](https://dorime.udany.net/) - 2D Platformer
* [PrinceJS](https://princejs.com/) - Prince of Persia

***

## ▷ Racing / Driving

* 🌐 **[⁠drifted](https://www.drifted.com/)** - Drifting-Focused Browser Games
* ⭐ **[Mario Kart PC](https://mkpc.malahieude.net/mariokart.php)** - Browser SNES Style Mario Kart / Multiplayer / [Custom Maps](https://mkpc.malahieude.net/creations.php)
* ⭐ **[Slope Plus](https://coweggs.itch.io/slope-plus)** - Downhill Ball Game
* [⁠PolyTrack](http://kodub.com/apps/polytrack) - TrackMania Inspired Browser Game w/ Community Tracks / [Track Codes / Sharing](https://www.polytrackcodes.com/) / [Subreddit](https://www.reddit.com/r/PolyTrack/) / [Discord](https://discord.com/invite/NqEwseAcZ9)
* [racing-game](https://racing.pmnd.rs/) - Driving Game / Requires Sign-Up / [Discord](https://discord.gg/dQW7fDmaAG) / [GitHub](https://github.com/pmndrs/racing-game)
* [The Race](https://therace.montblanclegend.com/), [2](https://therace.montblancexplorer.com/) - Driving Game
* [Road Rash](https://roadrash.pages.dev/) - Road Rash Adaptation ⁠
* [⁠Swervle](https://swervle.com/) - Daily Racing Game / [Discord](https://discord.com/invite/sSP8ZEJ9Pn)
* [slow roads](https://slowroads.io/) - Driving Game
* [JoeDangerTheGame](https://joedangerthegame.com/) - Trials Inspired Game

***

## ▷ Simulation

* 🌐 **[Sports Games](https://rentry.co/c7zwkv9t)** - Mock Sports Draft Game Index
* [⁠IsoCity](https://iso-city.com/) - City Building Game / [GitHub](https://github.com/amilich/isometric-city)
* [IsoCoaster](https://iso-coaster.com/) - Theme-Park Building Game / [GitHub](https://github.com/amilich/isometric-city)
* [HatTrick](https://www.hattrick.org/) - Multiplayer Football League Manager
* [⁠MatchSimulator](https://matchsimulator.com/) - Football League Simulator
* [FSHistory](https://s-macke.github.io/FSHistory/) - Play Classic Flight Simulator
* [⁠Ride Simulator](https://sims.willby.info/) - Disney Ride Control Simulators
* [Hacker Wars](https://hackerwars.io/) - Hacking Simulators
* [Sim CB](https://benoitessiambre.com/macro.html) - Central Bank Simulator
* [Orbity](https://orbity.io/game.php) - Spaceship Launching Game
* [⁠Chaser Dot](https://play.chaserdot.com/) - Live Storm Chase Simulation Game
* [Plane Food Simulator](https://sheepandram.itch.io/pfs2021) - Plane Food Eating Game
* [Alternate History Simulator](https://abw.blue/) - Write Alternate History
* [NationStates](https://www.nationstates.net/) - Nation Simulation Game / [Scripts](https://hare.kractero.com/)
* [Politics and War](https://politicsandwar.com/) - More Advanced Nation Building Simulation Game / [Discord](https://discord.com/invite/H9XnGxc)
* [GeoFS](https://www.geo-fs.com/geofs.php) - Plane Simulator
* [Money Simulator](https://simulator.money) - Money Simulator
* [BrantSteele](https://brantsteele.com/index.php) or [Simublast](https://www.simublast.com/) - Game Show Simulators

***

## ▷ RPGs

* ↪️ **[RPG / TTRPG Builders](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools/#wiki_.25B7_rpg_worldbuilding)**
* ↪️ **[ARPG / MMORPG Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools/#wiki_.25B7_arpg_.2F_mmorpg_tools)**
* [Fallen London](https://www.fallenlondon.com/) - Text-Based RPG
* [Yume Nikki Online Project](https://ynoproject.net/) - Multiplayer Yume Nikki / [Discord](https://discord.com/invite/fRG3AxUeKN)
* [⁠Stravaeger](https://stravaeger.com/) - Retro Survival Crafting RPG / [Discord](https://discord.gg/SV5rS8Xs6B)
* [Dynast](https://dynast.io/) - Survival Browser Game
* [Kingdom of Loathing](https://www.kingdomofloathing.com/) - Comedy RPG
* [Frasier Fantasy](https://edward-la-barbera.itch.io/frasier-fantasy) - Comedy RPG
* [Gridland](https://gridland.doublespeakgames.com/) - Grid Matching RPG
* [Backpack Hero](https://thejaspel.itch.io/backpack-hero) - Turn-Based RPG
* [Miniconomy](https://www.miniconomy.com/) - Economy Game
* [⁠OFF](https://off.zchr.org/) - Browser RPG
* [Forumwarz](https://www.forumwarz.com/) - Browser RPG
* [Dungeon Crawl](https://crawl.develz.org/) - Browser RPG
* [Isleward](https://www.isleward.com/), [2](https://bigbadwaffle.itch.io/isleward) - Browser RPG / Sign-Up Required
* [Hordes.io](https://hordes.io/) - Browser MMORPG / [Discord](https://discord.com/invite/hordes)
* [Aberoth](https://aberoth.com/) - Browser MMORPG
* [RPGMaker Game Archive](https://archive.org/details/rpgmaker-net-game-archive) - Collection of Games From RPGMaker

***

## ▷ Strategy

* ⭐ **[OpenFront](https://openfront.io/)** / [Wiki](https://openfront.wiki/) / [Subreddit](https://www.reddit.com/r/OpenFront/) / [Discord](https://discord.gg/k22YrnAzGp) / [GitHub](https://github.com/openfrontio/openfrontio), [⁠LANDS.io](https://lands.io/) / [Discord](https://discord.gg/landsio) or [Territorial.io](https://territorial.io/) / [Discord](https://discord.com/invite/pthqvpTXmh) - Conquest / War Style Games
* ⭐ **[Super Auto Pets](https://teamwood.itch.io/super-auto-pets)** - Pet Battle Game / [Resources](https://www.groundedsap.co.uk/)
* [⁠FreeCiv-Web](https://freecivweb.com/) - Civilization Remake / [GitHub](https://github.com/Lexxie9952/fcw.org-server)
* [⁠Gem Tower Defense](https://www.gemtowerdefense.com/) - Gem Combo-Style Tower Defense
* [⁠Littlewargame](https://littlewargame.com/) - Browser-Based RTS
* [⁠Feudal Wars](https://feudalwars.net/) - Browser-Based RTS / [Discord](https://discord.com/invite/SQFMnMK)
* [KDice](https://www.kdice.com/) - Multiplayer Dice War
* [War.app](https://war.app/) - Risk Clone
* [Neptune's Pride](https://np4.ironhelmet.com/) - Space Strategy Game
* [generals.io](https://generals.io/) - War Strategy Game
* [⁠Konkr.io](https://www.konkr.io/) - Turn-Based Kingdom Strategy Game
* [⁠Prince Chazz](https://princechazz.com/) - Chess-Style Roguelite

***

## ▷ Incremental / Idle

* 🌐 **[r/Incremental_Games](https://www.reddit.com/r/incremental_games/wiki/list_of_incremental_games)**, [Galaxy Click](https://galaxy.click/), [IncrementalDB](https://www.incrementaldb.com/) or [Almost Idle](https://almostidle.com/) - Incremental Games Indexes
* ⭐ **[Cookie Clicker](https://orteil.dashnet.org/cookieclicker/) / [2](https://orteil.dashnet.org/experiments/cookie/)** - Incremental Cookie Game
* ⭐ **Cookie Clicker Tools** - [Multiple Tools](https://github.com/CookieMonsterTeam/CookieMonster) / [Calculator](https://coderpatsy.bitbucket.io/cookies/cookies.html) / [Discord](https://discord.com/invite/cookie)
* [⁠PokéClicker](https://www.pokeclicker.com) - Incremental Pokémon Game / [Wiki](https://wiki.pokeclicker.com) / [Discord](https://discord.gg/a6DFe4p) / [GitHub](https://github.com/pokeclicker/pokeclicker)
* [The Thorp of Woodstock](https://cheerfulghost.github.io/civ-clicker/index.html) - Build a Civilization
* [BitBurner](https://bitburner-official.github.io/) - Incremental RPG
* [Progress Quest](http://progressquest.com/play/) - Idle RPG / [Discord](https://discord.com/invite/dz7MFNU)
* [Universal Paperclips](https://www.decisionproblem.com/paperclips/index2.html) - A Paperclip Creation Simulator
* [MousePoint](https://creativetechguy.com/mousepoint) - Incremental Mouse Movement Game
* [CandyBox](https://candybox2.github.io/) - Candy Eating Game
* [Particle Clicker](https://particle-clicker.web.cern.ch/) - Incremental Particle Physics Games
* [KittensGame](https://kittensgame.com/web/) - Incremental Kitten Maker
* [Incremancer](https://incremancer.gti.nz/) or [Danemancer](https://cirusdane.github.io/incremancer/) - Incremental Zombie Game
* [A Dark Room](https://adarkroom.doublespeakgames.com/) - Dark Room Survival Game
* [WarClicks](https://warclicks.com/) - Incremental War Game
* [Goblin Bet](https://goblin.bet/) - Bet on 1v1 Monster Fights
* [The First Alkahistorian](https://nagshell.github.io/elemental-inception-incremental/) - Incremental Elemental Game
* [FactoryIdle](https://factoryidle.com/) - Factory Idle Simulator
* [Antimatter Dimensions](https://ivark.github.io/) - Antimatter Idle Game / [Android](https://play.google.com/store/apps/details?id=kajfosz.antimatterdimensions) / [Discord](https://discord.gg/AntimatterDimensions)
* [Theory of Magic](https://mathiashjelm.gitlab.io/arcanum/) - Magic Idle Game
* [Succubox](https://www.glaielgames.com/succubox/) - Loot Box Idle Game
* [Swarm Simulator](https://www.swarmsim.com/) - Idle Bug Swarm Game

***

## ▷ Trivia / Guessing

* ⭐ **[GuessTheGame](https://guessthe.game/)** or [Gamedle](https://www.gamedle.wtf/) - Game Guessing Games
* [The Impossible Quiz](https://www.newgrounds.com/portal/view/365143) - Classic Quiz Browser Game
* [TriviaDuel](https://www.triviaduel.com/), [Fun Trivia](https://www.funtrivia.com/), [Sporcle](https://www.sporcle.com/), [uQuiz](https://uquiz.com/), [ARealMe](https://www.arealme.com/) or [JetPunk](https://www.jetpunk.com/) - Quiz / Trivia
* [QBReader](https://www.qbreader.org/play/mp/) or [⁠Protobowl](https://protobowl.com/) - Multiplayer Quiz Bowl Sessions
* [The Re-Ride](https://thereri.de/) - You Don't Know Jack: The Ride Remake / [Discord](https://discord.com/invite/89sgMHnDRB)
* [Salty Trivia](https://haitouch.itch.io/salty-trivia) - Comedy Style Trivia Game / [Discord](https://discord.gg/95JWgy9gue)
* [Online Jeopardy](https://jeopardy.app) - Multiplayer Jeopardy / [GitHub](https://github.com/howardchung/jeopardy)
* [FlightGuesser](https://flightguesser.com/) - Flight Path Guessing Game
* [Akinator](https://en.akinator.com/) - 20 Questions
* [⁠GuessMe](https://guessme.io/) - Majority Answers Guessing Game / [Discord](https://discord.gg/U9YbWWBJn5)
* [roughly](https://roughly.is/) - Daily Guessing Games
* [Amountle](https://www.amountle.dev/) - Daily Estimation Game
* [Buzzinga](https://buzzinga.io/) - Jeopardy Creator
* [Bestiefy](https://bestiefy.com/) - Friend Quizzes
* [WTM](https://whatthemovie.com/), [Moviedle](https://moviedle.xyz/), [Actorle](https://actorle.com/) / [TV](https://actorle.tv/), [Kino.wtf](https://www.kino.wtf/), [Flickle](https://flickle.app/), [⁠Flickle](https://www.flickle.co/) or [Framed](https://framed.wtf/) - Movie / TV Guessing
* [⁠Letterrankd](https://www.letterrankd.com/) - Letterboxd Ratings Guessing Game
* [Cinenerdle](https://www.cinenerdle.app/) - Movie Puzzles
* [BoxOfficeGA](https://boxofficega.me/) - Box Office Guessing
* [Scenewise](https://scenewise.io/) - Movie Scene Order Puzzle
* [⁠AniGuessr](https://aniguessr.com/) - Anime Guessing Game
* [AMQ](https://animemusicquiz.com/) - Anime Theme Song Guessing
* [ConnectTheStars](https://connectthestars.xyz/) or [Movie To Movie](https://movietomovie.com/) - Connect Stars through Movies
* [⁠Toon Tone](https://toontone.games/) - Cartoon Character Color Tone Guessing Game
* [Play Football](https://playfootball.games/) - Football Quizzes / Trivia
* [The Wiki Game](https://www.thewikigame.com/) or [WikiRacer](https://wikiracer.io/) - Wikipedia Exploration Games / [Automation Tool](https://www.sixdegreesofwikipedia.com/), [2](https://gitlab.com/johanbluecreek/wikiracer)
* [⁠FactorDay](https://factorday.com/) - Daily Wikipedia-Based Trivia / Crosswords
* [Catfishing](https://catfishing.net/) - Wiki Article Guessing Game
* [⁠Distrodle](https://distro.fedesito.me/) - Linux Distro Guessing Game
* [More or Less](https://moreorless.io/) - More or Less Guessing
* [Muzify](https://muzify.com/) (Sign-Up), [Musicle](https://musicle.app/), [Songdle](https://statt-land-song.ch/songdle), [⁠Whatsamusic](https://whatsamook.games/mu) / [Discord](https://discord.gg/NM7x5R6), [Bandle](https://bandle.app/), [Spotle](https://spotle.io/) or [Lofidle](https://lofidle.com/) - Music / Song Guessing Games
* [DanceMusic](https://dancemusic.wtf/) or [⁠EDMdle](https://edmdle.vercel.app/) - Electronic Music Guessing Games
* [⁠Musicle](https://musicle.fun/) - Daily Music Connections Game
* [⁠CluesBySam](https://cluesbysam.com/) - Clue Style Guessing Game
* [whatlang](https://whatlang.fun/) - Language Guessing Game / [GitHub](https://github.com/Inventoris/whatlang)
* [Poeltl](https://poeltl.nbpa.com/) - NBA Guessing Game
* [The Higher Lower Game](https://www.higherlowergame.com/) or [Google Feud](https://googlefeud.com/) - Guess What's Googled More
* [English Sandwich](https://englishsandwich.github.io/) - Guess Where Dishes are From
* [GunGuesser](https://gunguesser.com/) - Guess Where Historical Guns are From
* [Guess The Price](https://guesstheprice.net/) or [PricePoint](https://pricepoint.gg/) - Price Guessing Game
* [⁠Memorize Earth](https://memorizeearth.com/) - Jeopardy Style Geography Quiz
* [⁠WildGuesser](https://wildguesser.com/) or [Metazooa](https://metazooa.com/) - Animal Guessing Games
* [Pufferdle](https://pufferdle.com/) - Fish Guessing Game
* [ChessGuessr](https://www.chessguessr.com/) - Chess Style Guessing Game
* [⁠Slopcheck](https://slopcheck.co/) - AI vs. Real Image Guessing Game
* [⁠Dialed](https://dialed.gg/) - Color Memory Game
* [Huedle](https://huedle.com/), [WhatTheHex](https://yizzle.com/whatthehex/) or [Hexcodle](https://www.hexcodle.com/) - Hex Code Guessing Games
* [Nerdle](https://nerdlegame.com/), [Additional](https://additional.today/) or [Countle](https://www.countle.org/) - Math Guessing Games
* [⁠MCdle](https://www.mcdle.net/) or [Minecraftle](https://minecraftle.zachmanson.com/) - Minecraft Guessing Games
* [Gearoid Pokémon](https://gearoid.me/pokemon/), [Pokedle](https://pokedle.net/) or [Squirdle](https://squirdle.fireblend.com/) - Pokémon Guessing Games
* [Pokémon Infinite Heardle](https://nterrien.github.io/pkmn-infinite-heardle/) - Pokémon Music Guessing
* [LoLdle](https://loldle.net/) - League of Legends Guessing Games
* [Owdle](https://owdle.guessing.day/) - Overwatch Guessing Games
* [Guess The Year](https://guess-the-year.davjhan.com/) or [ChronoPhoto](https://www.chronophoto.app/) - Year Guessing Game
* [Wikitrivia](https://wikitrivia.tomjwatson.com/) - Guess Which Event Came First

***

## ▷ Rhythm

* ↪️ **[Rhythm Game Engines / Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools#wiki_.25B7_rhythm_tools)**
* [Web osu!mania](https://rentry.co/FMHYB64#wosu) - osu!mania Beatmaps / Web / [Discord](https://discord.com/invite/8zfxCdkfTx)
* [Taiko Web](https://rentry.co/FMHYB64#tnt) - Taiko no Tatsujin / Rhythm Game / Web
* [Rhythm Plus](https://rhythm-plus.com), [2](https://rhythmplus.io/) - Rhythm Game / Web / [Discord](https://discord.com/invite/ZGhnKp4) / [GitHub](https://github.com/henryzt/Rhythm-Plus-Music-Game)
* [Gpop.io](https://gpop.io/) - Rhythm Game / Multiplayer / Web
* [Bemuse](https://bemuse.ninja/) - Rhythm Game / Web / [Discord](https://discord.gg/aB6ucmx) / [GitHub](https://github.com/bemusic/bemuse)
* [Pulsus](https://www.pulsus.cc/play/) - 3x3 Letter Tile Rhythm Game / Web

***

## ▷ Tetris

* ⭐ **[TETR.IO](https://tetr.io/)** - Multiplayer Browser Tetris / [Plus](https://gitlab.com/UniQMG/tetrio-plus) / [Skin Database](https://you.have.fail/tetrioplus/) / [Stats](https://tsbeta.dan63.by/) / [Discord](https://discord.com/invite/tetrio) / [GitHub](https://github.com/tetrio/)
* [Jstris](https://jstris.jezevec10.com/) - Multiplayer Browser Tetris / [Plus](https://discord.gg/mtX8ek82xb) / [Skin Database](https://docs.google.com/spreadsheets/d/1xO8DTORacMmSJAQicpJscob7WUkOVuaNH0wzkR_X194/htmlview#)
* [Tetra eSports](https://tetraesports.com/) - Competitive Multiplayer Tetris / [Discord](https://discord.gg/6EFdcGuWKn)
* [⁠Techmino](https://github.com/26F-Studio/Techmino) - Multi-Mode Tetris Recreation
* [⁠Notris Foes](https://notrisfoes.com/) - Multiplayer Browser Tetris / [Discord](https://discord.com/invite/qBJeAKk)
* [⁠nestris](https://nestris.org/) - Multiplayer Browser Tetris / Practice
* [Apotris](https://akouzoukos.com/apotris/play/) - Customizable Browser Tetris w/ Responsive Controls / [Multi-Platform](https://akouzoukos.com/apotris) / [Source Code](https://gitea.com/akouzoukos/apotris)
* [Tetris](https://tetris.com/) - Browser Tetris
* [⁠LazyTetris](https://lazytetris.com/) - Browser Tetris
* [Tetr.js](http://farter.cn/tetr.js/) - Browser Tetris
* [First-Person Tetris](https://firstpersontetris.com/) - First Person Tetris
* [Sandtris](https://sandtris.com/) - Falling Sand Style Tetris
* [FOUR.lol](https://four.lol/) - Tetris Openers Wiki
* [Underdogs Cup Lounge](https://discord.gg/QCbC9cA) - Tetris Resources & Coaching Discord
* [Fumen](https://harddrop.com/fumen/) - Tetris Field Editor

***

## ▷ Pokémon

* ↪️ **[Pokémon Resources / Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools#wiki_.25B7_pokemon_tools)**
* ⭐ **[PokéRogue](https://pokerogue.net/)** - Pokémon Roguelike / [Wiki](https://wiki.pokerogue.net/start) / [Mobile](https://github.com/Admiral-Billy/Pokerogue-App) / [Subreddit](https://reddit.com/r/pokerogue/) / [Discord](https://discord.com/invite/uWpTfdKG49)
* ⭐ **[Pokémon Showdown](https://pokemonshowdown.com/)** - Online Pokémon Battles
* [DelugeRPG](https://www.delugerpg.com/) - Pokémon MMO
* [Pokemon Blaze Online](https://pokemonblazeonline.com/) - Pokémon MMO / [Discord](https://discord.com/invite/b3ZnXuf5fk)
* [Pokémon Revolution Online](https://pokemonrevolution.net/) - Pokémon MMO
* [⁠PokéOne](https://pokeonecommunity.com/) - Pokémon MMO / [Discord](https://discord.com/invite/bNYRTFn)
* [⁠PokéClicker](https://www.pokeclicker.com) - Incremental Pokémon Game / [Wiki](https://wiki.pokeclicker.com) / [Discord](https://discord.gg/a6DFe4p) / [GitHub](https://github.com/pokeclicker/pokeclicker)
* [⁠Pokelike](https://pokelike.xyz/) - Pokémon Roguelike / [Discord](https://discord.gg/YsakfWStYq)
* [PokéVoid](https://pokevoid.com/) - Pokémon Roguelike / PokéRogue Alt / [Discord](https://discord.gg/xsQummMK3H)
* [Pokemon Auto Chess](https://pokemon-auto-chess.com/) - Pokemon Style Teamfight Tactics / [Discord](https://discord.gg/6JMS7tr) / [GitHub](https://github.com/keldaanCommunity/pokemonAutoChess)
* [⁠PokéSurvivor](https://pokesurvivor.com/) - Pokémon-Style Vampire Survivors
* [TCG ONE](https://tcg.one/) - Online Pokémon Card Game / [Discord](https://discord.gg/MTBGxVE)

***

## ▷ GeoGuessr

* ⭐ **[Plonk It](https://www.plonkit.net/)** / [Discord](https://discord.gg/plonk-it-854419081813164042), **[Regionguessing](https://docs.google.com/spreadsheets/d/1UNvkoY-LaktF75nU_cP7-wVRAEvH3fSqVZet20HqxXA)**, [GeoTips](https://geotips.net/) / [Discord](https://discord.gg/svhWzU7FMa), [GeoHints](https://geohints.com/), [⁠GeoMetas](https://www.geometas.com/) or [Top Tricks](https://somerandomstuff1.wordpress.com/2019/02/08/geoguessr-the-top-tips-tricks-and-techniques/) - GeoGuessr Guides / Tips
* ⭐ **[Geotastic](https://geotastic.net/)** - Multiplayer GeoGuessr Alt / Requires Sign-Up
* ⭐ **[Globle](https://globle-game.com/)** - Country Hot-or-Cold Guessing Game / [Discord](https://discord.gg/Xpyy8dCr9g)
* [LearnableMeta](https://learnablemeta.com/) / [Discord](https://discord.gg/AcXEWznYZe) or [helloquiz](https://helloquiz.app/) / [Discord](https://discord.gg/td7bN9HKhX) - Geoguessr Practice Maps
* [Emily's GeoGuessr Tools](https://geo.emily.bz/) - GeoGuessr Tools
* [Geohub](https://www.geohub.gg/) - GeoGuessr Alt / Requires Google API
* [⁠GeoDuels](https://geoduels.io/) - Multiplayer GeoGuessr Alt
* [GuessWhereYouAre](https://guesswhereyouare.com/) - Multiplayer GeoGuessr Alt
* [OpenGuessr](https://openguessr.com/) - Multiplayer GeoGuessr Alt
* [⁠Maponica](https://maponica.com/) - Video-Based Multiplayer Geoguessr Alt
* [WorldGuessr](https://www.worldguessr.com/) - GeoGuessr Alt
* [FreeGuessr](https://freeguessr.com/) - GeoGuessr Alt
* [City Guesser](https://virtualvacation.us/guess) - Video-Based GeoGuessr
* [Quizzity](https://david-peter.de/quizzity/) or [⁠Sprawl Crawl](https://sprawlcrawl.com/) - City Guessing Games
* [⁠TVGuessr](https://www.tvguessr.garden/) - Guess Countries by TV Channels
* [Music Guessr](https://musicguessr.io/) - Guess Countries by Music
* [Back Of Your Hand](https://backofyourhand.com/) - Local GeoGuessr
* [⁠NYCGuessr](https://nycguessr.vercel.app/) - NYC Traffic Cam GeoGuessr
* [LostGamer](https://lostgamer.io/) - Video Game GeoGuessr
* [GTA V GeoGuessr](https://gta-geoguesser.com/) - GTA V GeoGuessr
* [Hyrule GeoGuessr](https://hyruleguessr.com/) - BOTW Hyrule GeoGuessr
* [⁠Anthropeum](https://anthropeum.com/) - Historical Artifact Guessing Game
* [Time Portal](https://www.eggnog.ai/entertimeportal), [⁠WenWare](https://wen-ware.com/) or [TimeGuessr](https://timeguessr.com/) - Historical Time-Period GeoGuessr
* [LanguageGuessr](https://languageguessr.io/) - Language GeoGuessr / Requires Sign-Up
* [Artifact Guesser](https://artifactguesser.com/) or [GeoArtwork](https://artsandculture.google.com/experiment/geo-artwork/wgEPVBAUiRVlEQ) - Guess Origins of Cultural Artifacts
* [MapGenerator](https://map-generator-nsj.vercel.app/) - GeoGuessr Map Generator
* [VirtualStreets](https://virtualstreets.org/) - Google Street Update Tracker

***

# ► [Gaming Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools)