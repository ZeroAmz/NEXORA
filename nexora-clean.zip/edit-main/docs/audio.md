***
***
**[◄◄ Back to Wiki Index](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/index)**
***
***

# ► Audio Streaming

## ▷ Streaming Apps

* 🌐 **[/music streaming/](https://rentry.co/musicstreaming)** or [Wiki Comparisons](https://wikipedia.org/wiki/Comparison_of_music_streaming_services) - Streaming Service Comparisons
* ↪️ **[Spotify Clients](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/audio/#wiki_.25BA_spotify_tools)**
* ↪️ **[YouTube Music Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/audio#wiki_.25B7_youtube_music_tools)**
* ↪️ **[YouTube Music Mobile](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android/#wiki_.25B7_youtube_music)**
* ⭐ **[⁠Limusic](https://simohypers.github.io/limusic/)** - YouTube Music Client / Windows, macOS, Linux / [GitHub](https://github.com/SimoHypers/limusic)
* [Sonora](https://sonorahq.org/) - YouTube Music Client / [Discord](https://discord.gg/a8N8Tx23rV) / [GitHub](https://github.com/nolight132/sonora)
* [Pear Desktop](https://github.com/pear-devs/pear-desktop) - YouTube Music Client / [Ad-Block Guide](https://github.com/pear-devs/pear-desktop/issues/4531)
* [BeatBoss](https://beatboss.thevolecitor.qzz.io/) - Cross-Platform Plugin-Based Player / [Web App](https://beatboss-web.thevolecitor.qzz.io/) / [GitHub](https://github.com/TheVolecitor/BeatBoss) / [Discord](https://discord.gg/85jnfZGfV5)
* [yewtube](https://github.com/mps-youtube/yewtube) - YouTube Music Client
* [⁠Meiro](https://meiro.elianiva.com/) - YouTube Music Client / [GitHub](https://github.com/elianiva/meiro)
* [Flow Desktop](https://github.com/Flow-Tube/Flow-Desktop) - YouTube Music Client
* [pulse](https://473999.net/pulse), [Kenku FM](https://www.kenku.fm/) / [GitHub](https://github.com/owlbear-rodeo/kenku-fm) or [Beatsync](https://www.beatsync.gg/) / [GitHub](https://github.com/freeman-jiang/beatsync) - Listen Together / Listening Parties
* [BetterSoundcloud](https://alirezakj.com/bsc/) - Soundcloud Client / Ad-Free / [GitHub](https://github.com/AlirezaKJ/BetterSoundCloud)
* [Nuclear](https://nuclearplayer.com/) - Streaming / [Discord](https://discord.com/invite/JqPjKxE) / [GitHub](https://github.com/nukeop/nuclear)
* [FunkWhale](https://funkwhale.audio/) - Decentralized Streaming Platform
* [Muffon](https://muffon.netlify.app/) - Streaming
* [⁠Squidify Desktop](https://github.com/kobayashi90/squidify-desktop) - Game & Anime Soundtracks Streaming App 

***

## ▷ Streaming Sites

* ⭐ **[YouTube Music](https://music.youtube.com/)** or [⁠Ytify](https://ytify.pp.ua/) / [Telegram](https://t.me/ytifytg) - YouTube Music WebUIs / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/audio#wiki_.25B7_youtube_music_tools)
* ⭐ **[Monochrome](https://monochrome.st/)** - Browser Music / Lossless / [Discord](https://monochrome.st/discord) / [GitHub](https://github.com/monochrome-music/monochrome)
* ⭐ **[⁠Octave](https://octavestreaming.com/)** - Browser Music / Lossless / Requires Discord / [Discord](https://discord.gg/5cZAbW3Tbg)
* ⭐ **[SoundCloud](https://soundcloud.com/)** or [⁠soundcloak](https://sc.maid.zone/) / [Instances](https://maid.zone/soundcloak/instances.html) - User-Made & User-Uploaded Songs / [Account Manager](https://github.com/Kuzuw/scam)
* ⭐ **[ArtistGrid](https://artistgrid.cx/)** / [GitHub](https://github.com/ArtistGrid/) or [⁠unmusic](https://unmusic.xyz/) - Unreleased
* [Spotify](https://open.spotify.com/) - Web Player / [Lyrics](https://github.com/mantou132/Spotify-Lyrics) / [Lyrics Script](https://greasyfork.org/en/scripts/377439)
* [Deezer](https://www.deezer.com/) - Browser Music / Requires Sign-Up / [Availability](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/deezer-availability.md)
* [Audiomack](https://audiomack.com/) - Browser Music
* [Pandora](https://www.pandora.com/) - Browser Music / US Only
* [⁠pointify](https://pointify.qzz.io/) - Browser Music
* [Jango](https://jango.com/) - Browser Music
* [SoundClick](https://www.soundclick.com/default.cfm) - Browser Music
* [⁠Arcod](https://player.arcod.xyz/) - Browser Music
* [Mixupload](https://mixupload.com/) - Browser Music
* [Tancpol](https://tancpol.net/) - Russian Music / Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators)
* [JioSaavn](https://www.jiosaavn.com/) or [Hayasaka](https://hayasaka.8man.in/) - Browser Music / [API](https://cyberboysumanjay.github.io/JioSaavnAPI/)
* [MTV REWIND](https://wantmymtv.xyz/) / [2](https://wantmymtv.org/) - Recreates MTV Experience from Different Eras
* [The 120 Minutes Archive](https://altmusictv.com/) - MTV's 120 Minutes Archive
* [Ballsack TV](https://bsky.app/profile/feed.ballsack.tv) - MTV Style User-Submitted Music Video Feed / [Discord](https://discord.gg/KT2Dht4zcZ)
* [⁠VersusMedia](https://watch.versusmedia.com/music-channel) - Independent Music Video Feed
* [Hype Machine](https://hypem.com/popular) - Rising
* [Bandcamp](https://bandcamp.com/discover/free-music) or [⁠Tent](https://forgejo.sny.sh/sun/Tent) - Free Music Release Platform
* [Mirlo](https://mirlo.space/) - Free Music Release Platform
* [Newgrounds Audio](https://www.newgrounds.com/audio) - User-Made Electronic Music
* [Audius](https://audius.co/) - User-Made Music
* [AudionautiX](https://audionautix.com/) - Mood-Based Streaming
* [LostMyspace](http://lostmyspace.com/) - Lost Myspace Songs
* [Openwhyd](https://openwhyd.org/) - Music Sharing Community / [Chrome](https://chromewebstore.google.com/detail/openwhyd-%E2%9C%9A-track/foohaghobcolamikniehcnnijdjehfjk)

***

## ▷ Genre Specific Streaming

* [The Urban Emporium](https://www.youtube.com/@theurbanemporium204/playlists) - Hip-Hop
* [MixtapeMonkey](https://mixtapemonkey.com/) - Hip-Hop / Mixtapes
* [DMO](https://dance-music.org/) - Electronic
* [Vapor Archive](https://vaporarchive.neocities.org/) - Vaporwave
* [Jamendo](https://www.jamendo.com/) or [Free Music Archive](https://freemusicarchive.org/) - Independent Music
* [Keygen Music](https://keygenmusic.tk/) - Keygen Music
* [Classical Music Only](https://classicalmusiconly.com/) or [Musopen](https://musopen.org/music/) - Classical Music
* [New Age Music](https://newage.one/) - New Age Music

***

## ▷ YouTube Music Tools

* ⭐ **[Better Lyrics](https://betterlyrics.org/)** / [Uploader](https://darkforcefreefire.github.io/unison-web/) / [Discord](https://discord.gg/UsHE3d5fWF) / [GitHub](https://github.com/better-lyrics/better-lyrics) or [YouLy+](https://github.com/ibratabian17/YouLyPlus) - Improved Lyrics Browser Extensions
* [Themesong](https://themesong.app/) or [BetterYTM](https://github.com/Sv443/BetterYTM) - Enhancement Extensions
* [YT Music Deleter](https://github.com/apastel/ytmusic-deleter) - Library Manager / Deleter / Windows, macOS, Linux
* [Spot Transfer](https://spot-transfer.vercel.app/), [Spotify2YoutubeMusic](https://github.com/mahdi-y/Spotify2YoutubeMusic) or [spotify_to_ytmusic](https://github.com/linsomniac/spotify_to_ytmusic) / [2](https://github.com/sigma67/spotify_to_ytmusic) - Spotify Playlist Importers
* [⁠TunesToTube](https://www.tunestotube.com/) - Easily Upload Songs to YouTube
* [YT Upload Clear](https://rentry.co/tv4uo) - Script to Clear Uploaded Songs

***

# ► Specialty Streaming

* ⭐ **[UCSB Cylinders](https://cylinders.library.ucsb.edu/index.php)** - Cylinder Audio Archive
* [Dream of the 90s](https://www.youtube.com/@Dreamofthe90s/playlists) - Obscure 90s
* [CitizenFreak](https://citizenfreak.com/) - Canadian Music
* [Irama Nusantara](https://www.iramanusantara.org/en) - Indonesian Music
* [DigLib](https://diglib.library.vanderbilt.edu/ama-browse.pl) - East African Recordings
* [Tasso Music](https://www.tassomusic.org/) - Early Modern Music
* [i78s](https://i78s.org/), [Archeophone](https://www.archeophone.org/html/languages/en/index.en.html), [CLPGS](https://www.clpgs.org.uk/) or [Tinfoil](https://www.tinfoil.com/) - Phonograph / Gramophone Recordings
* [FirstSounds](https://www.firstsounds.org/) - Oldest Music Recordings
* [Russian Records](https://www.russian-records.com/) - Russian Recordings
* [Measuring Polyphony](https://measuringpolyphony.org/) - Digital Encoding of Late Medieval Music

***

## ▷ Concerts / Live Shows

* ⭐ **[bt.etree](https://bt.etree.org/)** - Concert Recordings / Torrents
* ⭐ **[Bootleg.fm](https://bootleg.fm/)** - Bootleg Concert Recordings / Archive / [Discord](https://discord.gg/3yz4HNteuR)
* ⭐ **[hate5six](https://hate5six.com/)** - Concert Recordings
* ⭐ **[Tiny Desk Concerts](https://www.npr.org/series/tiny-desk-concerts/)** - Intimate Concerts at NPR Headquarters / [YouTube](https://www.youtube.com/@nprmusic)
* ⭐ **[setlist.fm](https://www.setlist.fm/)** - Setlist Database
* [OperaVision](https://operavision.eu/) or [OperaOnVideo](https://www.operaonvideo.com/) - Opera Recordings
* [r/MusicalBootlegs](https://www.reddit.com/r/MusicalBootlegs) or ["Slime Tutorials"](https://youtube.com/playlist?list=PLsIt5G4GJ27lxWP9Qi5N70zRSkJAT0ntc) - Broadway Show Recordings
* [JamBase](https://www.jambase.com/videos) - Concert Recordings
* [Relisten](https://relisten.net/) - Concert Recordings / [GitHub](https://github.com/relistennet)
* [DimeADozen](http://www.dimeadozen.org/) - Concert Recordings / Torrents
* [Guitars101](https://www.guitars101.com/) - Concert Recordings / Bootlegs
* [TheTradersDen](http://www.thetradersden.org/) - Concert Recordings / Torrents
* [Lossless Legs](https://www.shnflac.net/) - Concert Recordings / Torrents
* [etreedb](https://etreedb.org/) - Concert Recordings / Torrents
* [MuseBootlegs](https://www.musebootlegs.com/) - Bootleg Concert Recordings / Torrents
* [LiveBootlegConcert](https://livebootlegconcert.blogspot.com/) - Bootleg Concert Recordings / Torrents
* [Volume](https://volume.com/) - Live Cam Concerts
* [ConcertArchives](https://www.concertarchives.org/) or [⁠EntertainMe](https://www.entertainme.fun/) - Concert Tracking / Database
* [SongKick](https://www.songkick.com/) or [FindYourFest](https://www.findyourfest.com/) - Find Concerts / Music Festivals
* [Cadenza](http://www.cadenza.org/) - Find Classical / Contemporary Concerts
* [Konserthuset](https://www.konserthuset.se/en/play/) - Orchestra Recordings
* [WorldConcertHall](https://www.worldconcerthall.com/en/schedule-list/) - Concert Hall / Opera House Live Streams
* [ToolDriveProject](https://tooldriveproject.net/) - Tool Live Archive
* [RATM.live](https://ratm.live/) - Rage Against the Machine Live Archive
* [RHCPLiveArchive](https://www.rhcplivearchive.com/) - Red Hot Chili Peppers Live Archive
* [Radio Nowhere](https://rentry.co/FMHYB64#radio-nowhere) - Bruce Springsteen Concerts / Bootlegs
* [Phish.in](https://phish.in/) - Phish Live Archive / [Discord](https://discord.gg/KZWFsNN)

***

## ▷ DJ Mixes / Livesets

* ⭐ **[MixesDB](https://www.mixesdb.com/)** - DJ Mixes / Livesets / [Essentials List](https://rentry.co/dancemixbible/)
* ⭐ **[NTS Radio](https://www.nts.live/)** - DJ Radio Shows / [Interactive Tracklist](https://greasyfork.org/scripts/592656) / [Downloader](https://github.com/everdrone/nts) / [SoundCloud](https://rentry.co/ntssoundcloud) / [Mixcloud](https://www.mixcloud.com/NTSRadio/) / [Discovery Guide](https://rentry.co/musicdiscovery/#nts-radio)
* ⭐ **[BBC Radio 1 Essential Mix](https://rentry.co/musicdiscovery/#bbc-radio-1-essential-mix)** - BBC Radio 1 Essential Mix Archive + Guide / [Downloader](https://rentry.co/bbcemdl)
* ⭐ **[MiroPPB](https://miroppb.com/)** - A State of Trance Archive / DJ Mixes / [Downloader](https://rentry.co/asotdl)
* [TopDJMixes](https://topdjmixes.com/) - DJ Mixes / Livesets
* [⁠HD Mixtapes](https://hdmixtapes.org/) - DJ Mixes / Livesets
* [⁠BassBlog](https://bassblog.pro/) - DJ Mixes / Livesets
* [⁠TestPressing](https://www.testpressing.org/) - DJ Mixes / Livesets
* [GOA PsyTrance Livesets](https://rentry.co/FMHYB64#goa-psytrance-livesets) - DJ Mixes / Livesets
* [Rave Recording](https://rentry.co/FMHYB64#rave-library) - Rave Recordings / Archive

***

## ▷ Podcast Streaming

* ↪️ **[Android](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_android_podcasts_.2F_radio) / [iOS](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_ios_podcasts_.2F_radio)** - Podcast / Radio Apps
* ⭐ **[Spotify Podcasts](https://open.spotify.com/browse/podcasts)** - Podcast Streaming / Video Podcasts / [SponsorBlock](https://spotsponsorblock.org/) / [Companion](https://sebschaef.bitbucket.io/podify/) / [RSS Tool](https://github.com/Yetangitu/Spodcast) / [Video Download](https://rentry.co/spotifypodcast)
* ⭐ **[Pocket Casts](https://pocketcasts.com/)** - Cross-Platform Podcast Player / Playlists / Playback Controls / [Desktop App](https://pocketcasts.com/downloads/windows/)
* ⭐ **[Listen Notes](https://www.listennotes.com/)** - Podcast & Episode Search Engine / Curated Playlists / [API](https://www.listennotes.com/api/)
* [Apple Podcasts](https://podcasts.apple.com/) - Podcast Streaming / Discovery / Charts / Transcripts
* [Podcast Republic](https://www.podcastrepublic.net/) - Podcast Player / Playlists / Downloads / Custom RSS Feeds
* [Player FM](https://player.fm/) - Podcast Player / Discovery / Categories / Offline Listening
* [Podverse](https://podverse.fm/) - Open-Source Podcast Player / RSS Feeds / Podcasting 2.0 / Web & Mobile
* [Podbean](https://www.podbean.com/) - Podcast Streaming / Discovery / Hosting Platform
* [PodParadise](https://www.podparadise.com/) or [Podbay](https://podbay.fm/) - Browser-Based Podcast Players / Discovery
* [BBC Podcasts](https://www.bbc.co.uk/sounds/podcasts) - BBC Podcast Streaming / [Downloader](https://github.com/get-iplayer/get_iplayer)
* [Relay.fm](https://www.relay.fm/) - Independent Podcast Network / Technology & Creative Shows
* [Podchaser](https://www.podchaser.com/) - Podcast Database / Ratings / Reviews / Creator Credits
* [Podcast Index](https://podcastindex.org/) - Open Podcast Directory / Podcasting 2.0 / [API](https://podcastindex-org.github.io/docs-api/)
* [Podstatus](https://podstatus.com/charts) - Apple Podcasts & Spotify Rankings / Country & Category Charts
* [Rephonic](https://rephonic.com/graph) - Similar Podcast Discovery / Interactive Audience Graph
* [PodScripts](https://podscripts.co/) - Searchable Podcast Transcripts
* [jumbletop](https://jumble.top/) or [Pirate Podcast Feeds](https://piratefeeds.net/) - Premium Podcast Feed Indexes
* [PodcastToMP3](https://podcasttomp3.com/) - Search & Download Podcast Episodes / MP3
* [podcast-dl](https://github.com/lightpohl/podcast-dl), [PodcastBulkDownloader](https://github.com/cnovel/PodcastBulkDownloader), [PodDL](https://github.com/freshe/poddl) or [PodGrab](https://github.com/akhilrex/podgrab) - Podcast Downloaders / Archiving Tools
* [PinePods](https://pinepods.online/) - Self-Hosted Podcast Server / Multi-Device Sync / [GitHub](https://github.com/madeofpendletonwool/PinePods)
* [Grover](https://apps.microsoft.com/detail/9nblggh6c4bc) or [gPodder](https://gpodder.github.io/) - Desktop Podcast Clients
* [castero](https://github.com/xgi/castero) - Terminal-Based Podcast Client
* [EchoWalk](https://www.echowalk.com/) - Turn Articles & Webpages into Spoken Audio
* [PodSync](https://github.com/mxpv/podsync) or [PigeonPod](https://pigeonpod.cloud/) - Convert Video Channels & Playlists into Podcast RSS Feeds
* [OpenPodcast](https://openpodcast.dev/) - Podcast Analytics
* [Podnews](https://podnews.net/) - Podcast Industry News / Trends / New Releases

***

## ▷ Ambient / Relaxation

* ↪️ **[Android](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android/#wiki_.25B7_android_relaxation)** / **[iOS](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android/#wiki_.25B7_ios_relaxation)** - Ambient / Relaxation Mobile Apps
* ⭐ **[Drone Zone](https://somafm.com/player/#/now-playing/dronezone)**, **[NTS Slow Focus](https://www.nts.live/infinite-mixtapes/slow-focus)** or **[Music For Programming](https://musicforprogramming.net/latest/)** - Ambient Music Stations / Playlists
* ⭐ **[myNoise](https://mynoise.net/)** - Customizable Ambient Sound Mixer
* ⭐ **[Moodist](https://moodist.mvze.net/)** - Customizable Ambient Sound Mixer
* ⭐ **[Rainy Mood](https://www.rainymood.com/)** - Ambient Rain
* [Rainbow Hunt](https://rainbowhunt.com/) - Ambient Rain
* [Pluvior](https://pluvior.com/) - Ambient Rain
* [Rainyscope](https://rainyscope.com/) - Ambient Rain
* [FlowTunes](https://www.flowtunes.app/) - Customizable Ambient Sound Mixer
* [ambiphone](https://ambiph.one/) - Customizable Ambient Sound Mixer
* [⁠NoiseLoop](https://noiseloop.app/) - Customizable Ambient Sound Mixer
* [Ambie](https://ambieapp.com/) - Ambient Sound Mixer / App / [GitHub](https://github.com/jenius-apps/ambie)
* [Click Bath](https://hamishlang.github.io/clickbath/) - Ambient Sound Mixer with Customizable Musical Scale / Instruments
* [IMissTheOffice](https://imisstheoffice.eu/) - Ambient Office Sounds with Interactive UI
* [Homesick](https://scoreascore.com/homesick) - Ambient Home Sounds
* [VirtOcean](https://virtocean.com/) - Ambient Ocean Sounds
* [imissmycafe](https://imissmycafe.com/) - Ambient Cafe Sounds
* [Relaxing Sounds](https://unifycosmos.com/relaxing-sounds/), [Calmsound](https://www.calmsound.com/), [Click Relax](https://click-relax.com/) or [NoisyLoop](https://noisyloop.com/) - Ambient Soundscapes
* [lofi-player](https://magenta.tensorflow.org/lofi-player), [2](https://magenta.github.io/lofi-player/) - Create Room / Lofi Player
* [Wisdom Tree](https://github.com/HACKER097/wisdom-tree/) - TUI Concentration App
* [Generative.fm](https://generative.fm/) - Generative Ambient Music
* [NTS Field Recordings](https://www.nts.live/infinite-mixtapes/field-recordings), [Earth.fm](https://earth.fm/), [tree.fm](https://www.tree.fm/) or [Sounds of Maine](https://soundsofmaine.life/) - Field Recordings
* [HaloMe](https://halome.nu/) - Halo Menu Screens
* [CanvasCycle](https://www.effectgames.com/demos/canvascycle/) - 8-bit Scenes with Ambient Sounds
* [Ambient Mixer](https://www.ambient-mixer.com/) - User-Made Soundscapes
* [ChillOuts](http://www.chillouts.com/) - Meditation Aid
* [You are Listening To](https://youarelistening.to/) / [2](https://www.nts.live/shows/youarelisteningto) - Ambient City Sounds & Live Police Radio
* [SF 10-33](https://somafm.com/player24/station/sf1033) - Ambient Music & Live San Francisco Emergency Radio
* [The Sleeping Forecast](https://www.bbc.co.uk/programmes/p0cjyk2w/) or [The Shipping Forecast](https://www.bbc.co.uk/programmes/b006qfvv/) - Maritime Weather Broadcasts
* [TheWhiteNoiseMachine](https://thewhitenoisemachine.com/) - White Noise Generator

***

# ► Radio Streaming

* 🌐 **[FMSTREAM](https://fmstream.org/)** / [Virtual Radio](https://fmstream.org/setpos.htm), **[Recommended Streams](https://github.com/deroverda/recommended-radio-streams)**, **[Station Index](https://wikipedia.org/wiki/List_of_Internet_radio_stations)**, **[RadioStationWorld](https://radiostationworld.com/)** or **[Radio Browser](https://www.radio-browser.info/users)** - Radio Indexes
* ↪️ **[Android](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_android_podcasts_.2F_radio) / [iOS](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_ios_podcasts_.2F_radio)** - Podcast / Radio Apps
* ⭐ **[BBC Audio](https://www.bbc.com/audio)** - BBC Live & Catch-Up Radio / May Require UK VPN / [Downloader](https://github.com/get-iplayer/get_iplayer)
* ⭐ **[Drive From Home](https://drivefromhome.com/)** or [Drive & Listen](https://driveandlisten.app/) - Radio Driving Simulators
* [iHeartRadio](https://www.iheart.com/) / [Countries](https://help.iheart.com/hc//articles/228919427), [Mixcloud](https://www.mixcloud.com/), [myTuner](https://mytuner-radio.com/) or [TuneIn](https://tunein.com/) - Podcasts / Radio
* [Internet Archive](https://archive.org/details/audio?&sort=-downloads&page=1) - News / Classic Radio / Podcasts
* [Relic Radio](https://www.relicradio.com/) or [Old Time Radio](https://oldtime.radio/) - Classic Radio
* [Old Time Radio Downloads](https://www.oldtimeradiodownloads.com/) - Classic Radio Downloads
* [Braggoscope](https://www.braggoscope.com/) - BBC In Our Time Archive
* [AudioFilesDrive](https://t.me/AudioFilesDrive) - Radio Drama Downloads
* [radiobot](https://t.me/radiobot) - Radio / Telegram
* [raddio](https://radoxo.com/) - Simple Radio Player / Directory
* [Instant.audio](https://instant.audio/) - Minimalist Radio Player
* [Flicker Radio](https://flicker-mini.pages.dev/radiostations) - Simple / Lightweight Radio Player
* [QMPlay2](https://github.com/zaps166/QMPlay2) - Desktop Media / Radio Player
* [StreamURL](https://streamurl.link/) - Radio Stream URL Finder
* [LiveATC](https://www.liveatc.net/) - Air Traffic Radio Chatter
* [Broadcastify](https://www.broadcastify.com/) - Live Emergency, Aircraft and Rail Radio
* [OpenMHz](https://openmhz.com/) - Live Police Radio
* [RadioReference](https://www.radioreference.com/) - Scanner Frequency Database
* [Worldwide Radio](https://addons.mozilla.org/en-US/firefox/addon/worldwide-radio/) - Radio Extension

***

## ▷ Internet Radio

* ⭐ **[SomaFM](https://somafm.com/)** - Online Radio / User Supported / [Discovery Guide](https://rentry.co/musicdiscovery/#somafm)
* ⭐ **[AccuRadio](https://www.accuradio.com/)** - Online Radio Directory / [Add Features](https://greasyfork.org/scripts/591641)
* ⭐ **[RadioParadise](https://radioparadise.com/)** - Online Radio / Listener Supported
* [⁠WFMU](https://wfmu.org/) - Independent Internet Radio
* [Radiolise](https://radiolise.com/) - Online Radio Player / Directory
* [Audiophile](https://audiophile.fm/) - Online Radio Directory
* [You Radio](https://you.radio/) - Online Radio Directory
* [KWSX Radio](https://radio.kwsx.online/) - Online Radio / Listener Supported
* [⁠ScrobbleRadio](https://scrobblerad.io/) - Online Radio w/ Multi-Platform Scrobbling / [GitHub](https://github.com/jbwharris/scrobblerad.io)
* [Radio.dubbeh](https://radio.dubbeh.net/) - Online Radio Directory
* [My Radio](https://junguler.github.io/m3u-player-web/) - Online Radio Directory
* [⁠Freeform Radio](https://www.freeformradio.directory/) - Online Radio Directory
* [⁠Vijay's Radio Vibes](https://vijaysradiovibes.pages.dev/) - Random Radio Stations
* [Q-3](https://www.q-3.eu/) - Online Radio Directory
* [⁠DubLab](https://www.dublab.com/) - Online Radio
* [⁠BoxRadio](https://boxradio.net/) - Online Radio Directory
* [ShoutCast](https://directory.shoutcast.com/), [Zeno.fm](https://zeno.fm/) or [Live365](https://live365.com/) - User-Stations
* [Internet-Radio](https://internet-radio.com/) - Station-Directory
* [⁠The Lot Radio](https://www.thelotradio.com/) - Independent Internet Radio
* [⁠Worldwide FM](https://www.worldwidefm.net/) - Independent Internet Radio
* [deepcut.fm](https://deepcut.live/) - Deep-Cuts
* [⁠ROVR](https://www.rovr.live/) - Community-Curated Radio
* [Tilderadio](https://tilderadio.org/) - Community Radio
* [UpBeat](https://upbeatradio.net/) - Community Radio / [Discord](https://upbeat.pw/discord)
* [⁠Rinse FM](https://www.rinse.fm/) - London-Based Community Radio
* [radio.uwu](https://radio.uwu.network/) - Subculture Radio
* [Nectarine](https://www.scenestream.net/demovibes/streams/) - Demo Scene Music Radio
* [HollowEarthRadio](https://khuh.fm/) - Pacific Northwest Artists
* [Campus FM](https://www.campus-fm.com/) - College Radio
* [RadioSide](https://radioside.com/v1/) - Internet Radio Receiver
* [streamWriter](https://streamwriter.org/en/) - Internet Radio Audio Downloader

***

## ▷ Radio Directories

* ⭐ **[Radio Garden](https://radio.garden/)** / [Site Unblock](https://redd.it/18e12gf), [2](https://redd.it/13b53zs), [WorldRadioMap](https://worldradiomap.com/), [⁠TuneJourney](https://tunejourney.com/) or [⁠RadioCast](https://www.radiocast.co/) - Globe-Style World Radio
* [LiveOnlineRadio](https://liveonlineradio.net/) - Global Radio Directory / Country & Genre
* [OnlineRadioBox](https://onlineradiobox.com/) - International Radio Directory / Playlists
* [Streema](https://streema.com/) - Global AM/FM & Internet Radio Directory
* [Radio.net](https://www.radio.net/) - International Radio Directory / Player
* [RadioPuppy](https://www.radiopuppy.com/) - Radio Directory
* [⁠Radio Nations](https://radionations.com/) - Radio Directory
* [myTuner](https://mytuner-radio.com/) - Global Radio & Podcasts / Multi-Platform
* [TuneYou](https://tuneyou.com/) - Radio Directory / Discovery Focus
* [vTuner](https://vtuner.com/setupapp/guide/asp/BrowseStations/startpage.asp) - Radio Directory / Hardware Integration
* [radioline](https://www.radioline.co/) - Radio & Podcast Aggregator
* [TheNonStop Radio](https://thenonstopradio.com/) or [TheOneStop Radio](https://theonestopradio.com/) - Radio Directory
* [Radio Guide](https://www.radioguide.fm/) - Radio Directory
* [radio-locator](https://radio-locator.com/) - AM / FM Radio Search
* [Shortwave.Live](https://shortwave.live/) - Shortwave Radio Schedules
* [Xiph](https://dir.xiph.org/) - Icecast / Ogg Stream Directory
* [UKRadioLive](https://ukradiolive.com/) or [RadioFeeds](http://www.radiofeeds.co.uk/) - UK Radio Station Directories
* [ilovemusic](https://ilovemusic.de/) - German Radio Directory
* [Tvradiotuner](https://tvradiotuner.com/) - TV & Radio Stream Aggregator
* [VRadio](https://www.akouradio.com/) - Radio Directory / VRadio App

***

## ▷ Genre Specific Radio

* 🌐 **[⁠Unify.fm](https://www.unify.fm/)** - Independent Electronic Radio Index
* [Di.fm](https://www.di.fm/) - Electronic Radio
* [Scientific Sound Asia](https://www.scientificsound.asia/radio-station/) - Underground / Asian Electronic Radio ⁠
* [Rekt FM](https://rekt.network/) - Chill / Space / Dark / Horror Synth / EBSM / EDM Radio
* [Nightwave Plaza](https://plaza.one/) - Vaporwave Radio
* [Nightride.fm](https://nightride.fm/) - Synthwave / Darksynth Radio
* [TechnoBase](https://www.technobase.fm), [TranceBase](https://www.trancebase.fm), [HouseTime](https://www.HouseTime.fm) or [HardBase](https://www.HardBase.fm) - Electronic Radio / [Discord](https://discord.com/invite/xFRcWdNUkY)
* [HappyHardcore](https://www.happyhardcore.com/radio/) - Hardcore Dance Radio
* [⁠Death.FM](https://death.fm/) - Metal Radio / Community
* [CoreRadio](https://coreradio.online/listen) - Metalcore / Hardcore / Deathcore Radio
* [LISTEN.moe](https://listen.moe/) - J-Pop / K-Pop Radio
* [⁠WQXR](https://www.wqxr.org/streams/), [⁠The Classical Station](https://theclassicalstation.org/) or [NTS Sheet Music](https://www.nts.live/infinite-mixtapes/sheet-music) - Classical Music Radio
* [NTS Poolside](https://www.nts.live/infinite-mixtapes/poolside) or [Pool Suite](https://poolsuite.net/) - Summer Radio
* [NTS Otaku](https://www.nts.live/infinite-mixtapes/otaku) or [Openings Moe](https://openings.moe/) - Anime Theme Radio
* [Ongaku](https://ongaku.js.org/) or [r-a-d.io](https://r-a-d.io/) - Anime Radio
* [⁠Kobold.FM](https://kobold.messy.quest/) - Dungeon Synth & Fantasy Ambient Radio
* [420.moe](https://420.moe/) - 420 Radio
* [Daft Punk Cafe](https://daftpunk.cafe/) - Daft Punk Radio

***

## ▷ Lofi Radio

* ⭐ **[Flow-Fi](https://www.flowfi.app/)** - Lofi Radio
* ⭐ **[CityHop](https://www.cityhop.cafe/)** or [Japan Walkaround](https://thatguyedd.github.io/) - Lofi Radio / City Walks
* ⭐ **[Chillhop](https://app.chillhop.com/)** - Lofi Radio
* [Lofi and Games](https://lofiandgames.com/) - Lofi Radio + Simple Games
* [FlowTunes](https://www.flowtunes.app/) - Lofi + Focus Radio / Ambient Sounds
* [Lofizen](https://www.lofizen.co/) - Lofi Radio / Ambient Sounds
* [⁠Lofi Cities](https://loficities.com/) - Lofi Radio / Pixel Art Cities
* [Moon Phase Radio](https://www.moonphaseradio.com/) - Lofi Radio
* [Ambient Sleeping Pill](https://ambientsleepingpill.com/) - Lofi Radio
* [LofiCafe](https://www.loficafe.net/) - Lofi Radio
* [Ambicular](https://ambicular.com/) - Lofi Radio
* [FreeCodeCamp](https://coderadio.freecodecamp.org/) - Lofi Radio
* [Lofi Club](https://loficlub.vercel.app/) - Lofi Radio
* [Loofi](https://loofi.netlify.app/) - Lofi Radio
* [Lofi Limo](https://lofi.limo/) - Lofi Radio
* [DevTunes FM](https://radio.madza.dev/) - Lofi Radio
* [Moss Garden](https://moss.garden/) - Lofi Radio
* [Lofi Generator](https://lofigenerator.com/) - Generate Lofi Audio
* [Coding Cat](https://hostrider.com/) - Lofi Radio / Nyan Cat's Cousin

***

# ► Spotify Tools

* ↪️ **[Android Spotify Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25BA_android_audio)**
* ↪️ **[iOS Spotify Patchers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25BA_ios_audio)**
* ⭐ **[SpotX](https://github.com/SpotX-Official/SpotX)** or [BlockTheSpot](https://github.com/Nuzair46/BlockTheSpot-Installer) - Ad-Free Spotify Patchers / [Telegram](https://t.me/SpotxCommunity)
* ⭐ **[Spicetify](https://spicetify.app/)** - Spotify Themes & Plugins / [Improved Lyrics](https://spicylyrics.org/) / [Discord](https://discord.gg/VnevqPp2Rr) / [GitHub](https://github.com/spicetify/cli) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/spicetify-note.md)
* [⁠Spot SponsorBlock](https://spotsponsorblock.org/) - Skip Sponsored Spotify Podcast Ads / [GitHub](https://github.com/Spot-SponsorBlock/Spot-SponsorBlock-Extension)
* [Lofi](https://www.lofi.rocks/) - Mini Spotify Player Widget / [GitHub](https://github.com/dvx/lofi)
* [Trikatuka](https://trikatuka.aknakn.eu/) - Migrate Spotify Data to New Accounts
* [Kotify](https://github.com/dzirbel/kotify) or [Skiley](https://skiley.net/) - Spotify Library Managers
* [Versefy](https://versefy.app/) or [sptlrx](https://github.com/raitonoberu/sptlrx) - Display Synced Lyrics
* [⁠Spotify Karaoke](https://github.com/haroldalan/spotify-karaoke) - Fetching, Romanization & Translation for Web Player Lyrics
* [Syrics](https://github.com/akashrchandran/syrics-web) - Download Synced Lyrics
* [LoaderSpot](https://loadspot.vercel.app/) - Official Spotify Installers Archive
* [Random Music Generator](https://random-song.com/) - Find Random Songs, Albums, & Artists
* [Opslagify](https://opslagify.app/) - Calculate Storage Size of Spotify Library
* [Kira](https://kira.vercel.app/) / [GitLab](https://gitlab.com/timrossback/kira) or [Album Availability Map](https://kaaes.github.io/albums-availability/) - Check Regional Availability of Spotify Content
* [Chart My Music](https://www.chartmymusic.com/spotify/) - Generate Spotify Collage
* [Tierify](https://tierify.app/) - Create Spotify Tier Lists
* [Canvas Downloader](https://www.canvasdownloader.com/) - Extract Spotify Canvas Art
* [ListenByLabel](https://www.lbl.fm/) - Search Spotify Record Labels
* [xmplaylist](https://xmplaylist.com/) - Listen to SiriusXM Channels on Spotify
* [⁠SpotifyATVAdBlock](https://github.com/schultzyyy271/SpotifyATVAdBlock) - Spotify Adblock for AppleTV

***

## ▷ Playlist Tools

* ⭐ **[Exportify](https://exportify.app/)** / [GitHub](https://github.com/watsonbox/exportify) or [spotify-backup](https://github.com/caseychu/spotify-backup) - Export Playlists
* ⭐ **[spotgen](https://epsil.github.io/spotgen)**, [Unheard.FM](https://unheard.fm/) or [Chosic](https://www.chosic.com/) - Playlist Generators
* [Spoqify](https://spoqify.com/) - Anonymous Playlist Generator
* [SpotTransfer](https://spot-transfer.vercel.app/) / [GitHub](https://github.com/Pushan2005/SpotTransfer), [Trikatuka](https://trikatuka.aknakn.eu/), [TuneMyMusic](https://www.tunemymusic.com/) or [Spotify2YouTubeMusic](https://github.com/mahdi-y/Spotify2YoutubeMusic) - Playlist Transfer Tools
* [Playlist Hospital](https://playlisthospital.com/) - Restore Disabled Songs in Spotify Playlists
* [Playlister](https://playlister.cc/) or [Spotlistr](https://www.spotlistr.com/) - Platform-to-Spotify Playlist Converters
* [Playlistor](https://playlistor.io/) - Apple-to-Spotify Playlist Converter
* [Playlist Randomizer](https://stevenaleong.com/tools/spotifyplaylistrandomizer) - Better Shuffle for Playlists
* [Sort Your Music](https://sortyourmusic.playlistmachinery.com/) - Sort Playlists / [GitHub](https://github.com/plamere/SortYourMusic)
* [Spotify Dedup](https://spotify-dedup.com/) - Remove Duplicates in Playlists / [GitHub](https://github.com/JMPerez/spotify-dedup/)
* [Share Liked Songs](https://nonnullish.github.io/share-liked-songs/) - Create Shareable Playlist from Liked Songs / [GitHub](https://github.com/nonnullish/share-liked-songs)
* [Spotify Playlist Archive](https://spotifyplaylistarchive.com/) - Public Spotify Playlists Archive / [GitHub](https://github.com/mackorone/spotify-playlist-archive)

***

# ► Audio Ripping

* **Note** - Some sites and tools accept URLs from various streaming sites but only use a particular source (usually YouTube) to get the audio. We've only mentioned a platform if it can directly rip audio from there.

***

## ▷ Audio Ripping Sites

* ⭐ **[lucida](https://lucida.to/)** - Amazon Music / Soundcloud / FLAC / AAC / MP3 / [Status](https://status.lucida.to/status/lmbr) / [Telegram](https://t.me/lucidahasmusic) / [Discord](https://discord.com/invite/dXEGRWqEbS)
* ⭐ **[Monochrome](https://monochrome.st/)** - Multi-Site / FLAC / AAC / MP3 / E-AC3 / AC-4 / [Discord](https://monochrome.samidy.com/discord) / [GitHub](https://github.com/monochrome-music/monochrome)
* ⭐ **[Antra Web](https://antra.hoshi.cfd/)** - Multi-Site / FLAC / AAC / MP3 / Requires Sign-Up / [Telegram](https://t.me/antraaverse) / [Discord](https://discord.gg/J4yMnnMjqt)
* ⭐ **[DoubleDouble](https://doubledouble.top/)** - Amazon Music / Soundcloud / FLAC / [Telegram](https://t.me/lucidahasmusic)
* [Jumo-DL](https://jumo-dl.pages.dev/) - Qobuz / FLAC / MP3
* [⁠Octave](https://octavestreaming.com/) - Multi-Site / FLAC / Dolby Atmos / 320 AAC / 128 MP3 / Requires Discord / [Discord](https://discord.gg/5cZAbW3Tbg)
* [⁠ARCOD](https://arcod.xyz/) - Qobuz / FLAC / MP3 / [Discord](https://discord.com/invite/hgC6ZegbKD)
* [Rhythmax TIDAL Downloader](https://tidal.odskyler.com/) - Tidal / FLAC / [Discord](https://discord.gg/PAKgD6Jhfm)
* [⁠Rip Anything From Anywhere](https://anything.rip/) - Multi-Site / 320kb MP3
* [vdwn.cloud](https://vdwn.cloud/) - Multi-Site / 320kb MP3
* [⁠CYBROX](https://cybrox.pro/) - Multi-Site / 320kb MP3
* [AMP3](https://amp3.cc/) - Multi-Site / 320kb MP3
* [⁠AudioFetcher](https://audiofetcher.com/) - Multi-Site / Opus / 320kb MP3 / [Discord](https://discord.gg/DFZaejcJfg)
* [Spotisaver](https://spotisaver.net/) - YouTube / 320kb MP3
* [YTiz](https://ytiz.xyz/) - SoundCloud / Bandcamp / 128kb AAC
* [⁠Lossless Music Download](https://flac.music.hi.cn/) - Kuwo / MP3 / FLAC / Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators)
* [cobalt](https://cobalt.tools/) - SoundCloud / 128kb MP3 / [X](https://x.com/justusecobalt) / [Discord](https://discord.com/invite/pQPt8HBUPu) / [GitHub](https://github.com/imputnet/cobalt)
* [squid.wtf](https://squid.wtf/) - KHInsider / JioSaavn / FLAC
* [Rhythmax JioSaavn Downloader](https://saavn.odskyler.com/) - JioSaavn / 320kb AAC / [Discord](https://discord.gg/PAKgD6Jhfm) / [GitHub](https://github.com/ODSkyler/saavn-dl)

***

## ▷ Audio Ripping Tools

* ↪️ **[Video Audio Downloaders](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/video-tools#wiki_.25BA_video_download)** / **[YouTube](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/social-media#wiki_.25B7_youtube_downloaders)**
* ⭐ **[Mornye](https://desktop.mornye.com/)** - Amazon Music / Qobuz / Tidal / Deezer / [GitHub](https://github.com/mornyeapp/Mornye-Desktop)
* ⭐ **[Nicotine+](https://nicotine-plus.org/)** or [Soulseek](https://slsknet.org/) - P2P Audio Sharing Networks / [Stats](https://github.com/mrusse/Slsk-Upload-Stats-Tracker) / [Server App](https://github.com/slskd/slskd) / [Batch](https://github.com/fiso64/sldl)
* ⭐ **[Exact Audio Copy](https://www.exactaudiocopy.de/)** / [Guide](https://docs.google.com/document/d/1b1JJsuZj2TdiXs--XDvuKdhFUdKCdB_1qrmOMGkyveg) or [Whipper](https://github.com/whipper-team/whipper) - CD / DVD Audio Ripper
* ⭐ **[Firehawk52](https://rentry.co/FMHYB64#firehawk)** - Deezer / Qobuz / Tidal / Requires Sign-Up / [Telegram](https://t.me/firehawk52official) / [Discord](https://discord.gg/uqfQbzHj6K)
* [OnTheSpot](https://github.com/justin025/onthespot) - Apple Music / Bandcamp / Deezer / Qobuz / Spotify / Tidal / [Discord](https://discord.com/invite/hz4mAwSujH)
* [⁠Antra](https://github.com/anandprtp/Antra) - Qobuz / Tidal / Amazon Music / Soulseek / Converts from Multiple Sites / [Telegram](https://t.me/antraaverse) / [Discord](https://discord.gg/J4yMnnMjqt)
* [Votify](https://github.com/GladistonXD/votify-fix) - Spotify / 128kb Free / 256kb Premium / AAC / Requires WVD Keys / [Discord](https://discord.gg/aBjMEZ9tnq)
* [streamrip](https://github.com/nathom/streamrip) - Deezer / Tidal / Qobuz / 128kb Free / FLAC / Use Firehawk52 / [Colab](https://github.com/privateersclub/rip)
* [OrpheusDL](https://github.com/OrfiTeam/OrpheusDL) - Deezer / Qobuz / 128kb Free / FLAC / Use Firehawk52 / [Deezer Mod](https://github.com/uhwot/orpheusdl-deezer)
* [DeemixFix](https://gitlab.com/deeplydrumming/DeemixFix), [Deemix Revival](https://github.com/bambanah/deemix) or [SaturnMusic](https://github.com/SaturnMusic/) - Deezer / FLAC
* [Murglar](https://murglar.app/) - Deezer / SoundCloud / VK / 320kb MP3
* [QobuzDownloaderX](https://github.com/ImAiiR/QobuzDownloaderX) or [QobuzDownloaderX-MOD](https://github.com/DJDoubleD/QobuzDownloaderX-MOD) - Qobuz / 128kb Free / 256 ACC Premium / FLAC / Use Firehawk52
* [qobuz-dl](https://github.com/vitiko98/qobuz-dl) - Qobuz / 128kb Free / FLAC / Use Firehawk52
* [you-get](https://you-get.org/) - SoundCloud / Bilibili / 128kb MP3
* [BandCamp-DL](https://github.com/iheanyi/bandcamp-dl) - Bandcamp / 128kb MP3 / Free Only / [Discord](https://discord.com/invite/nwdT4MP)
* [⁠MusicDL](https://github.com/CharlesPikachu/musicdl) - Chinese Audio Platform Downloader
* [⁠NullBeat](https://nullbeat.thevolecitor.qzz.io/) - TorBox-Based Hi-Res Audio & CD FLAC Ripper
* [AccurateRip](https://www.accuraterip.com/) - Verify Ripped Tracks are Error-Free

***

## ▷ Telegram Bots

* [DeezerMusicBot](https://t.me/DeezerMusicBot) - Deezer / SoundCloud / VK / 320kb MP3 / FLAC / [Support](https://t.me/DeezerMusicNews)
* [deezload2bot](https://t.me/deezload2bot) - Deezer / 320kb MP3 / [Updates](https://t.me/DEDSEClulz)
* [scdlbot](https://t.me/scdlbot) - YouTube / SoundCloud / Bandcamp / Mixcloud / 128kb MP3
* [⁠alac_collab_bot](https://t.me/alac_collab_bot) - Apple Music / ALAC / Atmos / AAC / 20 Daily / [Telegram](https://t.me/apple_music_bot_alac)
* [⁠AppleMusicDW Bot](https://t.me/applemusicdw_bot) - Apple Music / ALAC / AAC / 50 Daily
* [vkmusbot](https://t.me/vkmusbot) or [Meph Bot](https://t.me/mephbot) - VK / 320kb MP3
* [GlomaticoBlueMusicBot](https://t.me/GlomaticoBlueMusicBot) - Amazon Music Downloader / [Telegram](https://t.me/GlomaticoBotSupport) / [Discord](https://discord.gg/aBjMEZ9tnq)

***

## ▷ Download Sites

* **Note** - Use **[redirect bypassers](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools/#wiki_.25B7_redirect_bypass)** to skip annoying link shorteners.

***

* 🌐 **[⁠Music Download Guide](https://rentry.co/wheredownloadmusic)** - Downloading Guide / Site Index
* ⭐ **[Audio Download CSE](https://cse.google.com/cse?cx=006516753008110874046:ibmyuhh72io)** / [CSE 2](https://cse.google.com/cse?cx=006516753008110874046:ohobg3wvr_w) / [CSE 3](https://cse.google.com/cse?cx=32d85b41e2feacd3f) - Multi-Site Search
* [FLAC Attack](https://flacattack.net/) or [Lossless-Music](https://lossless-music.org/) - FLAC
* [FlacMusic](https://www.flacmusic.info/) - FLAC
* [DiscogC](https://www.discogc.com/) - FLAC
* [LosslessAlbums](https://losslessalbums.club/) - FLAC
* [IntMusic](https://intmusic.net/) - MP3 / FLAC
* [GetRockMusic](https://getrockmusic.net/) - MP3 / FLAC
* [Core Radio](https://coreradio.online/) - MP3 / FLAC
* [AlterPortal](https://alterportal.net/) - MP3 / FLAC
* [ShareMania](https://sharemania.us/) - FLAC / MP3 / M4A
* [Exystence](https://exystence.net/) - MP3 / FLAC
* [ThemFire](https://themfire.pro/) - MP3 / FLAC
* [Canna](https://canna.to/?lang=eng) - MP3 / FLAC
* [Music Rider](https://musicrider.org/) - MP3 / FLAC
* [iPlusFree](https://www7.iplusfree.org/) - iTunes M4A
* [musify](https://musify.club/) - 320kb / MP3
* [ccMixter](https://ccmixter.org/) - DL / Stream / 320kb / MP3
* [RockDownload](https://www.rockdownload.org/) - 320kb / MP3
* [punk.cat](https://punkcata.blogspot.com/) - 320kb / MP3
* [SongsLover](https://songslover.net/) - 256kb / MP3
* [Ezhevika](https://ezhevika.blogspot.com/) - 192kb / MP3
* [Internet Archive](https://archive.org/details/audio) - MP3
* [SoundClick](https://www.soundclick.com/default.cfm) - MP3
* [z3.fm](https://z3.fm/) - MP3
* [nodata](https://nodata.tv/) - MP3
* [Discografias Completas](https://www.discografias-completas.org/) - MP3 / [Telegram](https://t.me/+wdUhO_yV_A5lM2E5)
* [Tancpol](https://tancpol.net/) - MP3
* [New Album Releases](https://newalbumreleases.net/) - MP3
* [mp3db](https://mp3db.pro/) - MP3
* [DeadPulpit](https://www.deadpulpit.com/) - MP3
* [CannaPower](https://canna-power.to) - MP3
* [GloryBeats](https://glorybeats.com/) - MP3
* [Mixupload](https://mixupload.com/) - MP3
* [FreeMP3Cloud](https://freemp3cloud.com/) - MP3
* [zvu4no](https://zvu4it.org/) - MP3
* [xprm](https://xprm.net/) - MP3 / DL / Stream / Requests
* [⁠Butterboy Compilations](https://butterboycompilations.blogspot.com/) - Music Compilations / MP3
* [⁠Primitive Offerings](https://primitiveofferings.blogspot.com/) - Rare Music Compilations / Use [Redirect Bypass](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/internet-tools#wiki_.25B7_redirect_bypass)
* [Geocities MIDIs](https://www.midicities.com/GeoCities), [Tricotism](https://www.tricotism.com/), [FreeMIDI](https://freemidi.org/), [ArtScene](http://artscene.textfiles.com/music/midi/) or [VGMusic](https://www.vgmusic.com/) - MIDI Files
* [Music Hoarders](https://discord.gg/kQUQkuwSaT) - Music Hoarding Community / [Wiki](https://musichoarders.xyz/)

***

## ▷ Genre Specific Ripping

* [HQ Hip Hop](https://94hiphop.com/) or [GoldHipHop](https://goldhiphop.pro/) - Hip Hop / MP3 / FLAC
* [Rapload](https://rapload.org/) or [HipHopa](https://hiphopa.net/) - Hip Hop / MP3
* [Rap War](https://rap-war-fam.blogspot.com/) - Hip Hop / MP3
* [Dez Flight Underground](https://dezflight-underground.com/) - Underground Hip Hop
* [⁠Certified Mixtapez](https://www.certifiedmixtapez.com/) - Mixtapes / MP3
* [Mixtape Collections](https://rentry.co/FMHYB64#mixtape-collections) - Mixtape Collections
* [Hipstrumentals](https://hipstrumentals.com/) - Instrumentals / MP3
* [Ektoplazm](https://ektoplazm.com/) - Electronic / MP3 / FLAC
* [KTI Music](https://ktimusic.blogspot.com/) - Electronic / MP3 / FLAC
* [1Gabba](https://1gabba.pw/) - Electronic / MP3
* [Gabber](https://gabber.od.ua/) - Electronic / MP3
* [⁠ELEKTROBEATS](https://elektrobeats.org/) - Electronic / MP3
* [EDMWaves](https://edmwaves.org/) - Electronic / MP3
* [PSYFP](https://psyfp.ucoz.ru/) - Electronic / MP3
* [DMO](https://dance-music.org/) - Electronic / MP3
* [MyPromoSound](https://mypromosound.com/) - Electronic / MP3
* [ElectronicFresh](https://electronicfresh.com/) - Electronic / MP3
* [r/xTrill](https://reddit.com/r/xTrill) - Electronic / [Backup](https://reddit.com/r/xTrillBackup)
* [⁠Die or DIY](https://dieordiy2.blogspot.com/) - Underground Electronic
* [EssentialHouse](https://essentialhouse.club/) - House / MP3
* [1Trance](https://1trance.org/) - Trance / MP3
* [1Techno](https://1techno.org/) - Techno / MP3
* [GlobalDJMix](https://globaldjmix.com/) - DJ Mixes / MP3
* [oVPN DJ Mixes](https://rentry.co/FMHYB64#ovpn-dj-mixes) - DJ Mixes
* [⁠Grime Archive](https://www.grimearchive.org/) - Grime Livesets
* [LOA2K](https://loa2k.neocities.org/) or [Nu Guide](https://nuvaporwave.neocities.org/mirrors.html) - Vaporwave
* [⁠Systems of Romance](https://www.systemsofromance.com/blog/) - Post-Punk / Minimal Synth / MP3
* [GetMetal Club](https://getmetal.club/) - Metal / MP3 / FLAC
* [Nuclear Holocaust](https://nuclear-holocaust.blogspot.com/) - Metal / FLAC
* [We Need Match](https://we-need-match.ru/) - Metal / FLAC / M4A
* [Take Metal](https://takemetal.org/) - Metal / MP3
* [⁠Old School Metal Music](https://oldschoolmetalmusicz.blogspot.com/) - Metal / MP3
* [Cova-Argh!!!!](https://josephbarulho.blogspot.com/) - Metal / MP3
* [Metalminos](https://metalminos.net/) - Metal / MP3
* [In The Fog](https://in-the-fog.ru/) - Metal / MP3
* [TechnicalDeathMetal](https://technicaldeathmetal.org/) - Metal / MP3
* [HeavyMetalRarities](https://heavymetalrarities.com/) - Metal / MP3
* [⁠With The Song Of Life](https://forwardwiththesong.blogspot.com/) - Classic Music / Compilations / MP3
* [⁠Urban Asprines](https://urbanaspirines.blogspot.com/) - Classic Rock / Psychedelic / FLAC
* [ProgRockVintage](https://www.progrockvintage.com/) - Classic Rock / MP3
* [⁠Paradise of Garage Comps](https://paradiseofgaragecomps.blogspot.com/) - Garage Rock / MP3
* [F.P.F.T.P.](https://fpftp.blogspot.com/) - Punk / MP3 / Use [Translator](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/text-tools/#wiki_.25B7_translators)
* [Sophie's Floorboard](https://sophiesfloorboard.blogspot.com/) - Hardcore / MP3
* [Lost Songs](https://lostsongshc.blogspot.com/) - Hardcore / MP3
* [BurningTheGround](https://burningtheground.net/) - 80s / 90s / FLAC
* [KPopFLAC](https://www.kpopflac.xyz/) - K-Pop / FLAC
* [KPopMusicDownload](https://kpopdownloadscmm.blogspot.com/) - K-Pop / MP3
* [aboutdisco](https://aboutdiscowithlove.blogspot.com/) - Disco / MP3
* [Classical Music Download](https://classical-music-download.com/) - Classical / FLAC
* [FlatblackAndClassical](https://www.flatblackandclassical.com/) - Classic Indian Music / FLAC
* [FoggyNotion](https://foggynotion-flac.blogspot.com/) - Classic Music / MP3 / FLAC
* [chucrute com quiabo](https://rabanetecomquiabo.blogspot.com/) or [MeetingInMusic](https://meetinginmusic.blogspot.com/) - Classical / MP3
* [The T-SQUARE Plaza](https://tsquareplaza.blogspot.com/) - Japanese / International Jazz Fusion / City Pop / FLAC
* [inconstant sol](https://inconstantsol.blogspot.com/), [David W. Niven Collection](https://archive.org/details/davidwnivenjazz) or [JazznBlues](https://jazznblues.club/) - Jazz / MP3
* [Bluegrass Archive](https://rentry.co/FMHYB64#bluegrass-archive) - Bluegrass / FLAC
* [MusicRepublic](https://music-republic-world-traditional.blogspot.com/) - World / MP3 / FLAC
* [⁠Tone and Wave](https://toneandwave.blogspot.com/) - Ska / MP3
* [⁠Nothin' Sez Somethin'](https://nathannothinsez.blogspot.com/) - Reggae / Dub / MP3
* [madrotter-treasure-hunt](https://madrotter-treasure-hunt.blogspot.com/) - Indonesian Music
* [⁠Tape Attack](https://tapeattack.blogspot.com/) - European DIY Cassettes
* [FondSound](https://www.fondsound.com/) - Experimental / MP3
* [Bootleg Radioclash](https://rentry.co/FMHYB64#bootleg-radioclash) - Mashups / MP3
* [⁠1000 Flights](https://1000flights.blogspot.com/) - Underground / MP3
* [The Noise-Arch Archive](https://archive.org/details/noise-arch) - Underground Cassette Tapes
* [Tom Lehrer Songs](https://tomlehrersongs.com/) - All Tom Lehrer Songs / Public Domain
* [Kiddie Records](http://www.kiddierecords.com/) - Classic Children's Records

***

# ► Audio Torrenting

* **Note** - Remember to get a [VPN](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/adblock-vpn-privacy#wiki_.25BA_vpn) before torrenting and [bind it to your client](https://wispydocs.pages.dev/torrenting/) if it allows.

***

* ↪️ **[General Torrent Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent)**
* ⭐ **[Redacted](https://redacted.sh/)** - MP3 / FLAC / Requires Sign-Up / [Interviews](https://interviewfor.red/), [2](https://clarasguide.valeena.workers.dev/Guides/private-trackers/#introducing-red)
* ⭐ **[New-Team](https://new-team.org/)** - MP3 / FLAC
* ⭐ **[Orpheus](https://orpheus.network/)** - MP3 / FLAC / Requires Sign-Up / [Interviews](https://interview.orpheus.network/)
* ⭐ **[Lidarr](https://lidarr.audio/)** / [GitHub](https://github.com/Lidarr/Lidarr) or [Headphones](https://github.com/rembo10/headphones) - Audio Torrent Autodownload
* ⭐ **[Audio Torrent CSE](https://cse.google.com/cse?cx=006516753008110874046:v75cyb4ci55)** - Multi-Site Search
* [TPB Music](https://thepiratebay.org/search.php?q=top100:100) - MP3 / FLAC / **Avoid Software / Games**
* [TheMixingBowl](https://themixingbowl.org/) - Forum / Mixes / MP3 / Requires Sign-Up
* [Metal Tracker](https://en.metal-tracker.com/) - Metal / MP3 320kb / FLAC
* [BlackTorrent](https://blacktorrent.ru/) or [iPlayMetal](https://metal.iplay.ro/) - Metal / MP3 / FLAC
* [MixtapeTorrent](http://www.mixtapetorrent.com/) - Mixtapes / MP3 / Various Bitrates
* [TribalMixes](https://www.tribalmixes.com/) - Forum / DJ Mixes / MP3
* [the /kpg/ torrent](https://rentry.co/FMHYB64#kpop-torrent) - K-Pop / MP3 320kb / FLAC
* [PandaCD](https://pandacd.io/) - User-Made Music / MP3 / FLAC
* [NFO DB](https://nfodb.net.ru/) - MP3 NFO Database
* [PreDB.eu](https://predb.eu) - Music PreDB

***

# ► Royalty Free Music

* ⭐ **[NCS](https://ncs.io/)** - Copyright Free Music
* ⭐ **[YouTube Audio Library](https://www.youtube.com/audiolibrary)** - Music / Sound Effects
* [UppBeat](https://uppbeat.io/) - Music for Creators / Freemium
* [BenSound](https://www.bensound.com/) - Popular Library / Freemium
* [Unminus](https://www.unminus.com/) - Professional Tracks
* [Free Music Archive](https://freemusicarchive.org/) - Curated Library
* [free-stock-music](https://www.free-stock-music.com/) - Stock Music Library / CC0 License
* [Pixabay Music](https://pixabay.com/music/) - Stock Music Library
* [Fugue](https://icons8.com/music) or [Free to Use](https://freetouse.com/music) - Music for Creators
* [Chosic](https://www.chosic.com/free-music/all/) - Royalty-Free Library / CC0 License
* [⁠OpenTracks](https://opentracks.com/en/) - Royalty-Free Library
* [tunetank](https://tunetank.com/) - Music for Videos
* [⁠Sound Image](https://soundimage.org/) - Music for Games
* [⁠Matthew C. Wright](https://matthewcwright.com/) - Royalty-Free Piano Music
* [purple-planet](https://www.purple-planet.com/) - Duo Composers
* [Incompetech Music](https://incompetech.com/music/royalty-free/music.html) - Composer Library / CC-BY License
* [joshwoodward](https://www.joshwoodward.com/) - Single Artist Collection

***

# ► Media Soundtracks

* 🌐 **[EverythingMoe](https://everythingmoe.com/section/music)** - Otaku Music Sites Index / [Discord](https://discord.gg/GuueaDgKdS)
* 🌐 **[Wotaku](https://wotaku.wiki/music)** - Otaku Music Index / [Discord](https://discord.gg/vShRGx8ZBC)
* ⭐ **[Sitting on Clouds](https://www.sittingonclouds.net/)**, [2](https://sittingonclouds.com/) - Anime / Game Soundtracks / [Forum](https://squid-board.org/) / [.onion](http://cloudscbr2l7prtthmz5jk5hxpndisu4ohqytsri5vyua3ksfswl7gyd.onion/) / [Discord](https://discord.com/invite/x23SFbE)
* ⭐ **[Squidify](https://www.squidify.org)**, [2](https://www.squidify.net/) - Game / Anime Soundtracks / [Desktop](https://github.com/kobayashi90/squidify-desktop)
* [joshw](https://pc.joshw.info/) / [Search](https://vgm.hcs64.com/) - Soundtracks
* [RenovationRecords](https://renovatiorecords.blogspot.com/) - HQ Movies Soundtracks
* [⁠Adtunes](https://adtunes.com/) - Commercial / Trailer Media Soundtrack Community
* [KDramaOST](https://kdramaost.com/en/) - KDrama Soundtracks
* [MusicDex](https://musicdex.org/), [AniPlaylist](https://aniplaylist.com/), [SakuraOST](https://www.sakuraost.com/), [OSAnime](https://osanime.com/), [VGMdb](https://vgmdb.net/), [JMAX](https://discord.gg/hCw8VqJV8J) or [OSAnime](https://osanime.com/) - Anime Soundtracks
* [Miu](https://discord.gg/pwkuanXBJh), [⁠Kara.moe](https://kara.moe/), [AnimeDex Music](https://animedex.fun/music) or [AnimeThemes](https://animethemes.moe/) / [Discord](https://discord.com/invite/m9zbVyQ) / [GitHub](https://github.com/AnimeThemes) - Anime Opening / Closing Themes
* [OtakuOst](https://otakuost.net/) - Anime Soundtracks & Japanese Music
* [AMV](https://www.animemusicvideos.org/) - Anime Music Videos
* [Doujin Cafe (Discord)](https://discord.com/invite/doujincafe) or [DoujinStyle](https://doujinstyle.com/) / [Discord](https://discord.com/invite/z2QDFdA) - Doujin Music
* [⁠Internet Checkpoint](https://internetcheckpoint.page/) - Archive of taia777 "Internet OST Checkpoints" / Life Stories / [Discord](https://discord.gg/Qwt7m8CFVn) / [GitHub](https://github.com/geauser/internetcheckpoint)

***

## ▷ Game Soundtracks

* ⭐ **[Khinsider](https://downloads.khinsider.com/)** or [⁠KHI-DL](https://khinsider.squid.wtf/) - Game Soundtracks / MP3 / FLAC / ALAC / [Bulk Downloader](https://github.com/madLinux7/khi-explorer)
* [Zophar's Domain](https://www.zophar.net/music) - Retro Game Music Rips / MP3 320 Kbps / FLAC
* [The 16-bit Audiophile Project](https://16bap.theclassicgamer.net/) - 16-bit Game Soundtracks / FLAC
* [RetroTracks](https://retro.sx/) - Retro Game Soundtracks / MP3 128 Kbps
* [VGMRips](https://vgmrips.net/packs/) - Retro Game Music Rips / VGM
* [HCS Forum](https://rentry.co/FMHYB64#hcs-forum) - Game Soundtracks
* [⁠OC Remix](https://ocremix.org/) - Game Music Remixes / Download / Torrent
* [NSF j](https://nsf.nesbbs.com/) - NES Music
* [HVSC](https://www.hvsc.c64.org/) - Commodore 64 Music
* [⁠8Beats](https://8beats.co/) - Game Music Radio / [Discord](https://discord.gg/EB9CFRacgN)
* [⁠CVGM](https://www.cvgm.net/) - Game Music Radio
* [VIP VGM](https://www.vipvgm.net/) - Game Music Radio
* [JetSetRadio](https://jetsetradio.live/), [2](https://jetsetradiofuture.live/) - Game Music Radio
* [Rainwave](https://rainwave.cc/) - Game Music Radio
* [RPGGamers Radio](https://www.rpgamers.net/radio/) - Game Music Radio
* [VGMRadio](https://vgmradio.com/) - Game Music Radio
* [VGM](https://vgm.mmosvc.com/) - Game Music Radio
* [⁠GTA Radio](https://gtaradio.net/) or [GTA Radio Nine](https://gtav-radio-nine.vercel.app/) - GTA Radio Stations
* [VGMPF](https://www.vgmpf.com/Wiki/index.php) - Retro Game Soundtracks / MP3
* [exotica](https://www.exotica.org.uk/) - Amiga Game Soundtracks / Retro Gaming Music Wiki
* [Chip Player JS](https://chiptune.app/) - Retro Game Soundtracks / Web / [GitHub](https://github.com/mmontag/chip-player-js)
* [Cirrus Retro](https://cirrusretro.com/) - Retro Game Soundtracks / Web
* [VGMdb](https://vgmdb.net/) - Video Game Music Database

***

# ► Tracking / Databases

* ⭐ **[RateYourMusic](https://rateyourmusic.com/)** - Ratings / Reviews / [Add Features](https://rateyourmusic.com/list/kknq/evenbetterrym-browser-extension/) / [Auto List Maker](https://zettaexa.github.io/autolists/) / [Forum](https://rym.fm/)
* ⭐ **[Discogs](https://www.discogs.com/)** - Ratings / Reviews / [Timestamps](https://martinbarker.me/tagger) / [Sale Notifications](https://discdogs.app/) / [Scout](https://greasyfork.org/en/scripts/439452-discogs-scout) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/partitioned-cookies.md)
* ⭐ **[Last.fm](https://www.last.fm/home)** / [Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/audio/#wiki_.25B7_last.fm_tools), [Libre.fm](https://libre.fm/) or [ListenBrainz](https://listenbrainz.org/) - Track Listening Habits / Songs
* ⭐ **[Muspy](https://muspy.com/)**, [⁠Midloop](https://midloop.net/) / [Discord](https://discord.gg/AvUxR59Yv5), [MusicButler](https://www.musicbutler.io/) or [Brew.fm](https://www.brew.fm/) - Get Album Release Updates
* ⭐ **[Tunefind](https://www.tunefind.com/)** - Find Music from Movies / TV Shows
* ⭐ **[MixesDB](https://www.mixesdb.com/)** - DJ Set Database / [Essentials List](https://rentry.co/dancemixbible/)
* [⁠Record Club](https://record.club/) - Ratings / Reviews
* [Ultimate Music Database](https://www.umdmusic.com/) - Music Database
* [MusicBrainz](https://musicbrainz.org/) - Music Database
* [⁠EntertainMe](https://www.entertainme.fun/), [rate.house](https://rate.house/), [libib](https://www.libib.com/), or [MediaTracker](https://github.com/bonukai/MediaTracker) - Media Tracking & Cataloging Tools
* [Maloja](https://github.com/krateng/maloja) or [Multi Scrobbler](https://github.com/FoxxMD/multi-scrobbler) - Self-Hosted Audio Scrobbling
* [Has it Leaked](https://hasitleaked.com/) - Album Leak Tracker
* [SoundtrackTracklist](https://soundtracktracklist.com/), [⁠What Song](https://what-song.com/) or [FilmMusicSite](https://www.filmmusicsite.com/en/) - Soundtrack Databases
* [SecondHandSongs](https://secondhandsongs.com/), [SampleBrainz](https://github.com/AndrewBelt/SampleBrainz), [RemixSearch](https://remixsearch.net/) or [WhoSampled](https://www.whosampled.com/) - Cover, Sample and Remix Databases
* [TrackID](https://trackid.net/) or [1001Tracklists](https://www.1001tracklists.com/) - Live Set Tracklist Databases
* [Metal Archives](https://www.metal-archives.com/) - Metal Band Database
* [⁠Nu-Metal Preservation](https://nu-metal-preservation.com/) - Nu-Metal Band Database
* [TheIndieRockPlaylist](https://www.theindierockplaylist.com/) - Indie Rock Archive
* [ClassicRockHistory](https://www.classicrockhistory.com/classic-rock-bands-list-and-directory/) - Classic Rock Band Archive
* [dbkpop](https://dbkpop.com/), [KPop Fandom](https://kpop.fandom.com/wiki/) or [KPopping](https://kpopping.com/) - K-Pop Databases
* [⁠VocaDB](https://vocadb.net/), [⁠TouhouDB](https://touhoudb.com/), or [⁠UtaiteDB](https://utaitedb.net/) - Anime / Doujin Music Databases / [VocaDB Discord](https://discord.com/invite/3bwXQNXKCz) / [TouhouDB Discord](https://discord.com/invite/GscZYEE) / [UtaiteDB Discord](https://discord.com/invite/hEY9JDb)
* [IDM Discovery](https://www.idmdiscovery.com/) - IDM Artist Archive
* [⁠Six Degrees of Hip-Hop](https://www.sixdegreesofhiphop.com/) - Hip-Hop Connections Map
* [Odesli](https://odesli.co/) / [Telegram Bot](https://t.me/odesli_bot) or [Squigly](https://squigly.link/) - Song / Podcast Platform Search
* [TuneMyMusic](https://www.tunemymusic.com/) - Transfer Playlists Between Services
* [Loudness War](https://dr.loudness-war.info/) - Albums Dynamic Range Database
* [Talpa Search](https://www.talpasearch.com/) - Find Albums by Describing Them
* [MyPitchFork](https://mypitchfork.fun/) - Individual Song Rating / Tracking
* [45Cat](https://www.45cat.com/) - Vinyl Ratings / Reviews
* [DAHR](https://adp.library.ucsb.edu/index.php) - American Historical Recordings Database
* [Obscurify](https://obscurifymusic.com/) or [MusicTaste](https://musictaste.space/) - Compare Music Taste to Others
* [AME](https://gitlab.com/SuperSaltyGamer/ame) - Music Site Enhancement Userscripts
* [Music Chart Maker](https://musicchartmaker.com/) - Create Album Collages

***

## ▷ Curated Recommendations

* ⭐ **[AnyDecentMusic](https://anydecentmusic.com/)** - Aggregated Critics' Album Ratings
* ⭐ **[AlbumOfTheYear](https://www.albumoftheyear.org/)** - Critic & User Ratings / Album Charts
* ⭐ **[Shfl](https://theshfl.com/)** - Curated Album Discovery / Genre & Label Filters
* ⭐ **[Bandcamp Daily](https://daily.bandcamp.com/)** - Independent Music Recommendations / [Hidden Gems](https://daily.bandcamp.com/hidden-gems)
* ⭐ **[The Quietus](https://thequietus.com/charts/)** - Independent Music Reviews / Monthly & Annual Charts
* [AllMusic](https://www.allmusic.com/) - Expert Album Reviews / Artist Recommendations
* [Sputnikmusic](https://www.sputnikmusic.com/) - Staff & User Album Reviews
* [Pitchfork](https://pitchfork.com/) / [The Fork](https://the-fork.vercel.app/) - Album Reviews / Searchable Review Database
* [Resident Advisor](https://ra.co/reviews) - Electronic Music Reviews / Recommended Releases
* [⁠TWGEEMA](https://twgeema.com/) - Electronic Music Recommendations
* [⁠beehype](https://beehy.pe/) - Global Music Recommendations
* [Essential Charts](https://4chanmusic.miraheze.org/wiki/Essential_Charts) - Community Album Recommendation Charts
* [r/ifyoulikeblank](https://www.reddit.com/r/ifyoulikeblank/) - Community Music Recommendations
* [Talk Classical List](https://talkclassical-list.github.io/) / [Playlist](https://open.spotify.com/playlist/2ssmoEdwODoE2tPOAcvRge) or [Classic FM Hall of Fame](https://rateyourmusic.com/list/Iai/the_classic_fm_hall_of_fame/) / [Playlist](https://open.spotify.com/playlist/09abNWaCFQHJo2eqtNdfu8) - Classical Music Recommendations
* [MusicTo](https://www.musicto.com/) - Human-Curated Playlists
* [The Drop](https://the-drop-reviews.vercel.app/) / [Melondy](https://melondy.com/) - Anthony Fantano Album Ratings & Recommendations
* [DigitalDreamDoor](https://digitaldreamdoor.com/pages/music0.html) - Greatest Music Lists by Genre & Era

***

## ▷ Music Discovery

* 🌐 **[/music discovery/](https://rentry.co/musicdiscovery)** - Music Discovery Guide
* ⭐ **[NTS Radio](https://www.nts.live/)** - Human-Curated Music Discovery / [Interactive Tracklist](https://greasyfork.org/scripts/592656) / [Downloader](https://github.com/everdrone/nts)
* ⭐ **[RateYourMusic Charts](https://rateyourmusic.com/charts/)** - Customizable Music Discovery Charts / [Add Features](https://rateyourmusic.com/list/kknq/evenbetterrym-browser-extension/) / [Forum](https://rym.fm/)
* ⭐ **[EveryNoise](https://everynoise.com/)** - Interactive Music Genre Discovery / [New Music](https://furia.com/page.cgi?type=log&skip=20#id492)
* ⭐ **[cosine.club](https://cosine.club/)** - Audio-Based Music Similarity Search / Underground Electronic Music
* ⭐ **[Musicmap](https://musicmap.info/)** - Interactive Music Genre History / Influences / Example Tracks
* [NTS In Focus](https://rentry.co/ntsinfocus), [NTS Guide To](https://rentry.co/ntsguideto) or [Discovery Guide](https://rentry.co/musicdiscovery/#nts-radio) - NTS Music Discovery Guides / Episode Indexes
* [NTS SoundCloud](https://rentry.co/ntssoundcloud) or [Mixcloud](https://www.mixcloud.com/NTSRadio/) - NTS Alternative Archives
* [Musicroamer](https://www.musicroamer.com/), [Music Galaxy](https://galaxy.spotifytrack.net/), [Music Atlas](https://music-atlas.app/), [Unchartify](https://unchartify.com/) / [Telegram](https://t.me/spotifyuncharted) or [LivePlasma](https://liveplasma.com/) - Visual Artist Discovery Tools
* [GNOD](https://www.gnod.com/), [Gnoosic](https://www.gnoosic.com/) or [Music-Map](https://www.music-map.com/) - Similar Artist Recommendations
* [SAGE](https://hate5six.com/sage) - Personalized Band Recommendations
* [⁠zig~zag](https://www.zig-zag.fm/) - Music Discovery Map / [Discord](https://discord.gg/uhst5zaMne)
* [Chosic](https://www.chosic.com/), [SongsLikeX](https://songslikex.com/), [Discover Quickly](https://discoverquickly.com/) or [Dubolt](https://dubolt.com/) - Similar Song / Playlist Discovery Tools
* [lazyrecords](https://lazyrecords.app/) or [TapeFear](https://www.tapefear.com/) - Obscure Music Discovery / Digital Crate Digging
* [Playlost.fm](https://playlost.fm/) - Similar Spotify Playlist Discovery
* [OrbitMusic](https://www.bbc.co.uk/orbitmusic) - Discover Emerging BBC Introducing Artists / [Limit Bypass](https://i.ibb.co/Y7gjmdqb/image.png), [2](https://files.catbox.moe/v7hy49.png), [3](https://i.imgur.com/FDx8jKa.png)
* [ArtistPath](https://artistpath.cc/) - Find Connections Between Music Artists
* [Radiooooo](https://radiooooo.com/) - Discover Music by Country & Decade
* [Best Ever Albums](https://www.besteveralbums.com/index.php) or [Acclaimed Music](https://acclaimedmusic.net/) - Greatest Albums / Aggregated Rankings
* [BestSellingAlbums](https://bestsellingalbums.org/) - Historical Album Sales Rankings
* [1001 Albums Generator](https://1001albumsgenerator.com/) - Daily Album Listening Challenge
* [Album Roulette](https://album-selector-chi.vercel.app/) - Random Album Recommendations
* [Music.ishkur](https://music.ishkur.com/) - Interactive Electronic Music Genre History
* [Genre Sampler](https://genresampler.com/) - RYM Genre Sampler / [GitHub](https://github.com/fouriels/rym-sampler)
* [MusicGenreTree](https://www.musicgenretree.org/chart.html) - Music Discovery by Genre / Random Recordings
* [Identifying Music Genres](https://chunisama.github.io/Identifying-Music-Genres/) - Interactive Music Genre Comparisons
* [Map of Metal](https://mapofmetal.com/) - Interactive History of Metal Music
* [Random Song Generator](https://randomsonggenerator.com/), [SampleRoulette](https://www.sampleroulette.io/) or [Samplette](https://samplette.io/) - Random YouTube Music Discovery
* [Kworb](https://kworb.net/), [Spotify Charts](https://charts.spotify.com/home) or [ChartRank](https://chartrank.app/) - Music Popularity / Streaming Charts
* [SuperFridayChart](https://www.superfridaychart.com/) - Spotify New Music Friday Chart Aggregator
* [⁠HappyHardcore](https://www.happyhardcore.com/forums/) - Hardcore Dance Music Forum
* [TranceFix](https://www.trancefix.nl/index.php) - Trance Music Forum

***

## ▷ Last.fm Tools

* 🌐 **[Awesome Last.fm](https://github.com/jnguyen1098/awesome-lastfm)** or [Last.fm Tool List](https://redd.it/1h8ec76) - Last.fm Tool Indexes
* ⭐ **[Last.fm Stats](https://lastfmstats.com/)** - In-Depth Last.fm Stats / [GitHub](https://github.com/felhag/lastfm-stats-web)
* ⭐ **[OpenScrobbler](https://openscrobbler.com/)** - Manually Scrobble Anything / [Discord](https://discord.gg/SEDp6Zy) / [GitHub](https://github.com/elamperti/openwebscrobbler)
* ⭐ **[Pano Scrobbler](https://github.com/kawaiiDango/pano-scrobbler)** - Multi-Platform Scrobbler
* ⭐ **[⁠bleh](https://bleh.yuzu.pet/)** - Last.fm Customization Script / [GitHub](https://github.com/katelyynn/bleh)
* [Last.fm Labs](https://www.last.fm/labs) - Last.fm Library Visualizers
* [Last.fm Iceberg](https://lastfm-iceberg.dawdle.space/) - Last.fm Artist Iceberg
* [TagCloud](https://tagcloud.rainosullivan.com/) - Last.fm Tag Cloud
* [Web Scrobbler](https://github.com/web-scrobbler/web-scrobbler) - Scrobble Any Site
* [Edit Scrobbles](https://greasyfork.org/en/scripts/485278) - Manually Edit Scrobbles
* [Descent](https://descent.live/) - Now Playing Tool
* [Chart My Music](https://www.chartmymusic.com/lastfm/), [TapMusic](https://www.tapmusic.net/), [SonicPrint](https://sonicprint.art/) or [MusicCoruMap](https://musicorumapp.com/generate) - Album Collages

***

# ► Audio Tools

* 🌐 **[Binaural Audio](https://binaural-audio.slite.page/p/i38zsD7728/Binaural-Audio)** - Binaural / 3D Audio Resources
* ↪️ **[System Audio Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/system-tools#wiki_.25B7_system_audio)**
* ↪️ **[Voice Change / Clone](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/ai#wiki_.25B7_voice_change_.2F_clone)**
* ↪️ **[Text to Speech](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/ai#wiki_.25B7_text_to_speech)**
* ⭐ **[Audio Glossary](https://wotaku.wiki/glossary/audio)** - Audio Terms Glossary
* ⭐ **[FFmpeg](https://ffmpeg.org/)**, [fre:ac](https://www.freac.org/) / [GitHub](https://github.com/enzo1982/freac), [Shutter Encoder](https://www.shutterencoder.com/) / [GitHub](https://github.com/paulpacifico/shutter-encoder), [FlicFlac](https://github.com/DannyBen/FlicFlac), [LameXP](https://sourceforge.net/projects/lamexp/) or [Sox](https://sourceforge.net/projects/sox/) - Audio Converters
* [Xconvert](https://www.xconvert.com/audio-tools) or [FreeConvert](https://www.freeconvert.com/audio-converter) - Online Audio Converters
* [⁠Hydrogenaudio Knowledgebase](https://wiki.hydrogenaudio.org/) - Audio Technology Wiki / Guides
* [CUETools](http://cue.tools/wiki/CUETools) - Manipulate .cue Files / [GitHub](https://github.com/gchudov/cuetools.net/)
* [Phiola](https://github.com/stsaz/phiola), [AudioToolSet](https://audiotoolset.com/) or [Safeaudiokit](https://safeaudiokit.com/) - Audio Multi-Tool Apps / Sites
* [Rarewares](https://www.rarewares.org/) - Rare Audio Software / Tools
* [Vocaroo](https://vocaroo.com/) - Online Voice Recorder
* [MusicKit](https://musickit.jull.dev/), [⁠Tuner](https://codeberg.org/thetwom/Tuner) or [Tone Generator](https://www.szynalski.com/tone-generator/) - Metronome, Tuner & Tone Generators
* [Tuner Ninja](https://tuner.ninja/) or [⁠Tonalics](https://tonalics.com/) - Instrument Tuners
* [Tunebat](https://tunebat.com/) or [QO & SPECTRE](https://docs.google.com/spreadsheets/u/0/d/1QEvWoGa10BctJ1yqDgZl3IoY8bhB3AwbHzgCHjJ5neI/htmlview) - Music Key / BPM Databases
* [Librescore Downloader](https://github.com/LibreScore/dl-librescore) - Librescore Downloader
* [M3Unator](https://github.com/hasanbeder/M3Unator) - Generate M3U Playlists from Open Directories

***

## ▷ Audio Players

* ↪️ **[Android Audio Players](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_android_audio_players)**
* ⭐ **[Foobar2000](https://www.foobar2000.org/)** / Feature-Rich Audio Player / Windows, macOS, Android, iOS
* ⭐ **Foobar2000 Tools** - [Components](https://audio-file.org/foobar2000-list-of-components/), [2](https://www.foobar2000.org/components) / [VU Meter](https://audio-file.org/foobar2000-vu-meter-skins-gallery/) / [Lyric Sync](https://rentry.co/FB2K-SyncedLyrics) / [Wiki](https://wiki.hydrogenaudio.org/index.php?title=Foobar2000:Foobar2000)
* ⭐ **[WACUP](https://getwacup.com/)** - Winamp Update Project / [Forum](https://getwacup.com/community/) / Windows / [Discord](https://discord.gg/5pVTdbj)
* ⭐ **[AIMP](https://www.aimp.ru/)** - Feature-Rich Audio Player / [Addons](https://aimp.ru/?do=catalog) / Windows, Linux, Android
* ⭐ **[MusicBee](https://getmusicbee.com/)** - Lightweight Audio Manager & Player / [Quality Badges](https://wiki.musichoarders.xyz/reference/musicbee/) / [Addons](https://getmusicbee.com/addons) / Windows
* [Astra](https://astramusic.dev/) - Audio Player / Windows, macOS, Linux / [Discord](https://discord.gg/CGESrnYfAy) / [GitHub](https://github.com/boof2015/astra)
* [Harmonoid](https://harmonoid.com/) - Audio Player / Windows, macOS, Linux, Android / [Discord](https://discord.gg/2Rc3edFWd8) / [GitHub](https://github.com/harmonoid/harmonoid)
* [Namida](https://github.com/namidaco/namida) - Feature-Rich Audio & Video Player / Windows, Linux, Android / [Telegram](https://t.me/namida_official) / [Discord](https://discord.gg/WeY7DTVChT)
* [Audion](https://audionplayer.com/) - Plugin-Based Audio Player / Windows, macOS, Linux, Android / [Discord](https://discord.gg/27XRVQsBd9) / [GitHub](https://github.com/dupitydumb/Audion)
* [TimeStretch](https://29a.ch/timestretch/) - Simple Web-Based Audio Player
* [MusikCube](https://github.com/clangen/musikcube) - Terminal-Based / Windows, macOS, Linux
* [ncmpc++](https://github.com/ncmpcpp/ncmpcpp) - Terminal-Based / macOS, Linux
* [XMPlay](https://www.un4seen.com/xmplay.html) - Module-Friendly / [Skins](https://www.un4seen.com/xmplay.html#skins) / [Plugins](https://www.un4seen.com/xmplay.html#plugins) / Windows
* [Butterchurn Visualizer](https://butterchurnviz.com/), [MusicVid](https://musicvid.org/), [MangoWave](https://mangowave.app/) / [GitHub](https://github.com/Louis-Mascari/MangoWave) or [Vizzy](https://vizzy.io/) - Online Audio Visualizers
* [CatNip](https://github.com/noriah/catnip) - Terminal-Based Audio Visualizer / Windows, macOS, Linux
* [PartyEngine](https://aggrocrab.itch.io/partyengine) - Audio Party Visualizer / Windows
* [Fooyin](https://www.fooyin.org/) - Audio Player / Windows, Linux / [GitHub](https://github.com/fooyin/fooyin)
* [⁠Nagi](https://github.com/Anthonyy232/Nagi) - Audio Player / Windows
* [Mornye](https://desktop.mornye.com/) - Audio Player / Windows, macOS, Linux / [GitHub](https://github.com/mornyeapp/Mornye-Desktop)
* [Snowify](https://snowify.cc/) - Audio Player / Windows, macOS, Linux / [Discord](https://discord.gg/JHDZraE5TD) / [GitHub](https://github.com/nyakuoff/Snowify)
* [Museeks](https://museeks.io/) - Simple Audio Player / Windows, macOS, Linux / [GitHub](https://github.com/martpie/museeks)
* [Audacious](https://audacious-media-player.org/) - Lightweight Audio Player / Windows, macOS, Linux / [GitHub](https://github.com/audacious-media-player/audacious)
* [Strawberry](https://www.strawberrymusicplayer.org/) - Audio Player / Windows, macOS, Linux / [GitHub](https://github.com/strawberrymusicplayer/strawberry) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/strawberry-note.md)
* [Sonora](https://sonorahq.org/) - Audio Player / Subsonic Player / Windows, macOS, Linux / [Discord](https://discord.gg/a8N8Tx23rV) / [GitHub](https://github.com/nolight132/sonora)
* [Exaile](https://exaile.org/) - Audio Player / Windows, macOS, Linux / [GitHub](https://github.com/exaile/exaile)
* [quodlibet](https://github.com/quodlibet/quodlibet/) - Audio Manager & Player / Windows, macOS, Linux
* [deadbeef](https://deadbeef.sourceforge.io/) - Audio Player / [Plugins](https://deadbeef.sourceforge.io/plugins.html) / Windows, macOS, Linux / [GitHub](https://github.com/DeaDBeeF-Player/deadbeef)
* [Swing](https://swingmx.com/) - Self-Hosted Browser Music Player / Windows, Linux / [Telegram](https://t.me/+9n61PFcgKhozZDE0) / [GitHub](https://github.com/swingmx/swingmusic)
* [Nora](https://noramusic.netlify.app/) - Audio Player / [Discord](https://discord.gg/c5rGKnBs4y) / [GitHub](https://github.com/Sandakan/Nora)
* [Dopamine](https://github.com/digimezzo/dopamine) - Simple Audio Player / Windows, macOS, Linux
* [Feishin](https://github.com/jeffvli/feishin) - Jellyfin / Navidrome / Subsonic Player / Windows, macOS, Linux / [Discord](https://discord.gg/FVKpcMDy5f)
* [Aonsoku](https://github.com/victoralvesf/aonsoku) - Navidrome / Subsonic Player / Windows, macOS, Linux
* [LedFx](https://docs.ledfx.app/en/stable/) - LED Music Sync / Windows / [Discord](https://discord.gg/xyyHEquZKQ) / [GitHub](https://github.com/ledfx/ledfx)
* [RockBox](https://www.rockbox.org/) - Custom Player for Audio Devices / [Wiki](https://www.rockbox.org/wiki/) / [Themes](https://themes.rockbox.org/)
* [VinylEngine](https://www.vinylengine.com/) - Record Player / Vinyl Info

***

## ▷ Audio Servers

* ⭐ **[Navidrome](https://navidrome.org)**
* ⭐ **[Airsonic Advanced](https://github.com/airsonic-advanced/airsonic-advanced)** / [Web UI](https://github.com/tamland/airsonic-refix)
* ⭐ **[koel](https://koel.dev/)**
* ⭐ **[iBroadcast](https://ibroadcast.com)**
* [Lyrion](https://lyrion.org/) / [Extensions](https://lyrion.org/extensions/applications/)
* [mStream](https://mstream.io/)
* [Mopidy](https://mopidy.com/)
* [Black Candy](https://github.com/blackcandy-org/blackcandy)
* [RMPC](https://rmpc.mierak.dev/) / [GitHub](https://github.com/mierak/rmpc) or [Music Player Daemon](https://www.musicpd.org/)
* [Polaris](https://github.com/agersant/polaris)
* [Gonic](https://github.com/sentriz/gonic)
* [Ampache](https://ampache.org/)

***

## ▷ Audio Metadata

* ⭐ **[MP3Tag](https://www.mp3tag.de/en/)** - Metadata Organizer
* ⭐ **[MusicBrainz Picard](https://picard.musicbrainz.org/)** - Metadata Organizer / [GitHub](https://github.com/metabrainz/picard)
* [Beets](https://beets.io/) - Metadata Organizer / [Guides](https://redd.it/11iaafu) / [GitHub](https://github.com/beetbox/beets)
* [TagEditor](https://github.com/Martchus/tageditor) - Metadata Organizer
* [tone](https://github.com/sandreas/tone) - Metadata Organizer
* [Kid3](https://kid3.kde.org/) - Metadata Organizer
* [Imploded](https://www.imploded.com/) - Metadata Organizer
* [MetaTogger](https://luminescence-software.org/en/metatogger/about/) - Metadata Organizer
* [TagScanner](https://www.xdlab.ru/en/) - Metadata Organizer

***

## ▷ Album Artwork

* ⭐ **[Cover Search Engine](https://covers.musichoarders.xyz)**, [CoverAtlas](https://www.coveratlas.com/), [Albumart.Digital](https://albumart.digital/) or [bigpictures](https://bigpictures.xyz/) - Album Art Search Engines
* ⭐ **[SpotifyArt](https://spotify-art.vercel.app/)** - Spotify Album Art Downloader / Web / [GitHub](https://github.com/Shiawaseu/SpotifyArt)
* [Apple Artwork](https://artwork.thekvt.eu.org/) - Apple Music Album Art Downloader
* [MediUX Album Covers](https://mediux.pro/albums) - Media Soundtrack Album Art
* [Classic Rock Covers](https://www.classic-rock-covers.com/) - Rock Album Art
* [⁠covers](https://covers.brunoimbrizi.com/) - Album Art Visual Similarity Search
* [Album Art Downloader](https://sourceforge.net/projects/album-art/), [kunst](https://github.com/sdushantha/kunst) or [Fetcher](https://github.com/bunnykek/Fetcher) - Album Art Download Apps

***

## ▷ Song Identification

* ⭐ **[Google Song Identification](https://support.google.com/websearch/answer/7554088)** / Android, iOS / [Guide](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/google-song-identification.md)
* ⭐ **[Shazam](https://www.shazam.com/)** / macOS, Android, iOS, Web / [Features](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_modded_apks) (search) / [Desktop App](https://github.com/BayernMuller/vibra), [2](https://github.com/zemoto/WhatAmIHearing) / [Extensions](https://github.com/FoxRefire/Librezam)
* ⭐ **[WatZatSong](https://www.watzatsong.com/en)** or [r/NameThatSong](https://reddit.com/r/NameThatSong) - Song ID Communities
* [FlairMax](https://apps.microsoft.com/detail/9pdzvj34ztxg) / Windows
* [Song Finder](https://songfinder.dev/) / Web
* [AudioTag](https://audiotag.info/) / Web
* [⁠SongFinder](https://songfinder.tech/) / Web
* [⁠SongFinder (gg)](https://songfinder.gg/) / Web
* [SoundHound](https://www.soundhound.com/soundhound) / Android, iOS
* [Audile](https://github.com/aleksey-saenko/MusicRecognizer) / Android
* [Audire](https://github.com/alexmercerind/audire) / Android
* [AmbientMusicMod](https://github.com/KieronQuinn/AmbientMusicMod) / Android
* [SongGuesser](https://songguesser.com/) - Identify Songs via Keyboard Taps / Melody
* [SampleSeek](https://www.sampleseek.co.uk/) - Find Sample Origins
* [AHA Music](https://www.aha-music.com/identify-songs-music-recognition-online) - Chrome Extension / Web
* [u/auddbot](https://www.reddit.com/user/auddbot) - Reddit Identification Bot (tag u/auddbot) / [GitHub](https://github.com/AudDMusic/RedditBot)

***

## ▷ Lyric Sites

* ⭐ **[LyricsTranslate](https://lyricstranslate.com/)** - Lyric Translations / Requests
* ⭐ **[dumb](https://github.com/rramiachraf/dumb)**, [Intellectual](https://intellectual.insprill.net/) or [Genius](https://genius.com/) - Lyric Explanations
* [lrc.red](https://lrc.red/), [AZLyrics](https://www.azlyrics.com/), [Lyricsify](https://www.lyricsify.com/), [Lyrhub](https://lyrhub.com/en), [FindMusicByLyrics](https://findmusicbylyrics.com/) or [Lyrics.com](https://www.lyrics.com/) - Lyric Search
* [⁠Lyrical Nonsense](https://www.utatime.com/global/) - Japanese Song Lyrics
* [⁠AnimeSongLyrics](https://www.animesonglyrics.com/) - Anime Song Lyrics
* [Lyricify](https://github.com/WXRIW/Lyricify-App) - Lyrics Desktop App
* [Versefy](https://versefy.app/) or [Lyrics-In-Terminal](https://github.com/Jugran/lyrics-in-terminal) - Lyric Finder for Spotify / Tidal / VLC
* [SongMeanings](https://songmeanings.com/) - Discover Song Meanings

***

## ▷ Karaoke / Synced Lyrics

* ⭐ **[LRCGET](https://github.com/tranxuanthang/lrcget)** or [⁠MLDL](https://anik200.github.io/mldl/) - Synced Lyrics Download Tool
* ⭐ **[LRCLIB](https://lrclib.net/)** - Synced Lyrics Search / [Uploader](https://lrclibup.boidu.dev/) / [GitHub](https://github.com/tranxuanthang/lrclib)
* [lrc.red](https://lrc.red/) - Download Synced Lyrics
* [Karaoke Mugen](https://mugen.karaokes.moe/en/) or [Karaoke Eternal](https://www.karaoke-eternal.com/) / [Discord](https://discord.gg/PgqVtFq) / [GitHub](https://github.com/bhj/KaraokeEternal/) - Karaoke Apps / Systems
* [⁠Karaoke Studio](https://karaoke.zoryva.me/) - Online Karaoke Player + Mobile Remote
* [⁠Spotify Karaoke](https://github.com/haroldalan/spotify-karaoke) - Karaoke, Romanization + Translation for Spotify Web Player Lyrics
* [Versefy](https://versefy.app/) or [sptlrx](https://github.com/raitonoberu/sptlrx) - Spotify Synced Lyrics
* [Syrics](https://github.com/akashrchandran/syrics-web) - Download Spotify Synced Lyrics
* [FB2K-SyncedLyrics](https://rentry.co/FB2K-SyncedLyrics) - Foobar2000 Synced Lyrics
* [⁠LRC Maker](https://lrc-maker.github.io/) / [GitHub](https://github.com/magic-akari/lrc-maker) or [Composer](https://composer.betterlyrics.org/) / [GitHub](https://github.com/better-lyrics/composer) - Synced Lyrics Editor
* [X-Minus](https://x-minus.pro/), [⁠Croonify](https://croonify.com/) or [LRCMaker.com](https://lrcmaker.com/) - Create / Find Karaoke Songs
* [synced+](https://mono-o-o.github.io/synced-plus/) - Word Synced Lyrics Creator / [GitHub](https://github.com/mono-o-o/synced-plus)
* [⁠Unison](https://unison.betterlyrics.org/) - Crowdsourced Synced Lyrics Database + API / [GitHub](https://github.com/better-lyrics/unison)
* [⁠Kara.moe](https://kara.moe/) - Anime Theme Song Videos / Download / Karaoke

***

## ▷ Sheet Music / Notation

* 🌐 **[Awesome Music](https://github.com/noteflakes/awesome-music)** - Music / Notation Tools Index
* 🌐 **[Awesome Sheet Music](https://github.com/ad-si/awesome-sheet-music)** - Sheet Music Software & Resources
* ↪️ **[Music Sheet Collections](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_music_sheet_collections)**
* ⭐ **[MuseScore](https://musescore.org/)**, [MC Musiceditor](https://www.mcmusiceditor.com/) or [Score Perfect Professional](https://archive.org/details/score-perfect-professional-lite-5.1/) - Music Scoring Software
* [Sheet Host](https://sheet.host/) - Sheet Music Hosting
* [The ABC Music Project](https://abc.sourceforge.net/) / [Editor](https://sourceforge.net/projects/toadflax/), [2](https://runabc.sourceforge.io/), [3](https://easyabc.sourceforge.net/) / [PNG Convert](https://sourceforge.net/projects/abccairo/) / [MIDI Convert](https://abcmidi.sourceforge.io/) / [Webpages](https://netabc.sourceforge.io/) - Notation Markup Language
* [Chordly](https://chordly.co.uk/) - Chord Sheet Creator / [GitHub](https://github.com/stufro/chordly)
* [Piascore](https://apps.apple.com/app/piascore-hd/id406141702) - iOS Music Score Viewer
* [r/sheetmusic](https://reddit.com/r/sheetmusic) - Reddit Community
* [VGLeadSheets](https://www.vgleadsheets.com/) - Transcribe Video Game Music
* [Omnizart](https://github.com/Music-and-Culture-Technology-Lab/omnizart) - Python Music Transcription Library
* [Audiveris](https://audiveris.github.io/audiveris/_pages/handbook/) - OMR Engine / [GitHub](https://github.com/Audiveris/audiveris)
* [Oemer](https://github.com/BreezeWhite/oemer) - OMR Tool / [Colab](https://colab.research.google.com/github/BreezeWhite/oemer/blob/main/colab.ipynb) / [Demo](https://breezewhite.github.io/oemer/)
* [Sheet Music Scanner](https://sheetmusicscanner.com/) - Mobile OMR App
* [Sound Slice](https://soundslice.com/) or [Nootka](https://sourceforge.net/projects/nootka/) - Sheet Music Learning
* [Nutkus](https://sourceforge.net/projects/nutkus/) - Notation Learning Game

***

## ▷ Spectrum Analyzers

* ⭐ **[Audio Quality Check Guide](https://redd.it/3l0yxp)**
* ⭐ **[Fakin' The Funk?](https://fakinthefunk.net/)**
* ⭐ **[Sonic Visualizer](https://www.sonicvisualiser.org/)**
* ⭐ **[Spek](https://www.spek.cc/)**
* [⁠AudioAuditor](https://audioauditor.org/) / [GitHub](https://github.com/Angel2mp3/AudioAuditor)
* [⁠Musigram](https://musitools.xyz/musigram/) / Web
* [⁠Acoustic Spectrum Analyzer](https://spec.squid.wtf/) / Web
* [⁠WhatsMyBitrate](https://whatsmybitrate.com/) / Web
* [Visual Analyser](https://www.sillanumsoft.org/)
* [Friture](https://friture.org/) / [GitHub](https://github.com/tlecomte/friture)
* [Spectro](http://spectro.enpts.com/)
* [Cambia](https://logs.musichoarders.xyz/) - CD Rip Log Checker

***

## ▷ [Linux Audio Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_linux_audio)

***

## ▷ [Mac Audio Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_mac_audio)

***

# ► Audio Editing

* 🌐 **[Awesome Music Production](https://github.com/ad-si/awesome-music-production)** or [AFreeStudio](https://www.afreestudio.com/) - Music Production Indexes
* ↪️ **[AI Audio Generation](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/ai#wiki_.25BA_audio_generation)**
* ↪️ **[Separate Voice / Instrumentals](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/ai#wiki_.25B7_voice_removal_.2F_separation)**
* ⭐ **[AudioSEX](https://audiosex.pro/)**, [KVR Audio](https://www.kvraudio.com/) or [VI-CONTROL](https://vi-control.net/community/) - Audio Production Forums / News
* [ProducerLibrary](https://producerlibrary.carrd.co/) - Audio Production Tutorials
* [⁠Beat Battle](https://beat-battle.net/) - Browser Beat Battle Game
* [⁠OpenUtau](https://www.openutau.com/) - Vocal Synth / Singing Platform / [Guides](https://utauguides.carrd.co/) / [GitHub](https://github.com/stakira/OpenUtau)
* [Tonocracy](https://tonocracy.com/), [NeuralAmpModeler](https://www.neuralampmodeler.com/), [GuitarML](https://guitarml.com/index.html) or [TONEX CS](https://www.ikmultimedia.com/products/tonex/#tonexcs) - Guitar Tones, Effects & Virtual Amps
* [Tone3000](https://tone3000.com/) - Guitar Tone Profiles
* [PresetShare](https://presetshare.com/) - Audio Presets / Requires Sign-Up
* [VSTSkins](https://vstskins.com/category/skins/?fwp_license=free) - VST Skins

***

## ▷ Audio Editors

* ⭐ **[Tenacity](https://tenacityaudio.org/)** / [Source Code](https://codeberg.org/tenacityteam/tenacity), [Audacity](https://www.audacityteam.org/) / [Discord](https://discord.com/invite/audacity) / [GitHub](https://github.com/audacity/audacity) or [ocenaudio](https://www.ocenaudio.com/) - Audio Editors
* ⭐ **[FL Studio](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/torrent#wiki_.25BA_torrent_sites)** (search) / [Guide](https://www.image-line.com/learn) / [2](https://www.image-line.com/fl-studio-learning/fl-studio-online-manual) / [3](https://support.image-line.com/action/knowledgebase), **[Reaper](https://www.reaper.fm/) / [Tips](https://www.reapertips.com/) / [Resources](https://www.realinks.net/) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/reaper-note.md)**, [KiraStudio](https://kirastudio.org/) / [GitHub](https://github.com/BleuBleu/KiraStudioPublic), [Zrythm](https://www.zrythm.org/en/index.html) / [GitLab](https://gitlab.zrythm.org/zrythm/zrythm), [Waveform](https://www.tracktion.com/products/waveform-free) or [LMMS](https://lmms.io/) / [Discord](https://discord.com/invite/PruNxpG) / [GitHub](https://github.com/LMMS) - Digital Audio Workstations
* ⭐ **[OpenMPT](https://openmpt.org/)** / [Source Code](https://source.openmpt.org/) / [GitHub](https://github.com/OpenMPT/openmpt/), [Schism Tracker](https://schismtracker.org/) / [GitHub](https://github.com/schismtracker/schismtracker), [Furnace](https://tildearrow.org/furnace/) / [Discord](https://discord.gg/QhA26dXD23) / [GitHub](https://github.com/tildearrow/furnace), [16-Bits](https://16-bits.org/) / [GitHub](https://github.com/8bitbubsy?tab=repositories) or [MilkyTracker](https://milkytracker.org/) / [GitHub](https://github.com/milkytracker/MilkyTracker) - Music Trackers
* [Team V.R releases](https://rentry.co/FMHYB64#team-vr), [G-MEH](https://g-meh.com/) / [Discord](https://discord.com/invite/g-meh) or [AudioZ](https://audioz.download/) / [Forum](https://audiosex.pro/) - Audio Editor Indexes
* [Ossia](https://ossia.io/) - Intermedia Sequencer / [GitHub](https://github.com/ossia/score)
* [Mixxx](https://mixxx.org/) / [GitHub](https://github.com/mixxxdj/mixxx), [VirtualDJ](https://www.virtualdj.com/) or [Serato](https://serato.com/) - DJ Software
* [Moises](https://moises.ai/) - Live Music Mixer
* [plugdata](https://plugdata.org/) - Visual Audio Editor / [Discord](https://discord.com/invite/eT2RxdF9Nq)
* [Element](https://kushview.net/element/) or [Bespoke](https://www.bespokesynth.com/) - Modular Audio Environments / [Discord](https://discord.com/invite/RVk3RVJ)
* [Bosca Ceoil](https://yurisizov.itch.io/boscaceoil-blue) - Simple Music Editor / Composer / [Web Version](https://humnom.net/apps/boscaceoil/)
* [Music Experiment](https://petersalomonsen.com/webassemblymusic/livecodev2/), [Sonic-Pi](https://sonic-pi.net/), [SuperCollider](https://supercollider.github.io/), [⁠Strudel](https://strudel.cc/) or [WebChuck IDE](https://ccrma.stanford.edu/~tzfeng/webchuck-ide/) - Code-Based Audio Creators
* [WaveTracker](https://wavetracker.org/) - Wavetable Audio Editor / [GitHub](https://github.com/squiggythings/WaveTracker)
* [FamiStudio](https://famistudio.org/) - NES Audio Editor / [Discord](https://discord.gg/QRCMe595Pv) / [GitHub](https://github.com/BleuBleu/FamiStudio)
* [LittleSoundDJ](https://www.littlesounddj.com/lsd/index.php) - Game Boy Audio Editor
* [Rosegarden](https://rosegardenmusic.com/) or [Ariamaestosa](https://ariamaestosa.github.io/ariamaestosa/docs/index.html) - MIDI Sequencer / Notation Editors
* [Basic Pitch](https://basicpitch.spotify.com/) - Audio-to-MIDI Converter
* [BitMidi](https://bitmidi.com/) or [VGMusic](https://www.vgmusic.com/) - MIDI Files
* [Mod Archive](https://modarchive.org/) - Audio Modules
* [Fadr](https://fadr.com/) or [StemRoller](https://www.stemroller.com/) / [GitHub](https://github.com/stemrollerapp/stemroller) - STEM Creator / Editors

***

## ▷ Browser Editors / Synths

* ⭐ **[BandLab](https://www.bandlab.com/)**, **[Audioalter](https://audioalter.com/)**, **[WavaCity](https://wavacity.com/)**, [⁠Riffle](https://www.riffle.studio/), [Bosca Ceoil](https://humnom.net/apps/boscaceoil/), [⁠Audiotool](https://www.audiotool.com/), [AudioMass](https://github.com/pkalogiros/audiomass), [editor.audio](https://editor.audio/), [TwistedWave](https://twistedwave.com/online) or [xAudioPro](https://www.xaudiopro.com/en/) - Online Editors / Web DAWs
* ⭐ **[Drumhaus](https://www.drumha.us/)**, [⁠10K Drum Machines](https://10kdrummachines.com/), [iO-808](https://io808.com/), [Sequencer64](https://www.sequencer64.com/), [Drummy](https://drummy.io/), [DrumBit](https://drumbit.app/), [Roland50.studio](https://roland50.studio/), [Acid Machine 2](https://errozero.co.uk/acid-machine/), [orDrumbox](https://www.ordrumbox.com/) or [Hydrogen](http://hydrogen-music.org/) - Virtual Drum Machines
* [UltraBox](https://ultraabox.github.io/), [AbyssBox](https://choptop84.github.io/abyssbox-app/), [JummBox](https://jummb.us/) / [GitHub](https://github.com/jummbus/jummbox), [BeepBox](https://www.beepbox.co/) or [GoldBox](https://aurysystem.github.io/goldbox/) - Online Sequencer / BeepBox Forks
* [Efflux](https://www.igorski.nl/application/efflux/) - Online Tracker / Sequencer
* [Sequencer](https://sequencer.henryfellerhoff.com/), [Draw Audio](https://draw.audio/) or [DrawBeats](https://drawbeats.com/) - Scale Sequencers
* [Petaporon](https://pixwlk.itch.io/petaporon) - Piano Sequencers / [Instrument Editor](https://pixwlk.itch.io/petaporon-editor)
* [⁠Signal](https://signalmidi.app/edit) / [Discord](https://discord.com/invite/XQxzNdDJse) / [GitHub](https://github.com/ryohey/signal/) or [OnlineSequencer](https://onlinesequencer.net/) - MIDI Editors
* [WebSynths](https://www.websynths.com/) - Browser Synthesizers
* [⁠CZP-1](https://www.crazyphase.com/czp-1/) - Phase Distortion Synthesizer
* [NoiseCraft](https://noisecraft.app/) - Modular Synth Builder
* [VirtualPiano](https://virtualpiano.net/) - Browser Pianos
* [MK-1](https://ericrosenbaum.github.io/MK-1/) - Online Sampling Keyboard
* [VO Pads](https://vo.odgn.net/) - Video Sample Sequencer
* [React Guitar](https://react-guitar.com/) - Virtual Guitar
* [Theremin](https://femurdesign.com/theremin/) - Virtual Theremin
* [Pantam Playground](https://www.yishama.com/virtual-pantam-playground/) - Virtual Pantam
* [WD-1](https://www.worteldrie.com/WD5/) or [YOU.DJ](https://you.dj/) - Online DJ / Beat Creators
* [PIXELSYNTH](https://ojack.xyz/PIXELSYNTH/) - Image to Sound Synthesizer
* [Slowed and Reverb](https://slowedandreverb.studio/) or [Song Slower](https://songslower.com/) - Make Slowed, Reverb and Remixed Songs
* [BeatMachine](https://beatmachine.branchpanic.me/) or [bungee](https://bungee.parabolaresearch.com/bungee-web-demo) - Audio Tempo Editors
* [MIDI Recorder](https://midi-recorder.web.app/) - MIDI Keyboard Recorder

***

## ▷ Audio Plugins

* 🌐 **[Free VST Plugins](https://bedroomproducersblog.com/free-vst-plugins/)**, [2](https://docs.google.com/spreadsheets/d/1wr0RjPfQvD_VrIivi4U4tsnqMdL78sWOaDUI2Z95R9U/htmlview?fbclid=IwAR3jUwxfkL7aMruLKomutJZ7-H3xjM1X4JX422mSbCgECdt5ugkHtGWlsF8##gid=0) - Freeware Plugin Index
* 🌐 **[Open-Source Audio Plugins](https://openaudio.webprofusion.com/)** - Open Source Plugin Projects Index
* ⭐ **[AudioZ](https://audioz.download/)** - Download / [Forum](https://audiosex.pro/)
* ⭐ **[Team V.R releases](https://rentry.co/FMHYB64#team-vr)** - Download
* ⭐ **[Surge XT](https://surge-synthesizer.github.io/)** - Hybrid / Subtractive Synth
* ⭐ **[Vital](https://vital.audio/)** or [Helm](https://tytel.org/helm/) - Wavetable Synths
* ⭐ **[Dexed](https://asb2m10.github.io/dexed/)** - Yamaha DX7 Emulation
* [G-MEH](https://g-meh.com/) - Download / [Discord](https://discord.com/invite/g-meh)
* [AudioWavePro](https://t.me/AudioWavePro) - Telegram / AudioZ Reuploads
* [Decent Sampler](https://www.decentsamples.com/product/decent-sampler-plugin/) or [sforzando](https://www.plogue.com/products/sforzando.html) - VST Samplers / [Libraries](https://www.decentsamples.com/), [2](https://sfzinstruments.github.io/), [3](https://unreal-instruments.wixsite.com/unreal-instruments)
* [Pianobook](https://www.pianobook.co.uk/) - 1500+ Sample Packs / Requires Sign-Up
* [VCV Rack 2](https://vcvrack.com/Rack) or [Cardinal](https://cardinal.kx.studio/) - Eurorack Simulators
* [IEM Plug-in Suite](https://plugins.iem.at/), [ModularSamples](https://github.com/publicsamples), [Igorski](https://www.igorski.nl/download) / [GitHub](https://github.com/igorski?utf8=✓&tab=repositories&q=vst), [SPARTA](https://leomccormack.github.io/sparta-site/) or [Chowdhury DSP](https://chowdsp.com/products.html) - Open-Source Plugins
* [Plugins4Free](https://plugins4free.com/), [looperman](https://www.looperman.com/free-music-software), [⁠Kilohearts Essentials](https://kilohearts.com/products/kilohearts_essentials), [⁠drumkits](https://drumkits.site/), [⁠blepfx](https://fx.amee.ee/) or [AirWindows](https://www.airwindows.com/) / [Consolidated](https://www.airwindows.com/consolidated/) - Plugins / Use Adblocker
* [⁠osci-render](https://osci-render.com/) - Audio-Visual Music Making Plugin / [GitHub](https://github.com/jameshball/osci-render)
* [Krush](https://www.tritik.com/product/krush/) - Bitcrusher Plugin
* [samplv1](https://samplv1.sourceforge.io/) - Polyphonic Sampler
* [MonkSynth](https://github.com/JonET/monksynth) - Monophonic Vocal Synthesizer Plugin / [Web](https://jonet.github.io/delaylama-web-demo/)
* [Maim](https://github.com/ArdenButterfield/Maim) - Audio Distortion Plugin
* [r/SynthRecipes](https://www.reddit.com/r/synthrecipes/) - Synth Request Subreddit

***

## ▷ SFX / Samples

* ⭐ **[Kits4Beats](https://kits4beats.com/)** - Samples / Use Ublock / [Telegram](https://t.me/kits4beats)
* ⭐ **[PLUGG SUPPLY](https://t.me/pluggsupply)** - Samples / Telegram / [VK](https://vk.com/pluggsupply)
* ⭐ **[OrangeFreeSounds](https://orangefreesounds.com/)** - Sound Effects
* [Stash](https://rentry.co/FMHYB64#dkl) - Samples / Drumkits / Presets
* [FreeSoundsLibrary](https://www.freesoundslibrary.com/) - Sound Effects
* [BandLab Samples](https://www.bandlab.com/sounds/free-samples) - Samples
* [⁠SoundPacks](https://soundpacks.com/) - Samples
* [SongStems](https://songstems.net/) - STEM Files
* [SoundGator](https://www.soundgator.com/) - Sound Effects
* [GDC](https://sonniss.com/gameaudiogdc) - Sound Effects
* [⁠BigSoundBank](https://bigsoundbank.com/) - Sound Effects
* [Citizen DJ](https://citizen-dj.labs.loc.gov/) - Sound Effects
* [Free Adobe SFX](https://www.adobe.com/products/audition/offers/AdobeAuditionDLCSFX.html) - Sound Effects
* [r/LoopKits](https://www.reddit.com/r/loopkits/), [Freesound](https://freesound.org/), [Voicy](https://www.voicy.network/), [looperman](https://www.looperman.com/loops) or [SampleSwap](https://sampleswap.org/) - User-Submitted Samples
* [⁠SmoredBoard](https://www.smoredboard.com/) / [Discord](https://discord.gg/bkYY39VgQ2), [EXP Soundboard](https://sourceforge.net/projects/expsoundboard/), [Sound Show](https://soundshow.app/) / [Discord](https://discord.com/invite/8pGnfJyzNq), [Soundux](https://soundux.rocks/), [Amplitude Soundboard](https://amplitude-soundboard.dan0v.com/) / [GitHub](https://github.com/dan0v/AmplitudeSoundboard) or [Resanance](https://resanance.com/) - Soundboard Programs
* [MyInstants](https://www.myinstants.com/index/us/), [101soundboards](https://www.101soundboards.com/), [Sound Instants](https://soundinstants.com/), [SoundboardGuys](https://soundboardguys.com/) or [Soundboard.com](https://www.soundboard.com/) - Online Soundboards
* [The Sounds Resource](https://sounds.spriters-resource.com/) - Game Sound Effects
* [⁠SourceSFX](https://sourcesfx.com/) - Source Engine Sound Effects Database
* [SampleBrain](https://gitlab.com/then-try-this/samplebrain), [rFXGen](https://raylibtech.itch.io/rfxgen), [Bfxr](https://www.bfxr.net/) / [GitHub](https://github.com/increpare/bfxr2), [ChipTone](https://sfbgames.itch.io/chiptone) or [SFXR](https://sfxr.me/) - Sound Effect Creators
* [BBC Sound Effects](https://sound-effects.bbcrewind.co.uk/) / [Downloader](https://github.com/get-iplayer/get_iplayer)
* [SNES Soundfonts](https://www.williamkage.com/snes_soundfonts/) or [Musical Artifacts](https://musical-artifacts.com/) - Soundfonts

***

# ► [System Audio](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/system-tools/#wiki_.25B7_system_audio)

***

# ► [Android Audio](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25BA_android_audio)

***

# ► [iOS Audio](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25BA_ios_audio)
