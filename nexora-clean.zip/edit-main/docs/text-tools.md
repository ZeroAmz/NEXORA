***
***
**[◄◄ Back to Wiki Index](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/tools-index)**
***
***

# ► Text Tools

* ↪️ **[Image to Text](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/image-tools#wiki_.25B7_image_to_text_.2F_ocr)**
* ↪️ **[Text to Speech](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/ai#wiki_.25B7_text_to_speech)**
* ↪️ **[Presentation / Slideshare](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_presentation_tools)**
* ↪️ **[Research Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/edu/#wiki_.25B7_research_tools)**
* ↪️ **[Data Visualization](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_data_visualization_tools)**
* ⭐ **[TextFixer](https://www.textfixer.com/)**, [SortMyList](https://sortmylist.com/) , [OnlineTextTools](https://onlinetexttools.com/), [Convert Case](https://convertcase.net/) or [The Alphabetizer](https://alphabetizer.flap.tv/) - Organize / Format Text
* ⭐ **[Paperless-ngx](https://docs.paperless-ngx.com)** / [Doc Analyzer](https://github.com/clusterzx/paperless-ai/) / [GitHub](https://github.com/paperless-ngx/paperless-ngx), [OpenPaper](https://openpaper.work/en/), [papis](https://github.com/papis/papis), [⁠Docspell](https://docspell.org/) / [GitHub](https://github.com/eikek/docspell), [⁠Papra](https://papra.app/en/) / [GitHub](https://github.com/papra-hq/papra) or [DataShare](https://datashare.icij.org/) - Document Managers
* [Diffr](https://loilo.github.io/diffr/) / [GitHub](https://github.com/loilo/diffr), [TextCompare](https://www.textcompare.org/), [OnlineTextCompare](https://onlinetextcompare.com/) or [CompareText](https://www.comparetext.io/) - Compare Text
* [Count Duplicates](https://www.somacon.com/p568.php) or [DuplicateWord](https://duplicateword.com/) - Count / Remove Duplicates in a List
* [⁠Unredact](https://github.com/leedrake5/unredact) - PDF Redaction Text Recovery
* [Textify](https://ramensoftware.com/textify) or [WindowTextExtractor](https://github.com/AlexanderPro/WindowTextExtractor) - Copy Text from Any Dialog
* [Scanner](https://simon-knuth.github.io/scanner/index) / [GitHub](https://github.com/simon-knuth/scanner) or [NAPS2](https://www.naps2.com/) - Scanner Apps
* [DocuSeal](https://www.docuseal.com/) - Free Document Signing / [GitHub](https://github.com/docusealco/docuseal)
* [Asciify](https://asciify.dev/) - ASCII Character Reference Chart

***

## ▷ Pastebins

* 🌐 **[⁠Awesome Pastebins](https://github.com/lorien/awesome-pastebins)** - Pastebin Index
* ⭐ **[PrivateBin](https://privatebin.net/)**, **[Paste.to](https://paste.to/)**, [NoteBin](https://notebin.de/), [TxtBin](https://txtbin.org/) or [⁠ZeroBin](https://www.zerobin.net/) - Markdown Support / Syntax Highlighting / [Instances](https://privatebin.info/directory) / [GitHub](https://github.com/PrivateBin/PrivateBin)
* ⭐ **[GitHub Gists](https://gist.github.com/)** or [GitLab Snippets](https://docs.gitlab.com/user/snippets/) - Multi-Syntax / Requires Sign-Up
* ⭐ **[Rentry](https://rentry.co/)**, [2](https://rentry.org/) - Markdown Support / Custom URLs / [CLI](https://github.com/radude/rentry) / [Styling](https://rentry.co/rentryarchived)
* ⭐ **[Yasosu](https://yaso.su/)** - Multi-Syntax / Markdown Support / Custom URLs / [Telegram](https://t.me/yaso_updates)
* ⭐ **[Fluffle](https://fluffle.cc/)** - Markdown Support / Custom URLs / [Styling](https://fluffle.cc/docs/markdown) / [Source Code](https://git.0x8e.net/t/fluffle) / [Note](https://github.com/fmhy/edit/blob/main/docs/.vitepress/notes/fluffle-note.md)
* ⭐ **[Paster](https://paster.net/)** - Multi-Syntax / Markdown Support
* ⭐ **[Katbin](https://katb.in/)** - Plain Text / [GitHub](https://github.com/sphericalkat/katbin)
* [Text.is](https://text.is/) - Markdown Support
* [Bpaste](https://bpa.st/), [2](https://bpa.st/) - Multi-Syntax / Markdown Support / [GitHub](https://github.com/supakeen/pinnwand)
* [snowbin](https://pastes.fmhy.net/), [2](https://paste.fmhy.net/) - Markdown Support / [GitHub](https://github.com/fmhy/snowbin)
* [Pastebin.com](https://pastebin.com/) - Multi-Syntax / [Proxy](https://pastebinp.com/)
* [⁠Ghostbin](https://ghostbin.linuxbox.ninja/) - Multi-Syntax / Markdown Support / [GitHub](https://github.com/borrougagnou/spectre-updated)
* [cryptgeon](https://cryptgeon.org/) - Single View / Plain Text / [GitHub](https://github.com/cupcakearmy/cryptgeon)
* [Paste](https://paste.boxlabs.uk/) - Multi-Syntax / Markdown Support / [GitHub](https://github.com/boxlabss/PASTE)
* [⁠Codepasta](https://codepasta.app/) - Multi-Syntax / Markdown Support
* [lesma](https://lesma.eu/) - Multi-Syntax / [GitLab](https://gitlab.com/ogarcia/lesma)
* [Pastee](https://pastee.dev/) - Multi-Syntax / [Discord](https://discord.com/invite/WQJ8z5G)
* [pst.moe](https://pst.moe/) - Multi-Syntax
* [pastes.dev](https://pastes.dev/) - Multi-Syntax / [GitHub](https://github.com/lucko/paste)
* [NoPaste](https://nopaste.boris.sh/) - Multi-Syntax / [GitHub](https://github.com/bokub/nopaste)
* [⁠Pastefy](https://pastefy.app/) - Multi-Syntax / [Discord](https://go.intera.dev/discord) / [GitHub](https://github.com/interaapps/pastefy)
* [pastemyst](https://paste.myst.rs/) - Multi-Syntax / [GitHub](https://github.com/codemyst/pastemyst)
* [CentOS Pastebin](https://paste.centos.org/) - Multi-Syntax
* [dpaste.com](https://dpaste.com/) - Multi-Syntax
* [snippet.host](https://snippet.host/) - Multi-Syntax / [.onion](http://snippetwtaasz6cid2he6vxcuwu3phck5uumidsbamkgmq3cuuydxiyd.onion/) / [Status](https://bit.ly/snippethoststatus)
* [ProtectedText](https://www.protectedtext.com/) - Multi-Tab
* [⁠Memochō](https://bin.kv2.dev/) / [GitHub](https://github.com/SitiSchu/memocho) or [bin](https://basedbin.fly.dev/) - Minimal Pastebins
* [txt.fyi](https://txt.fyi/) - Plain Text
* [⁠paste.sh](https://paste.sh/) - Plain Text / [GitHub](https://github.com/dgl/paste.sh)
* [MarkdownPastebin](https://markdownpastebin.com/) - Markdown Support
* [Sparked Paste](https://paste.sparked.host/) - Plain Text / Syntax Highlighting / [GitHub](https://github.com/sparkedhost/paste)
* [Riseup Pad](https://pad.riseup.net/) - WYSIWYG Pastebin
* [itty.bitty](https://itty.bitty.site/) - Site / Pastebin / [GitHub](https://github.com/arfct/itty-bitty)
* [Opengist](https://opengist.io/) / [Demo](https://demo.opengist.io/) / [Discord](https://discord.gg/9Pm3X5scZT) / [GitHub](https://github.com/thomiceli/opengist), [Drift](https://drift.lol/) or [MicroBin](https://microbin.eu/) / [GitHub](https://github.com/szabodanika/microbin) - Self-Hosted Pastebins

***

## ▷ Translators

* **Note** - [AI Chatbots](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/ai#wiki_.25B7_online_chatbots) sometimes translate better than traditional translators, especially when it comes to languages with inherently different structures.

***

* ⭐ **[DeepL](https://www.deepl.com/translator)** - Online AI-Based Translation
* ⭐ **[Google Translate](https://translate.google.com/)** / [Chrome Extension](https://chromewebstore.google.com/detail/google-translate/aapbdbdomjkkjkaonfhkkikfgjllcleb) / [.onion](http://st.g4c3eya4clenolymqbpgwz3q3tawoxw56yhzk4vugqrl6dtu3ejvhjid.onion/) - Online
* ⭐ **[Translate Web Pages](https://github.com/FilipePS/Traduzir-paginas-web)**, [⁠KISS Translator](https://github.com/fishjar/kiss-translator/blob/dev/README.en.md) or [Linguist Translator](https://github.com/translate-tools/linguist) - Browser Extensions
* ⭐ **[r/Translator](https://www.reddit.com/r/translator/)** - Translation Request Community
* [⁠Mozhi](https://codeberg.org/aryak/mozhi#instances) - Multi Translation Engine Frontend
* [LibreTranslate](https://libretranslate.com/), [2](https://translate.disroot.org/) - FOSS Translator / Self-Hosted / Offline / [GitHub](https://github.com/LibreTranslate/LibreTranslate)
* [Translate Shell](https://www.soimort.org/translate-shell/) - Translation CLI / [GitHub](https://github.com/soimort/translate-shell)
* [Bing Translator](https://www.bing.com/translator) - Online
* [Yandex Translator](https://translate.yandex.com/) - Online
* [Reverso](https://context.reverso.net/translation/) - Online In-Context Translations
* [Nice Translator](https://nicetranslator.com/) - Batch Multi-Language Translation
* [⁠Sakana Translate](https://chat.sakana.ai/translate) - English > Japanese / Chinese Translator
* [Translator++](https://dreamsavior.net/) or [Renpy Translator](https://github.com/anonymousException/renpy-translator) - CAT For Games
* [⁠Translumo](https://github.com/ramjke/Translumo) - Real-Time Translation Tool
* [Poedit](https://poedit.com/) - Software Translation / [GitHub](https://github.com/vslavik/poedit)
* [Morsecode World](https://morsecode.world/) or [The Morse Lab](https://themorselab.com/) - Morse Code Translation Tools
* [Sign Translate](https://rylo.com/sign/translate/) - Text to Sign-Language Video Translator
* [Text to Sign](https://wecapable.com/tools/text-to-sign-language-converter/) - Sign Language Translator
* [⁠Braille Translator](https://wecapable.com/braille-translator/) - Braille Translator
* [LingoJam](https://lingojam.com/) - Translator Creator

***

## ▷ Audio Transcription

* 🌐 **[ASR Leaderboard](https://huggingface.co/spaces/hf-audio/open_asr_leaderboard)** - Speech to Text Leaderboard
* ⭐ **[Turboscribe](https://turboscribe.ai/)** or [Revoldiv](https://revoldiv.com/) - AI-Based Transcriptions / Web
* ⭐ **[Whisper](https://github.com/openai/whisper)** - Audio Transcription / Windows, macOS, Linux / [WebUI](https://huggingface.co/spaces/hf-audio/whisper-large-v3), [2](https://ggml.ai/whisper.cpp/)
* [WhisperX](https://github.com/m-bain/whisperX) - Advanced Whisper with timestamps / Windows, macOS, Linux
* [⁠Transcrisper](https://transcrisper.com/), [Dictation](https://dictation.io/speech) or [oTranscribe](https://otranscribe.com/) - Audio Transcription Tools / Web
* [Vibe](https://thewh1teagle.github.io/vibe/) - Audio Transcription / Windows, macOS, Linux
* [Buzz](https://github.com/chidiwilliams/buzz) - Audio Transcription Tool / Windows, macOS, Linux
* [Handy](https://handy.computer/) - Audio Transcription Tool / Windows, macOS, Linux / [Discord](https://discord.gg/WVBeWsNXK4) / [GitHub](https://github.com/cjpais/Handy)
* [Parakeet](https://huggingface.co/spaces/nvidia/parakeet-tdt-0.6b-v2) - Audio Transcription / Web
* [SpeechNotes](https://speechnotes.co/) - Speech Recognition Notes App / Web
* [VoiceNotebook](https://voicenotebook.com/) - Speech Transcription Notebook / Android, iOS, Web

***

## ▷ Encode / Decode

* ⭐ **[CyberChef](https://gchq.github.io/CyberChef/)** / Web / [GitHub](https://github.com/gchq/CyberChef)
* ⭐ **[Base64 Decode](https://www.base64decode.org/)** or [base64.run](https://base64.run/) - Base64 Specific / Web
* ⭐ **[Auto Decoder](https://greasyfork.org/en/scripts/485772-fmhy-base64-auto-decoder)** - Auto-Decode B64 Links on Pastebins
* [Ciphey](https://github.com/Ciphey/Ciphey) - Automated Decryption Tool / Windows, macOS, Linux
* [Online Tools](https://emn178.github.io/online-tools/index.html) / Web
* [cryptii](https://cryptii.com/) or [DenCode](https://dencode.com/) / Web
* [quipqiup](https://www.quipqiup.com/) or [dCode](https://www.dcode.fr/en) - Cryptogram Solvers / Web
* [Universal Encoding Tool](https://unenc.com/) - Encode / Convert Text / Web
* [StegCloak](https://stegcloak.surge.sh/) - Hide Messages in Text / Web
* [Base64 Repair](https://base64.guru/tools/repair) - Fix Broken Base64 / Web
* [SearchDecode](https://github.com/bewf/SearchDecode) - ⁠Base64 Search Decoder / Extension
* Base64 Extensions - [Chrome](https://chromewebstore.google.com/detail/base64-decode-copy/llcfmnginbnmkeddkjjellcimmffjdcf) / [Firefox](https://addons.mozilla.org/en-US/firefox/addon/base64-decoder/)

***

## ▷ Grammar Check

* **Note** - Most chatbots in the AI section can also check grammar.

***

* ⭐ **[Harper](https://writewithharper.com/)** / Windows, macOS, Linux, Web / [Discord](https://discord.com/invite/JBqcAaKrzQ) / [GitHub](https://github.com/automattic/harper)
* [LanguageTool](https://languagetool.org/) / Windows, macOS, Linux, Web, Docker / [GitHub](https://github.com/languagetool-org/languagetool)
* [Writing Tools](https://github.com/theJayTea/WritingTools) / Windows, macOS, Linux
* [QuillBot](https://quillbot.com/grammar-check) / Web / [Extension](https://quillbot.com/app) / [Features](https://rentry.co/FMHYB64#quill)
* [DeepL Write](https://www.deepl.com/write) / Web
* [⁠Kagi Proofread](https://translate.kagi.com/proofread) - Signup Required / Web

***

## ▷ Emojis / Emoticons

* ⭐ **[symbl](https://symbl.cc/)** - Emoji & Unicode Index
* ⭐ **[Emojipedia](https://emojipedia.org/)**, [Emoji Charts](https://unicode.org/emoji/charts/), [EmojiDB](https://emojidb.org/), [OpenMoji](https://openmoji.org/), [JoyPixels](https://www.joypixels.com/) or [Emoji Picker](https://github-emoji-picker.vercel.app/) - Emoji Indexes
* ⭐ **[Slackmojis](https://slackmojis.com/)** - Custom Emojis
* ⭐ **[Amp What](https://www.amp-what.com/)** - Unicode Index
* [EmojiCreator](https://emojicreator.ai/), [My Emoji Maker](https://myemojimaker.com/) or [Slackmoji Lab](https://slackmojilab.com/) - Make Custom Animated Emojis
* [⁠AnimGifMoji](https://www.animgifmoji.com/) - GIF to Emoji Converter
* [⁠Animated Noto Emojis](https://googlefonts.github.io/noto-emoji-animation/) - Google Animated Emojis
* [Animated Fluent Emojis](https://animated-fluent-emoji.vercel.app/) - Microsoft Animated Emojis / [GitHub](https://github.com/Tarikul-Islam-Anik/Animated-Fluent-Emojis)
* [Cult of the Party Parrot](https://cultofthepartyparrot.com/) - Party Parrot Emojis
* [Emojify](https://madelinemiller.dev/apps/emojify/) - Emojify Text
* [Asciify Unicode](https://asciify.dev/unicode) - ASCII & Unicode Reference
* [Unicode Explorer](https://unicode-explorer.com/) or [Compart](https://www.compart.com/en/unicode) - Unicode Character Identification
* [CopyChar](https://copychar.cc/) - Special Characters Index
* [Graphemica](https://graphemica.com/) - Typography Reference
* [Unifoundry](https://unifoundry.com/) - Unifont Repository
* [emotes.io](https://emotes.io/), [CuteSymbols](https://www.cutesymbols.net/) / [2](https://www.textemoji.org/), [⁠Kaomoji](https://kaomojicopypaste.org/), [cutesymbols.io](https://cutesymbols.io/) or [GetSymbol](https://www.getsymbol.net/) - Copy Unicode Emotes
* [Character Map](https://github.com/character-map-uwp/Character-Map-UWP) - Custom Font & Emojis / Windows

***

## ▷ Typing Lessons

* ⭐ **[Monkeytype](https://monkeytype.com/)** - Custom Touch Typing Tests / [Discord](https://discord.com/invite/monkeytype) / [GitHub](https://github.com/monkeytypegame/monkeytype)
* ⭐ **[keybr](https://www.keybr.com/)** - Custom Touch Typing Practice / [GitHub](https://github.com/aradzie/keybr.com)
* [⁠Layouts Wiki](https://layouts.wiki/) - Alt Typing Layouts Wiki
* [Typing Guide](https://docs.google.com/document/d/1W0jhfqJI2ueJ2FNseR4YAFpNfsUM-_FlREHbpNGmC2o) - In-Depth Typing Guide
* [Typ.ing](https://typ.ing/), [Typings](https://typings.gg/), [⁠TypeGG](https://typegg.io/) / [Discord](https://discord.com/invite/64v955z) or [typing.works](https://typing.works/) - Typing Tests
* [⁠ttyper](https://github.com/max-niederman/ttyper) or [⁠Smassh](https://github.com/kraanzu/smassh) - Typing Test TUIs
* [Typing.com](https://www.typing.com/), [⁠Keytopia](https://keytopia.org/) or [Typing Club](https://www.typingclub.com/) - Touch Typing Lessons / Practice
* [typing.academy](https://www.typing.academy/) or [⁠VocaType](https://vocatype.app/) - Typing Lessons
* [TypeRacer](https://play.typeracer.com/), [ZType](https://zty.pe/), [TypeRush](https://www.typerush.com/) or [ARRRType](https://www.arrrtype.com/) - Typing Games
* [NGram Type](https://ranelpadon.github.io/ngram-type/), [KeyZen MAB](https://adamgradzki.com/keyzen-mab/) or [Keyzen Colemak](https://ranelpadon.github.io/keyzen-colemak-dh/) - Touch Typing Tests
* [⁠Typersguild](https://typersguild.com/), [TypeBook](https://typebook.lol/), [TypeLit.io](https://www.typelit.io/) or [Entertrained](https://entertrained.app/) - Practice Typing with Books
* [TypingStudy](https://www.typingstudy.com/) or [TypeFast](https://typefast.io/) - Multilingual Touch Typing Tests
* [10fastfingers](https://10fastfingers.com/) - Typing Competitions / [Discord](https://discord.gg/4KypVEM)

***

# ► Text Editors

* 🌐 **[List of Text Editors](https://wikipedia.org/wiki/List_of_text_editors)** - Text Editor / Notepad Index
* ↪️ **[Android Text Editor](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_android_text_tools)**
* ↪️ **[Code Editors / IDEs](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/dev-tools#wiki_.25B7_ides_.2F_code_editors)**
* ⭐ **[Notepad++](https://notepad-plus-plus.org/)** - Notepad & Code Editor / Windows / [GitHub](https://github.com/notepad-plus-plus/notepad-plus-plus)
* [NotepadNext](https://github.com/dail8859/NotepadNext) - Notepad & Code Editor / Windows, macOS, Linux
* [EncryptPad](https://evpo.net/encryptpad/) - Encrypted Text Editor / Windows, macOS, Linux / [GitHub](https://github.com/evpo/EncryptPad)
* [Notepads](https://www.notepadsapp.com/) - Text Editor / Windows / [GitHub](https://github.com/0x7c13/Notepads)
* [FastNotes](https://fastedit.frozenassassine.de/) - Text Editor / Windows / [GitHub](https://github.com/FrozenAssassine/Fastedit)
* [Kompad](https://github.com/hudy9x/kompad) - Text Editor / Web
* [Sublime Text](https://www.sublimetext.com/) - Text Editor / Windows, macOS, Linux / [Package Manager](https://packagecontrol.io/)
* [Zim Wiki](https://zim-wiki.org/) - Wiki Text Editor / Windows, macOS, Linux / [GitHub](https://github.com/zim-desktop-wiki/zim-desktop-wiki)
* [tomboy-ng](https://github.com/tomboy-notes/tomboy-ng) - TomBoy-Based Text Editor / Windows, macOS, Linux
* [SciTE](https://www.scintilla.org/SciTE.html) - Text Editor / Windows, macOS, Linux

***

## ▷ Note-Taking

* ↪️ **[Self-Hosted Note-Taking](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_server_.2F_selfhosting)**
* ⭐ **[Obsidian](https://obsidian.md/)** - Markdown Note-Taking / Windows, macOS, Linux, Android, iOS / [Discord](https://discord.gg/obsidianmd)
* ⭐ **Obsidian Tools** - [Publish Notes](https://docs.forestry.md/) / [Note Sync](https://synch.run/) / [Web Clipper](https://github.com/obsidianmd/obsidian-clipper) / [Google Drive Sync](https://github.com/stravo1/obsidian-gdrive-sync) / [Guides](https://obsidian.md/help/) / [Forum](https://forum.obsidian.md/)
* ⭐ **[Anytype](https://anytype.io/)** / E2EE / Windows, macOS, Linux, Android, iOS / [Telegram](https://t.me/anytype) / [GitHub](https://github.com/anyproto/anytype-ts)
* ⭐ **[AppFlowy](https://appflowy.com/)** / Windows, macOS, Linux, Android, iOS, Docker / [Discord](https://discord.com/invite/appflowy-903549834160635914) / [GitHub](https://github.com/AppFlowy-IO)
* ⭐ **[Logseq](https://logseq.com/)** - Outlining / Windows, macOS, Linux, Android, iOS, Web / [Discord](https://discord.com/invite/VNfUaTtdFb) / [GitHub](https://github.com/logseq/logseq)
* ⭐ **[Notesnook](https://notesnook.com/)** - Note-Taking / E2EE / Windows, macOS, Linux, Android, iOS, Web / [Discord](https://discord.com/invite/zQBK97EE22) / [GitHub](https://github.com/streetwriters/notesnook)
* [Simplenote](https://simplenote.com/) - Note-Taking / Windows, macOS, Linux, Android, iOS, Web / [GitHub](https://github.com/Automattic/simplenote-electron)
* [AFFiNE](https://affine.pro/) - Note-Taking / All Platforms + Web / [GitHub](https://github.com/toeverything/AFFiNE)
* [Notion](https://www.notion.com/) - Note-Taking / All Platforms + Web
* Notion Tools - [Resources](https://www.notioneverything.com/notion-world), [2](https://chief-ease-8ab.notion.site/List-of-200-Notion-Resources-e1b46cd365094265bd47b8a2b25bb41e) / [Guide](https://easlo.notion.site/Notion-Beginner-to-Advanced-8a492960b049433289c4a8d362204d20) / [Markdown Extractor](https://notionconvert.com/) / [Web Clipper](https://www.notion.com/web-clipper)
* [Lokus](https://www.lokusmd.com/) - Markdown Note-Taking / Windows, macOS, Linux / [GitHub](https://github.com/lokus-ai/lokus)
* [Trilium](https://triliumnotes.org/) - Info Manager / Windows, macOS, Linux / [GitHub](https://github.com/TriliumNext/Trilium)
* [Mochi Cards](https://mochi.cards/) - Note-Taking / Study Tools / All Platforms
* [Silicon](https://github.com/cu/silicon) - Note-Taking / Self-Hosted
* [Tolaria](https://tolaria.md/) - Markdown Note-Taking / Windows, macOS, Linux / [GitHub](https://github.com/refactoringhq/tolaria)
* [Flotes](https://flotes.app/) - Markdown Note-Taking / Web / [Discord](https://discord.gg/uARTASUtX2)
* [QOwnNotes](https://www.qownnotes.org/) - Markdown Note-Taking / Windows, macOS, Linux / [Telegram](https://t.me/QOwnNotes) / [GitHub](https://github.com/pbek/QOwnNotes)
* [vNote](https://github.com/vnotex/vnote) - Markdown Note-Taking / Windows, macOS, Linux
* [HelixNotes](https://helixnotes.com/) - Markdown Note-Taking / All Platforms / [Discord](https://discord.gg/V7HYtShrB7) / [Source Code](https://gitlab.com/ArkHost/HelixNotes)
* [neutriNote](https://github.com/appml/neutrinote) - Markdown Note-Taking / Android
* [Quillpad](https://quillpad.github.io/) - Markdown Note-Taking / Android / [GitHub](https://github.com/quillpad/quillpad)
* [OneNote](https://play.google.com/store/apps/details?id=com.microsoft.office.onenote&hl=en-us) - Markdown Note-Taking / Math Support / Android
* [Tiddly](https://tiddlywiki.com/) - Info Manager / Windows, macOS, Linux / [Desktop](https://github.com/tiddly-gittly/TidGi-Desktop)
* [Org-roam](https://www.orgroam.com/) - Info Manager / Self-Hosted / [GitHub](https://github.com/org-roam/org-roam)
* [Desklamp](https://desklamp.io/) - Reading / Note-Taking / Highlighting Tool / Windows / [Guide](https://app.desklamp.io/read?id=46b203c6-d8df-453d-b546-95a8fa7a44b9&mode=explore)
* [Memos](https://usememos.com/) - Note-Taking / Self-Hosted / [Discord](https://discord.gg/tfPJa4UmAv) / [GitHub](https://github.com/usememos/memos)
* [Papers.IM](https://papers.im/) - Note-Taking / Web
* [Joplin](https://joplinapp.org/) - Note-Taking / E2EE / All Platforms / [Firefox](https://addons.mozilla.org/en-US/firefox/addon/joplin-web-clipper/) / [Chrome](https://chrome.google.com/webstore/detail/joplin-web-clipper/alofnhikmmkdbbbgpnglcpdollgjjfek?hl=en-GB) / [Discord](https://discord.com/invite/d2HMPwE) / [GitHub](https://github.com/laurent22/joplin)
* [MicroPad](https://getmicropad.com/) - Note-Taking / Windows, macOS, Linux / [Web](https://web.getmicropad.com/)
* [DocMost](https://docmost.com/) - Note-Taking / Self-Hosted / [GitHub](https://github.com/docmost/docmost)
* [KeyNote NF](https://github.com/dpradov/keynote-nf) - Note-Taking / E2EE / Windows
* [SilentNotes](https://www.martinstoeckli.ch/silentnotes/) - Note-Taking / E2EE / Windows, Android / [GitHub](https://github.com/martinstoeckli/SilentNotes)
* [Google Keep](https://keep.google.com/) - Minimal Note-Taking / Android, iOS, Web / [Chrome](https://chromewebstore.google.com/detail/google-keep-chrome-extens/lpcaedmchfhocbbapmcbpinfpgnhiddi)
* [Notally](https://github.com/OmGodse/Notally) or [NotallyX](https://github.com/PhilKes/NotallyX) - Minimal Note-Taking / Android
* [Easy Notes](https://github.com/Kin69/EasyNotes) - Minimal Note-Taking / Android
* [⁠Org Mode](https://orgmode.org/) - CLI Note-Taking / Windows, macOS, Linux
* [ColorNote](https://www.colornote.com/) - Minimal Note-Taking / Android
* [Notebook](https://www.zoho.com/notebook/mobile-app.html) - Note-Taking / Drawing / Android
* [Walling](https://walling.app/) or [Workflowy](https://play.google.com/store/apps/details?id=com.workflowy.android) - Note-Taking Apps for Projects / Android
* [⁠Crypt.ee](https://crypt.ee/) - Encrypted Notes / E2EE / All Platforms
* [Standard Notes](https://standardnotes.com/) - Encrypted Notes / E2EE / All Platforms / [Web](https://app.standardnotes.com/) / [Discord](https://discord.com/invite/9VNW3kK554) / [GitHub](https://github.com/standardnotes/app)

***

## ▷ Whiteboards / Handwritten

* ⭐ **[Excalidraw](https://excalidraw.com/)** - Whiteboard / [Sharing](https://excalihub.dev/) / [Github](https://github.com/excalidraw/excalidraw)
* ⭐ **[OpenBoard](https://openboard.ch/en)** - Whiteboard
* [Saber](https://saber.adil.hanney.org/) - Handwritten Notes / All Platforms / [GitHub](https://github.com/saber-notes/saber)
* [Butterfly](https://butterfly.linwood.dev/) - Handwritten Notes / All Platforms / [Discord](https://discord.com/invite/97zFtYN) / [GitHub](https://github.com/LinwoodDev/Butterfly)
* [Xournal++](https://xournalpp.github.io/) - Handwritten Notes / Windows, macOS, Linux / [GitHub](https://github.com/xournalpp/xournalpp)
* [rNote](https://rnote.flxzt.net/) - Handwritten Notes / Windows, macOS, Linux / [GitHub](https://github.com/flxzt/rnote)
* [Notein](https://www.notein.ai/) / [Features](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_modded_apks) (search) - Handwritten Notes / Android
* [Text to Handwriting](https://saurabhdaware.github.io/text-to-handwriting/) - Text to Handwriting Converters
* [tldraw](https://www.tldraw.com/) - Whiteboard
* [DGM](https://app.dgmjs.dev/) - Whiteboard
* [NotebookCast](https://www.notebookcast.com/) - Whiteboard
* [WebWhiteboard](https://webwhiteboard.com/) - Whiteboard
* [Drawnix](https://drawnix.com/) - Whiteboard / [GitHub](https://github.com/plait-board/drawnix/blob/develop/README_en.md)
* [WBO](https://wbo.ophir.dev/) - Whiteboard
* [OurBoard](https://www.ourboard.io/) - Whiteboard
* [Whiteboard.fi](https://whiteboard.fi/) - Whiteboard
* [Whiteboard Fox](https://r3.whiteboardfox.com/) - Whiteboard
* [LucidSpark](https://lucid.co/lucidspark) - Idea / Collaboration Whiteboards
* [Creately](https://creately.com/) - Idea / Collaboration Whiteboards
* [Miro](https://miro.com/) - Idea / Collaboration Whiteboards

***

## ▷ Office Suites

* ↪️ **[Office Activation](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/system-tools#wiki_.25B7_windows_activation)** / [Custom Install Guide](https://massgrave.dev/office_c2r_custom)
* ⭐ **[LibreOffice](https://www.libreoffice.org/)** - FOSS Office Suite / [GitHub](https://github.com/LibreOffice/core)
* ⭐ **[OnlyOffice](https://www.onlyoffice.com/)** - Office Suite / [Web](https://edit.chaxus.com/)
* ⭐ **[Microsoft Office](https://massgrave.dev/office_c2r_links)** / [Linux](https://gist.github.com/eylenburg/38e5da371b7fedc0662198efc66be57b) / [macOS](https://massgrave.dev/office_for_mac) - Office Suite / [Hotkeys](https://support.microsoft.com/en-us/office/keyboard-shortcuts-in-microsoft-365-e765366f-24fc-4054-870d-39b214f223fd) / [Removal Tool](https://github.com/abbodi1406/WHD/blob/master/scripts/OfficeScrubber_14.zip), [2](https://gitlab.com/stdout12/batutil/-/tree/master/OfficeScrubber), [3](https://codeberg.org/stdout12/BatUtil/src/branch/master/OfficeScrubber)
* [Calligra](https://calligra.org/) - FOSS Office Suite
* [Ziziyi](https://office.ziziyi.com/), [2](https://o.ziziyi.com/) - Online Office Suite / [GitHub](https://github.com/baotlake/office-website)
* [Office365Version](https://www.office365versions.com/) - Office 365 Version History

***

## ▷ Online Editors

* ⭐ **[nanotype](https://nanotype.app/)** - Local Saves
* ⭐ **[Proton Docs](https://proton.me/drive/docs)** - Local / Cloud Saves / [Discord](https://discord.com/invite/proton)
* [Leaflet](https://leaflet.pub/) - Cloud Saves / Customizable / [Examples](https://leaflet.pub/bfed2569-f9c0-4c2a-a281-9f57bc372082)
* [Browserpad](https://browserpad.org/) - Local / [GitHub](https://github.com/Browserpad/browserpad)
* [⁠Chaxus](https://edit.chaxus.com/) - Local Saves / [GitHub](https://github.com/ranuts/document)
* [EdenText](https://edentext.app/) - Local Saves / [GitHub](https://github.com/stffnb/edentext)
* [Online Notepad](https://onlinenotep.ad) - Local Saves
* [Notepad](https://notepad.js.org/) - Local Saves / [GitHub](https://github.com/amitmerchant1990/notepad)
* [onlinenotepad](https://onlinenotepad.org/) - Local Saves
* [notepad-online.net](https://notepad-online.net/) - Local Saves
* [ssavr](https://www.ssavr.com/) - Local Saves
* [notepad-online.com](https://notepad-online.com/) - Local Saves
* [JustNotePad](https://justnotepad.com/) - Local Saves
* [NotesOnline](https://notesonline.org/) - Local Saves
* [PasteePad](https://pasteepad.com/) - Local Saves / [GitHub](https://github.com/glauberramos/pastee)
* [Notes](https://notes.xtra.wtf/) - Local / Cloud Saves / [GitHub](https://github.com/xtrafr/notes)
* [Shrib](https://shrib.com/) - Local / Cloud Saves
* [MemOnNotepad](https://www.memonotepad.com/) - Local / Cloud Saves
* [Write Box](https://write-box.appspot.com/) - Local / Cloud Saves
* [dDocs](https://docs.fileverse.io/) - Cloud Saves / [GitHub](https://github.com/fileverse/fileverse-ddocs)
* [NimbleText](https://nimbletext.com/Live) - Cloud Saves
* [ZippyJot](https://www.zippyjot.com/) - Cloud Saves
* [TinyList](https://tinylist.app/) - Cloud Saves / [GitHub](https://github.com/baggachipz/tinylist)
* [TextSlave](https://www.textslave.com/) - Cloud Saves

***

## ▷ Mind Mapping

* ⭐ **[Obsidian Canvas](https://obsidian.md/canvas)**
* [FreeMind](https://freemind.sourceforge.io/)
* [Kinopio](https://kinopio.club/)
* [Freeplane](https://github.com/freeplane/freeplane)
* [Mindomo](https://www.mindomo.com/)
* [Yuque](https://www.yuque.com/)
* [MindMapp](https://mindmapp.cedoor.dev/app)
* [are.na](https://www.are.na/)
* [Domino](https://kool.tools/domino)
* [GitMind](https://gitmind.com/)
* [xTiles](https://xtiles.app/en)
* [Capacities](https://capacities.io/)
* [bubbl](https://bubbl.us/)
* [Heimer](https://github.com/juzzlin/Heimer)
* [Cubox](https://cubox.cc/)
* [vym](https://github.com/insilmaril/vym)
* [⁠Tangent](https://www.tangentnotes.com/) - Markdown Mind Mapping / [Discord](https://discord.gg/6VpvhUnxFe) / [GitHub](https://github.com/suchnsuch/Tangent)
* [markmap](https://markmap.js.org/) - Markdown Mind Mapping / [GitHub](https://github.com/markmap/markmap)
* [Coggle](https://coggle.it/) - Collaborative
* [CardSmith](https://cardsmith.co/) - Collaborative Mind Mapping
* [MindMeister](https://www.mindmeister.com/) - Collaborative Mind Mapping
* [Slatebox](https://slatebox.com/) - Collaborative Mind Mapping

***

## ▷ Text / Code Collaboration

* ⭐ **[Google Docs](https://www.google.com/docs/about/)** / [HTML Converter](https://github.com/evbacher/gd2md-html) / [Templates](https://gdoc.io/)
* ⭐ **[CryptPad](https://cryptpad.fr/)** / [Instances](https://cryptpad.org/instances/)
* [Mattermost](https://mattermost.com/)
* [Codeshare](https://codeshare.io/)
* [HackMD](https://hackmd.io/)
* [Taskade](https://www.taskade.com/)
* [Socket](https://socket.io/)
* [Whimsical](https://whimsical.com/)
* [Ellipsus](https://ellipsus.com/)
* [Etherpad](https://etherpad.org/)
* [SharePad](https://sharepad.io/)
* [Pixso](https://pixso.net/)
* [FidusWriter](https://www.fiduswriter.org/)
* [Overleaf](https://www.overleaf.com/)
* [Typst](https://typst.app/home) / [Resources](https://github.com/qjcg/awesome-typst) / [Discord](https://discord.gg/2uDybryKPe) / [GitHub](https://github.com/typst/typst)
* [Rustpad](https://rustpad.io) / [GitHub](https://github.com/ekzhang/rustpad)
* [OnlineInterview.io](https://onlineinterview.io/)

***

## ▷ Spreadsheet Editors

* 🌐 **[MTEB Leaderboard](https://huggingface.co/spaces/mteb/leaderboard)** - Text Embedding AI Leaderboard
* [⁠QSV](https://github.com/dathere/qsv) or [Xan](https://github.com/medialab/xan) - CSV CLI Toolkits
* [⁠Proton Sheets](https://proton.me/drive/sheets) / [Discord](https://discord.com/invite/proton), [DOCX Editor](https://www.docx-editor.dev/editor) / [GitHub](https://github.com/eigenpal/docx-editor), [⁠dSheets](https://sheets.fileverse.io/) or [EditCSVOnline](https://editcsv.com/) - Online Spreadsheet Viewers / CSV Editors
* [tad](https://github.com/antonycourtney/tad), [Tree Sheets](https://strlen.com/treesheets/), [⁠SmoothCSV](https://smoothcsv.com/), [VisiData](https://www.visidata.org/), [Gnumeric](https://gnome.pages.gitlab.gnome.org/gnumeric-web/) or [Quadratic](https://www.quadratichq.com/) - Spreadsheet Viewers / CSV Editors
* [Framacalc](https://framacalc.org/) or [EtherCalc](https://ethercalc.net/) / [GitHub](https://github.com/audreyt/ethercalc) - Collaborative Spreadsheets
* [Jamovi](https://www.jamovi.org/) - Statistical Spreadsheets
* [⁠Excel Easy](https://www.excel-easy.com/) - Excel / Spreadsheet Guide
* [Excel Macro Mastery](https://excelmacromastery.com/vba-articles/) - Excel VBA Guides
* [ExcelJet](https://exceljet.net/formulas) or [Excel Functions](https://www.excelfunctions.net/) - Excel Formulas
* [Vertex42](https://www.vertex42.com/) - Excel Templates
* [Plain Text Table](https://plaintexttools.github.io/plain-text-table/) - Text Tables
* [SubjectiveSort](https://wiesenthal.github.io/SubjectiveSort/) - Create Ranked List from CSV
* [Structifi](https://structifi.com/) - Convert Files to Structured Data
* [TadViewer](https://www.tadviewer.com/) - View / Analyze Tabular Data
* [⁠PerspectiveFix](https://perspectivefix.app/) - Document Perspective Correction Tool

***

## ▷ Writing Tools

* ↪️ **[RPG / Fantasy Writing Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/game-tools/#wiki_.25B7_rpg_worldbuilding)**
* ⭐ **[Writer](https://www.gibney.org/writer)**, [FocusWriter](https://gottcode.org/focuswriter/), [Writemonkey](https://writemonkey.com/), [blank.page](https://blank.page/), [Telegra.ph](https://telegra.ph/), [Aurelius](https://aurelius.ink), [ZenPen](https://zenpen.io/), [Write.as](https://write.as/), [Owri](https://owri.netlify.app/), [WriteSpace](https://www.writespace.app/) or [WriteNext](https://www.writenext.io/) - Distraction-Free Writing
* ⭐ **[Manuskript](https://www.theologeek.ch/manuskript/)** - Writing Organizer / Planner
* ⭐ **[NovelWriter](https://novelwriter.io/)** - Novel Editor
* ⭐ **[Linked](https://uselinked.com/)**, [journaltxt](https://journaltxt.github.io/), [Gekri](https://gekri.com/), [Microsoft Journal](https://www.microsoft.com/en-us/garage/profiles/journal/), [Diarium](https://diariumapp.com/) or [jrnl.sh](https://jrnl.sh/) - Journal Apps
* ⭐ **[TextFX](https://textfx.withgoogle.com/)** / [GitHub](https://github.com/google/generative-ai-docs/tree/main/demos/palm/web/textfx) or [Rytr](https://rytr.me/) - AI Creative Writing Tools / No Sign-Up
* [Writality](https://www.writality.com/) - Novel Editor
* [Tuesday JS](https://kirill-live.itch.io/tuesday-js) - Novel Editor / [GitHub](https://github.com/Kirilllive/tuesday-js)
* [RenPy](https://www.renpy.org/) - Novel Editor / [GitHub](https://github.com/renpy/renpy)
* [Fortelling](https://www.fortelling.app/) - Novel Editor
* [⁠Neo](https://github.com/hughhowey/neo) - Novel Editor
* [Novelist](https://beta.novelist.app) - Novel Editor
* [Bibisco](https://bibisco.com/) - Novel Editor
* [Infinite Story](https://infinite-story.com/), [Strand](https://strand.jinay.dev/), [Agora](https://www.agorawriter.com/) or [WriteAlong](https://www.writealong.io/) - Collaborative Writing / Feedback
* [Gateway Forge](https://gatewayforge.com/) / [Modules](https://gatewayforge.com/resources) / [Discord](https://discord.gg/c3PEQxxKfn) or [Chronicler](https://chronicler.pro/) / [Discord](https://discord.gg/cXJwcbe2b7) / [GitHub](https://github.com/mak-kirkland/chronicler) - Worldbuilding / Story Writing Apps
* [⁠Heavyweight](https://heavyweight.cc/) - Generate Important-Looking Letters
* [LanguageIsAVirus](https://www.languageisavirus.com/) - Writing Prompts
* [Twinery](https://twinery.org/) - Interactive Non-Linear Story Creator
* [TextUSM](https://textusm.com/) - User Story Map Generator / [GitHub](https://github.com/harehare/textusm)
* [Idyll](https://idyll-lang.org/editor) - Create Interactive Essays / [GitHub](https://github.com/idyll-lang/idyll)
* [STARC](https://starc.app/), [WriteSolo](https://www.writersolo.com/) or [Celtx](https://www.celtx.com/) - Script / Screen Writing Tools
* [Rarebit](https://rarebit.neocities.org/) - Webcomics Template
* [PolyGlot](https://draquet.github.io/PolyGlot/) or [VulgarLang](https://www.vulgarlang.com/) - Spoken Language Construction Tools
* [How to annotate literally everything](https://beepb00p.xyz/annotating.html) - Annotation Tools / Resources
* [Label Buddy](https://jeromedockes.github.io/labelbuddy/labelbuddy/current/) - Annotation Tool / [GitHub](https://github.com/jeromedockes/labelbuddy)
* [MonsterWriter](https://www.monsterwriter.com/) - Thesis Writing / Note-Taking
* [Writer Plus](https://play.google.com/store/apps/details?id=co.easy4u.writer) - Note-Taking App for Writers / Android

***

## ▷ To Do Lists

* ↪️ **[Android To-Do Apps](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/android#wiki_.25B7_to-do_apps)**
* ↪️ **[Calendars / Events](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25B7_calendars_.2F_events)**
* ⭐ **[TickTick](https://www.ticktick.com/)** / [Features](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/linux#wiki_.25B7_software_sites2) (search)
* ⭐ **[Super Productivity](https://super-productivity.com/)** / [GitHub](https://github.com/super-productivity/super-productivity)
* [Columns](https://columns.app/) - Checklists
* [YearCompass](https://yearcompass.com/) - New Years Resolution Booklet
* [daily.place](https://www.daily.place/)
* [Mindwtr](https://mindwtr.app/) / [GitHub](https://github.com/dongdongbh/Mindwtr)
* [SuperList](https://www.superlist.com/)
* [dooit](https://github.com/dooit-org/dooit) / [Extras](https://github.com/dooit-org/dooit-extras)
* [ToDo List](https://www.abstractspoon.com/) / [GitHub](https://github.com/abstractspoon)
* [Fokus](https://fokus-website.netlify.app/)
* [OpenToDoList](https://gitlab.com/rpdev/opentodolist)
* [Microsoft To Do](https://to-do.office.com/)
* [LunaTask](https://lunatask.app/)
* [ToDoZero](https://todozero.com/)
* [LifeAt](https://lifeat.io/)
* [Tasks](https://github.com/BaldissaraMatheus/Tasks.md)
* [Taskwarrior](https://taskwarrior.org/)
* [Vikunja](https://vikunja.io/) - Self-Hosted

***

## ▷ ASCII Art

* ⭐ **[TAAG](https://patorjk.com/software/taag/)** [Kammerl](https://www.kammerl.de/ascii/AsciiSignature.php), [ASCII Art Studio](https://www.majorgeeks.com/files/details/ascii_art_studio.html) or [ASCII Today](https://ascii.today/) - ASCII Art / Text Generators
* [REXPaint](https://www.gridsagegames.com/rexpaint/), [Asciistrator](https://wieslawsoltes.github.io/Asciistrator/), [ASCII Sketch](https://files.littlebird.com.au/ascii-sketch.html), [Playscii](https://jp.itch.io/playscii), [⁠Monosketch](https://monosketch.io/), [Asciify](https://asciify.org/editor) or [PabloDraw](https://picoe.ca/products/pablodraw/) - ASCII Editors / Drawing
* [ASCII Paint](https://ascii.alienmelon.com/), [⁠TextPaint](https://textpaint.com/) or [⁠ASCII Blaster](https://asdf.us/asciiblaster/), [2](https://ircart.github.io/asciiblaster/) / [GitHub](https://github.com/ircart/asciiblaster) - ASCII Paint Tools
* [⁠shabzefilters](https://lumo-flt.vercel.app/), [ascii-art-generator](https://www.ascii-art-generator.org/), [asciiart](https://asciiart.club/), [ascii-image-converter](https://github.com/TheZoraiz/ascii-image-converter), [Monospace](https://codepen.io/Mikhail-Bespalov/pen/JoPqYrz), [ITOA](https://itoa.hex.dance/), [text-image](https://www.text-image.com/) or [ASCII-art-creator](https://github.com/CherryPill/ASCII-art-creator) - Image / Video to ASCII Art
* [Love ASCII](http://loveascii.com/), [asciiart.eu](https://www.asciiart.eu/), [EmojiCombos](https://emojicombos.com/), [16colors](https://16colo.rs/), [ascii.co](https://ascii.co.uk/art) or [RoySAC](https://www.roysac.com/sitemap.html) - Browse / Copy ASCII Art
* [Image to Braille](https://505e06b2.github.io/Image-to-Braille/) - Convert Images to Braille
* [AnsiLove](https://www.ansilove.org/downloads.html) or [convert-ascii-to-image](https://onlinetools.com/ascii/convert-ascii-to-image) - ANSI / ASCII Art to PNG Converters
* [lvllvl](https://lvllvl.com/) or [Petmate](https://nurpax.github.io/petmate/) - C64 PETSCII Image Editor

***

# ► Markup Tools

* ↪️ **[HTML Tools](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/dev-tools#wiki_.25B7_html)**
* ⭐ **[Markdown Guide](https://www.markdownguide.org/)** - Guide for Markdown (.md)
* ⭐ **[generatedata.com](https://generatedata.com/)** - Generate Test Data in Markup Formats
* [markup.rocks](https://markup.rocks/) - Markup Editor / Web
* [⁠BBCode Text Editor](https://bbcode.ilma.dev/) - BBCode Editor / Web
* [Markup Validation Service](https://validator.w3.org/) - Validate Your Markup Language Structure
* [YAMLine](https://yamline.com/) - Online YAML Tools / Converters
* [yq](https://mikefarah.gitbook.io/yq/) - Portable YAML Processor / [GitHub](https://github.com/mikefarah/yq)
* [readme.so](https://readme.so/) - Create README.md Files
* [Tableconvert](https://tableconvert.com/) - Markdown / Code Converter
* [Linkspector](https://github.com/UmbrellaDocs/action-linkspector) - Check Markdown Files for Dead Links
* [Table Magic](https://stevecat.net/table-magic/) - Table to Markdown Converters
* [Clipboard2Markdown](https://euangoddard.github.io/clipboard2markdown/) - Text to Markdown Converter
* [gd2md-html](https://github.com/evbacher/gd2md-html) - Convert Google Doc to Markdown
* [anydoc](https://firecrawl.github.io/anydoc/) / [GitHub](https://github.com/firecrawl/anydoc), [MarkItDown](https://github.com/microsoft/markitdown) or [GetMarkdown](https://www.getmarkdown.com/) - File to Markdown Converter
* [Quartz](https://quartz.jzhao.xyz/), [Perlite](https://perlite.secure77.de/) or [FlowerShow](https://flowershow.app/) - Publish Markdown
* [Markdown Tutorial](https://www.markdowntutorial.com/) - Interactive Markdown Tutorial
* [emoji-cheat-sheet](https://github.com/ikatyang/emoji-cheat-sheet) - Emoji Markdown Cheatsheet

***

## ▷ Markdown Editors

* ⭐ **[MarkD](https://markd.it/)**
* ⭐ **[HedgeDoc](https://hedgedoc.org/)**
* [⁠Markdown Monster](https://markdownmonster.west-wind.com/) / [GitHub](https://github.com/RickStrahl/MarkdownMonster)
* [Zettlr](https://www.zettlr.com/) / [GitHub](https://github.com/Zettlr/Zettlr)
* [Dillinger](https://dillinger.io/)
* [Tinymarkdwn Editor](https://jmcrafter26.github.io/tinymarkdwn-editor/) / [GitHub](https://github.com/JMcrafter26/tinymarkdwn-editor)
* [Markdown Viewer](https://github.com/ThisIs-Developer/Markdown-Viewer/) / [Web](https://markdownviewer.pages.dev/)
* [MarkdownTools](https://www.markdowntools.com/)
* [MarkLiveEdit](https://markdownlivepreview.dev/)
* [Glow](https://github.com/charmbracelet/glow)
* [⁠Tinta](https://github.com/oipoistar/tinta)
* [MarkdownLivePreview](https://markdownlivepreview.com/)
* [Vrite](https://editor.vrite.io/)
* [MindForger](https://www.mindforger.com/)
* [⁠Markpad](https://markpad.sftwr.dev/) - Lightweight / Minimal / [GitHub](https://github.com/alecdotdev/Markpad)
* [⁠SilverBullet](https://silverbullet.md/) - Self-Hosted

***

## ▷ LaTeX Tools

* ⭐ **[Typst](https://typst.app/home)** - LaTeX Alternative / [Resources](https://github.com/qjcg/awesome-typst) / [Discord](https://discord.gg/2uDybryKPe) / [GitHub](https://github.com/typst/typst)
* ⭐ **[Overleaf](https://www.overleaf.com/)**, [LyX](https://www.lyx.org/), [⁠TeXPage](https://www.texpage.com/) or [TeXStudio](https://texstudio.org/) - LaTeX Editors
* [⁠Notepix](https://notepix.ai/) / [Discord](https://discord.gg/Q4chBVDFvK) or [⁠Prism](https://prism.openai.com/) / [Discord](https://discord.com/invite/ffMZrSxUQa) - AI-Powered LaTeX Editors
* [⁠SimpleTex](https://simpletex.cn/) - Convert Images to LaTeX / Markdown
* [Learn LaTeX](https://www.learnlatex.org/) - LaTeX Guide
* [Tables Generator](https://www.tablesgenerator.com/) - Create LaTeX Tables
* [⁠TikZ Editor](https://tikz.dev/editor/) - LaTeX TikZ Diagram Editor / [GitHub](https://github.com/DominikPeters/tikz-editor)
* [LaTeX-OCR](https://lukas-blecher.github.io/LaTeX-OCR/) - Extract Mathematical Expressions
* [Detexify](https://detexify.kirelabs.org/classify.html) - Character Recognition

***

# ► Fonts

* ⭐ **[Nerd Fonts](https://www.nerdfonts.com/)** - Icon-Rich Developer / Terminal Fonts
* [OpenDyslexic](https://opendyslexic.org/) - Typeface for Dyslexia
* [Typewolf](https://www.typewolf.com/) or [Typ.io](https://typ.io/) - Trending Website Fonts
* [Cava's Pixel Resources](https://caveras.net/) - Pixel Fonts
* [Oldschool PC Fonts](https://int10h.org/oldschool-pc-fonts/) - Oldschool PC Fonts
* [FiraCode](https://github.com/tonsky/FiraCode), [Cascadia Code](https://github.com/microsoft/cascadia-code) or [Maple Font](https://github.com/subframe7536/Maple-font) - Monospace Fonts

***

## ▷ Open Source / Freeware

* ⭐ **[FontSource](https://fontsource.org/)** - Open Source
* ⭐ **[Font Squirrel](https://www.fontsquirrel.com/)** - Commercial Use
* ⭐ **[DaFont](https://www.dafont.com/)** - Freeware
* ⭐ **[1001 Fonts](https://www.1001fonts.com/)** - Freeware
* [Modern Fonts Stacks](https://modernfontstacks.com/) - Collection of CSS System Font Stacks
* [Velvetyne](https://velvetyne.fr/) - Open Source
* [uncut.wtf](https://uncut.wtf/) - Open Source
* [Beautiful Web Type](https://beautifulwebtype.com/) - Open Source
* [FontRepo](https://www.fontrepo.com/) - Open Source
* [Tunera Type Foundry](https://www.tunera.xyz/) - Open Source
* [Bunny Fonts](https://fonts.bunny.net/) - Open Source
* [Google Fonts](https://fonts.google.com/) - Commercial Use / [Self-Host](https://gwfh.mranftl.com/fonts) / [Privacy-Friendly API](https://fonts.coollabs.io/)
* [FontShare](https://fontshare.com/) - Commercial Use
* [OnlineWebFonts](https://www.onlinewebfonts.com/) - Commercial Use
* [Fontlot](https://fontlot.com/) - Freeware
* [Fontsly](https://fontsly.com/) - Freeware
* [FOSSFonts](https://fossfonts.com/) - Freeware
* [Fonts4Free](https://www.fonts4free.net/) - Freeware
* [FontSpace](https://www.fontspace.com/) - Freeware
* [Online Fonts](https://online-fonts.com/) - Freeware
* [CDNFonts](https://www.cdnfonts.com/) - Freeware
* [Fontesk](https://fontesk.com/) - Freeware
* [FontStruct](https://fontstruct.com/) - Freeware
* [iFonts](https://ifonts.xyz/) - Freeware
* [DownloadFonts](https://www.downloadfonts.io/) - Freeware
* [AbstractFonts](https://www.abstractfonts.com/) - Freeware
* [FontGet](https://www.fontget.com/) - Freeware
* [FreeFontsDownload](https://freefontsdownload.net/) - Freeware
* [Fonts2u](https://fonts2u.com/) - Freeware
* [Awwwards](https://www.awwwards.com/awwwards/collections/free-fonts/) - Freeware
* [GlukFonts](https://www.glukfonts.pl/fonts.php) - Freeware
* [Iconian](https://www.iconian.com/) - Freeware

***

## ▷ Free Fonts

* ⭐ **[Fonts CSE](https://cse.google.com/cse?cx=82154ebab193e493d)** - Multi-Site Font Search
* ⭐ **[Font Piracy 101](https://gist.github.com/Overimagine1/9f32e11b4c770fcd33374ad936a57d90)** - Font Download Guide
* ⭐ **[wFonts](https://wfonts.com/)**
* ⭐ **[BeFonts](https://befonts.com/)**
* [Free Fonts Family](https://freefontsfamily.com/)
* [Cufon Fonts](https://www.cufonfonts.com/)
* [⁠FontFreak](https://www.fontfreak.com/)
* [FontsFree](https://fontsfree.net)
* [DFonts](https://www.dfonts.org/)
* [⁠FontYukle](https://www.fontyukle.net/)
* [⁠Font.Download](https://font.download/)
* [Free Font Download](https://www.freefontdownload.org/)
* [Font Spring](https://www.fontspring.com/free)
* [⁠FontBolt](https://www.fontbolt.com/)
* [Best Font](https://best-font.com/)
* [FFonts](https://www.ffonts.net/)
* [⁠DaFontFree](https://www.dafontfree.co/)
* [FontsHub](https://fontshub.pro/)
* [Font Meme](https://fontmeme.com/)
* [FONToMASS](https://m.vk.com/topic-178186634_39300099?offset=0)
* [Mr.E-Fonts](https://archive.org/details/Mr.E-Fonts)
* [psd_fonts](https://vk.com/psd_fonts)
* [1001 Free Fonts](https://www.1001freefonts.com/)
* [⁠Famous Fonts](https://famfonts.com/)

***

# ► Font Tools

* ⭐ **[Font Interceptor](https://fontinterceptor.mschfmag.com/)** - Download Fonts from Websites
* ⭐ **[FontDrop](https://fontdrop.info/)** - Analyze Font Files
* ⭐ **[Font Analyzer](https://font-analyzer-six.vercel.app/)**, [Adobe Fonts](https://fonts.adobe.com/fonts/vs/upload), [Font Finder](https://www.whatfontis.com/), [WhatTheFont](https://www.myfonts.com/pages/whatthefont), [Identifont](http://www.identifont.com/) - Find Similar Fonts
* [⁠r/identifythisfont](https://www.reddit.com/r/identifythisfont/) - Font Identification Subreddit
* [Transfonter](https://transfonter.org/) - Create CSS @font-face Kits
* [FontBase](https://fontba.se/), [NexusFont](https://www.xiles.app/) or [Linux Font Manager](https://github.com/FontManager/font-manager) - Font Managers
* [Fonts Ninja](https://fonts.ninja/tools) or [WhatFont](https://whatfonttool.com/) - Find Similar Fonts / Extensions
* [Colors & Fonts](https://www.colorsandfonts.com/) - Typography Tools
* [DS-Fusion](https://ds-fusion.github.io/) - AI Typography Generator
* [Formito](https://formito.com/tools/logo) - Typography Logo Maker
* [Type Terms](https://avark.agency/typeterms/) - Typography Cheat Sheet
* [The Good Line-Height](https://thegoodlineheight.com/) - Typography Scaling Editor
* [⁠Hyperglot](https://hyperglot.rosettatype.com/) - Font Language Support Checker
* [So You Need A Typeface 2.0](https://ianli.github.io/so-you-need-a-typeface/) - Examples of Font Styles
* [Type Design Resources](https://typedesignresources.com/) or [Free Faces](https://www.freefaces.gallery/) - Typeface Resources

***

## ▷ Font / Text Generators

* ⭐ **[FontoGen](https://github.com/SerCeMan/fontogen)** or [⁠Refont](https://refont.ai/) - Custom AI Font Generators
* ⭐ **[Make WordArt](https://www.makewordart.com/)**, [TitleArt](https://titleart.dvy.io/), [FlameText](https://www.flamingtext.com/), [MakeText](https://maketext.io/), [TextGiraffe](https://www.textgiraffe.com/), [Text Pro](https://textpro.me/) or [CoolText](https://cooltext.com/) - WordArt Generators / 3D Text
* [Polona Typo](https://typo.polona.pl/en/) - Generate WordArt from Book, Poster, & Map Letters
* [⁠PixelFrame](https://pixelframe.design/) - Custom Pop Culture Font / Graphic Generator
* [⁠gradient text generator](https://lovewich.neocities.org/widgets/gradient-text), [Text Color Fader](https://patorjk.com/text-color-fader/) or [⁠Colorize FUN](https://colorize.fun/) - Rainbow Text Generator
* [Fast3DText](https://fast3dtext.com/), [TextDrom](https://en.textdrom.com/), [3DText2GIF](https://3dtext2gif.com/) or [TextStudio](https://www.textstudio.com/) - Animated / 3D Text Generators
* [Textanim](https://textanim.com/) or [Space Type Generator](https://spacetypegenerator.com/) - Animated Text Generators
* [Batname](https://batname.vercel.app/) - Batman (2022) Text Generator
* [NFG's Arcade Font Maker](https://nfggames.com/games/fontmaker/) or [Arcade Font Writer](https://arcade.photonstorm.com/) - Arcade Text Generators
* [The Ransomizer](https://www.ransomizer.com/) - Ransom Note Style Text
* [Glitch](https://glitchtextgenerator.com/) - Zalgo Text Generator

***

## ▷ Font Customization

* ⭐ **[TypeTrials](https://typetrials.com/)** - Variable Font Playground
* [V-Fonts](https://v-fonts.com/) or [Phase](https://www.eliashanzer.com/phase/) - Variable Fonts Testers
* [enFont](https://enfont-terrible.com/) or [Calligraphr](https://www.calligraphr.com/en/) - Custom Font Creators
* [Fontjoy](https://fontjoy.com/) - Generate Font Combinations
* [⁠Bastardica](https://bastardica.mitpit.com/) - Font Mixer
* [FontSprite](https://adamstrange.itch.io/fontsprite) - FontSprite Editor
* [BitFontMaker2](https://pentacom.jp/pentacom/bitfontmaker2/) - BitMap Font Editor
* [FontEdit](https://github.com/ayoy/fontedit), [metaflop](https://www.metaflop.com/), [MFEKglif](https://github.com/MFEK/glif), [Glyphr Studio](https://www.glyphrstudio.com/), [Birdfont](https://birdfont.org/), [Universal Sans](https://universalsans.com/) or [FontForge](https://fontforge.org/en-US/) / [GitHub](https://github.com/fontforge/fontforge) - Font / Typeface Editors

***

## ▷ Unicode Text Generators

* ⭐ **[YayText](https://yaytext.com/)**
* ⭐ **[Messletters](https://www.messletters.com/)**
* ⭐ **[FSymbols](https://fsymbols.com/generators/)**
* ⭐ **[Fancy Text](https://fancy-text.net/)**
* [Cool Fonts Online](https://coolfont.org/)
* [⁠Discord Fonts](https://discord-fonts.com/)
* [⁠Fonti](https://fonti.cool/)
* [Aesthetic Font Generator](https://www.tesms.net/)
* [FontGenOnline](https://fontgenonline.com/)
* [TextEditor](https://texteditor.com/)
* [CuteFontCopy](https://cutefontcopy.com/)
* [FontGenerator.design](https://fontgenerator.design/)
* [Font Generator Online](https://www.fontgeneratoronline.com/)
* [FontGenerator.cc](https://fontgenerator.cc/)
* [FontGen](https://fontgen.cool/)
* [FontGenerator.cool](https://fontgenerator.cool/)
* [Fancy Text Decorator](https://fancytextdecorator.com/)